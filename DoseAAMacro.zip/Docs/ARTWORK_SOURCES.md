# Akatsuki artwork — v2.7

Source: user-provided 31575.jpg inside 31575.zip, supplied for this dashboard. The file is bundled unchanged as Images/UI/DoseAkatsuki.jpg. No artist/source URL was supplied, and no ownership of the artwork is claimed by Dose.

Original format: JPEG, 1920x1080, 294599 bytes.

SHA-256: 14f7cab7c7a7a4b3bd0cb3ab3a8ea4651f0d53972fca59381be7d9fa98795735

The interface renders a full group banner and a separate Itachi/Pain close-up from this same original file. Cropping occurs at runtime; the bundled image bytes are not edited. No generated anime artwork or runtime network download is used.

Older theme artwork files are retained as inactive historical assets. Akatsuki is the only selectable theme.


# Faded Itachi wallpaper — v3.1

Source: user-provided download.webp inside download.zip, supplied for the background behind this dashboard. No artist/source URL was supplied, and no ownership of the artwork is claimed.

Original: WebP, 860x484, preserved unchanged as Images/UI/Originals/DoseItachiBackdrop.webp. SHA-256: f7fcf57b79d05699b920115a3bab48e9be632b87ef5f715eb1a874ff8ba8ccf5.

Images/UI/DoseItachiBackdrop.png is a Windows-compatible, lossless format conversion with identical decoded RGB pixels. Runtime crops share the existing 1800x930 dashboard canvas, with low opacity over dark surface colors. Decoration excludes the Roblox viewing rectangle and keeps existing control positions and settings. The original group banner/portrait asset is unchanged.


# Ethereal — v3.5

Existing artwork from Howl's Moving Castle (2004), Studio Ghibli. No AI-generated artwork is used. These are collected film scenery/poster images from the Ghibli Wallpapers reference collection, pinned at:
https://github.com/ChrolloKyber/ghibli-wallpapers/tree/39b6ced2a07a04b550ca5c2d6ef2bed8e4f90d11

Source files:
- Howl's Moving Castle/Howl'sMovingCastle05.png (film lake scenery), SHA-256 7e7ad1396d739eb4a837b40494c1a281b5d886c2cf323ab45cc2160b338c26df.
- Howl's Moving Castle/Howl'sMovingCastle08.png (existing Japanese poster), SHA-256 e66b02fa17a28c72c8a466fda79dd4b7b978803b4a8b91366bd229c9a74e7427.

Ordinary Lanczos downsampling and JPEG format conversion were used to keep the download small; no generative editing was used. Bundled assets:
- Images/UI/DoseEtherealLake.jpg, 1920x1080, SHA-256 cecbe654c0f2ac856c4eebebb6dcf27a3d6b5e240bf4c926e9aef1c6145395f7.
- Images/UI/DoseEtherealCastle.jpg, 1200x1689, SHA-256 72c2fefdb8d95cc33d99f5f32318422626e1efae5f0143869acd9bcc0a7efec4.

Film/poster rights remain with their respective owners. No ownership of that artwork is claimed by Dose. Rendering uses local assets and the existing cover-crop/fade helpers; no runtime network request is made. Akatsuki and Ethereal are now the selectable themes; earlier single-theme statements above describe earlier releases.
