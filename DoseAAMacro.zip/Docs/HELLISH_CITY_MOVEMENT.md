# Change Hellish City movement

This uses the existing Custom Map recorder; no movement source changes are needed.

1. Finish the current run/chest opening, stop the macro (F3 by default), and return to the lobby.
2. Select Dungeon and Confirm. If the Scheduler is enabled, turn it off before recording. Leave No Movement off if that option is shown.
3. Open Map movement in the left navigation. Select Hellish City in the Map dropdown and click Record.
4. Recording is armed for Hellish City, not a teleport to that map. The macro starts playing the confirmed mode normally and waits until Hellish City is detected.
5. Wait for the normal zoom/spawn setup and the message: "Recording - walk to the desired location, press G to stop recording".
6. Walk the route with W/A/S/D, Space and/or arrow keys, then press G. Recording saves automatically and the macro stops.
7. Enable Use custom movement for map, return to the lobby and start the macro again (F2 by default). Check the Process log to confirm custom movement is being used.

Keyboard input is recorded; mouse camera turns and clicks are not. Keep the starting camera orientation consistent. The recording is keyed by map name, so the Hellish City route is used in any mode that reaches that map while custom movement is enabled.

The Use custom movement for map switch enables all saved map recordings. Maps without a usable recording retain their built-in movement. The route is stored in Settings/CustomMovement/Hellish City.txt; re-recording keeps the previous file as .bak. The panel's Delete button removes the custom route and restores the built-in route, retaining a backup.
