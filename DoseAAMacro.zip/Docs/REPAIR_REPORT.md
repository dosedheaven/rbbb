# Dose AA Macro v3.7

The chest-opening engine is rewritten around a serial, owned session. Every successful Open input immediately creates a debt of two game-center clicks. It sends the first, waits two seconds, sends the second, and only then inspects the returned menu/counters. Menu headings, background zero counters, and Lobby/Enter labels cannot bypass the debt. Failed inputs remain owed across recovery or a new F2 start after the engine stops in the same app instance. F3 reload clears runtime tracking.

The old engine waited for the heading to disappear before claiming rewards, and its claim routine interpreted any Return to Lobby label as a token-overlay/top-click cue. These assumptions are removed. The old code reproduces the reported failure in the new visible-heading test: one Open, zero reward clicks. The native overlay regression leaves the real heading and Lobby label visible throughout both rewards, and the rewritten engine sends only Open/center/center, repeats, then one Continue.

A returned chest menu requires its heading AND the dedicated Continue reference in the bottom button region. Both Common and Rare zero references remain exact and must be confirmed together over three seconds and at least three samples. The session stays locked until the dedicated, freshly matched Continue click actually closes the menu. The chest engine never calls legacy finish, token-overlay, lobby or Enter Dungeon click paths.

Entrance, route and legacy finish/Continue paths refuse while the session is locked. Start/finish dispatchers resume pending chest work before their normal setup/replay clicks. A due schedule or Auto Challenge trip is deferred at the final boss until rewards are handled; ordinary-floor Challenge/schedule behavior is preserved.

The existing two-minute chest recovery interval, two rescan attempts, 15-minute total budget, per-row 200-Open cap and 60-second/40-center-input claim bounds are retained. The old heading-disappearance/stalled-open heuristic no longer controls claiming. Unknown/blocked screens or an unclosed Continue stop with the session locked instead of falling back to another dungeon. Extra/late rewards can require additional bounded center pairs.

No UI, shop item policies (including Axe/Headsplitter), settings format, movement, rare/future room ranking, shrine/curse choices, artwork or window calibration changes are included. Copy your old Settings folder beside Main.ahk before launching. Main stays at ZIP root and documentation stays under Docs.

Verification includes actual serial engine/wrappers, real native header/Continue/Lobby capture and input conversion, actual entry/legacy locks, start/end dispatcher tests, the full real two-minute recovery interval and previous entrance/recovery/shop/config regressions. Game rewards, inventory and input effects are simulated. No live Roblox validation is claimed.
