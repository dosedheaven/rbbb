# Dose AA Macro v4.1 — core and console rebuild

This release replaces lifecycle/result handling and the operator UI while keeping the tested mode-specific game routines, image references and saved settings formats. It is not a replacement game client or a claim that every legacy gameplay primitive was rewritten.

## Reported freeze and the replacement

The v4.0 upgrade loop could recognize a Return screen without XP and hand it to a monitor that waited for XP. The old monitor also repeatedly clicked the leaderboard area. This reproduced with Auto Challenge enabled and disabled, explaining the missing result webhook without blaming the half-hour scheduler.

Placement, upgrades and monitoring now share one read-only results observer and one results controller. Both Return variants use the same broad search region. Verified outcomes are recorded once per active stage; a webhook failure cannot strand navigation. Unknown outcomes are explicitly logged without inventing a defeat or sending a fabricated result webhook. Once recorded, an outcome cannot change under the navigation adapter.

The controller owns result dismissal and bounded retries. Mode navigation sends its specific Next/Replay/Return action only after navigation evidence. The generic and Dungeon adapters no longer blindly click the screen while waiting. Story Next Level reads the recorded outcome, and Story Infinity Return to Lobby waits for the lobby instead of immediately starting map detection there.

## Other rebuilt boundaries

- Shared bounded navigation separates match output variables from explicit action coordinates (AHK names are case-insensitive). Natural matches use validated game-window conversion; fixed points and legacy offsets retain their documented semantics.
- One session records phase, stage/profile identity, progress and recovery attempts. A step returning without a handoff reconciles the screen; it cannot silently end the run. Errors and recovery-policy stops are contained and logged.
- One connection service observes disconnects, confirms them twice and owns bounded server launches. Existing saved server-link behavior is retained. No server switch is permitted while chest reward work is pending.
- Chest opening owns the screen exclusively: Open, center click, two seconds, second center click, verify, repeat. A local atomic checkpoint preserves owed dismissals and boss-exit status across reload. Both chest types must be positively empty before Continue can release ownership.
- Pause suspends active transition clocks. During movement it is queued until movement keys are released; results and named deadlines shift on resume. Intentional long combat waits do not acquire a global two-minute reset.
- Cursed Festival camera branching requires consecutive samples. Strange Town now includes Dungeon in its built-in movement branch. Existing distances/durations and all other built-in routes remain; custom recordings still take precedence. All movement keys release on completion/error/exit.
- The console has vertical navigation, six unit cards, visible run controls, anime artwork and live phase/profile/progress. The original game window size, capture hole, coordinates and image catalog are retained. Panel/profile visibility changes are batched to prevent repaint storms.
- Save uses a complete temporary configuration file before replacement. The first save makes a one-time full Settings backup when an existing Configuration.txt is present. Existing saved values are not reset by the UI rebuild.

## Preserved policies

Current rare chests, tied-room ranking, future-rare routing, configured curses/shrines, green OPEN/boss/single/double/triple layouts, dynamic shop compaction and known item exclusions retain their existing decision policies. Auto Challenge remains solo and uses its separate Challenge unit profile; it becomes due thirty minutes after completion and waits for the current floor and pending boss rewards. All six unit profiles, recording/import/export, scheduler/team swapping, settings and Debug/Guide panels remain accessible. Akatsuki and Ethereal reuse bundled anime images/fonts; no generated art or runtime artwork download is added.

The existing limitation remains: Aures Maul and Solar Cleaver have no captured shop references and are not recognized exclusions. Axe and Headsplitter are the supported remembered exclusions. See SHOP_REPAIR.md.

## Verification and limits

Current results are recorded in Tests/Rebuild/Verification and Tests/Rebuild/VERIFICATION.md; older release records are explicitly under Tests/History. Tests use actual AutoHotkey v2 production functions, native reference windows and isolated settings, with simulated game transitions and network/input effects. No test sends a live webhook, joins Roblox or reads private configuration/log contents. UI checks cover native clicks, six-profile settings round trips, map lists and font bounds at multiple display scales.

This cannot guarantee a three-hour live Roblox run, server response, map physics, recognition after a game update or webhook delivery. Result deduplication is per active app stage, not a cross-process/network exactly-once guarantee. Unrecognized or obscured screens may stop safely with local diagnostics instead of choosing a guessed room or abandoning possible rewards. A live supervised run remains the next end-to-end check.

Main.ahk is first at ZIP root; Docs contains the guides. Copy the entire old Settings folder into the new installation before launching. Keep v4.0 separately as rollback.
