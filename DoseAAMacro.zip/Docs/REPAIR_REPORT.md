# Dose AA Macro v3.6

Headsplitter is added to the shop's never-buy list alongside Axe. Both use the same existing remembered exclusions: detected items remain excluded as confirmed purchases compact/reposition the rows, even if later icon scans miss them. Golden Fishhook then Fishhook remain the first purchase priorities; other eligible items retain their existing purchase/retry/Continue behavior.

The supplied transparent 80x80 PNG is preserved unchanged at Images/Shop/Headsplitter.png. The detector uses opaque artwork color points, ignoring the transparent background and disconnected crop border, with fourteen reference variants for 28–40 pixel shop icons (nearest and bilinear sampling). These variants accommodate the larger supplied buff icon; the source image has not been verified against a live shop screenshot. Screens/input in tests are simulated.

No changes to the exclusion-memory algorithm, purchase positions/timing/limits, UI/themes, settings/persistence, movement, room/rare/future routing, shrines/curses, chest-saving/opening/paired reward clicks or boss/lobby recovery are included. Only the item recognizer, shop log descriptions and release metadata change in the application. Aures Maul and Solar Cleaver still lack captured references and are not blocked.

Main.ahk remains at ZIP root; informational pages are under Docs. Copy your entire old Settings folder beside Main.ahk before launch to preserve your saved configuration. The format is unchanged; private Settings/Logs are not included in the release.

Native shop-image, row-reflow/memory and regression results are recorded under Tests. Live Roblox matching still needs confirmation.
