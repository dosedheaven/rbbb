# Dose AA Macro v3.9

Auto Challenge now explicitly detects and clicks the green Start button after Play Now. The supplied screenshot has a separate Start/Cancel queue. The previous shared Story routine used an older Start reference and a vertical click offset; its departure helper could also mistake this queue for loading when the old menu/Areas markers were absent.

Challenge now has its own short Play Now step, retaining the known client points for the existing opener and solo choice. It polls for Start immediately after that choice, using Start lettering captured from the supplied screenshot and the existing older reference as a fallback. Each Start click uses a fresh detection at the actual matched center, without the shared routine's -35 offset or trailing solo click. A queue already open skips walking and Play Now.

The default polling interval is 250 ms. An unchanged Start button gets at most three attempts, at least 1.5 seconds apart, within the existing 45-second departure budget. Cancel and Matchmake are never selected as fallbacks. Blank frames between Play Now and Start cannot establish departure: two missing-menu/Areas samples are accepted only after a Start click. A positive in-map vote screen can still confirm a stage that auto-started. Failed or unreadable launches stop without the map-loading handoff.

Only Challenge startup, its added image reference and version metadata change in the application. The shared Story/Legend/Raid starters, Challenge movement, Auto Challenge timing, Dungeon chest engine/locks, shop, room routing, UI, calibration and settings are byte-identical to v3.8.

Validation: 26 controller assertions, 15 native-window assertions using the supplied Start/Cancel pixels, 14 configuration/default assertions and 91 Python reliability tests pass. Native checks cover shifted Start text, pre-open queues, retry limits and Cancel rejection. An old-version baseline demonstrates premature departure with the supplied Start button still visible. Inputs and game transitions are simulated; these checks do not establish a live Roblox launch.

Main.ahk remains first at ZIP root; documentation stays under Docs. Only cropped button fixtures are included, not the full screenshot. Copy the entire old Settings folder beside Main.ahk before launching. No private Settings/Logs are included.
