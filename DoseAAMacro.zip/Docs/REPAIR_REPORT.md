# Dose AA Macro v3.5

Chest reward claiming now clicks the center of the actual Roblox client area twice, with a two-second interval. The second click is still sent if a single reward already exposed the chest menu, before the existing stable-menu/empty-counter checks permit another chest or Continue. Extra rewards retain bounded retry pairs. Open button positions, chest-saving rules, strict joint Common/Rare empty verification, overlay checks, inactivity recovery and boss/lobby recovery remain intact.

Axe exclusions are collected before any purchases, kept for the shop visit, and shifted with the remaining cards when a confirmed purchase removes a row. Failed later icon matches cannot clear a known exclusion. Each purchase still rescans, and the icon search region accommodates post-purchase offsets. Unexpected row-count changes with a remembered Axe conservatively skip remaining offers rather than guessing the excluded item. Purchase priority remains Golden Fishhook, Fishhook, then other eligible items bottom to top.

Ethereal is a second selectable theme with existing Howl's Moving Castle artwork, a blue/mint palette and faded scenery. No generated art is used. Akatsuki remains available. Saved supported themes are preserved; new installations default to Ethereal. Select Settings > Anime Theme > Ethereal and restart to apply it to an existing installation. Main controls, feature callbacks, game viewport and calibration are unchanged.

The ZIP now has Main.ahk directly at its top level; informational Markdown pages are under Docs. Lib, Images, Tests and the empty Settings/Logs folders remain beside Main, preserving runtime paths. Copy your entire old Settings folder beside the new Main.ahk before launching. No configuration migration or private settings inclusion is performed.

See Tests verification records for executed regression tests. Screens and game input are simulated; live Roblox/server behavior remains to be confirmed. No changes to room/rare/future routing, movement, shrines, avoided curses or the unsupported Aures Maul/Headsplitter/Solar Cleaver exclusions are included.
