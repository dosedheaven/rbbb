# Dose AA Macro v3.8

Auto Challenge now explicitly selects Play Now/solo after reaching the Challenge area. The old ChallengeMode walked to the queue and immediately handed off to map loading without calling the shared solo action. The new flow reuses the unchanged PlayHere routine used by the other modes. It never calls FindMatch or inherits another mode's Matchmaking checkbox.

The Challenge entry recognizes either the existing Cancel marker or the existing Matchmaking text reference in the choice popup. If the menu is already present, movement is skipped. Otherwise the original ChallengeMovement runs once; the code then waits up to 30 seconds for a menu, rather than repeatedly holding A while a popup may be open.

After the shared solo routine returns, a positive vote screen or two consecutive samples with no menu/Areas indicator confirm departure. If the menu remains or the window is unreadable, there is no map-loading handoff. The departure check has a 45-second default budget; the shared routine retains its existing internal clicks/waits. The entrance guard is cleared when this flow exits.

Pending boss chests still block Challenge. The half-hour Auto Challenge timing, return to selected mode, Challenge unit profile, shared Story/Legend/Raid play/matchmaking routines, Dungeon chest engine, shop exclusions, UI/themes, settings format and calibration are unchanged.

Tests execute the actual Challenge helpers and unchanged shared solo routine. Native tests use real Cancel/Matchmaking/Areas reference pixels and a synthetic window; game transitions and clicks are simulated. Live Challenge-menu matching still needs confirmation.

Main.ahk remains at ZIP root and informational pages stay under Docs. Copy the entire old Settings folder beside Main.ahk before launching. No private Settings/Logs are included.
