# Dose AA Macro v4.0

Auto Challenge now recognizes the current Join Matchmaking popup with Play Here and Find Match tiles. The v3.9 entry detector only knew older Cancel/Matchmaking references and the later Start screen; it missed the supplied current choice popup, so it could report menu not found even while Play Here was visible.

A Challenge-only Play Here text reference is captured from the supplied screenshot. Both entry recognition and solo selection check this reference. If it is already visible, Challenge skips movement and the old opener click, then clicks the detected Play Here center. It also checks for the new popup after using an older queue opener. Matching follows the menu within its search region instead of assuming the old solo click point. A Find Match tile alone is not accepted as the solo button. Existing older choice references remain supported.

The separate Start detection from v3.9 remains: fresh matched Start center, at most three attempts spaced at least 1.5 seconds, and no absence-only loading confirmation before a Start click. Positive in-map vote UI can still confirm an auto-started stage. Cancel and Find Match are never fallback actions.

Only Challenge entry/solo recognition, its added image reference and version metadata change in the application. The Start/departure logic, shared Story/Legend/Raid starters, Challenge movement, Auto Challenge timer, chest engine/locks, shop, room routing, UI, settings and calibration remain byte-identical to v3.9.

Validation: 32 controller assertions, 21 native-window assertions using supplied current-menu and Start/Cancel pixels, 14 defaults/configuration assertions and 91 Python reliability tests pass. The native checks include a shifted current menu and Find Match negative detection. An actual v3.9 detector baseline rejects the same supplied current-menu pixels that v4.0 recognizes. Input effects/game transitions are simulated; a live Roblox run remains necessary to confirm end-to-end behavior.

Main.ahk remains first at ZIP root; documentation stays under Docs. Only cropped UI fixtures are included, not the full screenshot. Copy the entire old Settings folder beside Main.ahk before launching. No private Settings/Logs are included.
