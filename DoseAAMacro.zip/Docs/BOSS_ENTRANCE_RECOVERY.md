# Post-boss entrance recovery — v2.8

This recovery is armed only after the boss chest-opening pass positively confirms that both Common and Rare chest counters are empty. Failed/incomplete opening and intermediate saved-chest screens do not arm it. A new unverified boss chest pass clears any stale authorization first.

The macro first tries the usual Enter Dungeon flow. In the armed post-boss case it allows five Enter attempts, then continues observing for a route. If the Enter screen stays unchanged for 30 seconds from the first attempt, it tries the lobby workaround. A route appearing before recovery is confirmed normally; the lobby detour is skipped. Death Continue is handled separately from the five Enter attempts.

Recovery identifies the existing dungeon X, clicks its fresh matched point and verifies that the dungeon menu closed. It then identifies Return to Lobby using the existing two reference patterns. It waits for two consecutive lobby detections before resetting recovery state and handing off to the existing CheckLobby/start-selected-mode flow. The normal dungeon-entry routine reopens the menu from the lobby.

Normal startup retains its existing six-attempt/45-second entrance behavior. Recovery is limited to one attempt per verified boss completion, with at most three X clicks and three Return to Lobby clicks. Menu closure and lobby arrival each have bounded waits. Missing/obscured controls or an unknown confirmation screen receive no guessed input. If recovery fails, the log explains where it stopped; later callers do not get another Enter retry budget for that unresolved completion.

The macro uses the existing image patterns and calibrated window-aware input helpers. No new button coordinates or UI changes are introduced. If your live Return to Lobby/confirmation screen differs from these references, supply that screen so its detection can be updated. The native tests use synthetic exact-pattern windows and simulated game transitions, not a live Roblox server.

Relevant log entries include: “Boss chests confirmed empty”, “Post-boss Enter Dungeon unchanged”, “dungeon menu confirmed closed”, and “lobby confirmed”. A click alone never proves that the return or restart succeeded.


This decision policy is retained in v4.1. The rebuilt lifecycle, pause-aware timing, persistence and console are described in REPAIR_REPORT.md and ARCHITECTURE.md.
