# Update to v4.1 without losing your settings

1. Save in the old version and close it.
2. Extract DoseAAMacro.zip into a new folder. Main.ahk is at its top level, beside Lib, Images, Docs and Settings.
3. Copy the ENTIRE old Settings folder into the new folder beside Main.ahk. Include subfolders, recordings, profiles, schedules, theme and private-server/webhook settings. In very old releases it is inside Anime Adventures (Framework).
4. Launch the new Main.ahk with AutoHotkey v2. Check your selected mode and unit profile, position Roblox with F1 and start with F2 or Start run. Auto Challenge still uses the separate Challenge profile.

The v4.0 to v4.1 configuration keys and six profile field names are unchanged. Copying only Configuration.txt omits settings stored elsewhere. Do not copy old Main.ahk or Lib files over the new release; that restores old code. Release ZIPs contain empty Settings/Logs folders, never private configuration or logs.

The first v4.1 save with an existing Configuration.txt copies the entire Settings folder to Backups/Settings-before-4.1. This one-time backup is not overwritten by later saves. Configuration.txt is replaced only after a complete temporary file is written. Keep the previous installation as well.

Settings/RuntimeChest.ini records unfinished chest work. F3/Stop now preserves this checkpoint. Start restores it only with a matching chest menu or a same-process pending reward phase; an unrelated/unknown screen stops with an explanation. Do not delete the checkpoint just to bypass pending rewards. If it cannot be matched, reopen the chest screen for that run before starting again. A failed game process/rejoin may make such work unrecoverable; no matching screen is invented.

Supported saved themes remain selected. Fresh installs default to Ethereal; Akatsuki is available in Settings > Anime Theme. Theme selection still takes effect after restart. Both use existing bundled anime artwork.

The console is 1800x930 physical pixels. A 1920x1080 display is recommended. UI font/control checks cover 100%, 125% and 150% scaling; in-game image recognition still requires the macro's configured Roblox size and consistent game UI. See the in-app Guide.
