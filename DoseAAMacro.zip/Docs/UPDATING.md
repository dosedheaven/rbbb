# Keep your settings when updating

1. Click Save in the old version and close it.
2. Extract the new DoseAAMacro.zip into a new folder. Starting with v3.5, Main.ahk is directly inside the extracted folder, beside Lib, Images and Docs.
3. Copy the ENTIRE old Settings folder into that new folder, beside Main.ahk. Include its subfolders and merge/replace files if Windows asks. In older releases, the old Settings folder is inside Anime Adventures (Framework).
4. Launch the new Main.ahk and check your saved options.

The v3.8 to v3.9 configuration format is unchanged. The full folder preserves configuration, profiles, Dungeon priorities/avoided choices and their existing preset marker, custom placements, custom movement, keybinds, schedules and other saved options. Copying only Configuration.txt misses settings held elsewhere. Keep the old installation as a backup.

A saved Akatsuki theme remains Akatsuki. To use the new art, choose Settings > Anime Theme > Ethereal, then restart. New installations without saved theme settings default to Ethereal.

Do not copy old Lib or Main.ahk over the new release. That restores old program code. Release ZIPs include empty Settings/Logs directories, never your private configuration or logs.

For future releases use the same process unless the release explicitly documents a migration.
