# Control Room console — v4.1

The 1800x930 console separates the game, navigation, configuration and anime artwork. The physical Roblox viewing rectangle remains x3/y33/w797/h597, with an outer 816x638 game window at offsets -5/+1. The larger macro window does not resize the game capture region.

Vertical navigation opens Unit profiles, Settings, Placement, Map movement, Scheduler, Detection, Guide and Adaptations. The workspace keeps all six original unit profiles and mode-specific options. Start run, Pause/Resume and Stop are visible below the game; the original configurable F1-F4 hotkeys remain.

The artwork rail uses the existing Akatsuki or Ethereal images and matching colors. Text uses a readable UI font; themed display fonts are limited to artwork headings. Rounded cards replace decorative lines across labels. Native map dropdown arrows and scrolling lists remain functional.

Running locks configuration widgets so their input cannot interrupt automation. Pause allows editing; the active stage retains its snapped unit-profile identity, while changes to that profile's settings can take effect. During a map walk, Pause queues until keys release. Change restores mode selection only while stopped. Stop/F3 reloads the app and preserves the chest checkpoint.

Live session status shows the phase, detected map, active profile and latest action. Auto Challenge shows its local completion-based countdown. Session activity retains the Open log action. A mode change and profile browsing never implicitly replaces saved profile values.

Panel/profile changes update only controls whose visibility actually changes and batch painting. Console refresh changes text/enabled state only when necessary. The native UI audit exercises actual coordinate checkbox clicks, map-list scrolling, all modes, panels, six-profile save/load and text metrics. See Tests/Rebuild/VERIFICATION.md for tested scale/theme combinations; a native Windows desktop and live Roblox are still required for final acceptance.
