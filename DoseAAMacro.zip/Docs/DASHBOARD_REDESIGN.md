# Akatsuki dashboard — v2.7

The wider 1800x930 layout separates Roblox, controls and artwork. It targets the macro's recommended 1920x1080 display at 100% Windows scaling. Roblox retains its original 797x597 viewing rectangle, 816x638 window size and click offsets.

The left column contains Roblox, activity and session switches. The middle column has navigation, two columns of three unit cards, mode selection, profile/adaptation settings and all context options. The right column displays the complete supplied group image above an Itachi/Pain portrait crop. Rounded surfaces and angled window corners replace the old decorative lines.

Akatsuki is the only theme. Older saved theme names fall back to Akatsuki. Configuration files, profiles, callbacks, game behavior and detector code retain their existing implementation. A separate presentation module repositions the existing controls after configuration loading. No game coordinates or settings formats change.

Native AutoHotkey preview checks cover actual save/load of synthetic values across all six unit profiles, profile navigation, every mode's visible context controls, Settings, Advanced, Debug, Scheduler, Card Picker, movement/placement panels, five Guide pages, font metrics, bundled artwork and viewport geometry. The original image is bundled unchanged and both crops are rendered at runtime. Tests use Wine with a Segoe UI substitute and synthetic game/service hooks; live Roblox and other display-scale combinations have not been exercised. See Tests/AutoHotkey_Dashboard_Verification.txt and Tests/UI_Layout_Verification.md.

Copy your existing Settings folder into the extracted update before starting it. This archive excludes personal settings and logs. The window title and startup log show the current release number from VERSION.txt.
