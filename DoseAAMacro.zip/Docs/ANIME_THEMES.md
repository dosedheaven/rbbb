# Anime themes — v4.1

Choose Settings > Anime Theme > Akatsuki or Ethereal. The existing theme-save/restart behavior is retained, including saving for the next launch when the macro is active. Existing supported selections are preserved; fresh installations default to Ethereal.

Ethereal uses existing Howl's Moving Castle scenery/poster artwork with mist-blue controls, mint highlights and faded lake scenery in the console artwork panels. No generated artwork or runtime network download is used. Akatsuki retains the supplied group image and portrait artwork.

Theme changes affect decorative artwork, palette and the artwork caption font. Unit controls, checkboxes, movement/placement selectors, panel callbacks, settings formats and the Roblox viewport/calibration remain unchanged. The application stays 1800x930, with the existing Roblox outer size 816x638 and viewing area x3/y33/w797/h597.

Source and image-conversion information is in ARTWORK_SOURCES.md.
