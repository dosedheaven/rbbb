# Architecture and operation — v4.1

Main.ahk composes the engine and the retained feature adapters. MacroLoop runs one handoff at a time, unwinding the previous step through MacroNextStep. There is no parallel background controller issuing game actions.

| Module | Owns | Delegates |
| --- | --- | --- |
| Engine/Session | stage identity, phase, immutable recorded result, bounded policy, trace | no game input |
| Engine/Results | shared observation, stage-result transaction, result dismissal, reconciliation | mode-specific navigation, chest owner, existing webhook sender |
| Engine/DungeonScreens | foreground Shop/Shrine and stable route/entry reconciliation | existing room/special-screen policies |
| DungeonChestOpening | serial Open/center/pause/center, zero proof, exclusive chest lock | calibrated window input and local checkpoint |
| Engine/Persistence | stage profile identity, one-time Settings backup, atomic chest checkpoint | saved field names remain compatible |
| Engine/Movement | preparation, stable angle sampling, key release | existing/custom map routes |
| Engine/Pause | pause state, active-time clock, movement checkpoint | named timer shifting and native AHK pause |
| Engine/ChallengeSchedule | one eligibility calculation | existing solo-entry and mode-return adapters |
| Engine/Connection | disconnect confirmation and bounded server recovery | saved server launch and verified lobby |
| GuiDashboard / GuiPanels / GuiStyle | presentation, event wiring, panel/profile visibility, console refresh | existing controls/settings models |

The diagram describes ownership rather than a separate timer running each box. Results observation is read-only. Results dismissal never runs while chest ownership or a foreground Dungeon menu is confirmed. Mode adapters retain settings-specific decisions such as Story Next Level, Replay and Return to Lobby. There are still legacy mode-specific game primitives; this is a rebuilt lifecycle and UI around retained/tested feature adapters, not a claim of a new implementation for every skill/map/mode.

A verified stage result is counted and claims its webhook attempt before external sending. An exception is logged and navigation continues. This prevents duplicate attempts during an in-process handoff; it cannot prove network delivery or deduplicate across an app restart. Unknown results preserve progress without inventing statistics.

Results have a 45-second budget and two ten-second rescans. A fresh positively recognized navigation screen can complete even if an old watchdog deadline has elapsed. Ordinary recovery has a bounded retry count; recognized-but-unselectable routes cannot reconcile indefinitely. Existing configurable entrance/load/vote/end/stage guards remain. Intentional open-ended combat waits are not reset by a general two-minute idle rule.

Chest recovery's two-minute interval remains inside the chest owner. A pending pair prevents zero reads, another Open, Continue, entry and server switching. After both types have stable empty proof, a fresh Continue click must close the menu before ownership releases. RuntimeChest.ini preserves debt before Open, after dismissals and after verified closure. Reload restoration is conservative and requires matching screen/process evidence; it does not resurrect rewards lost on a disconnected server.

Movement follows spawn reset/settling. Cursed Festival and Strange Town require three consistent angle samples. Existing map durations remain. Custom map routes and No Movement keep their precedence. A movement pause is queued so held keys are released before native pause stops the worker.

SessionTrace.tsv rotates at two MiB, retaining one previous trace. Failures can rotate up to three game-client-only BMP captures under Logs/Diagnostics. Diagnostic capture itself does not upload them. Existing webhook/screenshot behavior remains controlled by the original sender/settings.

Tests use actual production bodies with explicit external-boundary adapters. Native fixtures test real matching/client conversion while simulating game state and input effects. They are a regression gate, not a live Roblox certification. See Tests/Rebuild/VERIFICATION.md.
