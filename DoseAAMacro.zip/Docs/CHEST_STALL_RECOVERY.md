# Serial boss chest opening — v4.1

Sequence: Open one chest; wait for its opening animation; send one click to the center of Roblox's actual client area; wait two seconds; send the second center click; confirm the complete chest menu; repeat. A one-item chest still receives the harmless second center click. Additional rewards can trigger more bounded pairs.

A session records each owed click before looking for zero counters. It never requires the chest heading to disappear: the heading can remain behind rewards. Return to Lobby/Enter labels behind a reward are ignored for reward dismissal. No top-screen token-overlay or finish clicks are used by this engine.

After the pair, the heading and the specific Continue button in the calibrated bottom region must be present continuously for three seconds. The Continue text matcher allows 3% error; the Common/Rare zero references remain at 0.000001 tolerances. Both zero references must be confirmed together for three seconds and at least three samples. The exit is one freshly detected Continue click, followed by verified menu closure. An unresponsive Continue never triggers a finish/Enter/lobby fallback.

Until closure, startup/room/finish/entrance recovery paths are locked. After an engine stop, a new F2 start in the same app instance resumes pending chest clicks before the ordinary setup clicks. F3 reload preserves an atomic Settings/RuntimeChest.ini checkpoint. Start reconciles it with the current screen before resuming; a verified empty exit retains its boss-recovery authorization. At the boss, pending Challenge/schedule trips wait for rewards; ordinary-floor behavior is unchanged.

Recovery remains local to the chest session: two-minute inactivity interval, two rescans, and a 15-minute total budget. Unknown screens are not guessed. Refused clicks remain owed; exhaustion leaves entry locked. The per-row 200-Open limit and per-claim 60-second/40-center-input bounds remain in place. The obsolete requirement for a disappearing heading is removed.

Tests reproduce the old one-Open/zero-dismissal failure, keep actual native heading/Lobby pixels visible behind a reward overlay, refuse second clicks and resume them, cover Continue, leave background zeros visible, exercise all entry/legacy locks, and run the production two-minute recovery timing. Screens/rewards/inventory/input effects are simulated; live Roblox still needs confirmation.


Chest/entrance/recovery clocks now exclude paused time. The two-minute interval belongs only to this chest session; it never resets normal combat, loading or another deliberate wait. General results/reconnect code cannot dismiss a chest reward or switch servers while the chest lock is held. Checkpoint writes happen before Open and after dismissals/verified exit; a process crash between input and disk write can conservatively leave an extra dismissal owed, which is why matching the current screen remains required.
