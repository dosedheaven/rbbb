# Chest rewards and recovery — v3.5

For an observed Open-to-reward transition, the macro sends two clicks to the center of Roblox's actual client area, separated by two seconds. The pair completes even when the first click reveals the menu after a one-item chest. The middle of the wider dashboard is never used. Extra reward screens can trigger more bounded pairs. The claim loop retains its 60-second limit and 40-click cap; refused input or unreadable windows cannot unlock Continue.

Only after the pair completes can the menu qualify as returned: it must remain visible for three seconds. Before Continue, both Common and Rare empty-counter references must be visible together for three consecutive samples and three stable seconds. Stored zero counts alone never skip pending rewards. Saving chests for the boss retains its existing option behavior.

The chest-only inactivity recovery remains 120 seconds with two rescan attempts under the existing 15-minute total deadline. It does not replace other modes' movement, loading, shop, shrine or entrance waits. Post-boss lobby recovery is still armed only after the full verified chest drain. This update changes reward input position/sequence, not that supervisor or its limits.

Tests use synthetic game states with actual native client-coordinate conversion and real two-second timing. Live Roblox reward screens still need user confirmation.
