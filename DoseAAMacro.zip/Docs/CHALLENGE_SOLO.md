# Auto Challenge solo start — v3.9

Keep your farming mode selected and enable Auto Challenge. Use the Challenge placement profile for its units/upgrades.

After the original movement, the macro opens the existing choice menu, chooses Play Now/solo, detects the separate green Start button and clicks its matched center. It checks immediately after Play Now rather than waiting through the shared Story starter. If the Start queue is already visible it skips movement and Play Now. The supplied Start lettering and the existing older Start reference are both supported.

Start is retried at most three times, at least 1.5 seconds apart, within the 45-second departure budget. It never falls back to Cancel or Matchmake. Missing menu/Areas markers establish departure only after Start has been clicked; a positive in-map vote screen also confirms departure. Brief blank frames before Start appears cannot trigger map loading.

The half-hour local timer, return to the selected mode, pending-boss-chest priority, original movement and other modes' shared starters are unchanged. The shared Matchmaking checkbox does not control Challenge.

Tests use the actual production controller and detection against the supplied Start/Cancel pixels in a native test window. Game transitions and input effects are simulated; live Roblox matching still needs confirmation. Only cropped UI fixtures are bundled.
