# Auto Challenge solo start — v4.0

Keep your farming mode selected and enable Auto Challenge. Use the Challenge placement profile for its units/upgrades.

After the original movement, Challenge detects the current Play Here / Find Match menu and clicks the matched Play Here lettering to choose solo. If that popup is already open it skips movement and the older opener. A shifted menu is handled by detecting the button position. The prior older choice layout remains supported. Find Match is never selected.

Next it detects the separate green Start button and clicks its matched center. A Start queue already visible skips Play Here as well. Start is retried at most three times, at least 1.5 seconds apart, within the 45-second departure budget. It never falls back to Cancel or matchmaking. Missing menu/Areas markers establish departure only after Start has been clicked; a positive in-map vote screen also confirms departure. Brief blank frames before Start appears cannot trigger map loading.

The half-hour local timer, return to the selected mode, pending-boss-chest priority, original movement, and other modes' shared starters are unchanged. Another mode's Matchmaking checkbox does not control Challenge.

Tests use the actual production controller and detection against the supplied current menu and Start/Cancel pixels in a native test window. Game transitions/input effects are simulated; live Roblox matching still needs confirmation. Only cropped UI fixtures are bundled.
