# Auto Challenge solo start — v3.8

Leave your farming mode selected and enable Auto Challenge. Set up the Challenge placement profile for the units/upgrades you want during Challenge runs.

Challenge now walks the existing route once, recognizes the area/choice menu, calls the same PlayHere (Play Now/solo) routine used by other modes, verifies departure, and then hands control to the existing map loading/placement flow. The A movement itself and its seven-second hold are unchanged.

If the menu is already open, it does not walk out of it. It accepts the existing Cancel or Matchmaking-text reference as entry evidence, but never chooses Matchmake. The hidden/shared Matchmaking checkbox does not control Challenge. After the shared solo routine returns, the transition must show a vote screen or two consecutive missing menu/Areas samples before map loading starts. A menu that remains open produces an explicit stopped/unconfirmed message.

The 30-minute local timer and return-to-selected-mode behavior are unchanged. A due Challenge can depart after an ordinary Dungeon floor, but final-boss chest opening retains priority until its verified exit. Other modes keep their existing play/matchmaking behavior.

The shared UI coordinates and references are reused, without a new screenshot-derived calibration. Native test windows confirm the references and input order, not a live Roblox session. If the actual Challenge choice layout differs from the other modes, its normal-size menu screenshot is needed to adjust the Challenge-only handling.
