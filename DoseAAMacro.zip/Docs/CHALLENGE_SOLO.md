# Auto Challenge solo start — v4.1

Keep your farming mode selected and enable Auto Challenge. An enabled fresh app session retains the existing immediate-Challenge behavior; later repeats use the completion-based local timer. Use the Challenge placement profile for its units/upgrades.

After the original movement, Challenge detects the current Play Here / Find Match menu and clicks the matched Play Here lettering to choose solo. If that popup is already open it skips movement and the older opener. A shifted menu is handled by detecting the button position. The prior older choice layout remains supported. Find Match is never selected.

Next it detects the separate green Start button and clicks its matched center. A Start queue already visible skips Play Here as well. Start is retried at most three times, at least 1.5 seconds apart, within the 45-second departure budget. It never falls back to Cancel or matchmaking. Missing menu/Areas markers establish departure only after Start has been clicked; a positive in-map vote screen also confirms departure. Brief blank frames before Start appears cannot trigger map loading.

One shared eligibility rule makes Challenge due thirty minutes after its completion. It switches after an ordinary floor, and checks again at a verified lobby after boss rewards. Pending boss/chest work defers it. The selected farming mode and dedicated Challenge unit profile remain separate. Original Challenge movement and other modes' shared starters remain. Another mode's Matchmaking checkbox does not control Challenge.

Tests use the actual production controller and detection against the supplied current menu and Start/Cancel pixels in a native test window. Game transitions/input effects are simulated; live Roblox matching still needs confirmation. Only cropped UI fixtures are bundled.
