# Dose AA Macro v4.1

Use AutoHotkey v2 on Windows and launch Main.ahk at the top of this extracted folder. Python is only required if you want to run the optional development tests.

For an update, copy the entire old Settings folder beside Main.ahk before launching; see UPDATING.md. Save a separate copy of the old installation. Do not mix old Lib files with this release.

1. Keep Roblox visible and use F1 to apply the configured game window size.
2. Choose and confirm your mode. Pick the unit profile and enable/configure its six units as required. Auto Challenge uses its own Challenge profile.
3. Review Dungeon Advanced Settings if using Dungeon. Existing values are retained; new installations use Rare Chest > Chest > Shop > Shrine > Hoard > Boss, no avoided curses and Burst/Chaos/Vamparism shrine exclusions.
4. Start with Start run or F2. Pause/Resume with the visible button or F4; movement pauses queue until the walk ends. Stop/F3 reloads the app and preserves unfinished chest work.

The new console preserves the game capture geometry. A 1920x1080 display is recommended for the 1800x930 macro window. The in-app Guide covers game/display setup, custom movement, placement and configuration.

REPAIR_REPORT.md describes the rebuilt core and its tested limits. Logs/SessionTrace.tsv and up to three game-only Logs/Diagnostics images help diagnose a stop locally. These are not automatically uploaded by the diagnostic capture. Your existing webhook settings and sender remain unchanged.

A live supervised run is still needed to confirm Roblox recognition/transitions on your machine. Offline reference-window tests cannot promise a perfect three-hour run or detect every future game UI change.
