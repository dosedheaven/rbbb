# Current rare-room selection — v2.6

The macro classifies all detected current cards in the supported single-, double- and triple-room layouts before choosing. It follows your saved route priorities, with the existing curse checks and entry rechecks.

When two or three current rooms both have a confirmed rare chest, it compares them before clicking:

1. With RareChest Path enabled, prefer a tied current rare whose route also has a confirmed future rare preview.
2. If their future-rare status is equal, compare extra confirmed rewards in your configured order. With Rare Chest > Chest > Shop > Shrine > Hoard > Boss, an extra Chest beats an extra Shop; an extra Shop beats Shrine/Hoard.
3. If every confirmed reward is equal, retain the existing stable room order.

Example: left = Rare Chest; right = Rare Chest + Shop with a confirmed future rare. The right room is attempted first. A rejected curse or failed current-room recheck still excludes that room, and the macro tries the remaining eligible current rare before falling back to future-only routes.

The CHEST label is shared by normal and rare chests. An extra Chest tie bonus requires a separate same-card label in two of three samples, alongside the rare icon and its own label. A single shared label, nearby duplicate hits, unreadable evidence or neighboring-card text contributes no extra bonus. This bonus does not change normal-room/chest classification or let a lower-priority room replace a current rare.

Turning RareChest Path off removes future previews from the tie comparison. Extra current rewards still follow your configured order. Explicit priorities such as Shop before Rare Chest remain respected. Future-only route selection, preview rectangles/reference patterns, shrine policy, chest saving/opening, shop buying, movement and UI are unchanged.

The log lists each tied rare candidate, whether its future rare was confirmed, its extra confirmed rewards, and the ranked path order. Only detected evidence is compared; there is no prediction beyond the existing future-rare preview detector, nor a count of all future shop/chest rewards.

Validation uses native AutoHotkey with synthetic windows and mocked routing scenes. It reproduces the first-match failure in v2.5 and checks the new choices. Live Roblox artwork/layout changes may still require detector updates.
