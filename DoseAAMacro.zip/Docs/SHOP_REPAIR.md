# Shop policy — v3.5

Golden Fishhook is attempted first, then regular Fishhook, then other eligible items bottom to top. Existing detectors, purchase-button classifier, retry limits and try-other-items/Continue policy are retained.

Axe is never-buy when recognized by its stored reference. Before any purchase, all active rows are checked and known Axe exclusions are remembered for the entire shop visit. A confirmed purchase removes one item from that remembered order; exclusions move with the cards. A missing reference on a later scan cannot erase a confirmed exclusion. The row-local icon scan also covers a wider region for compacted cards. The guard is applied again before purchase input.

If an unexpected row-count change makes a remembered exclusion ambiguous, remaining offers are skipped for that visit rather than risking the known Axe. If detection/window/input fails, no later purchase or Continue is sent. Tests explicitly hide the Axe reference after the first purchase and verify it remains unbought across every original position.

Aures Maul, Headsplitter and Solar Cleaver do not yet have captured references and are not blocked. No inventory/buff OCR or additional item priority is added. Synthetic tests do not prove that the original Axe reference matches every live-game appearance.
