# Shop policy — v3.6

Golden Fishhook is attempted first, then regular Fishhook, then other eligible items bottom to top. Existing detectors, purchase-button classifier, retry limits and try-other-items/Continue policy are retained.

Axe and Headsplitter are never-buy when recognized by their stored references. Before any purchase, all active rows are checked and known Axe/Headsplitter exclusions are remembered for the entire shop visit. A confirmed purchase removes one item from that remembered order; exclusions move with the cards. A missing reference on a later scan cannot erase a confirmed exclusion. Headsplitter uses opaque color points from the supplied transparent icon, sampled at fourteen shop-sized variants from 28 to 40 pixels; the transparent background and disconnected crop border are ignored. The row-local icon scan covers the existing wider region for compacted cards. The guard is applied again before purchase input.

If an unexpected row-count change makes a remembered exclusion ambiguous, remaining offers are skipped for that visit rather than risking the known Axe. If detection/window/input fails, no later purchase or Continue is sent. Tests explicitly hide Axe and Headsplitter references after the first purchase and verify that remembered exclusions follow row compaction across every original position.

Aures Maul and Solar Cleaver do not yet have captured references and are not blocked. No inventory/buff OCR or additional item priority is added. Synthetic tests do not prove that the item references match every live-game appearance. Headsplitter was supplied as a larger buff icon; matching in the actual shop still needs confirmation.


This decision policy is retained in v4.1. The rebuilt lifecycle, pause-aware timing, persistence and console are described in REPAIR_REPORT.md and ARCHITECTURE.md.
