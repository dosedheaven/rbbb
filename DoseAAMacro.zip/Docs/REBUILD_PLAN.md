# Dose rebuild plan — v4.1

Goal: preserve existing features/configuration and native game calibration while rebuilding the automation lifecycle and presenting a new operator console. This is a substantive core/UI rebuild using the proven mode-specific assets and adapters, not a claim that every legacy gameplay primitive has been rewritten.

## Invariants
- Roblox remains 816x638 at calibration (-5,1); UI never paints over its viewing region.
- All six unit profiles, mode selectors, scheduler/team swap, recording/import/export, shrines/curses/routes, shop exclusions, double rewards and boss chest locks remain accessible.
- Auto Challenge uses its dedicated Challenge profile; ordinary runs use the selected profile. User explicitly chose to retain this behavior.
- Chests retain exclusive screen ownership until verified empty and Continue closed. Results/recovery cannot steal that ownership.
- No private Settings/Logs or webhook contents are inspected. Existing module is retained unchanged. No external messages are sent by tests.
- No generated anime images. Reuse bundled artwork and fonts/licenses.

## Replacement architecture
1. Session controller: explicit phase, stage identity, observable progress, bounded transitions, structured local diagnostics, outcome/webhook idempotence.
2. Results controller: one screen observer and one bounded processor for all stage-end evidence. Never demote a recognized end screen to ordinary stage monitoring; unknown results are not recorded as losses. Handle delayed markers, overlapping prompts and resumes.
3. Operational recovery: retry unrecognized results under a deadline, rescan, then mode-aware recovery while preserving reward ownership. Intentional infinite combat waits retain their mode rules. No global two-minute inactivity reset.
4. Movement preparation: verify active calibrated game, successful spawn-reset settling, then record the selected angle branch; add explicit Dungeon behavior to Strange Town while retaining established movement distances. Ambiguous angle samples wait for stable evidence rather than choosing a direction on a single miss.
5. Operator console: new vertical navigation, workspace, anime artwork, run controls and live session status. Reuse original control models and callbacks so settings formats and options survive.
6. Settings: keep existing files; create one rotating local backup before the first save with this version. No automatic overwriting of old values or resetting Dungeon presets.

## Review and verification
- Failing v4.0 baseline reproduced with native Return references, Auto Challenge on/off.
- Controller tests: late/absent outcome, both Return variants, no XP, repeated handoffs, ordinary and Challenge stage, chest lock, paused timing, ignored clicks and unknown screens.
- Native reference-window integration; real GUI at multiple display scaling factors with all profiles/modes/panels and control bounds; no live Roblox or webhook delivery during tests.
- Run existing route/shop/chest/entrance/defaults regressions against the rebuilt application adapters. Record which historical checks are superseded by deliberate behavior changes.
- Public ZIP preserves Main at root, excludes private Settings/Logs and is verified byte-for-byte after publication. Keep v4.0 rollback.

## Completion
Core/UI implementation and the offline regression gates are complete. Current verification is in Tests/Rebuild/VERIFICATION.md. Live Roblox acceptance remains outstanding; publication is gated by ZIP integrity, exclusion of private data and public download-byte verification.
