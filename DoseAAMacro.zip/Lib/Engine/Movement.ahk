#Requires AutoHotkey v2.0

; Stable camera branching: absence is not immediately interpreted as the other
; orientation. Both maps retain their original durations and direction mapping.
DoseMovementAngle(pattern,rect,samples:=3,pollMs:=180) {
    global WF_LastIssue
    hits:=0,misses:=0,started:=A_TickCount
    while A_TickCount-started<2500 {
        match:=WF_FindText(&X,&Y,rect[1],rect[2],rect[3],rect[4],0.15,0.15,pattern)
        if WF_LastIssue!=""
            throw MacroStop("Movement angle cannot be read: " WF_LastIssue)
        hits:=match ? hits+1 : 0,misses:=match ? 0 : misses+1
        if hits>=samples
            return true
        if misses>=samples
            return false
        Sleep(pollMs)
    }
    throw MacroStop("Movement camera angle did not stabilize; no direction guessed.")
}

DoseRunMapMovement(mapName) {
    global rblxID
    if !WF_PrepareDungeon()
        throw MacroStop("Map movement blocked: game window is not ready")
    DoseSession.phase:="Map movement"
    DoseSession.Progress("Movement begins: " mapName)
    try HandleMapMovement(mapName)
    finally {
        ; Release every movement key even when an error/transition unwinds a walk.
        DoseReleaseMovementKeys()
    }
    DoseSession.Progress("Movement completed: " mapName)
}

DoseRunStageMovement(mapName) {
    global NoMovement
    if NoMovement.Visible && NoMovement.Value {
        AddToLog("Skipping movement...")
        return
    }
    if !WF_PrepareDungeon()
        throw MacroStop("Stage movement blocked: game window is not ready")
    DoseSession.phase:="Map movement"
    try {
        if !CM_HandleStageMovement(mapName)
            DoseRunMapMovement(mapName)
    } finally {
        DoseReleaseMovementKeys()
    }
    DoseSession.phase:="Movement complete"
    DosePauseCheckpoint()
}
