#Requires AutoHotkey v2.0

DoseIsDungeonRun() {
    global mode,inChallengeMode
    return IsSet(mode) && mode="Dungeon" && !(IsSet(inChallengeMode) && inChallengeMode)
}

DoseDungeonMenuHeader() {
    global WF_LastIssue
    if !DoseIsDungeonRun()
        return ""
    if WF_FindText(&X,&Y,140,200,375,250,0,0,Shop)
        return "Shop"
    if WF_LastIssue!=""
        return "Blocked"
    if WF_FindText(&X,&Y,140,200,375,250,0,0,Shrine)
        return "Shrine"
    return WF_LastIssue!="" ? "Blocked" : ""
}

DoseDungeonScreenStep() {
    if !DoseIsDungeonRun() || !WF_PrepareDungeon()
        return 0
    header:=DoseDungeonMenuHeader()
    if header="Shop" || header="Shrine"
        return DoseResumeDungeonMenu
    if header="Blocked"
        return 0
    first:=DungeonEntranceScene(&X,&Y,&layout)
    if first!="Route" && first!="Enter"
        return 0
    Sleep(180)
    second:=DungeonEntranceScene(&X,&Y,&again)
    if first!=second || (first="Route" && layout!=again)
        return 0
    return LookForDungeonRooms
}

DoseResumeDungeonMenu() {
    DoseSession.phase:="Dungeon menu"
    if !CheckDungeonSpecials()
        return false
    return LookForDungeonRooms()
}
