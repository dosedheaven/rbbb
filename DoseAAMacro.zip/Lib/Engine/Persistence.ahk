#Requires AutoHotkey v2.0

DoseUnitProfileName() {
    global inChallengeMode,PlacementSelection
    if MacroLoopState.Active && DoseSession.stageId>0 && DoseSession.stageProfile!=""
        return DoseSession.stageProfile
    return inChallengeMode ? "Challenge" : PlacementSelection.Text
}

DoseUnitPrefix() {
    name:=DoseUnitProfileName()
    return name="Default" ? "" : (name="Fool's Hunt" || name="Winter Event") ? "event" : name
}

DoseBackupSettings(root:="",destination:="") {
    if root=""
        root:=A_ScriptDir "\Settings"
    if destination=""
        destination:=A_ScriptDir "\Backups\Settings-before-4.1"
    if !FileExist(root "\Configuration.txt") || DirExist(destination)
        return false
    SplitPath(destination,,&parent)
    if !DirExist(parent)
        DirCreate(parent)
    DirCopy(root,destination,false)
    return true
}

DoseSaveChestCheckpoint(owedOverride:=-1) {
    global DoseChestState,DungeonChestExitLocked,rblxID,BossRoomCompleted,DungeonBossExitPending
    if !IsObject(DoseChestState)
        return
    try {
        root:=A_ScriptDir "\Settings"
        if !DirExist(root)
            DirCreate(root)
        path:=root "\RuntimeChest.ini",temporary:=path ".pending"
        if FileExist(temporary)
            FileDelete(temporary)
        owed:=owedOverride>=0 ? owedOverride : DoseChestState.owedClicks
        IniWrite(1,temporary,"Chest","Format")
        IniWrite(DungeonChestExitLocked ? 1 : 0,temporary,"Chest","Pending")
        IniWrite(owed,temporary,"Chest","Owed")
        IniWrite(DoseChestState.rewardChain ? 1 : 0,temporary,"Chest","Chain")
        IniWrite(owed ? "Reward" : DoseChestState.phase,temporary,"Chest","Phase")
        IniWrite(DoseChestState.commonOpens,temporary,"Chest","CommonOpens")
        IniWrite(DoseChestState.rareOpens,temporary,"Chest","RareOpens")
        boss:=(IsSet(BossRoomCompleted) && BossRoomCompleted) || (IsSet(DungeonBossExitPending) && DungeonBossExitPending)
        IniWrite(boss ? 1 : 0,temporary,"Chest","BossExit")
        IniWrite(WinGetPID(rblxID),temporary,"Chest","Process")
        FileMove(temporary,path,1)
    } catch as err {
        DoseSession.Trace("checkpoint-error",err.Message)
    }
}

DoseRestoreChestCheckpoint() {
    global DoseChestState,DungeonChestExitLocked,rblxID,BossRoomCompleted
    if DungeonChestExitBlocked()
        return
    path:=A_ScriptDir "\Settings\RuntimeChest.ini"
    if !FileExist(path)
        return
    try {
        if IniRead(path,"Chest","Format",0)!=1
            return
        if IniRead(path,"Chest","Pending",0)!=1 {
            if IniRead(path,"Chest","BossExit",0)=1 && WinExist(rblxID) && WinGetPID(rblxID)=Integer(IniRead(path,"Chest","Process",0)) {
                scene:=DungeonEntranceScene(&X,&Y,&layout)
                if scene="Enter"
                    DungeonArmBossExitRecovery()
            }
            return
        }
        bossExit:=IniRead(path,"Chest","BossExit",0)=1
        owed:=Integer(IniRead(path,"Chest","Owed",-1))
        phase:=IniRead(path,"Chest","Phase","")
        if owed<0 || owed>2 || !RegExMatch(phase,"^(Menu|Reward|Common|Rare|Verify|Verified|Continue|Complete)$")
            throw Error("Invalid chest checkpoint")
        if !WF_PrepareDungeon()
            throw MacroStop("Saved chest work exists, but Roblox is not ready. Position the game and start again.")
        sameProcess:=WinGetPID(rblxID)=Integer(IniRead(path,"Chest","Process",0))
        if phase="Verified" && owed=0 && sameProcess && !DungeonChestMenuVisible() && DoseChestExitSceneConfirmed() {
            DoseChestState:=DungeonChestNewState(),DoseChestState.phase:="Complete"
            BossRoomCompleted:=bossExit
            DungeonChestExitLocked:=false,DoseSaveChestCheckpoint()
            if bossExit
                DungeonArmBossExitRecovery()
            AddToLog("Saved empty-chest exit reconciled with the current dungeon screen")
            return
        }
        if !DungeonChestMenuVisible() && !(sameProcess && (owed>0 || phase="Reward") && !CheckForLobbyText())
            throw MacroStop("Saved chest work could not be matched to the current screen. Open its chest menu before resuming.")
        state:=DungeonChestNewState(),state.phase:=phase,state.owedClicks:=owed
        state.rewardChain:=owed>0 || IniRead(path,"Chest","Chain",0)=1,state.lastClaim:=DoseActiveTick()
        state.commonOpens:=Max(0,Min(200,Integer(IniRead(path,"Chest","CommonOpens",0))))
        state.rareOpens:=Max(0,Min(200,Integer(IniRead(path,"Chest","RareOpens",0))))
        DoseChestState:=state,DungeonChestExitLocked:=true
        BossRoomCompleted:=bossExit
        AddToLog("Restored chest checkpoint: " owed " reward dismissal(s) pending; entry remains locked")
    } catch as err {
        if Type(err)="MacroStop"
            throw err
        throw MacroStop("Chest checkpoint unreadable; no input sent. Keep Settings/RuntimeChest.ini for inspection.")
    }
}

DoseChestExitSceneConfirmed() {
    first:=DungeonEntranceScene(&X,&Y,&layout)
    if first!="Route" && first!="Enter"
        return false
    Sleep(250)
    second:=DungeonEntranceScene(&X,&Y,&again)
    return first=second && (first!="Route" || layout=again)
}
