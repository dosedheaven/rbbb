#Requires AutoHotkey v2.0

DoseActiveTick() {
    return A_TickCount-DoseSession.pauseTotal-(DoseSession.paused ? A_TickCount-DoseSession.pauseAt : 0)
}

DoseSetPaused(value,underlying:=true) {
    if !MacroLoopState.Active
        return false
    if value {
        DoseSession.paused:=true,DoseSession.pauseAt:=A_TickCount
        AddToLog("Macro paused; configuration is editable")
    } else {
        if !WF_PrepareDungeon() {
            AddToLog("Cannot resume: position Roblox and clear its view first")
            return false
        }
        duration:=A_TickCount-DoseSession.pauseAt
        DoseSession.pauseTotal+=duration,DoseSession.Shift(duration),TimerManager.ShiftAll(duration)
        DoseSession.paused:=false,DoseSession.pauseRequested:=false
        AddToLog("Macro resumed")
    }
    ; Timers stop while an AHK thread is paused. Refresh the console explicitly
    ; before pausing so Resume and configuration remain usable.
    try DoseConsoleTick()
    try AA_StyleTick()
    if underlying
        Pause(value)
    else
        Pause()
    return true
}

DosePauseCheckpoint() {
    if !DoseSession.pauseRequested
        return
    DoseSession.pauseRequested:=false
    DoseSetPaused(true,false)
}

DoseReleaseMovementKeys(*) {
    for key in ["w","a","s","d","space","left","right","up","down"]
        SendInput("{" key " up}")
}
