#Requires AutoHotkey v2.0

; The result policy is pure. Session diagnostics write local traces only.
class DoseResultsState {
    __New(now,timeoutMs:=45000,outcomeMs:=8000) {
        this.started:=now,this.deadline:=now+timeoutMs,this.outcomeDeadline:=now+outcomeMs
        this.candidate:="",this.samples:=0,this.outcome:="",this.recorded:=false
        this.webhookAttempted:=false,this.lastAction:=0,this.actions:=0,this.rescans:=0
        this.lastSignature:="",this.lastProgress:=now
    }
    Observe(e,now) {
        if e.kind="Blocked" || e.kind="Chest" || e.kind="Shop" || e.kind="Shrine"
            return
        signature:=e.kind "|" e.outcome "|" e.navigation "|" e.next "|" e.xp
        if signature!=this.lastSignature
            this.lastSignature:=signature,this.lastProgress:=now
        if !this.recorded && e.outcome!="" {
            this.samples:=e.outcome=this.candidate ? this.samples+1 : 1
            this.candidate:=e.outcome
            if (this.samples>=2 || e.navigation || e.next || e.xp)
                this.outcome:=e.outcome
        }
    }
    Decide(e,now,retryMs:=1200) {
        if e.kind="Chest"
            return "Chest"
        if e.kind="Shop" || e.kind="Shrine"
            return "Menu"
        if e.kind="Blocked"
            return now>=this.deadline ? "Recover" : "Wait"
        this.Observe(e,now)
        if !this.recorded && this.outcome!=""
            return "Record"
        if (!this.recorded && now>=this.outcomeDeadline && (e.navigation || e.next || e.xp))
            return "RecordUnknown"
        if this.recorded && e.navigation
            return "Route"
        if now>=this.deadline
            return "Recover"
        if (this.actions>=6 || (this.lastAction && now-this.lastAction<retryMs))
            return "Wait"
        if e.unit
            return "CloseUnit"
        if this.recorded && e.next
            return "Next"
        if this.recorded && e.xp
            return "Dismiss"
        return "Wait"
    }
    Acted(now) {
        this.lastAction:=now,this.actions+=1
    }
    Shift(ms) {
        this.deadline+=ms,this.outcomeDeadline+=ms
        if this.lastAction
            this.lastAction+=ms
    }
}

class DoseSession {
    static phase:="Idle",map:="",stageId:=0,stageStarted:=0
    static lastProgress:=0,lastAction:="Ready",results:=0,step:="",recoveries:=0
    static stageMode:="",stageProfile:="",challenge:=false,runId:=""
    static recent:=[],heartbeat:=0,traceRoot:=""
    static paused:=false,pauseRequested:=false,pauseAt:=0,pauseTotal:=0,diagnosticSequence:=0
    static BeginRun() {
        this.runId:=FormatTime(,"yyyyMMdd-HHmmss") "-" A_TickCount
        this.recoveries:=0,this.phase:="Starting",this.lastProgress:=A_TickCount
        this.Trace("run","start")
    }
    static BeginStage(mapName) {
        global inChallengeMode,ModeDropdown,PlacementSelection
        this.stageId+=1,this.stageStarted:=A_TickCount,this.map:=mapName
        this.challenge:=inChallengeMode,this.stageMode:=ModeDropdown.Text
        this.stageProfile:=inChallengeMode ? "Challenge" : PlacementSelection.Text
        this.results:=0,this.phase:="Loading",this.lastProgress:=A_TickCount,this.recoveries:=0
        this.Trace("stage",mapName " / " this.stageProfile)
    }
    static ExpectResults(source,e:=0,options:=0) {
        if !this.stageStarted
            this.stageStarted:=A_TickCount
        if !IsObject(this.results) {
            timeout:=IsObject(options) ? options.timeoutMs : 45000
            outcome:=IsObject(options) ? options.outcomeMs : 8000
            this.results:=DoseResultsState(A_TickCount,timeout,outcome)
            this.phase:="Results",this.lastProgress:=A_TickCount
            this.Trace("results",source)
        }
        if IsObject(e)
            this.results.Observe(e,A_TickCount)
        return this.results
    }
    static Enter(stepName) {
        this.step:=stepName
        phases:=Map("RestartStage","Loading","PlacingUnits","Placement","MonitorStage","Playing",
            "DoseProcessStageResults","Results","HandleStageEnd","Results","MonitorDungeonEnd","Dungeon results",
            "MonitorEndScreen","Results navigation","CheckLobby","Lobby","StartSelectedMode","Starting",
            "ChallengeMode","Challenge entry","DoseResumeChestSession","Chest rewards")
        if phases.Has(stepName)
            this.phase:=phases[stepName]
        this.Trace("step",stepName)
    }
    static Progress(message) {
        this.lastProgress:=A_TickCount,this.lastAction:=message
        this.Trace("progress",message)
    }
    static Shift(ms) {
        if IsObject(this.results)
            this.results.Shift(ms)
    }
    static Trace(event,detail) {
        this.recent.Push({at:A_TickCount,event:event,detail:detail})
        if this.recent.Length>80
            this.recent.RemoveAt(1)
        try {
            folder:=this.traceRoot!="" ? this.traceRoot : A_ScriptDir "\Logs"
            if !DirExist(folder)
                DirCreate(folder)
            path:=folder "\SessionTrace.tsv"
            if FileExist(path) && FileGetSize(path)>2*1024*1024
                FileMove(path,folder "\SessionTrace.previous.tsv",1)
            FileAppend(FormatTime(,"yyyy-MM-dd HH:mm:ss") "`t" this.runId "`t" this.stageId "`t" this.phase
                "`t" event "`t" StrReplace(StrReplace(detail,"`n"," "),"`t"," ") "`n",path,"UTF-8")
        }
    }
}
