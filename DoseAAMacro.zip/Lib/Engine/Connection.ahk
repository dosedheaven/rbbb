#Requires AutoHotkey v2.0

; One connection owner. Callers observe; only DoseRejoin launches a server link.
class DoseConnectionState {
    static lastCheck:=0,missingSince:=0,hits:=0,notified:=false
    static Reset() {
        this.lastCheck:=0,this.missingSince:=0,this.hits:=0,this.notified:=false
    }
}

DoseConnectionCheck() {
    global rblxID
    now:=DoseActiveTick()
    if DoseConnectionState.lastCheck && now-DoseConnectionState.lastCheck<1000
        return false
    DoseConnectionState.lastCheck:=now
    if !WinExist(rblxID) {
        if !DoseConnectionState.missingSince
            DoseConnectionState.missingSince:=now
        if now-DoseConnectionState.missingSince>=15000 {
            if DungeonChestExitBlocked()
                throw MacroStop("Roblox closed with rewards pending; checkpoint retained. Reopen the saved chest screen before resuming.")
            AddToLog("Roblox window missing; starting bounded connection recovery")
            return NextStep(RejoinPrivateServer)
        }
        return false
    }
    DoseConnectionState.missingSince:=0
    if !WF_PrepareDungeon()
        return false
    disconnected:=WF_FindText(&X,&Y,230,160,610,410,0.05,0.05,Disconnect)
        || WF_FindText(&X,&Y,230,160,610,410,0.05,0.05,DisconnectOld)
    DoseConnectionState.hits:=disconnected ? DoseConnectionState.hits+1 : 0
    if DoseConnectionState.hits<2
        return false
    if !DoseConnectionState.notified {
        DoseConnectionState.notified:=true
        AddToLog("Disconnect dialog confirmed in two observations")
        try sendDCWebhook()
    }
    if DungeonChestExitBlocked()
        throw MacroStop("Disconnected with rewards pending; checkpoint retained. No automatic server switch.")
    return NextStep(RejoinPrivateServer)
}

DosePrivateServerLink() {
    path:=A_ScriptDir "\Settings\PrivateServer.txt"
    return FileExist(path) ? Trim(FileRead(path,"UTF-8")) : ""
}

DoseOpenServerLink(link) {
    Run(link!="" ? link : "roblox://placeID=8304191830")
}

DoseRejoin(overrides:=0) {
    global rblxID,FW_ReconnectTimeoutMs,BossRoomCompleted
    options:={attemptMs:Max(30000,FW_ReconnectTimeoutMs),pollMs:1000,launchMs:3000,maxAttempts:3}
    if IsObject(overrides)
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name%:=value
    if DungeonChestExitBlocked()
        throw MacroStop("Connection recovery blocked by unfinished chest rewards")
    DoseSession.phase:="Rejoining"
    link:=DosePrivateServerLink()
    Loop options.maxAttempts {
        AddToLog("Connection recovery: launch " A_Index "/" options.maxAttempts)
        try DoseOpenServerLink(link)
        catch {
            DoseSession.Trace("connection","Server launch failed")
            continue
        }
        Sleep(options.launchMs)
        deadline:=DoseActiveTick()+options.attemptMs,hits:=0,lastMessage:=0
        while DoseActiveTick()<deadline {
            if WinExist(rblxID) {
                forceRobloxSize()
                if WF_PrepareDungeon() {
                    lobby:=WF_FindText(&X,&Y,746,514,789,530,0.000001,0.000001,AreaText)
                    hits:=lobby ? hits+1 : 0
                    if hits>=2 {
                        DoseConnectionState.Reset(),BossRoomCompleted:=false
                        DungeonClearBossExitRecovery()
                        DoseSession.Progress("Connection recovery: lobby verified")
                        AddToLog("Reconnected successfully; lobby confirmed")
                        return NextStep(StartSelectedMode)
                    }
                } else
                    hits:=0
            } else
                hits:=0
            if !lastMessage || DoseActiveTick()-lastMessage>=15000 {
                lastMessage:=DoseActiveTick()
                DoseSession.Trace("connection","Waiting for verified lobby")
            }
            Sleep(options.pollMs)
        }
        DoseCaptureFailure("Connection timeout","Lobby not verified")
    }
    throw MacroStop("Server connection not verified after bounded attempts; inspect the Roblox window and session trace.")
}
