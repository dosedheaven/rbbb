#Requires AutoHotkey v2.0

; A single eligibility rule; the interval still begins at Challenge completion.
DoseChallengeEligible(now,lastFinished,enabled,active,rewardsPending) {
    return enabled && !active && !rewardsPending && now-lastFinished>=1800000
}

DoseAutoChallengeDue() {
    global ChallengeBox,inChallengeMode,challengeStartTime,BossRoomCompleted
    rewards:=DungeonChestExitBlocked() || (IsSet(BossRoomCompleted) && BossRoomCompleted)
    return DoseChallengeEligible(A_TickCount,challengeStartTime,ChallengeBox.Value,inChallengeMode,rewards)
}
