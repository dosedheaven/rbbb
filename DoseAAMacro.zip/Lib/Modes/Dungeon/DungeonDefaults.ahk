#Requires AutoHotkey v2.0

; The v2 preset is applied on the first Dungeon selection only. Existing unit,
; placement, webhook, and other settings are not involved.
global Dose_DungeonSettingsRoot := A_ScriptDir "\Settings"
global Dose_DungeonDefaultsSessionApplied := false

DoseDungeonSettingsDirectory() {
    global Dose_DungeonSettingsRoot
    return Dose_DungeonSettingsRoot
}

DoseEnsureDungeonDefaults() {
    global Dose_DungeonDefaultsSessionApplied
    global routePriorityOrder, cursePriorityOrder, shrinePriorityOrder
    global routeDropDowns, curseDropDowns, shrineDropDowns
    directory := DoseDungeonSettingsDirectory()
    marker := directory "\DoseDungeonPreset-v2.txt"
    if (Dose_DungeonDefaultsSessionApplied || FileExist(marker))
        return false
    preset := DoseDungeonDefaults()
    if (routeDropDowns.Length != preset.route.Length
        || curseDropDowns.Length != preset.curses.Length
        || shrineDropDowns.Length != preset.shrines.Length) {
        AddToLog("Dose Dungeon defaults could not be applied: controls are not ready")
        return false
    }
    safeToSave := true
    try {
        if !DirExist(directory)
            DirCreate(directory)
        oldConfig := directory "\RoutePriority.txt"
        backup := directory "\RoutePriority.beforeDose2.txt"
        if (FileExist(oldConfig) && !FileExist(backup))
            FileCopy(oldConfig,backup,0)
    } catch {
        safeToSave := false
        AddToLog("Dose defaults will apply for this session; existing Dungeon settings could not be backed up")
    }
    for row, value in preset.route
        routeDropDowns[row].Choose(value)
    for row, value in preset.curses
        curseDropDowns[row].Choose(value)
    for row, value in preset.shrines
        shrineDropDowns[row].Choose(value)
    routePriorityOrder := preset.route
    cursePriorityOrder := preset.curses
    shrinePriorityOrder := preset.shrines
    UpdateEnabledCurses()
    UpdateEnabledShrines()
    Dose_DungeonDefaultsSessionApplied := true
    try {
        if (safeToSave && SaveDungeonLocal()) {
            FileAppend("Dose Dungeon preset applied in v" DoseReleaseVersion() "`n",marker,"UTF-8")
            AddToLog("Dose Dungeon defaults applied once; later edits will be kept")
            return true
        }
    } catch {
    }
    AddToLog("Dose Dungeon defaults applied for this session; saving was unavailable")
    return true
}
