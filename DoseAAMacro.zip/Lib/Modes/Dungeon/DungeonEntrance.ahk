#Requires AutoHotkey v2.0

; Recovery is armed only by a successful final boss chest drain. A normal
; entrance timeout, an obscured window or remaining chests cannot arm it.
global DungeonChestExitLocked := false

DungeonChestExitBlocked() {
    return DungeonChestExitLocked
}

global DungeonBossExitPending := false, DungeonBossExitRecoveries := 0

; Startup only. Keep room-dialog Enter, chest saving, shop and shrine policies
; separate. Search coordinates share the existing WindowFollow calibration.
DungeonEntranceScene(&X, &Y, &layout) {
    global WF_LastIssue
    X := "", Y := "", layout := ""
    if WF_FindText(&X, &Y, 250, 340, 550, 495, 0.20, 0.20, EnterDungeon)
        return "Enter"
    if (WF_LastIssue != "")
        return "Blocked"
    if WF_FindText(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath) {
        if WF_FindText(&X, &Y, 308, 391, 494, 437, 0.10, 0.10, DungeonDeathContinue)
            return "Death"
        return WF_LastIssue = "" ? "DeathPending" : "Blocked"
    }
    if (WF_LastIssue != "")
        return "Blocked"
    rooms := DungeonScanRooms(&diagnostic)
    if (WF_LastIssue != "")
        return "Blocked"
    if !DungeonValidLayout(rooms)
        return "Waiting"
    for room in rooms
        layout .= room.index ":" room.type ";"
    return "Route"
}

DungeonOpenEntranceMenu() {
    if DungeonChestExitBlocked() {
        AddToLog("Chest session unfinished; DungeonOpenEntranceMenu refused")
        return false
    }
    global rblxID
    ; Preserve the original lobby click at CLIENT (85,400), while sending it
    ; through the validated screen-coordinate input helper. No guessed offsets.
    try {
        hwnd := WinExist(rblxID)
        point := Buffer(8, 0)
        NumPut("Int",85,"Int",400,point)
        if (!hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int")) {
            AddToLog("Dungeon entrance: lobby button coordinates unavailable")
            return false
        }
        FT_GetOffset(&dx, &dy)
        return WF_RobloxClick(NumGet(point,0,"Int")-dx, NumGet(point,4,"Int")-dy)
    } catch {
        AddToLog("Dungeon entrance: lobby button coordinates unavailable")
        return false
    }
}

DungeonStartEntrance() {
    if DungeonChestExitBlocked() {
        AddToLog("Chest session unfinished; DungeonStartEntrance refused")
        return false
    }
    global WF_LastIssue
    if !WF_PrepareDungeon() {
        AddToLog("Dungeon entrance window not ready: " WF_LastIssue)
        return false
    }
    scene := DungeonEntranceScene(&X,&Y,&layout)
    if (scene = "Blocked") {
        AddToLog("Dungeon entrance screen unreadable: " WF_LastIssue)
        return false
    }
    ; Resume an already-open entrance/route instead of toggling the lobby menu.
    if (scene = "Waiting") {
        if !DungeonOpenEntranceMenu() {
            AddToLog("Dungeon entrance lobby click refused; no room selection attempted")
            return false
        }
        AddToLog("Dungeon entrance opened; waiting for Enter Dungeon")
    }
    return DungeonWaitForEntrance()
}

DungeonWaitForEntrance(timeoutMs := 45000, pollMs := 500, retryMs := 1500, maxClicks := 6, recoveryAfterMs := 30000) {
    if DungeonChestExitBlocked() {
        AddToLog("Chest session unfinished; DungeonWaitForEntrance refused")
        return false
    }
    global WF_LastIssue
    started := A_TickCount, lastClick := 0, clicks := 0, enterClicks := 0, previousLayout := ""
    lastScene := "Waiting", retriesExhausted := false, stuckSince := 0
    recoverable := DungeonBossExitPending && DungeonBossExitRecoveries=0
    if recoverable
        maxClicks := Min(maxClicks,5)
    Loop {
        if (A_TickCount-started >= timeoutMs)
            break
        scene := DungeonEntranceScene(&X,&Y,&layout)
        lastScene := scene
        if (scene = "Blocked") {
            AddToLog("Dungeon entrance screen unreadable: " WF_LastIssue "; no further clicks")
            return false
        }
        if (scene="Enter" && DungeonBossExitPending && DungeonBossExitRecoveries>=1) {
            AddToLog("Post-boss entrance recovery already attempted; no further Enter clicks. Inspect the recovery log")
            return false
        }
        if (scene!="Enter")
            stuckSince := 0
        else if (enterClicks && !stuckSince)
            stuckSince := A_TickCount
        if (scene = "Route") {
            if (layout = previousLayout) {
                DungeonClearBossExitRecovery()
                AddToLog("Dungeon entrance confirmed: stable route screen ready")
                return true
            }
            previousLayout := layout
        } else {
            previousLayout := ""
            if (scene = "Enter" || scene = "Death") {
                attempts := (recoverable && scene="Enter") ? enterClicks : clicks
                if (attempts < maxClicks && (!lastClick || A_TickCount-lastClick >= retryMs)) {
                    ; Fresh match immediately before input, using the detected
                    ; text center rather than the previous fixed client click.
                    text := scene = "Enter" ? EnterDungeon : DungeonDeathContinue
                    x1 := scene = "Enter" ? 250 : 308
                    y1 := scene = "Enter" ? 340 : 391
                    x2 := scene = "Enter" ? 550 : 494
                    y2 := scene = "Enter" ? 495 : 437
                    tolerance := scene = "Enter" ? 0.20 : 0.10
                    if WF_FindText(&X,&Y,x1,y1,x2,y2,tolerance,tolerance,text) {
                        if !WF_RobloxClick(X,Y) {
                            AddToLog("Dungeon entrance click refused; no room selection attempted")
                            return false
                        }
                        clicks += 1, lastClick := A_TickCount
                        if (scene="Enter") {
                            enterClicks += 1
                            if !stuckSince
                                stuckSince := A_TickCount
                        }
                        displayedClicks := (recoverable && scene="Enter") ? enterClicks : clicks
                        AddToLog("Dungeon entrance: " (scene = "Enter" ? "Enter Dungeon" : "death Continue")
                            " click " displayedClicks "/" maxClicks "; waiting for route confirmation")
                    } else if (WF_LastIssue != "") {
                        AddToLog("Dungeon entrance recheck failed: " WF_LastIssue)
                        return false
                    }
                } else if (attempts >= maxClicks && !retriesExhausted) {
                    retriesExhausted := true
                    AddToLog("Dungeon entrance click limit reached; waiting for route without further clicks")
                }
            }
        }
        if (recoverable && scene="Enter" && stuckSince && enterClicks>=maxClicks
            && A_TickCount-stuckSince>=recoveryAfterMs) {
            AddToLog("Post-boss Enter Dungeon unchanged after " enterClicks " attempts and "
                (A_TickCount-stuckSince)//1000 "s; starting verified lobby recovery")
            return DungeonRecoverBossEntrance()
        }
        Sleep(Max(1,Min(pollMs,timeoutMs-(A_TickCount-started))))
    }
    AddToLog("Dungeon entrance timed out after " timeoutMs//1000 "s; last screen=" lastScene
        "; clicks=" clicks ". No room selection attempted. Check the visible entrance and Debug patterns.")
    return false
}

DungeonArmBossExitRecovery() {
    if DungeonChestExitBlocked() {
        AddToLog("Chest session unfinished; DungeonArmBossExitRecovery refused")
        return false
    }
    global DungeonBossExitPending, DungeonBossExitRecoveries
    DungeonBossExitPending := true, DungeonBossExitRecoveries := 0
    AddToLog("Boss chests confirmed empty; stuck-entrance lobby recovery armed")
}

DungeonClearBossExitRecovery() {
    global DungeonBossExitPending, DungeonBossExitRecoveries
    DungeonBossExitPending := false, DungeonBossExitRecoveries := 0
}

DungeonBossRecoveryOptions(overrides := 0) {
    options := {pollMs:250,retryMs:1500,closeMs:12000,lobbyMs:60000,maxCloseClicks:3,maxLobbyClicks:3}
    if IsObject(overrides)
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    return options
}

DungeonBossRecoveryFind(text,&X,&Y,x1,y1,x2,y2) {
    global WF_LastIssue
    return WF_FindText(&X,&Y,x1,y1,x2,y2,0.10,0.10,text)
}

DungeonBossRecoveryAtLobby() {
    return WF_FindText(&X,&Y,746,514,789,530,0.000001,0.000001,AreaText)
}

DungeonBossRecoveryClose(options) {
    global WF_LastIssue
    started := A_TickCount, lastClick := 0, clicks := 0, clear := 0
    while (A_TickCount-started<options.closeMs) {
        enterVisible := DungeonBossRecoveryFind(EnterDungeon,&X,&Y,250,340,550,495)
        if (WF_LastIssue!="")
            return false
        closeVisible := DungeonBossRecoveryFind(DungeonRedX,&closeX,&closeY,640,175,700,205)
        if (WF_LastIssue!="")
            return false
        clear := !enterVisible && !closeVisible ? clear+1 : 0
        if (clear>=2) {
            AddToLog("Post-boss dungeon menu confirmed closed")
            return true
        }
        if (closeVisible && clicks<options.maxCloseClicks
            && (!lastClick || A_TickCount-lastClick>=options.retryMs)) {
            if !DungeonBossRecoveryFind(DungeonRedX,&closeX,&closeY,640,175,700,205) {
                if (WF_LastIssue!="")
                    return false
                Sleep(options.pollMs)
                continue
            }
            if !WF_RobloxClick(closeX,closeY)
                return false
            clicks += 1, lastClick := A_TickCount
            AddToLog("Post-boss recovery: dungeon X click " clicks "/" options.maxCloseClicks)
        }
        Sleep(options.pollMs)
    }
    AddToLog("Post-boss recovery: dungeon menu closure not confirmed; no Return to Lobby click")
    return false
}

DungeonBossRecoveryReturn(options) {
    global WF_LastIssue
    started := A_TickCount, lastClick := 0, clicks := 0, lobbyHits := 0
    while (A_TickCount-started<options.lobbyMs) {
        lobby := DungeonBossRecoveryAtLobby()
        if (WF_LastIssue!="")
            return false
        lobbyHits := lobby ? lobbyHits+1 : 0
        if (lobbyHits>=2) {
            AddToLog("Post-boss recovery: lobby confirmed; restarting selected mode")
            return true
        }
        if !lobby {
            ; Never act on a result screen behind a reappearing dungeon menu.
            if DungeonBossRecoveryFind(EnterDungeon,&X,&Y,250,340,550,495) {
                AddToLog("Post-boss recovery: Enter Dungeon reappeared; lobby return stopped")
                return false
            }
            if (WF_LastIssue!="")
                return false
            if (clicks<options.maxLobbyClicks && (!lastClick || A_TickCount-lastClick>=options.retryMs)) {
                matchedText := ""
                for text in [LobbyText,LobbyText2] {
                    if DungeonBossRecoveryFind(text,&X,&Y,80,85,739,224) {
                        matchedText := text
                        break
                    }
                    if (WF_LastIssue!="")
                        return false
                }
                if (matchedText!="") {
                    ; Use only a fresh recognized control. Unknown confirmation
                    ; dialogs receive no guessed clicks and time out visibly.
                    if !DungeonBossRecoveryFind(matchedText,&X,&Y,80,85,739,224) {
                        if (WF_LastIssue!="")
                            return false
                        Sleep(options.pollMs)
                        continue
                    }
                    if !WF_RobloxClick(X,Y)
                        return false
                    clicks += 1, lastClick := A_TickCount
                    AddToLog("Post-boss recovery: Return to Lobby click " clicks "/" options.maxLobbyClicks)
                }
            }
        }
        Sleep(options.pollMs)
    }
    AddToLog("Post-boss recovery: lobby not confirmed; no dungeon restart. Check the visible Return to Lobby/confirmation screen")
    return false
}

DungeonRecoverBossEntrance(overrides := 0) {
    if DungeonChestExitBlocked() {
        AddToLog("Chest session unfinished; DungeonRecoverBossEntrance refused")
        return false
    }
    global DungeonBossExitRecoveries, WF_LastIssue
    if (!DungeonBossExitPending || DungeonBossExitRecoveries>=1) {
        AddToLog("Post-boss recovery refused: final chest verification absent or recovery already attempted")
        return false
    }
    if !WF_PrepareDungeon() {
        AddToLog("Post-boss recovery: window not ready; no recovery input")
        return false
    }
    ; Revalidate the exact stuck screen before closing anything.
    if !DungeonBossRecoveryFind(EnterDungeon,&X,&Y,250,340,550,495) {
        AddToLog("Post-boss recovery: stuck entrance no longer confirmed; no recovery input")
        return false
    }
    DungeonBossExitRecoveries += 1
    options := DungeonBossRecoveryOptions(overrides)
    if !DungeonBossRecoveryClose(options) {
        AddToLog("Post-boss recovery stopped during menu close: " WF_LastIssue)
        return false
    }
    if !DungeonBossRecoveryReturn(options) {
        AddToLog("Post-boss recovery stopped before confirmed lobby: " WF_LastIssue)
        return false
    }
    DungeonClearBossExitRecovery()
    ; Preserve the normal macro-loop handoff; do not catch MacroNextStep.
    return NextStep(CheckLobby)
}
