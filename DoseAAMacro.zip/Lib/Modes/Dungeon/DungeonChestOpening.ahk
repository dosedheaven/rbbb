#Requires AutoHotkey v2.0

; Serial chest owner: every Open owes two center clicks, independent of headings.
global DoseChestState := 0

DungeonChestOptions(overrides := 0) {
    options := {pollMs:250, afterOpenMs:2000, departMs:4000, claimMs:60000,
        claimClickMs:2000, rewardSettleMs:3000, emptySamples:3, stalledClicks:4, totalMs:900000, maxOpenClicks:200,
        recoveryIdleMs:120000, recoveryPollMs:1000, maxRecoveries:2, session:0, continueMs:8000}
    if IsObject(overrides) {
        for name, value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    }
    return options
}

DungeonChestMenuVisible() {
    global WF_LastIssue
    if WF_FindText(&X,&Y,140,200,375,250,0,0,ChestRoom)
        return true
    if (WF_LastIssue != "")
        return false
    return WF_FindText(&X,&Y,358,238,604,261,0,0,ChestRoomLuck)
}

DungeonChestInput(x,y,description) {
    global rblxID
    ; Retain the working legacy CLIENT click positions, but validate and deliver
    ; them via WindowFollow. In particular, do not guess a title-bar offset.
    try {
        hwnd := WinExist(rblxID), point := Buffer(8,0)
        NumPut("Int",x,"Int",y,point)
        if (!hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int"))
            return false
        FT_GetOffset(&dx,&dy)
        if !WF_RobloxClick(NumGet(point,0,"Int")-dx,NumGet(point,4,"Int")-dy)
            return false
        AddToLog("Chest action sent: " description)
        return true
    } catch {
        return false
    }
}

DungeonChestRewardCenterClick(step) {
    global rblxID
    ; Center of Roblox's actual client area, independent of the wider macro UI.
    try {
        WinGetClientPos(,,&w,&h,rblxID)
        if (w<=0 || h<=0)
            return false
        return DungeonChestInput(w//2,h//2,"claim chest reward " step "/2 at game center")
    } catch {
        return false
    }
}

DungeonChestMenuReturnProof(visible,options,&since,&samples,requiredSamples := 2) {
    if !visible {
        since := 0,samples := 0
        return false
    }
    if !samples
        since := A_TickCount
    samples += 1
    return samples>=requiredSamples && A_TickCount-since>=options.rewardSettleMs
}


DungeonChestNewState() {
    return {phase:"Menu",owedClicks:0,lastClaim:0,claimClicks:0,rewardChain:false,
        verified:false,lastProgress:A_TickCount,lastRecovery:0,recoveries:0,commonOpens:0,rareOpens:0}
}

DungeonChestState(options) {
    global DoseChestState, DungeonChestExitLocked
    if !IsObject(options.session)
        options.session := DungeonChestNewState()
    DoseChestState := options.session
    DungeonChestExitLocked := true
    return options.session
}

; A heading alone can remain visible behind rewards. A returned menu also needs
; the exact Continue reference in its own bottom-button region.
DungeonChestMenuReady() {
    global WF_LastIssue
    if !DungeonChestMenuVisible() || WF_LastIssue!=""
        return false
    return WF_FindText(&X,&Y,380,385,615,490,0.03,0.03,DungeonContinue)
}

DungeonChestDrainKind(kind,options,deadline) {
    global WF_LastIssue
    state := DungeonChestState(options),emptyStreak := 0,missingSince := 0
    property := kind="Common" ? "commonOpens" : "rareOpens"
    while (A_TickCount<deadline) {
        ; A failed/late pair survives recovery; never inspect zero counts or Open
        ; another chest while either mandatory dismissal is still owed.
        if state.owedClicks {
            if !DungeonClaimChestReward(options)
                return false
        }
        if !DungeonChestMenuReady() {
            if (WF_LastIssue!="")
                return false
            emptyStreak := 0
            if (state.rewardChain) {
                state.owedClicks := 2,state.phase := "Reward"
                if !DungeonClaimChestReward(options)
                    return false
                continue
            }
            if !missingSince
                missingSince := A_TickCount
            if (A_TickCount-missingSince>=options.departMs) {
                AddToLog(kind " chest menu not fully confirmed; no Open or Continue sent")
                return false
            }
            Sleep(options.pollMs)
            continue
        }
        missingSince := 0
        empty := kind="Common" ? IsCommonChestDone() : IsRareChestDone()
        if (WF_LastIssue!="")
            return false
        if empty {
            emptyStreak += 1
            if (emptyStreak>=options.emptySamples) {
                AddToLog(kind " chests confirmed empty (" emptyStreak " checks after rewards)")
                return true
            }
            Sleep(options.pollMs)
            continue
        }
        emptyStreak := 0
        if (state.%property%>=options.maxOpenClicks) {
            AddToLog(kind " chest Open limit reached; keeping dungeon entry locked")
            return false
        }
        if !DungeonChestInput(565,kind="Common" ? 260 : 320,"open " kind " chest") {
            AddToLog(kind " chest Open refused; keeping dungeon entry locked")
            return false
        }
        state.%property% += 1
        state.owedClicks := 2,state.claimClicks := 0,state.lastClaim := 0
        state.rewardChain := true,state.verified := false,state.phase := "Reward"
        AddToLog("Chest queue: " kind " Open sent; TWO center dismissals now required")
        Sleep(Min(options.afterOpenMs,Max(1,deadline-A_TickCount)))
        claim := DungeonChestOptions(options)
        claim.claimMs := Min(claim.claimMs,Max(1,deadline-A_TickCount))
        if !DungeonClaimChestReward(claim) {
            AddToLog(kind " reward pair/menu incomplete; no next Open, Continue, or Enter Dungeon")
            return false
        }
    }
    AddToLog("Chest deadline reached; keeping dungeon entry locked")
    return false
}

DungeonClaimChestReward(overrides := 0) {
    global WF_LastIssue
    options := DungeonChestOptions(overrides),state := DungeonChestState(options)
    started := A_TickCount,stableSince := 0,samples := 0
    if !state.owedClicks
        state.owedClicks := 2
    state.phase := "Reward",state.rewardChain := true,state.verified := false
    while (A_TickCount-started<options.claimMs) {
        if state.owedClicks {
            stableSince := 0,samples := 0
            if (!state.lastClaim || A_TickCount-state.lastClaim>=options.claimClickMs) {
                if (state.claimClicks>=40) {
                    AddToLog("Chest dismissal limit reached; reward still pending; entry locked")
                    return false
                }
                if !WF_PrepareDungeon() || !DungeonChestRewardCenterClick(3-state.owedClicks) {
                    AddToLog("Chest center input refused; " state.owedClicks " dismissal(s) still owed")
                    return false
                }
                state.owedClicks -= 1,state.claimClicks += 1,state.lastClaim := A_TickCount
                AddToLog("Chest queue: " state.owedClicks " mandatory dismissal(s) remain")
            }
            Sleep(options.pollMs)
            continue
        }
        ready := DungeonChestMenuReady()
        if (WF_LastIssue!="")
            return false
        if DungeonChestMenuReturnProof(ready,options,&stableSince,&samples) {
            DungeonChestProgress(options,"Menu")
            AddToLog("Chest pair complete; full chest menu stable; checking remaining chests")
            return true
        }
        ; A delayed second/extra reward can outlast the nominal pair. Only center
        ; clicks are allowed here. Never use background Lobby/Enter labels.
        if (!ready && A_TickCount-state.lastClaim>=options.claimClickMs) {
            state.owedClicks := 2
            AddToLog("Chest menu still covered; retrying a bounded center-click pair")
        }
        Sleep(options.pollMs)
    }
    AddToLog("Chest reward claim timed out; entry locked; no Continue sent")
    return false
}

DungeonChestConfirmAllEmpty(options,deadline) {
    global WF_LastIssue
    state := DungeonChestState(options),stableSince := 0,samples := 0,started := A_TickCount
    if state.owedClicks
        return false
    observeMs := Max(options.departMs,options.rewardSettleMs+Max(4*options.pollMs,250))
    while (A_TickCount<deadline && A_TickCount-started<observeMs) {
        ready := DungeonChestMenuReady(),commonEmpty := false,rareEmpty := false
        if (WF_LastIssue!="")
            return false
        if ready {
            commonEmpty := IsCommonChestDone()
            if (WF_LastIssue!="")
                return false
            rareEmpty := IsRareChestDone()
            if (WF_LastIssue!="")
                return false
        }
        if (!state.owedClicks && DungeonChestMenuReturnProof(ready && commonEmpty && rareEmpty,
            options,&stableSince,&samples,options.emptySamples))
            return true
        Sleep(options.pollMs)
    }
    return false
}

DungeonOpenAllChests(overrides := 0) {
    options := DungeonChestOptions(overrides),state := DungeonChestState(options)
    deadline := A_TickCount+options.totalMs
    Loop 3 {
        if !DungeonChestDrainKind("Common",options,deadline)
            return false
        if !DungeonChestDrainKind("Rare",options,deadline)
            return false
        if DungeonChestConfirmAllEmpty(options,deadline) {
            state.verified := true,state.rewardChain := false,state.phase := "Verified"
            AddToLog("All chests confirmed empty: Common and Rare; verified Continue may now run")
            return true
        }
        AddToLog("Final chest proof changed; both rows will be checked again")
    }
    AddToLog("Both chest counters not verified together; dungeon entry stays locked")
    return false
}

; This is the only chest-owned exit. It never calls the legacy finish/entry
; click loops. One fresh Continue click, then verify departure before unlocking.
DungeonChestContinueVerified(overrides := 0) {
    global DoseChestState,DungeonChestExitLocked,WF_LastIssue
    options := DungeonChestOptions(overrides)
    if (!IsObject(DoseChestState) || !DoseChestState.verified || DoseChestState.owedClicks)
        return false
    if !DungeonChestMenuReady() || !IsCommonChestDone() || !IsRareChestDone() || WF_LastIssue!=""
        return false
    if !WF_FindText(&X,&Y,380,385,615,490,0.03,0.03,DungeonContinue)
        return false
    if !WF_RobloxClick(X,Y)
        return false
    AddToLog("Chest exit: one verified Continue click; waiting for chest menu to close")
    started := A_TickCount,absent := 0
    while (A_TickCount-started<options.continueMs) {
        visible := DungeonChestMenuVisible()
        if (WF_LastIssue!="")
            return false
        absent := visible ? 0 : absent+1
        if (absent>=2) {
            DungeonChestExitLocked := false,DoseChestState.phase := "Complete"
            AddToLog("Chest exit verified; dungeon entry unlocked")
            return true
        }
        Sleep(options.pollMs)
    }
    AddToLog("Continue did not close chest menu; no entry/finish fallback sent")
    return false
}

DungeonChestProgress(options,phase,confirmed := true) {
    if !IsObject(options.session)
        return
    state := options.session
    if (confirmed && state.phase!=phase)
        state.lastProgress := A_TickCount
    state.phase := phase
}

DungeonOpenAllChestsWithRecovery(overrides := 0) {
    global DoseChestState
    options := DungeonChestOptions(overrides)
    options.session := IsObject(DoseChestState) && DungeonChestExitBlocked() && DoseChestState.phase!="Complete"
        ? DoseChestState : DungeonChestNewState()
    state := DungeonChestState(options),deadline := A_TickCount+options.totalMs
    while (A_TickCount<deadline) {
        pass := DungeonChestOptions(options),pass.totalMs := Max(1,deadline-A_TickCount)
        try {
            if DungeonOpenAllChests(pass)
                return true
        } catch as err {
            AddToLog("Chest state error at line " err.Line "; entry remains locked")
        }
        if (options.maxRecoveries<=0)
            return false
        AddToLog("Chest session unfinished; waiting for its bounded inactivity rescan")
        if !DungeonChestResumeAfterStall(options,deadline)
            return false
    }
    return false
}

DungeonChestResumeAfterStall(options,deadline) {
    state := options.session
    while (A_TickCount<deadline) {
        if (state.recoveries>=options.maxRecoveries) {
            AddToLog("Chest recovery attempts exhausted; entry remains locked")
            return false
        }
        if (A_TickCount-Max(state.lastProgress,state.lastRecovery)>=options.recoveryIdleMs) {
            state.recoveries += 1,state.lastRecovery := A_TickCount
            AddToLog("Chest inactivity recovery " state.recoveries "/" options.maxRecoveries
                ": rescanning after " options.recoveryIdleMs//1000 "s; entry remains locked")
            if WF_PrepareDungeon() {
                if (state.owedClicks || state.rewardChain) {
                    AddToLog("Chest recovery: resuming pending reward claim with center clicks only")
                    claim := DungeonChestOptions(options)
                    claim.claimMs := Min(claim.claimMs,Max(1,deadline-A_TickCount))
                    if DungeonClaimChestReward(claim)
                        return true
                } else if DungeonChestWaitForStableMenu(options,deadline)
                    return true
            }
        }
        Sleep(Max(1,Min(options.recoveryPollMs,deadline-A_TickCount)))
    }
    return false
}

DungeonChestWaitForStableMenu(options,deadline) {
    global WF_LastIssue
    since := 0,samples := 0,started := A_TickCount
    observeMs := Max(options.departMs,options.rewardSettleMs+Max(4*options.pollMs,250))
    while (A_TickCount<deadline && A_TickCount-started<observeMs) {
        ready := DungeonChestMenuReady()
        if (WF_LastIssue!="")
            return false
        if DungeonChestMenuReturnProof(ready,options,&since,&samples)
            return true
        Sleep(options.pollMs)
    }
    return false
}

DungeonChestRewardPending(state) {
    return state.owedClicks>0 || state.rewardChain
}
