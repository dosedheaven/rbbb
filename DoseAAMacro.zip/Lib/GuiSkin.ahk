#Requires AutoHotkey v2.0

; Decorative controls are confined to the macro panel/footer. The Roblox
; transparency rectangle and all game coordinates remain unchanged.
DoseBuildBackdrop(g, imagePath := "") {
    if (imagePath = "")
        imagePath := DoseThemeArtworkPath()
    if !FileExist(imagePath)
        return false
    try {
        palette := DoseThemePalette(AA_ThemeName())
        ; A complete group banner retains the supplied artwork's lettering.
        ; The lower portrait focuses on Itachi/Pain without the quote/title.
        banner := DoseBuildArtwork(g,imagePath,1544,60,228,152,255,palette.background,palette.focusX)
        if (AA_ThemeName()="Ethereal") {
            SplitPath(imagePath,,&artDir)
            global DosePortrait := DoseBuildArtwork(g,artDir "\DoseEtherealCastle.jpg",1544,226,228,432,255,
                palette.background,0.5)
        } else {
            global DosePortrait := DoseBuildArtwork(g,imagePath,1544,226,228,432,255,
                palette.background,0.5,{x:610,y:174,w:350,h:906},0)
        }
        DoseRoundControl(banner,16), DoseRoundControl(DosePortrait,16)
        return banner
    } catch {
        return false
    }
}

; Render original artwork with a proportional cover crop and focal point. Bundled image bytes stay
; unchanged. The GUI owns the returned Picture bitmap and frees it on destroy.
DoseBuildArtwork(g,path,x,y,w,h,opacity := 255,background := "0B0C11",focusX := 0.5,sourceBox := 0,focusY := 0.5) {
    bitmap := DoseArtworkBitmap(path,w,h,opacity,background,focusX,sourceBox,focusY)
    if !bitmap
        return false
    try {
        picture := g.Add("Picture",Format("x{} y{} w{} h{}",x,y,w,h),"HBITMAP:" bitmap)
        bitmap := 0 ; ownership transferred to the Picture control
        return picture
    } finally {
        if bitmap
            DllCall("gdi32\DeleteObject","Ptr",bitmap)
    }
}

DoseArtworkBitmap(path,w,h,opacity,background,focusX := 0.5,sourceBox := 0,focusY := 0.5) {
    source := 0, result := 0, cover := 0, brush := 0
    srcDC := 0, dstDC := 0, cropDC := 0, oldSrc := 0, oldDst := 0, oldCrop := 0
    try {
        source := LoadPicture(path,"GDI+")
        if !source
            return 0
        info := Buffer(A_PtrSize=8 ? 32 : 24,0)
        if !DllCall("gdi32\GetObjectW","Ptr",source,"Int",info.Size,"Ptr",info)
            return 0
        sw := NumGet(info,4,"Int"), sh := Abs(NumGet(info,8,"Int"))
        if (sw<=0 || sh<=0)
            return 0
        srcDC := DllCall("gdi32\CreateCompatibleDC","Ptr",0,"Ptr")
        dstDC := DllCall("gdi32\CreateCompatibleDC","Ptr",0,"Ptr")
        cropDC := DllCall("gdi32\CreateCompatibleDC","Ptr",0,"Ptr")
        dib := Buffer(40,0)
        NumPut("UInt",40,"Int",w,"Int",-h,"UShort",1,"UShort",32,dib)
        result := DllCall("gdi32\CreateDIBSection","Ptr",dstDC,"Ptr",dib,"UInt",0,"Ptr*",&pixels := 0,"Ptr",0,"UInt",0,"Ptr")
        cover := DllCall("gdi32\CreateDIBSection","Ptr",cropDC,"Ptr",dib,"UInt",0,"Ptr*",&cropPixels := 0,"Ptr",0,"UInt",0,"Ptr")
        if !(srcDC && dstDC && cropDC && result && cover)
            return 0
        oldSrc := DllCall("gdi32\SelectObject","Ptr",srcDC,"Ptr",source,"Ptr")
        oldDst := DllCall("gdi32\SelectObject","Ptr",dstDC,"Ptr",result,"Ptr")
        oldCrop := DllCall("gdi32\SelectObject","Ptr",cropDC,"Ptr",cover,"Ptr")
        sx := 0, sy := 0, sourceW := sw, sourceH := sh
        if IsObject(sourceBox) {
            sx := Max(0,Min(sw-1,sourceBox.x)), sy := Max(0,Min(sh-1,sourceBox.y))
            sourceW := Max(1,Min(sw-sx,sourceBox.w)), sourceH := Max(1,Min(sh-sy,sourceBox.h))
        }
        ratio := Max(w/sourceW,h/sourceH), cw := Round(w/ratio), ch := Round(h/ratio)
        DllCall("gdi32\SetStretchBltMode","Ptr",cropDC,"Int",4)
        DllCall("gdi32\SetBrushOrgEx","Ptr",cropDC,"Int",0,"Int",0,"Ptr",0)
        if !DllCall("gdi32\StretchBlt","Ptr",cropDC,"Int",0,"Int",0,"Int",w,"Int",h,
            "Ptr",srcDC,"Int",sx+Round((sourceW-cw)*Min(1,Max(0,focusX))),
            "Int",sy+Round((sourceH-ch)*Min(1,Max(0,focusY))),"Int",cw,"Int",ch,"UInt",0x00CC0020)
            return 0
        color := Integer("0x" background)
        rgb := ((color & 255)<<16) | (color & 0xFF00) | ((color>>16) & 255)
        brush := DllCall("gdi32\CreateSolidBrush","UInt",rgb,"Ptr")
        rect := Buffer(16,0)
        NumPut("Int",w,"Int",h,rect,8)
        DllCall("user32\FillRect","Ptr",dstDC,"Ptr",rect,"Ptr",brush)
        if !DllCall("msimg32\AlphaBlend","Ptr",dstDC,"Int",0,"Int",0,"Int",w,"Int",h,
            "Ptr",cropDC,"Int",0,"Int",0,"Int",w,"Int",h,"UInt",opacity<<16)
            return 0
        output := result
        result := 0
        return output
    } catch {
        return 0
    } finally {
        if oldSrc
            DllCall("gdi32\SelectObject","Ptr",srcDC,"Ptr",oldSrc)
        if oldDst
            DllCall("gdi32\SelectObject","Ptr",dstDC,"Ptr",oldDst)
        if oldCrop
            DllCall("gdi32\SelectObject","Ptr",cropDC,"Ptr",oldCrop)
        for dc in [srcDC,dstDC,cropDC]
            if dc
                DllCall("gdi32\DeleteDC","Ptr",dc)
        for objectHandle in [source,result,cover,brush]
            if objectHandle
                DllCall("gdi32\DeleteObject","Ptr",objectHandle)
    }
}

DoseBuildBrandBadge(g, releaseVersion) {
    global uiTheme
    g.Add("Text","x14 y644 w78 h2 Background" uiTheme[3],"")
    if (AA_ThemeName() = "Tokyo Ghoul")
        g.SetFont("s14 Norm c" uiTheme[7],DoseHeadingFont())
    else
        g.SetFont("s13 Bold c" uiTheme[7],"Segoe UI")
    g.Add("Text","x15 y650 w80 h24 BackgroundTrans","DOSE")
    g.SetFont("s8 c" uiTheme[1],"Segoe UI")
    g.Add("Text","x16 y675 w78 h15 BackgroundTrans","AA  /  v" releaseVersion)
    g.SetFont("s9 c" uiTheme[1],"Segoe UI")
}

; Load a bundled, redistributable icon-capable font for this process only.
; No system font installation or administrator access is needed.
DoseIconFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\DejaVuSans.ttf"
    family := "Segoe UI Symbol"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "DejaVu Sans"
    }
    return family
}

; Only decorative palette/assets/type change; game transparency and coordinates
; are intentionally outside this data.
DoseThemePalette(name) {
    if (name="Ethereal")
        return {header:"EEF5FA",background:"0B121D",accent:"78B9DA",card:"14212F",
            input:"0B1623",highlight:"B6E9DC",button:"21384A",off:"3B5060",
            on:"78B9DA",divider:"2C485B",art:"DoseEtherealLake.jpg",focusX:0.5}
    return {header:"F2EEE9",background:"0B0C10",accent:"C22A44",card:"15161D",
        input:"0C0D13",highlight:"FF7181",button:"20212B",off:"3A3B46",
        on:"C22A44",divider:"2C2D35",art:"DoseAkatsuki.jpg",focusX:0.5}
}

DoseThemeArtworkPath(name := "", root := "") {
    if (name = "")
        name := AA_ThemeName()
    if (root = "")
        root := A_ScriptDir "\Images\UI"
    return root "\" DoseThemePalette(name).art
}

; A process-private, OFL licensed display face. Body/input fonts remain readable.
DoseHeadingFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\NewRocker-Regular.ttf"
    family := "Segoe UI"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "New Rocker"
    }
    return family
}

DoseStyleHeadings(title,activity) {
    title.Text := "DOSE  /  AA MACRO  " version
    title.SetFont("s12 Bold","Segoe UI")
}

DoseBuildThemeSignature(g,imagePath := "") {
    global uiTheme, AA_CardColor
    DoseDashboardSurface(g,1544,672,228,36,AA_CardColor,16)
    ethereal := AA_ThemeName()="Ethereal"
    label := g.Add("Text","x1556 y676 w204 h28 Background" AA_CardColor " c" uiTheme[7],ethereal ? "ETHEREAL" : "AKATSUKI")
    if ethereal
        label.SetFont("s15 Norm","Georgia")
    else
        label.SetFont("s15 Norm",DoseHeadingFont())
    return label
}


; Faded wallpaper surfaces are decoration only. No new settings, timers, event
; handlers or game overlays. Every crop shares the same 1800x930 canvas so the
; image continues across cards, gutters and the activity area without stretching.
DoseWallpaperSurface(g,x,y,w,h,color,opacity := 62,path := "",cropX := unset,cropY := unset) {
    global DoseWallpaperFile
    if (path="")
        path := IsSet(DoseWallpaperFile) ? DoseWallpaperFile : A_ScriptDir "\Images\UI\DoseItachiBackdrop.png"
    if !FileExist(path)
        return false
    sourceW := AA_ThemeName()="Ethereal" ? 1920 : 860
    sourceH := AA_ThemeName()="Ethereal" ? 1080 : 484
    scale := Max(1800/sourceW,930/sourceH)
    sx := IsSet(cropX) ? cropX : x, sy := IsSet(cropY) ? cropY : y
    box := {x:sx/scale,y:(sourceH-930/scale)/2+sy/scale,w:w/scale,h:h/scale}
    try return DoseBuildArtwork(g,path,x,y,w,h,opacity,color,0.5,box)
    catch
        return false
}

DoseBuildWallpaperMargins(g) {
    global uiTheme, DoseDashboardDecor
    ; Deliberately exclude the complete Roblox viewing rectangle and title row.
    for rect in [[0,632,808,298],[808,31,578,899],[1386,31,414,899]] {
        ctrl := DoseWallpaperSurface(g,rect[1],rect[2],rect[3],rect[4],uiTheme[2],82)
        if IsObject(ctrl)
            DoseDashboardDecor[ctrl.Hwnd] := true
    }
}

DoseBuildUnitWallpaper(g,index,x,y,w,h) {
    global uiTheme
    ; Bitmap dimensions and crop use the unchanged final two-column card bounds.
    ; The same control is moved/shown by the existing layout and profile handlers.
    fx := 824+Mod(index-1,2)*280, fy := 224+((index-1)//2)*152
    ctrl := DoseWallpaperSurface(g,x,y,264,140,uiTheme[4],50,,fx,fy)
    if !IsObject(ctrl)
        ctrl := g.Add("Text",Format("x{} y{} w{} h{} Background{}",x,y,w,h,uiTheme[4]))
    return ctrl
}

DoseThemeWallpaperPath(root := "") {
    if (root="")
        root := A_ScriptDir "\Images\UI"
    return root "\" (AA_ThemeName()="Ethereal" ? "DoseEtherealLake.jpg" : "DoseItachiBackdrop.png")
}
