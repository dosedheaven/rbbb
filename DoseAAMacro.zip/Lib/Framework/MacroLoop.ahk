#Requires AutoHotkey v2.0

; ============================================================================
;  MacroLoop.ahk  -  [Optimised] fixes the crash after running for a long time
; ----------------------------------------------------------------------------
;  Before: each step started the next one from inside itself
;      MonitorStage -> HandleStageEnd -> MonitorEndScreen -> RestartStage -> MonitorStage -> ...
;  None of them ever finished, so every match left more unfinished calls behind
;  until AutoHotkey ran out of room (the error you saw after a long run).
;
;  Now: a step hands off with NextStep(NextFunction). That ends the current step right
;  there, and RunMacroLoop starts the next one. Same steps, same clicks, same
;  order - but only one step is ever running, so nothing piles up.
; ============================================================================

class MacroNextStep extends Error {
    __New(step) {
        super.__New("Macro step hand-off")
        this.Step := step
    }
}

class MacroLoopState {
    static Active := false
}

; Hand off to the next step. Used where the code used to do "return NextFunction()".
NextStep(step) {
    if (MacroLoopState.Active)
        throw MacroNextStep(step)
    return RunMacroLoop(step) ; safety net: not started from StartMacro, run it the normal way
}

; Runs one step at a time. Started once by StartMacro.
RunMacroLoop(step) {
    MacroLoopState.Active := true
    DoseSession.BeginRun()
    FW_OnMacroStart()   ; [Framework] start with no failsafe timers armed
    try {
        try DoseRestoreChestCheckpoint()
        catch MacroStop as stop {
            FW_Log("[Recovery] " stop.Message)
            return
        }
        loop {
            try {
                DoseSession.Enter(step.Name)
                step()
                DoseSession.Trace("returned","Step returned: " step.Name)
                FW_Log("Reconciling screen after " step.Name " returned without a next step")
                NextStep(DoseResumeAfterReturn)
            } catch MacroNextStep as handoff {
                step := handoff.Step
            } catch MacroStop as stop {
                ; [Framework] a failsafe decided the macro should stop (Lib\Framework\Failsafe.ahk)
                FW_Log("[Framework] Macro stopped: " stop.Message)
                return
            } catch Error as err {
                ; [Framework] unexpected runtime error: log it and rejoin, or re-throw when too many
                try step := FW_HandleStepError(err)
                catch MacroStop as stop {
                    FW_Log("[Recovery stopped] " stop.Message)
                    return
                } catch Error as fatal {
                    try DoseCaptureFailure("Recovery error",fatal.Message)
                    FW_Log("[Recovery error] " fatal.Message " - stopped; see local diagnostics")
                    return
                }
            }
        }
    } finally {
        MacroLoopState.Active := false
        DoseSession.phase := "Stopped"
        DoseSession.paused:=false,DoseSession.pauseRequested:=false
    }
}
