#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\Lib\Tools\Image.ahk
; [Modularized] This file keeps the game lifecycle: hotkeys, StartMacro/TogglePause, mode starters,
;   RestartStage, monitors, end screens, lobby/load/vote checks, reconnect/rejoin, stage setup.
;   Placement/upgrades/stage events/navigation/map detection/map movement -> Lib\Game\*.ahk,
;   contracts -> Lib\Modes\Contract.ahk, shared helpers -> Lib\Tools\ and Lib\Functions\.
global macroStartTime := A_TickCount
global stageStartTime := A_TickCount
global contractPageCounter := 0
global contractSwitchPattern := 0

global adaptations := 0
global setMahoragoStyle := false

LoadKeybindSettings()  ; Load saved keybinds
Hotkey(F1Key, (*) => moveRobloxWindow())
Hotkey(F2Key, (*) => StartMacro())
Hotkey(F3Key, (*) => Reload())
Hotkey(F4Key, (*) => TogglePause())

F5:: {

}

F6:: {

}

F7:: {
    Run (A_ScriptDir "\Lib\Tools\FindText.ahk")
}


StartMacro(*) {
    try CP_OverlayHide()   ; [Custom placement] no circles on screen while the macro runs
    if (MacroLoopState.Active) {   ; [Framework] F2 while already running would start a second, interleaved loop
        AddToLog("Macro is already running - press " F3Key " to reload")
        return
    }
    if (!ScheduleStart() && !ValidateMode()){   ; schedule on → it picks the mode, no need to select one
        return
    }
    RunMacroLoop(StartSelectedMode)
} 


TogglePause(*) {
    if !MacroLoopState.Active
        return
    if DoseSession.phase="Map movement" && !DoseSession.paused {
        DoseSession.pauseRequested:=!DoseSession.pauseRequested
        AddToLog(DoseSession.pauseRequested ? "Pause queued until map movement releases its keys" : "Queued pause cancelled")
        return
    }
    DoseSetPaused(!DoseSession.paused,true)
}

GetNameForMode() {
    if (PlacementSelection.Text = "Winter Event") {
        return "event"
    }
    if (PlacementSelection.Text = "Fool's Hunt") {
        return "event"
    }
    if (PlacementSelection.Text = "Default") {
        return ""
    }
    return PlacementSelection.Text
}

ChallengeMode(overrides := 0) {
    try DoseSession.phase:="Challenge entry"
    global FW_EntranceTimeoutMs,WF_LastIssue
    options := {menuMs:30000,departureMs:45000,pollMs:250,choiceSettleMs:250,startRetryMs:1500,maxStartClicks:3}
    if IsObject(overrides)
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    if DungeonChestExitBlocked() {
        AddToLog("Challenge deferred: unfinished boss chests still own the screen")
        return false
    }
    if !WF_PrepareDungeon() {
        AddToLog("Challenge window not ready; no movement or Play Now sent")
        return false
    }
    StageGuard.Arm("Entrance",FW_EntranceTimeoutMs)
    try {
        visible := ChallengeEntryMenuVisible()
        if (WF_LastIssue!="")
            return false
        if !visible {
            AddToLog("Moving to Challenge area")
            ChallengeMovement()
        }
        started := DoseActiveTick()
        Loop {
            if ChallengeEntryMenuVisible()
                break
            if (WF_LastIssue!="") {
                AddToLog("Challenge menu unreadable; no solo/matchmaking input sent")
                return false
            }
            if (DoseActiveTick()-started>=options.menuMs) {
                AddToLog("Challenge menu not found after movement; stopped without walking again")
                return false
            }
            Reconnect()
            StageGuard.Check("Entrance","Challenge menu did not appear")
            Sleep(options.pollMs)
        }
        if !ChallengeStartPromptVisible(&startX,&startY) {
            if (WF_LastIssue!="")
                return false
            AddToLog("Challenge: selecting Play Now (solo)")
            if !ChallengeSelectPlayNow(options)
                return false
        } else
            AddToLog("Challenge Start queue already open; skipping Play Now")
        if !ChallengeConfirmSoloDeparture(options) {
            AddToLog("Challenge solo launch not confirmed; no map-loading handoff")
            return false
        }
        AddToLog("Challenge solo departure confirmed; waiting for the map")
        return NextStep(RestartStage)
    } finally {
        StageGuard.Disarm("Entrance")
    }
}

ChallengeStartPromptVisible(&X,&Y) {
    global WF_LastIssue
    if WF_FindText(&X,&Y,200,350,620,545,0.03,0.03,ChallengeStartText)
        return true
    if (WF_LastIssue!="")
        return false
    return WF_FindText(&X,&Y,200,350,620,545,0.03,0.03,StartStoryButton)
}

ChallengePlayHereVisible(&X,&Y) {
    return WF_FindText(&X,&Y,180,180,610,430,0.03,0.03,ChallengePlayHereText)
}

ChallengeEntryMenuVisible() {
    global WF_LastIssue
    if ChallengeStartPromptVisible(&X,&Y)
        return true
    if (WF_LastIssue!="")
        return false
    if ChallengePlayHereVisible(&X,&Y)
        return true
    if (WF_LastIssue!="")
        return false
    if WF_FindText(&X,&Y,325,520,489,587,0.03,0.03,ModeCancel)
        return true
    if (WF_LastIssue!="")
        return false
    return WF_FindText(&X,&Y,230,200,610,470,0.03,0.03,MatchMakingText)
}

; Keep the known Play Now client points, but do not call the shared Story
; helper's delayed Start loop or trailing clicks after Challenge has launched.
ChallengeSelectPlayNow(options) {
    global WF_LastIssue
    if ChallengeStartPromptVisible(&X,&Y)
        return true
    if (WF_LastIssue!="")
        return false
    ; The current Join Matchmaking popup has Play Here / Find Match tiles.
    ; Match its solo lettering and use the detected center, including on resume.
    if ChallengePlayHereVisible(&X,&Y)
        return WF_RobloxClick(X,Y)
    if (WF_LastIssue!="")
        return false
    choice := WF_FindText(&X,&Y,230,200,610,470,0.03,0.03,MatchMakingText)
    if (WF_LastIssue!="")
        return false
    if !choice {
        if !ChallengeClickClient(400,435)
            return false
        Sleep(options.choiceSettleMs)
        if ChallengeStartPromptVisible(&X,&Y)
            return true
        if (WF_LastIssue!="")
            return false
        if ChallengePlayHereVisible(&X,&Y)
            return WF_RobloxClick(X,Y)
        if (WF_LastIssue!="")
            return false
    }
    ; Preserve the existing older choice layout when its references are used.
    return ChallengeClickClient(330,325)
}

ChallengeClickClient(x,y) {
    global rblxID
    try {
        hwnd := WinExist(rblxID),point := Buffer(8,0)
        NumPut("Int",x,"Int",y,point)
        if !hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int")
            return false
        FT_GetOffset(&dx,&dy)
        return WF_RobloxClick(NumGet(point,0,"Int")-dx,NumGet(point,4,"Int")-dy)
    } catch {
        return false
    }
}

ChallengeConfirmSoloDeparture(options) {
    global WF_LastIssue
    started := DoseActiveTick(),absent := 0,starts := 0,lastStart := 0,limitLogged := false
    while (DoseActiveTick()-started<options.departureMs) {
        if WF_FindText(&X,&Y,301,64,503,154,0.03,0.03,VoteStart)
            return true
        if (WF_LastIssue!="")
            return false
        if ChallengeStartPromptVisible(&X,&Y) {
            absent := 0
            if (starts<options.maxStartClicks && (!lastStart || DoseActiveTick()-lastStart>=options.startRetryMs)) {
                ; Fresh match: click its true calibrated center, with no -35
                ; offset and no inferred coordinate from the uploaded crop.
                if ChallengeStartPromptVisible(&X,&Y) {
                    if !WF_RobloxClick(X,Y)
                        return false
                    starts += 1,lastStart := DoseActiveTick()
                    AddToLog("Challenge: Start click " starts "/" options.maxStartClicks "; waiting for queue departure")
                } else if (WF_LastIssue!="")
                    return false
            } else if (starts>=options.maxStartClicks && !limitLogged) {
                AddToLog("Challenge Start retry limit reached; no Cancel/matchmaking fallback")
                limitLogged := true
            }
        } else {
            if (WF_LastIssue!="")
                return false
            menu := ChallengeEntryMenuVisible()
            if (WF_LastIssue!="")
                return false
            lobby := WF_FindText(&X,&Y,746,514,789,530,0.000001,0.000001,AreaText)
            if (WF_LastIssue!="")
                return false
            ; Blank frames between Play Now and Start must NOT count as joined.
            absent := (starts>0 && !menu && !lobby) ? absent+1 : 0
            if (absent>=2)
                return true
        }
        Reconnect()
        StageGuard.Check("Entrance","Challenge Start/solo queue did not leave the lobby")
        Sleep(options.pollMs)
    }
    return false
}

StoryMode() {
    global StoryDropdown, StoryActDropdown
    
    ; Get current map and act
    currentStoryMap := StoryDropdown.Text
    currentStoryAct := StoryActDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for " currentStoryMap)
    if (Random(1, 2) = 1) {
        StoryMovement()
    } else {
        OppositeStoryMovement()
    }
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Story entrance not reached")   ; [Framework]
        if (Random(1, 2) = 1) {
            StoryMovement()
        } else {
            OppositeStoryMovement()
        }
    }
    AddToLog("Starting " currentStoryMap " - " currentStoryAct)
    
    if (StoryUINav.Value) {
        StartStory(currentStoryMap, currentStoryAct)
    } else {
        StartStoryNoUINavigation(currentStoryMap, currentStoryAct)
    }

    ; Handle play mode selection
    if (StoryActDropdown.Text != "Infinity") {
        PlayHere()  ; Always PlayHere for normal story acts
    } else {
        if (MatchMaking.Value) {
            FindMatch()
        } else {
            PlayHere()
        }
    }

    NextStep(RestartStage)
}


LegendMode() {
    global LegendDropdown, LegendActDropdown
    
    ; Get current map and act
    currentLegendMap := LegendDropdown.Text
    currentLegendAct := LegendActDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for " currentLegendMap)
    StoryMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Legend entrance not reached")   ; [Framework]
        StoryMovement()
    }
    AddToLog("Starting " currentLegendMap " - " currentLegendAct)
    if (StoryUINav.Value) {
        StartLegend(currentLegendMap, currentLegendAct)
    } else {
        StartLegendNoUINavigation(currentLegendMap, currentLegendAct)
    }

    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    NextStep(RestartStage)
}

RaidMode() {
    global RaidDropdown, RaidActDropdown
    
    ; Get current map and act
    currentRaidMap := RaidDropdown.Text
    currentRaidAct := RaidActDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for " currentRaidMap)
    RaidMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Raid entrance not reached")   ; [Framework]
        RaidMovement()
    }
    AddToLog("Starting " currentRaidMap " - " currentRaidAct)
    if (StoryUINav.Value) {
        StartRaid(currentRaidMap, currentRaidAct)
    } else {
        StartRaidNoUINavigation(currentRaidMap, currentRaidAct)
    }
    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    NextStep(RestartStage)
}

InfinityCastleMode() {
    global InfinityCastleDropdown
    
    ; Get current difficulty
    currentDifficulty := InfinityCastleDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for Infinity Castle")
    InfCastleMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Infinity Castle entrance not reached")   ; [Framework]
        InfCastleMovement()
    }
    AddToLog("Starting Infinity Castle - " currentDifficulty)

    ; Select difficulty with direct clicks
    if (currentDifficulty = "Normal") {
        FixClick(418, 375)  ; Click Easy Mode
    } else {
        FixClick(485, 375)  ; Click Hard Mode
    }
    
    ;Start Inf Castle
    if (ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        ClickUntilGone(0, 0, 325, 520, 489, 587, ModeCancel, -10, -120)
    }

    NextStep(RestartStage)
}

FoolsEvent() {
    ; Execute the movement pattern
    AddToLog("Moving to position for Fool's Hunt")
    EventMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok:=FT(&X, &Y, 468-150000, 386-150000, 468+150000, 386+150000, 0, 0, JoinMatchmaking)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Fool's Hunt entrance not reached")   ; [Framework]
        EventMovement()
    }

    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    AddToLog("Starting Fool's Hunt")
    NextStep(RestartStage)
}

CursedWombMode() {
    AddToLog("Moving to Cursed womb")
    CursedWombMovement()

    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 445, 440, 650, 487, 0, 0, Capacity)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Cursed Womb entrance not reached")   ; [Framework]
        if (ok := FT(&X, &Y, 434-150000, 383-150000, 434+150000, 383+150000, 0, 0, RobuxPurchaseKey)) {
            AddToLog("Found Key Purchase Attempt")
            Sleep 50000
        }
        CursedWombMovement()
    }

    FixClick(500, 190)
    for char in StrSplit("Key (Cursed Womb)") {
    Send char
    Sleep (100)
    } 
    sleep (1000)
    FixClick(215, 285)
    sleep (500)
    FixClick(345, 370)
    sleep (500)
    
    NextStep(RestartStage)
}

ContractMode() {
   Sleep(2500)
   FixClick(33, 400)
   Sleep(2500)
   HandleContractJoin()
   Sleep(2500)
   NextStep(RestartStage)
}

PortalMode() {
    HandlePortalJoin()
    Sleep(2500)
    NextStep(RestartStage)
}

DungeonMode() {
    try DoseSession.phase:="Entering dungeon"
    AddToLog("Entering Dungeon Mode")
    if !DungeonStartEntrance()
        return false
    return LookForDungeonRooms()
}

CheckForReturnToLobby() {
    ; Compatibility observer: all recognition belongs to the results controller.
    evidence:=DoseResultsEvidence()
    return evidence.kind!="Blocked" && evidence.navigation
}

CheckForNextText() {
    ; Compatibility observer: all recognition belongs to the results controller.
    evidence:=DoseResultsEvidence()
    return evidence.kind!="Blocked" && evidence.next
}

MonitorEndScreen() {
    global mode, StoryDropdown, StoryActDropdown, ReturnLobbyBox, MatchMaking, challengeStartTime, inChallengeMode

    lastResult:=IsObject(DoseSession.results) ? DoseSession.results.outcome : ""
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(3000)  
        StageGuard.Check("EndScreen", "end screen not handled")   ; [Framework]
        
        evidence:=DoseResultsEvidence()
        if evidence.kind="Chest"
            return NextStep(DoseResumeChestSession)
        if evidence.kind="Shop" || evidence.kind="Shrine"
            return NextStep(DoseResumeDungeonMenu)
        if !evidence.navigation && (evidence.next || evidence.xp || evidence.unit)
            return NextStep(DoseProcessStageResults)
        ; Navigation adapters send only their mode-specific action, after the
        ; shared controller has recorded the outcome and verified the screen.
        if evidence.navigation {
            AddToLog("Found Lobby Text - Current Mode: " (inChallengeMode ? "Challenge" : mode))
            Sleep(2000)
            if (!inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                 AddToLog("Challenge completed - returning to " mode " mode")
                inChallengeMode := false
                challengeStartTime := A_TickCount
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Check if it's time for challenge mode
            if (!inChallengeMode && ChallengeBox.Value) {
                if (DoseAutoChallengeDue()) {
                    AddToLog("30 minutes passed - switching to Challenge mode")
                    inChallengeMode := true
                    challengeStartTime := A_TickCount
                    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                    return NextStep(CheckLobby)
                }
            }

            if (mode = "Story") {
                AddToLog("Handling Story mode end")
                if (StoryActDropdown.Text != "Infinity") {
                    if (NextLevelBox.Value && lastResult = "win") {
                        AddToLog("Next level")
                        ClickNextLevel()
                    } else {
                        AddToLog("Replay level")
                        ClickReplay()
                    }
                } else {
                    if (PortalSwap.Value && GetMapForFarming(StoryDropdown.Text) != "no map found") {
                        SwitchActiveFarm()
                        Sleep(1500)
                        ClickReturnToLobby()
                        return NextStep(CheckLobby)
                    } else if (ReturnLobbyBox.Value) {
                        AddToLog("Return to lobby")
                        ClickReturnToLobby()
                        return NextStep(CheckLobby)
                    } else {
                        AddToLog("Story Infinity replay")
                        ClickReplay()
                    }
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Raid") {
                AddToLog("Handling Raid end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replay raid")
                    ClickReplay()
                    return NextStep(RestartStage)
                }
            }
            else if (mode = "Dungeon") {
                AddToLog("Handling Dungeon end")
                return NextStep(MonitorDungeonEnd)
            }
            else if (mode = "Infinity Castle") {
                AddToLog("Handling Infinity Castle end")
                if (lastResult = "win") {
                    AddToLog("Next floor")
                    ClickReplay() ; Uses the replay coords for next level
                } else {
                    AddToLog("Restart floor")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Cursed Womb") {
                AddToLog("Handling Cursed Womb End")
                AddToLog("Returning to lobby")
                ClickReturnToLobby()
                return NextStep(CheckLobby)
            }
            else if (mode = "Fool's Hunt") {
                AddToLog("Handling Fool's Hunt end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Winter Event") {
                AddToLog("Handling Winter Event end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else {
                AddToLog("Handling end case")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                    return NextStep(RestartStage)
                }
            }
        }
        Reconnect()
    }
}


MonitorStage() {
    global mode,StoryActDropdown
    lastClickTime:=A_TickCount,lastUnitClose:=0,unitClicks:=0
    DoseSession.phase:="Playing"
    Loop {
        e:=DoseResultsEvidence()
        if e.kind="Chest"
            return NextStep(DoseResumeChestSession)
        if e.kind="Shop" || e.kind="Shrine"
            return NextStep(DoseResumeDungeonMenu)
        if e.outcome!="" || e.navigation || e.xp || e.next {
            DoseSession.ExpectResults("stage monitor",e)
            return NextStep(DoseProcessStageResults)
        }
        StageGuard.Check("Stage","stage took too long")
        if e.unit && unitClicks<3 && (!lastUnitClose || A_TickCount-lastUnitClose>=1500) {
            p:=e.points["unit"]
            if WF_RobloxClick(p.x,p.y)
                lastUnitClose:=A_TickCount,unitClicks+=1
        }
        if !e.unit
            unitClicks:=0
        if (mode="Story" && StoryActDropdown.Text="Infinity") || mode="Winter Event" {
            if A_TickCount-lastClickTime>=30000 {
                AddToLog("Performing anti-AFK click")
                FixClick(560,560),lastClickTime:=A_TickCount
            }
        }
        if mode="Winter Event" || mode="Fool's Hunt"
            CheckForCardSelection()
        CheckForMahoraga(),CheckForMahoragaAdaptation()
        Reconnect()
        Sleep(750)
    }
}

PerformAntiAFK(lastClickTime) {
    if (A_TickCount - lastClickTime >= 60000) {
        AddToLog("Performing anti-AFK click")
        Loop 3 {
            FixClick(560, 560)
        }
        return A_TickCount ; Return the updated lastClickTime
    }
}

HandleStageEnd() {
    return DoseProcessStageResults()
}

Zoom() {
    MouseMove(400, 300)
    Sleep 100

    ; Zoom in smoothly
    Loop 10 {
        Send "{WheelUp}"
        Sleep 50
    }

    ; Look down
    Click
    MouseMove(400, 400)  ; Move mouse down to angle camera down
    
    ; Zoom back out smoothly
    Loop 20 {
        Send "{WheelDown}"
        Sleep 50
    }
    
    ; Move mouse back to center
    MouseMove(400, 300)
}

TpSpawn() {
    FixClick(26, 570) ;click settings
    Sleep 300
    FixClick(400, 215)
    Sleep 300
    loop 6 {
        Sleep 150
        SendInput("{WheelDown 1}") ;scroll
    }
    Sleep 300
    if (ok := FT(&X, &Y, 215, 160, 596, 480, 0.20, 0.20, Spawn)) {
        AddToLog("Found Teleport to Spawn button")
        FixClick(X + 100, Y - 30)
        Sleep(1200)
        DoseSession.Trace("spawn","Reset sent; settling before movement")
    } else {
        AddToLog("Could not find Teleport button")
    }
    Sleep 300
    FixClick(583, 147)
    Sleep 300

    ;
}

TpLobby() {
    FixClick(26, 570) ;click settings
    Sleep 300
    FixClick(400, 215)
    Sleep 300
    loop 4 {
        Sleep 250
        SendInput("{WheelDown 1}") ;scroll
    }
    Sleep 300
    if (ok := FT(&X, &Y, 233, 424, 567, 471, 0.20, 0.20, ReturnToLobbySettings)) {
        AddToLog("Found Teleport to Lobby button")
        FixClick(X + 150, Y - 30)
    } else {
        AddToLog("Could not find Teleport button")
    }
    Sleep 300
    FixClick(525, 415)
    Sleep 300
    return NextStep(CheckLobby)
}

CloseChat() {
    if (ok := FT(&X, &Y, 123, 50, 156, 79, 0, 0, OpenChat)) {
        AddToLog "Closing Chat"
        FixClick(138, 30) ;close chat
    }
}

BasicSetup() {
    SendInput("{Tab}") ; Closes Player leaderboard
    Sleep 1000
    FixClick(569, 72) ; Closes Player leaderboard
    Sleep 1000
    FixClick(569, 72) ; Closes Player leaderboard
    Sleep 300
    CloseChat()
    Sleep 300
    Zoom()
    Sleep 300
    TpSpawn()
}
    
RestartStage() {
    global adaptations, setMahoragoStyle, inChallengeMode

    adaptations := 0
    setMahoragoStyle := false

    currentMap := (ModeDropdown.Text = "Fool's Hunt") ? DetectHuntMap() : DetectMapImageSearch() ;(ModeDropdown.Text = "Dungeon") ? DetectMapImageSearch() : DetectMap() backup
    DoseSession.BeginStage(currentMap)
    CP_SetStageMap(currentMap)   ; [Custom placement] which map's spots to use
    
    if (ModeDropdown.Text = "Fool's Hunt") {
        if (BringUnits.Value) {
            CoordMode("Mouse", "Window")
            ClickAndHoldExit()
            CoordMode("Mouse", "Client")
            Sleep(1000)
        }
    }

    ; Wait for loading
    CheckLoaded()

    if (!inChallengeMode) {
        if (!IsCorrectMap(currentMap)) {
            AddToLog("Incorrect map detected, teleporting to lobby")
            return TpLobby()
        }
    }

    if (ModeDropdown.Text = "Fool's Hunt") {
        if (MatchMaking.Value) {
            if (ShouldSkipMap(currentMap)) {
                AddToLog("Map is set to be skipped: " currentMap ", returning to lobby")
                return TpLobby()
            }
        }
    }

    ; Do initial setup and map-specific movement during vote timer
    BasicSetup()
    
    if currentMap!="no map found"
        DoseRunStageMovement(currentMap)

    ; Wait for game to actually start
    StartedGame()
    StageGuard.Arm("Stage", FW_StageGuardApplies() ? FW_StageTimeoutMs : 0)   ; [Framework] not armed for Story Infinity / Winter Event

    CP_HandleRecording(currentMap)   ; [Custom placement] record mode: you click the spots, then the macro stops

    ; Begin unit placement and management
    if (NewPlacementMethod.Visible && NewPlacementMethod.Value) { ; For April Fools Event
        PlaceFoolUnits()
    } else {
        PlacingUnits()
    }
    
    ; Monitor stage progress
    NextStep(MonitorStage)
}

Reconnect() {
    return DoseConnectionCheck()
}

RejoinPrivateServer() {
    return DoseRejoin()
}

CheckForXp(closeLeaderboard := false) {
    ; Compatibility observer: all recognition belongs to the results controller.
    evidence:=DoseResultsEvidence()
    return evidence.kind!="Blocked" && evidence.xp
}

CheckLobby() {
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("Lobby", FW_LobbyTimeoutMs)   ; [Framework]
    loop {
        Sleep 1000
        StageGuard.Check("Lobby", "lobby not reached")   ; [Framework]
        if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
            break
        }
        if (CheckForEndGameScreens()) {
            return NextStep(MonitorStage)
        }
        Reconnect()
    }
    Sleep(SleepTime())
    AddToLog("Returned to lobby, restarting selected mode")
    return NextStep(StartSelectedMode)
}

CheckForEndGameScreens() {
    return DoseRouteStageEnd("lobby reconciliation")
}

CheckForLobbyText() {
    if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
        return true
    }
    return false
}

CheckForLobby() {
    loop {
        Sleep 1000
        if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
            break
        }
        Reconnect()
    }
    AddToLog("Returned to lobby.")
    return true
}

CheckLoaded() {
    StageGuard.Arm("Load", FW_LoadTimeoutMs)   ; [Framework]
    loop {
        Sleep(1000)
        StageGuard.Check("Load", "stage did not load")   ; [Framework]
        
        ; Check for vote screen 742, 287, 832, 377
        if (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStart) or (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStartLaptop) or (ok := FT(&X, &Y, 700, 260, 805, 400, 0.10, 0.10, Units) or (ok := FT(&X, &Y, 10, 40, 790, 620, 0, 0, UnitManager) or PixelGetColor(320, 60) = 0x00EE00)))) {
            AddToLog("Successfully Loaded In")
            Sleep(1000)
            break
        } 
;13, 263, 89, 334
        Reconnect()
    }
}

StartedGame() {
    StageGuard.Arm("Vote", FW_VoteTimeoutMs)   ; [Framework]
    loop {
        Sleep(1000)
        StageGuard.Check("Vote", "vote screen did not close")   ; [Framework]
        if (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStart) or (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStartLaptop))) {
            FixClick(350, 103) ; click yes
            FixClick(350, 100)
            FixClick(350, 97)
            continue  ; Keep waiting if vote screen is still there
        }
        
        ; If we don't see vote screen anymore the game has started
        AddToLog("Game started")
        global stageStartTime := A_TickCount
        break
    }
}

StartSelectedMode() {
    if DungeonChestExitBlocked()
        return NextStep(DoseResumeChestSession)
    known:=DoseDungeonScreenStep()
    if IsObject(known)
        return NextStep(known)
    DoseRouteStageEnd("start reconciliation")
    global inChallengeMode, firstStartup, challengeStartTime
    FixClick(400,340)
    FixClick(400,390)
    CloseChat()

    ; Also check at a verified lobby after final-boss rewards. Normal floor
    ; switches remain in the mode-specific end-navigation adapters.
    if (!firstStartup && DoseAutoChallengeDue() && CheckForLobbyText()) {
        AddToLog("Challenge due at lobby - entering before the next farming run")
        inChallengeMode:=true
        challengeStartTime:=A_TickCount
    }

    if (ChallengeBox.Value && firstStartup) {
        AddToLog("Auto Challenge enabled - starting with challenge")
        inChallengeMode := true
        firstStartup := false
        challengeStartTime := A_TickCount  ; Set initial challenge time
        ChallengeMode()
        return
    }

    if (!inChallengeMode)
        Sched_RunPendingTeamSwap()   ; [Scheduler team swap] equip the scheduled step's team while still in the lobby

    ; If we're in challenge mode, do challenge
    if (inChallengeMode) {
        AddToLog("Starting Challenge Mode")
        ChallengeMode()
        return
    }    
    else if (ModeDropdown.Text = "Story") {
        StoryMode()
    }
    else if (ModeDropdown.Text = "Legend") {
        LegendMode()
    }
    else if (ModeDropdown.Text = "Raid") {
        RaidMode()
    }
    else if (ModeDropdown.Text = "Infinity Castle") {
        InfinityCastleMode()
    }
    else if (ModeDropdown.Text = "Contract") {
        if (contractsEnabled) {
            ContractMode()
        } else {
            AddToLog("Contracts are is not currently in Anime Adventures!")
        }
    }
    else if (ModeDropdown.Text = "Fool's Hunt") {
        FoolsEvent()
    }
    else if (ModeDropdown.Text = "Winter Event") {
        if (isWinter) {
            WinterEvent()
        } else {
            AddToLog("The Winter Event is not currently in Anime Adventures!")
        }
    }
    else if (ModeDropdown.Text = "Cursed Womb") {
        CursedWombMode()
    }
    else if (ModeDropdown.Text = "Portal") {
        PortalMode()
    }
    else if (ModeDropdown.Text = "Dungeon") {
        DungeonMode()
    }
}

ValidateMode() {
    if (ModeDropdown.Text = "") {
        AddToLog("Please select a gamemode before starting the macro!")
        return false
    }
    if (!confirmClicked) {
        AddToLog("Please click the confirm button before starting the macro!")
        return false
    }
    return true
}

GetNavKeys() {
    return StrSplit(FileExist("Settings\UINavigation.txt") ? FileRead("Settings\UINavigation.txt", "UTF-8") : "\,#,}", ",")
}

CheckEndAndRoute() {
    return DoseRouteStageEnd("stage/post-upgrade check")
}

SleepTime() {
    time := [0, 5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000]  ; Array of sleep values
    timeIndex := LobbySleepTimer.Value  ; Get the selected speed value

    if timeIndex is number  ; Ensure it's a number
        return time[timeIndex]  ; Use the value directly from the array
}

ClickReplay() {
    FixClick(480,121)
    sleep 1000
    FixClick(480,121)
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, Replay, 0, -35, RetryBackup)
}

ClickNextLevel() {
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, Nextlevelforstory, 0, -35)
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, NextLevel, 0, -35, NextRoomInf)
    FixClick(480,121)
    sleep 1000
    FixClick(480,121)
}

ClickReturnToLobby() {
    FixClick(200,121)
    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
}

ClickStartStory() {
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, StartStoryButton, 0, -35)
}

CheckForRobloxApp() {
    return FT(&X, &Y, 14, 55, 57, 115, 0, 0, RobloxApp) ? true : false
}

CheckForNotification() {
    return FT(&X, &Y, 748, 94, 778, 551, 0, 0, ExitNotification) ? true : false
}