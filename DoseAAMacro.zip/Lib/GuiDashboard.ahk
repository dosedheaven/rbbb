#Requires AutoHotkey v2.0

; Operator console. Coordinates are device pixels: Roblox's capture rectangle
; remains fixed across Windows display scaling, independent of GUI font sizes.
global DoseDashboardWidth:=1800,DoseDashboardHeight:=930
 global DoseDashboardDecor:=Map(),DoseUnitsButton:="",DoseConsoleInfo:="",DoseConsoleMap:=""
 global DoseConsoleProfile:="",DoseConsoleAction:="",DoseConsoleRun:="",DoseConsolePause:=""
 global DoseConsoleStop:="",DoseConsolePhase:="",DoseConsoleHint:="",DoseConsoleNav:=[],DoseConsoleChangeMode:="",DoseConsoleChallenge:=""

DoseRoundControl(ctrl,radius:=12) {
    r:=Buffer(16,0)
    if !DllCall("user32\GetClientRect","Ptr",ctrl.Hwnd,"Ptr",r)
        return
    region:=DllCall("gdi32\CreateRoundRectRgn","Int",0,"Int",0,"Int",NumGet(r,8,"Int")+1,"Int",NumGet(r,12,"Int")+1,"Int",radius,"Int",radius,"Ptr")
    if region && !DllCall("user32\SetWindowRgn","Ptr",ctrl.Hwnd,"Ptr",region,"Int",true)
        DllCall("gdi32\DeleteObject","Ptr",region)
}

DoseDashboardSurface(g,x,y,w,h,color,radius:=16,wallpaper:=false) {
    c:=g.Add("Text",Format("x{} y{} w{} h{} Background{}",x,y,w,h,color))
    DoseDashboardDecor[c.Hwnd]:=true
    DoseRoundControl(c,radius)
    return c
}

DoseBuildDashboardSurfaces(g) {
    DoseDashboardSurface(g,812,40,132,878,"101824",18)
    DoseDashboardSurface(g,956,48,564,96,AA_CardColor,18)
    DoseDashboardSurface(g,956,648,564,68,AA_CardColor,18)
    DoseDashboardSurface(g,956,728,564,186,AA_CardColor,18)
    DoseDashboardSurface(g,16,644,776,64,AA_CardColor,18)
    DoseDashboardSurface(g,16,720,776,194,AA_CardColor,18)
    DoseDashboardSurface(g,1532,48,252,672,AA_CardColor,18)
    DoseDashboardSurface(g,1532,732,252,182,AA_CardColor,18)
}

DoseDashboardMove(ctrl,x,y,w:=unset,h:=unset) {
    if IsSet(w) && IsSet(h)
        ctrl.Move(x,y,w,h)
    else if IsSet(w)
        ctrl.Move(x,y,w)
    else
        ctrl.Move(x,y)
}

DoseDashboardTextHeight(ctrl,width) {
    dc:=DllCall("user32\GetDC","Ptr",ctrl.Hwnd,"Ptr")
    font:=SendMessage(0x31,0,0,ctrl.Hwnd),old:=DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",font,"Ptr")
    rect:=Buffer(16,0),height:=0
    NumPut("Int",width,rect,8)
    style:=DllCall("user32\GetWindowLongW","Ptr",ctrl.Hwnd,"Int",-16,"UInt")
    height:=DllCall("user32\DrawTextW","Ptr",dc,"Str",ctrl.Text,"Int",-1,"Ptr",rect,"UInt",(style & 0x200) ? 0x420 : 0x410)
    DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",old)
    DllCall("user32\ReleaseDC","Ptr",ctrl.Hwnd,"Ptr",dc)
    return height
}

DoseDashboardPanelControl(ctrl) {
    ctrl.GetPos(&x,&y,&w,&h)
    ny:=176+Round((y-85)*1.5),nx:=x+152
    if ctrl.Type="DDL" || ctrl.Type="ComboBox"
        ctrl.Move(nx,ny,w)
    else {
        nh:=Max(h,Round(h*1.5))
        if ctrl.Type="Text" && ctrl.Text!="" {
            needed:=DoseDashboardTextHeight(ctrl,w)
            if needed>nh && needed<=nh+6
                nh:=needed
        }
        ctrl.Move(nx,ny,w,nh)
    }
}

DoseApplyDashboardLayout() {
    global DoseUnitsButton,DoseConsoleNav,DoseConsoleRun,DoseConsolePause,DoseConsoleStop
    global DoseConsolePhase,DoseConsoleMap,DoseConsoleProfile,DoseConsoleAction,DoseConsoleHint,DoseConsoleChangeMode,DoseConsoleChallenge
    panels:=Map(),unitBackgrounds:=Map()
    for name,controls in AA_Panels
        for c in controls
            panels[c.Hwnd]:=true
    for unit in UnitData
        unitBackgrounds[unit.Background.Hwnd]:=true
    for c in [process1,process2,process3,process4,process5,process6,process7]
        unitBackgrounds[c.Hwnd]:=true
    for hwnd,c in aaMainUI {
        if c.Type="Text" && c.Text="" && c!=robloxHolder && !panels.Has(hwnd) && !unitBackgrounds.Has(hwnd) && !DoseDashboardDecor.Has(hwnd)
            c.Visible:=false
        if c.Type="Text" && (c.Text="DOSE" || RegExMatch(c.Text,"^AA  /  v"))
            c.Visible:=false
    }
    for name,controls in AA_Panels
        for c in controls
            DoseDashboardPanelControl(c)
    Loop 6 {
        i:=A_Index,x:=960+Mod(i-1,2)*280,y:=176+((i-1)//2)*152,u:=UnitData[i]
        for key in ["BorderTop","BorderBottom","BorderLeft","BorderRight","Divider","CornerTL","CornerTLV","CornerBR","CornerBRV"]
            if u.HasOwnProp(key) {
                u.%key%.Visible:=false
                u.DeleteProp(key)
            }
        u.Background.Move(x,y,264,140),DoseRoundControl(u.Background,16)
        u.Title.Move(x+36,y+12,86,24)
        u.UpgradeText.Move(x+130,y+15,106,18)
        u.PlacementText.Move(x+16,y+49,118,20)
        u.PriorityText.Move(x+16,y+77,118,20)
        u.LimitText.Move(x+16,y+105,100,20)
        for label in [u.Title,u.PlacementText,u.PriorityText,u.UpgradeText,u.LimitText]
            label.Opt("+BackgroundTrans")
        spots:=[[14,12,0],[154,45,88],[154,73,88],[240,12,0],[125,104,0],[154,101,88]]
        for names in AA_UnitProfiles
            for k,name in names {
                ctrlName:=name i,c:=%ctrlName%
                if spots[k][3]
                    c.Move(x+spots[k][1],y+spots[k][2],spots[k][3])
                else
                    c.Move(x+spots[k][1],y+spots[k][2],20,20)
            }
    }
    aaMainUI.SetFont("s9 Bold c" uiTheme[1],"Segoe UI")
    DoseUnitsButton:=AA_Btn(aaMainUI,"x824 y110 w108 h38","Unit profiles")
    DoseUnitsButton.OnEvent("Click",(*)=>AA_ShowPanel(""))
    DoseConsoleNav:=[DoseUnitsButton,SettingsBtn,CustomPlacementBtn,CustomMovementBtn,SchedulerBtn,DebugButton,guideBtn,MaharagaButton]
    captions:=["Unit profiles","Settings","Placement","Map movement","Scheduler","Detection","Guide","Adaptations"]
    for i,c in DoseConsoleNav {
        c.Move(824,110+(i-1)*50,108,38),c.Text:=captions[i]
        c.SetFont("s9 Bold","Segoe UI")
    }
    DoseConsoleNav.Push(EditRoute),DoseConsoleNav.Push(EditMaps),DoseConsoleNav.Push(EditCardPrio)
    aaMainUI.Add("Text","x828 y64 w102 h22 BackgroundTrans c" uiTheme[7],"CONSOLE")
    aaMainUI.SetFont("s8 Norm c" uiTheme[1],"Segoe UI")
    aaMainUI.Add("Text","x826 y530 w108 h104 BackgroundTrans","Separate profiles.`n`nAuto Challenge uses its Challenge profile.")
    aaMainUI.Add("Text","x826 y816 w108 h64 BackgroundTrans","F1  Position`nF2  Start`nF3  Stop / reload`nF4  Pause")
    DoseConsoleChallenge:=aaMainUI.Add("Text","x826 y770 w108 h36 BackgroundTrans","Auto Challenge off")
    windowTitle.Move(22,4,320,26),windowTitle.Text:="DOSE  /  CONTROL ROOM  " version
    AA_StatusDot.Move(352,5,16,20),AA_StatusText.Move(374,8,1140,18)
    minimizeButton.Move(1712,2,32,26),exitButton.Move(1754,2,32,26)

    modeSelectionGroup.Move(976,61,440,18)
    for c in [ModeDropdown,StoryDropdown,StoryActDropdown,LegendDropDown,LegendActDropdown,RaidDropdown,RaidActDropdown,InfinityCastleDropdown,PortalDropdown,PortalJoinDropdown,ContractPageDropdown,ContractJoinDropdown,ConfirmButton] {
        c.GetPos(&x,&y,&w,&h)
        c.Move(x+152,92,w)
    }
    Hotkeytext.Move(976,61,440,18),Hotkeytext.Text:="RUN CONFIGURATION"
    Hotkeytext2.Move(976,92,524,28)
    Hotkeytext2.Text:="Pause to edit configuration • Start when ready"
    for c in [Hotkeytext,Hotkeytext2,modeSelectionGroup]
        c.Opt("+Background" AA_CardColor)
    labels:=[PlacementSelectionText,PlacementPatternText,PlaceSpeedText,LobbySleepText]
    fields:=[PlacementSelection,PlacementPatternDropdown,PlaceSpeed,LobbySleepTimer]
    alabels:=[FirstAdaptationText,SecondAdaptationText,FinalAdaptationText,MahoragoModeText]
    afields:=[FirstAdaptation,SecondAdaptation,FinalAdaptation,MahoragoMode]
    shortLabels:=["Unit profile","Pattern","Place speed","Lobby delay"]
    shortAdapt:=["Adaptation 1","Adaptation 2","Adaptation 3","Attack style"]
    Loop 4 {
        labels[A_Index].Text:=shortLabels[A_Index],alabels[A_Index].Text:=shortAdapt[A_Index]
        x:=976+(A_Index-1)*132
        for c in [labels[A_Index],alabels[A_Index]]
            c.Move(x,658,126,18),c.Opt("+Background" AA_CardColor)
        fields[A_Index].Move(x,684,126),afields[A_Index].Move(x,684,126)
    }
    placementSaveText.Move(976,740,500,18),placementSaveText.Text:="MODE OPTIONS"
    placementSaveBtn.Move(976,868,116,30),placementSaveBtn.Text:="Save settings"
    EditRoute.Move(1238,866,264,32),EditMaps.Move(1320,866,84,32),EditCardPrio.Move(1412,866,90,32)
    DoseLayoutRunOptions()

    DoseConsoleChangeMode:=AA_Btn(aaMainUI,"x1428 y58 w72 h24","Change")
    DoseConsoleChangeMode.OnEvent("Click",DoseConsoleEditMode)

    ; Visible run controls and a compact session bar under the game.
    DoseConsoleRun:=AA_Btn(aaMainUI,"x32 y658 w108 h34","Start run")
    DoseConsoleRun.OnEvent("Click",DoseConsoleStart)
    DoseConsolePause:=AA_Btn(aaMainUI,"x150 y658 w108 h34","Pause")
    DoseConsolePause.OnEvent("Click",(*)=>TogglePause())
    DoseConsoleStop:=AA_Btn(aaMainUI,"x268 y658 w108 h34","Stop")
    DoseConsoleStop.OnEvent("Click",(*)=>Reload())
    StatsWinsText.Move(400,652,160,20),StatsLossText.Move(564,652,160,20),StatsRateText.Move(400,679,330,20)
    for hwnd,c in aaMainUI
        if c.Type="Text" && (c.Text="Stats" || c.Text="Upgrade Settings" || c.Text="Auto Settings")
            c.Visible:=false
    ActivityTitle.Move(32,731,420,24),ActivityTitle.Text:="SESSION ACTIVITY"
    OpenLogLink.Move(704,734,68,18)
    process1.Move(32,765,740,28)
    for i,c in [process2,process3,process4,process5,process6,process7]
        c.Move(32,795+(i-1)*18,740,18)
    for c in [ActivityTitle,OpenLogLink,process1,process2,process3,process4,process5,process6,process7]
        c.Opt("+BackgroundTrans")
    footerSwitch:=0
    for sw in AA_Switches {
        if sw.cb=PriorityUpgrade || sw.cb=MaxUpgradeBeforeMoving || sw.cb=AutoAbilityBox || sw.cb=ChallengeBox {
            footerSwitch+=1,y:=644+(footerSwitch-1)*32
            sw.cb.Move(826,y),sw.pill.Move(826,y),sw.label.Move(860,y,76,28)
            sw.label.Text:=sw.cb=PriorityUpgrade ? "Priority" : sw.cb=MaxUpgradeBeforeMoving ? "One at time" : sw.cb=AutoAbilityBox ? "Abilities" : "Challenge"
        } else
            DoseDashboardPanelControl(sw.cb)
    }
    aaMainUI.SetFont("s8 Bold c" uiTheme[7],"Segoe UI")
    aaMainUI.Add("Text","x1548 y746 w220 h20 BackgroundTrans","LIVE SESSION")
    aaMainUI.SetFont("s10 Bold c" uiTheme[1],"Segoe UI")
    DoseConsolePhase:=aaMainUI.Add("Text","x1548 y777 w218 h24 BackgroundTrans","Ready")
    aaMainUI.SetFont("s9 Norm c" uiTheme[1],"Segoe UI")
    DoseConsoleMap:=aaMainUI.Add("Text","x1548 y810 w218 h20 BackgroundTrans","Map: —")
    DoseConsoleProfile:=aaMainUI.Add("Text","x1548 y835 w218 h20 BackgroundTrans","Profile: —")
    DoseConsoleAction:=aaMainUI.Add("Text","x1548 y862 w218 h42 BackgroundTrans","Waiting for a run")
    DoseConsoleHint:=aaMainUI.Add("Text","x976 y150 w534 h18 BackgroundTrans","Configure a profile, confirm a mode, then start.")
    for selector in [CP_MapList,CM_MapList] {
        SendMessage(0x1701,12,0,selector.Hwnd)
        if !selector.Value
            selector.Choose(1)
    }
    ; Preserve physical text size at 100/125/150% Windows display scaling.
    if A_ScreenDPI!=96
        for hwnd,c in aaMainUI
            if c.Type!="Pic" && c.Type!="Picture"
                try DoseNormalizeConsoleFont(c)
    for hwnd,c in aaMainUI
        if c.Type="Text" && c.Text!=""
            DoseFitConsoleText(c)
    windowTitle.SetFont("s" Round(12*96/A_ScreenDPI,2) " Bold","Segoe UI")
    for hwnd,b in AA_FlatBtns {
        if IsObject(b.underline) {
            b.ctrl.GetPos(&x,&y,&w,&h)
            b.underline.Move(x+10,y+h-2,w-20,2)
        }
        DoseRoundControl(b.ctrl,10)
    }
    WinSetRegion("0-12 12-0 1788-0 1800-12 1800-918 1788-930 12-930 0-918",aaMainUI)
    AA_SetBtnActive(DoseUnitsButton,true)
    SetTimer(DoseConsoleTick,500)
}

DoseLayoutRunOptions() {
    checks:=[NextLevelBox,ReturnLobbyBox,MatchMaking,TeamSwap,SaveChestsBox,StopAfterDefeat,DenyShrines,PrioritiseFutureRareChests,NewPlacementMethod,NoMovement,BringUnits,PortalSwap]
    count:=0
    for c in checks {
        if !c.Visible
            continue
        c.Move(976+Mod(count,2)*264,766+(count//2)*25,252,22)
        count+=1
    }
    y:=766+Ceil(count/2)*25
    PhysicalTeamText.Move(976,y,118,20),PhysicalTeam.Move(1098,y,88)
    MagicTeamText.Move(1240,y,118,20),MagicTeam.Move(1362,y,88)
}

DoseConsoleStart(*) {
    if WF_PrepareDungeon()
        StartMacro()
    else
        AddToLog("Position Roblox with F1 before starting: " WF_LastIssue)
}

DoseConsoleTick() {
    static lastLock:=-1,lastRun:=-1,lastTooltip:=""
    if !AA_GuiAlive() {
        SetTimer(DoseConsoleTick,0)
        return
    }
    running:=MacroLoopState.Active,locked:=running && !DoseSession.paused
    try {
        DoseConsoleText(DoseConsolePause,DoseSession.paused ? "Resume" : "Pause")
        DoseConsoleText(DoseConsolePhase,running ? DoseSession.phase : "Ready / stopped")
        DoseConsoleText(DoseConsoleMap,"Map: " (DoseSession.map="" ? "—" : DoseSession.map))
        DoseConsoleText(DoseConsoleProfile,"Profile: " (!running || DoseSession.stageProfile="" ? PlacementSelection.Text : DoseSession.stageProfile))
        DoseConsoleText(DoseConsoleAction,StrLen(DoseSession.lastAction)>64 ? SubStr(DoseSession.lastAction,1,61) "…" : DoseSession.lastAction)
        if lastTooltip!=DoseSession.lastAction
            AA_Tip(DoseConsoleAction,DoseSession.lastAction),lastTooltip:=DoseSession.lastAction
        due:=Max(0,1800000-(A_TickCount-challengeStartTime))
        DoseConsoleText(DoseConsoleChallenge,!ChallengeBox.Value ? "Auto Challenge off" : inChallengeMode ? "Challenge running" : due=0 ? "Challenge due after this floor" : "Next Challenge`n" Format("{:02}:{:02}",due//60000,Mod(due//1000,60)))
        DoseConsoleText(DoseConsoleHint,locked ? "Run active • pause before changing configuration" : "Settings are editable • each stage keeps its active profile")
        ; Change native enabled state only on run/pause transitions. Reapplying
        ; it to hundreds of controls every tick needlessly floods WM_PAINT.
        if locked!=lastLock || running!=lastRun {
            DoseConsoleRun.Enabled:=!running,DoseConsolePause.Enabled:=running
            for c in DoseConsoleNav
                c.Enabled:=!locked
            safeButtons:=Map(DoseConsoleRun.Hwnd,true,DoseConsolePause.Hwnd,true,DoseConsoleStop.Hwnd,true,minimizeButton.Hwnd,true,exitButton.Hwnd,true)
            for hwnd,button in AA_FlatBtns
                if !safeButtons.Has(hwnd)
                    button.ctrl.Enabled:=!locked
            for sw in AA_Switches
                sw.pill.Enabled:=!locked,sw.label.Enabled:=!locked
            for hwnd,c in aaMainUI {
                if c.Type="CheckBox" || c.Type="DDL" || c.Type="ComboBox" || c.Type="Edit"
                    c.Enabled:=!locked
            }
            ConfirmButton.Enabled:=!locked,placementSaveBtn.Enabled:=!locked
            DoseConsoleChangeMode.Enabled:=!running
            lastLock:=locked,lastRun:=running
        }
    }
}

DoseConsoleText(control,value) {
    if control.Text!=value
        control.Text:=value
}

DoseConsoleEditMode(*) {
    global confirmClicked
    if MacroLoopState.Active
        return
    confirmClicked:=false
    ModeDropdown.Visible:=true,ConfirmButton.Visible:=true,modeSelectionGroup.Visible:=true
    Hotkeytext.Visible:=false,Hotkeytext2.Visible:=false
    OnModeChange()
}

DoseNormalizeConsoleFont(control) {
    font:=SendMessage(0x31,0,0,control.Hwnd),info:=Buffer(92,0)
    if !font || !DllCall("gdi32\GetObjectW","Ptr",font,"Int",92,"Ptr",info)
        return
    height:=Abs(NumGet(info,0,"Int"))
    if height>0
        control.SetFont("s" Round(height*72*96/(A_ScreenDPI*A_ScreenDPI),2))
}

DoseFitConsoleText(control) {
    control.GetPos(&x,&y,&w,&h)
    if w<28 || y<31
        return
    Loop 2 {
        dc:=DllCall("user32\GetDC","Ptr",control.Hwnd,"Ptr")
        font:=SendMessage(0x31,0,0,control.Hwnd),info:=Buffer(92,0)
        old:=DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",font,"Ptr")
        rect:=Buffer(16,0),style:=DllCall("user32\GetWindowLongW","Ptr",control.Hwnd,"Int",-16,"UInt")
        width:=AA_FlatBtns.Has(control.Hwnd) ? w-12 : w
        NumPut("Int",width,rect,8)
        needed:=DllCall("user32\DrawTextW","Ptr",dc,"Str",control.Text,"Int",-1,"Ptr",rect,"UInt",(style & 0x200) ? 0x420 : 0x410)
        DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",old)
        DllCall("user32\ReleaseDC","Ptr",control.Hwnd,"Ptr",dc)
        if needed<=h && NumGet(rect,8,"Int")<=width
            return
        if !DllCall("gdi32\GetObjectW","Ptr",font,"Int",92,"Ptr",info)
            return
        height:=Abs(NumGet(info,0,"Int"))-1
        if height<9
            return
        control.SetFont("s" Round(height*72/A_ScreenDPI,2))
    }
}
