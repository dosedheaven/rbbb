#Requires AutoHotkey v2.0

; Presentation only. Repositions the existing controls after configuration load;
; their values, callbacks, settings files, game coordinates and viewport remain.
global DoseDashboardWidth := 1800, DoseDashboardHeight := 930
global DoseDashboardDecor := Map(), DoseUnitsButton := ""

DoseDashboardSurface(g,x,y,w,h,color,radius := 16,wallpaper := false) {
    ctrl := wallpaper ? DoseWallpaperSurface(g,x,y,w,h,color,62) : false
    if !IsObject(ctrl)
        ctrl := g.Add("Text",Format("x{} y{} w{} h{} Background{}",x,y,w,h,color))
    DoseDashboardDecor[ctrl.Hwnd] := true
    DoseRoundControl(ctrl,radius)
    return ctrl
}

DoseRoundControl(ctrl,radius := 12) {
    ; Native rounded/angled surfaces: no animation timers or web dependency.
    rect := Buffer(16,0)
    if !DllCall("user32\GetClientRect","Ptr",ctrl.Hwnd,"Ptr",rect)
        return
    w := NumGet(rect,8,"Int"), h := NumGet(rect,12,"Int")
    r := Round(radius*A_ScreenDPI/96)
    region := DllCall("gdi32\CreateRoundRectRgn","Int",0,"Int",0,"Int",w+1,"Int",h+1,"Int",r,"Int",r,"Ptr")
    if (region && !DllCall("user32\SetWindowRgn","Ptr",ctrl.Hwnd,"Ptr",region,"Int",true))
        DllCall("gdi32\DeleteObject","Ptr",region)
}

DoseBuildDashboardSurfaces(g) {
    global uiTheme, AA_CardColor
    DoseBuildWallpaperMargins(g)
    DoseDashboardSurface(g,812,32,568,886,"0D0E14",22,true)
    DoseDashboardSurface(g,824,148,544,60,AA_CardColor)
    DoseDashboardSurface(g,824,684,544,68,AA_CardColor)
    DoseDashboardSurface(g,824,764,544,150,AA_CardColor)
    DoseDashboardSurface(g,24,650,760,202,AA_CardColor,22,true)
    DoseDashboardSurface(g,24,866,208,52,AA_CardColor)
    DoseDashboardSurface(g,248,866,288,52,AA_CardColor)
    DoseDashboardSurface(g,552,866,232,52,AA_CardColor)
    DoseDashboardSurface(g,1392,44,384,870,AA_CardColor,24)
}

DoseDashboardMove(ctrl,x,y,w := unset,h := unset) {
    if IsSet(w) && IsSet(h)
        ctrl.Move(x,y,w,h)
    else if IsSet(w)
        ctrl.Move(x,y,w)
    else
        ctrl.Move(x,y)
}

DoseDashboardPanelControl(ctrl) {
    ctrl.GetPos(&x,&y,&w,&h)
    ; A dropdown's height includes its popup list. Preserve the native list
    ; sizing instead of stretching it like a label or decorative card.
    if (ctrl.Type="DDL" || ctrl.Type="ComboBox") {
        ctrl.Move(x+16,224+Round((y-85)*1.5),w)
        return
    }
    ; Registered panels share the original 550x296 content canvas. Give that
    ; canvas more vertical room, retaining every control and its relationships.
    ny := 224+Round((y-85)*1.5), nx := x+16
    nh := Max(h,Round(h*1.5))
    if (ctrl.Type="Text" && ctrl.Text!="") {
        needed := DoseDashboardTextHeight(ctrl,w)
        if (needed>nh && needed<=nh+6)
            nh := needed
    }
    ctrl.Move(nx,ny,w,nh)
    if (ctrl.Type="Text" && ctrl.Text="")
        DoseRoundControl(ctrl,14)
}

DoseDashboardTextHeight(ctrl,width) {
    font := SendMessage(0x31,0,0,ctrl.Hwnd)
    dc := DllCall("user32\GetDC","Ptr",ctrl.Hwnd,"Ptr")
    previous := DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",font,"Ptr")
    rect := Buffer(16,0)
    NumPut("Int",Round(width*A_ScreenDPI/96),rect,8)
    style := DllCall("user32\GetWindowLongW","Ptr",ctrl.Hwnd,"Int",-16,"UInt")
    flags := (style & 0x200) ? 0x420 : 0x410
    height := DllCall("user32\DrawTextW","Ptr",dc,"Str",ctrl.Text,"Int",-1,"Ptr",rect,"UInt",flags)
    DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",previous,"Ptr")
    DllCall("user32\ReleaseDC","Ptr",ctrl.Hwnd,"Ptr",dc)
    return Ceil(height*96/A_ScreenDPI)
}

DoseApplyDashboardLayout() {
    global DoseUnitsButton
    panelHandles := Map()
    for name,controls in AA_Panels
        for ctrl in controls
            panelHandles[ctrl.Hwnd] := true
    unitBackgrounds := Map()
    for unit in UnitData
        unitBackgrounds[unit.Background.Hwnd] := true
    for ctrl in [process1,process2,process3,process4,process5,process6,process7]
        unitBackgrounds[ctrl.Hwnd] := true
    ; Retire the previous decorative rectangles. Panel backgrounds and real
    ; controls are retained; game transparency is never hidden or resized.
    for hwnd,ctrl in aaMainUI {
        if (ctrl.Type="Text" && ctrl.Text="" && ctrl!=robloxHolder
            && !panelHandles.Has(hwnd) && !unitBackgrounds.Has(hwnd)
            && !DoseDashboardDecor.Has(hwnd))
            ctrl.Visible := false
        if (ctrl.Type="Text" && (ctrl.Text="DOSE" || RegExMatch(ctrl.Text,"^AA  /  v")))
            ctrl.Visible := false
    }
    for unit in UnitData {
        for key in ["BorderTop","BorderBottom","BorderLeft","BorderRight","Divider",
            "CornerTL","CornerTLV","CornerBR","CornerBRV"] {
            if unit.HasOwnProp(key) {
                unit.%key%.Visible := false
                unit.DeleteProp(key)
            }
        }
    }
    for name,controls in AA_Panels
        for ctrl in controls
            DoseDashboardPanelControl(ctrl)

    ; Six clear cards in two columns. All six placement profiles reuse these
    ; exact positions; switching profiles changes visibility/values as before.
    Loop 6 {
        i := A_Index, x := 824+Mod(i-1,2)*280, y := 224+((i-1)//2)*152
        unit := UnitData[i]
        unit.Background.Move(x,y,264,140)
        DoseRoundControl(unit.Background,18)
        unit.Title.Move(x+35,y+12,88,24)
        unit.Title.SetFont("s11 Bold","Segoe UI")
        unit.UpgradeText.Move(x+131,y+15,104,18)
        unit.UpgradeText.SetFont("s8 Norm","Segoe UI")
        unit.PlacementText.Move(x+16,y+49,118,20)
        unit.PriorityText.Move(x+16,y+77,118,20)
        unit.LimitText.Move(x+16,y+105,100,20)
        for label in [unit.Title,unit.PlacementText,unit.PriorityText,unit.UpgradeText,unit.LimitText]
            label.Opt("+BackgroundTrans")
        spots := [[14,15,0],[154,45,88],[154,73,88],[240,16,0],[125,108,0],[154,101,88]]
        for names in AA_UnitProfiles {
            for k,name in names {
                controlName := name i
                try {
                    ctrl := %controlName%
                    if spots[k][3]
                        ctrl.Move(x+spots[k][1],y+spots[k][2],spots[k][3])
                    else
                        ctrl.Move(x+spots[k][1],y+spots[k][2])
                }
            }
        }
    }

    ; Navigation uses the original callbacks. Units is a direct return to the
    ; main cards, so closing a panel never relies on remembering its active tab.
    aaMainUI.SetFont("s9 Bold c" uiTheme[1],"Segoe UI")
    DoseUnitsButton := AA_Btn(aaMainUI,"x824 y46 w124 h34","Units")
    DoseUnitsButton.OnEvent("Click",(*) => AA_ShowPanel(""))
    nav := [[SettingsBtn,960,46,124,"Settings"],[CustomPlacementBtn,1096,46,124,"Placement"],
        [CustomMovementBtn,1232,46,136,"Custom Map"],[SchedulerBtn,824,90,124,"Scheduler"],
        [DebugButton,960,90,124,"Debug"],[guideBtn,1096,90,124,"Guide"],
        [MaharagaButton,1232,90,136,"Adaptations"]]
    for item in nav {
        btn := item[1]
        btn.Move(item[2],item[3],item[4],34)
        btn.Text := item[5]
        btn.SetFont("s9 Bold","Segoe UI")
    }
    for hwnd,button in AA_FlatBtns {
        if IsObject(button.underline) {
            button.ctrl.GetPos(&x,&y,&w,&h)
            button.underline.Move(x+12,y+h-2,w-24,2)
        }
        DoseRoundControl(button.ctrl,12)
    }
    AA_SetBtnActive(DoseUnitsButton,true)
    minimizeButton.Move(1710,2,34,26), exitButton.Move(1750,1,34,28)
    windowTitle.Move(24,3,310,27)
    AA_StatusDot.Move(354,4,16,20), AA_StatusText.Move(376,8,770,18)

    ; Keep native map selectors legible and their list arrows/scrollbars intact.
    for selector in [CP_MapList,CM_MapList] {
        selector.SetFont("s9 Norm c" uiTheme[1],"Segoe UI")
        SendMessage(0x1701,12,0,selector.Hwnd) ; CB_SETMINVISIBLE
        if !selector.Value
            selector.Choose(1)
    }

    ; Original mode/map/act controls and confirmation flow.
    modeSelectionGroup.Move(840,155,500,18)
    modeSelectionGroup.SetFont("s8 Bold","Segoe UI")
    for ctrl in [ModeDropdown,StoryDropdown,StoryActDropdown,LegendDropDown,LegendActDropdown,
        RaidDropdown,RaidActDropdown,InfinityCastleDropdown,PortalDropdown,PortalJoinDropdown,
        ContractPageDropdown,ContractJoinDropdown,ConfirmButton] {
        ctrl.GetPos(&x,&y,&w,&h)
        ctrl.Move(x+16,182,w)
    }
    Hotkeytext.Move(840,155,500,18), Hotkeytext2.Move(840,182,500,20)
    for ctrl in [Hotkeytext,Hotkeytext2,modeSelectionGroup]
        ctrl.Opt("+Background" AA_CardColor)

    labels := [PlacementSelectionText,PlacementPatternText,PlaceSpeedText,LobbySleepText]
    fields := [PlacementSelection,PlacementPatternDropdown,PlaceSpeed,LobbySleepTimer]
    altLabels := [FirstAdaptationText,SecondAdaptationText,FinalAdaptationText,MahoragoModeText]
    altFields := [FirstAdaptation,SecondAdaptation,FinalAdaptation,MahoragoMode]
    Loop 4 {
        x := 840+(A_Index-1)*132
        for ctrl in [labels[A_Index],altLabels[A_Index]] {
            ctrl.Move(x,695,126,18)
            ctrl.SetFont("s8 Bold","Segoe UI")
            ctrl.Opt("+Background" AA_CardColor)
        }
        fields[A_Index].Move(x,719,126), altFields[A_Index].Move(x,719,126)
    }
    ; Every context-specific run option is moved, including currently hidden
    ; options used by other modes. Overlapping alternatives retain visibility rules.
    options := [NextLevelBox,ReturnLobbyBox,MatchMaking,TeamSwap,SaveChestsBox,StopAfterDefeat,
        DenyShrines,PrioritiseFutureRareChests,NewPlacementMethod,NoMovement,BringUnits,PortalSwap,
        PhysicalTeamText,PhysicalTeam,MagicTeamText,MagicTeam,EditMaps,EditCardPrio,EditRoute]
    for ctrl in options {
        ctrl.GetPos(&x,&y,&w,&h)
        ctrl.Move(x+16,792+Round((y-451)*1.15),w)
        if ctrl.Type="Text"
            ctrl.Opt("+Background" AA_CardColor)
    }
    DoseLayoutRunOptions()
    placementSaveText.Move(840,774,500,18), placementSaveText.Text := "RUN OPTIONS"
    placementSaveText.SetFont("s8 Bold c" uiTheme[7],"Segoe UI")
    placementSaveText.Opt("+Background" AA_CardColor)
    placementSaveBtn.Move(840,868,112,30)
    EditRoute.Move(1102,866,246,32)
    EditMaps.Move(1180,866,80,32), EditCardPrio.Move(1268,866,80,32)

    ActivityTitle.Move(42,662,590,24), ActivityTitle.Text := "Activity"
    ActivityTitle.SetFont("s12 Bold c" uiTheme[1],"Segoe UI")
    OpenLogLink.Move(700,666,70,18)
    for label in [ActivityTitle,OpenLogLink,process1,process2,process3,process4,process5,process6,process7]
        label.Opt("+BackgroundTrans")
    process1.Move(42,696,722,30)
    for i,ctrl in [process2,process3,process4,process5,process6,process7]
        ctrl.Move(42,730+(i-1)*20,722,18)

    ; Move footer labels and their switches together, retaining hidden checkbox
    ; values and the switch event objects created by AA_StyleFinish.
    for hwnd,ctrl in aaMainUI {
        if (ctrl.Type="Text" && (ctrl.Text="Stats" || ctrl.Text="Upgrade Settings" || ctrl.Text="Auto Settings")) {
            x := ctrl.Text="Stats" ? 38 : (ctrl.Text="Upgrade Settings" ? 262 : 566)
            ctrl.Move(x,870,198,16)
        }
    }
    StatsWinsText.Move(38,888,90,14), StatsLossText.Move(134,888,90,14), StatsRateText.Move(38,904,180,14)
    for sw in AA_Switches {
        sw.cb.GetPos(&x,&y,&w,&h)
        if (sw.cb=PriorityUpgrade || sw.cb=MaxUpgradeBeforeMoving || sw.cb=AutoAbilityBox || sw.cb=ChallengeBox) {
            nx := (sw.cb=PriorityUpgrade || sw.cb=MaxUpgradeBeforeMoving) ? 262 : 566
            ny := (sw.cb=PriorityUpgrade || sw.cb=AutoAbilityBox) ? 888 : 904
            sw.cb.Move(nx,ny), sw.pill.Move(nx,ny), sw.label.Move(nx+34,ny)
        } else {
            ; Hidden panel checkboxes remain the source of truth too.
            DoseDashboardPanelControl(sw.cb)
        }
    }
    ; Regions use device pixels and must follow each button's final size.
    for hwnd,button in AA_FlatBtns
        DoseRoundControl(button.ctrl,12)
    ; Chamfer the outer window without touching the rectangular game viewport.
    WinSetRegion("0-16 16-0 1784-0 1800-16 1800-914 1784-930 16-930 0-914",aaMainUI)
    aaMainUI.SetFont("s9 Norm c" uiTheme[1],"Segoe UI")
}


; Lay out only the options shown by the existing mode rules. Checkbox values
; never affect layout, and repacking does not change their values or callbacks.
DoseLayoutRunOptions() {
    checks := [NextLevelBox,ReturnLobbyBox,MatchMaking,TeamSwap,SaveChestsBox,StopAfterDefeat,
        DenyShrines,PrioritiseFutureRareChests,NewPlacementMethod,NoMovement,BringUnits,PortalSwap]
    count := 0
    for ctrl in checks {
        if !ctrl.Visible
            continue
        ctrl.Move(840+Mod(count,2)*264,794+(count//2)*24,252,20)
        ctrl.SetFont("s9 Norm","Segoe UI")
        count += 1
    }
    teamY := 794+Ceil(count/2)*24
    PhysicalTeamText.Move(840,teamY,118,20),PhysicalTeam.Move(962,teamY,88)
    MagicTeamText.Move(1104,teamY,118,20),MagicTeam.Move(1226,teamY,88)
}
