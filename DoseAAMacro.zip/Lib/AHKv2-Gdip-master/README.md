# AHKv2-Gdip
This repository contains the GDI+ library (Gdip_All.ahk) compatible with the current [AutoHotKey v2](https://autohotkey.com/v2/).

Support for AHK v1 is dropped (find the original `Gdip_All.ahk` library if you need it).  


# Examples
See the appropriate Examples folder for usage examples

# Usage
All of the Gdip_*() functions use the same syntax as before, so no changes should be required, with one exception:  

The `Gdip_BitmapFromBRA()` function requires you to read the .bra file witih `FileObj.RawRead()` instead of the `FileRead` command. See the Tutorial.11 file in the Examples folder
