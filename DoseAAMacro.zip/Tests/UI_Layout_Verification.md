# v2.7 dashboard verification

AutoHotkey 2.0.19 under Wine 10 on an isolated 1920x1080 display at 96 DPI. Segoe UI is substituted with DejaVu Sans in the test environment only. The app does not install fonts or change Windows font settings; bundled icon/display fonts load privately.

The preview constructs the production main UI, Settings, Advanced, Scheduler, Card Picker, Custom Map, Custom Placement, Debug builders and all five Guide pages. Game/network/recording hooks and Debug actions are substituted; private settings/log startup is excluded. Scheduler/Card settings and general configuration writes use unique temporary synthetic files.

Actual SaveSettings and readInSettings functions exercise all six profiles and run options, retaining the same native control handles and values across save/load and navigation. Native text metrics check visible labels. Checks cover unconfirmed/confirmed mode visibility, every mode's context-control bounds, active panel navigation, original switch callbacks, current artwork bounds, fonts, defaults and unchanged viewport calibration. Screens are visually inspected too.

The final artwork is the unchanged user-supplied JPEG. Both the complete group banner and subject crop are rendered through the production GDI code. AkatsukiThemeTests.ahk verifies the single theme, legacy saved-name fallback, theme saving, private fonts, image rendering, missing-image fallback and game transparency key. AnimeThemeTests.ahk remains a compatible entry point for this current suite.

Native route-panel/default tests and the 88 Python source/geometry/policy checks were rerun. The comparison against v2.6 proves gameplay, movement, original event handlers and settings persistence code are unchanged. Earlier gameplay verification records keep their release labels. This verification does not cover live Roblox or every Windows scaling/font configuration.
