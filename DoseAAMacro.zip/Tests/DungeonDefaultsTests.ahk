#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; Run PrepareDefaultsTests.py first. All files below are synthetic fixtures in a
; unique temp directory, never the user's Settings/Logs. No Main or game startup.
#Include %A_ScriptDir%\..\Lib\AppInfo.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonDefaults.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\RoutePriorityPicker.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\CursePriorityPicker.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\ShrinePriorityPicker.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Utilities.ahk
#Include %A_ScriptDir%\..\Lib\GuiPanels.ahk
#Include %A_ScriptDir%\DungeonConfigForTests.ahk
global aaMainUI := Gui("+ToolWindow -DPIScale"), debugMessages := false
global uiTheme := ["F1F5FF","0D1220","8B7CF8","171D30","303030","10192B","77E5F4"]
global AA_CardColor := "171D30", DFChecks := 0
global DFTemp := A_Temp "\DoseDefaultsTest-" A_TickCount
Dose_DungeonSettingsRoot := DFTemp "\Settings"
DFAssert(value,label) {
    global DFChecks
    DFChecks += 1
    if !value
        throw Error(label)
}
DFMain()
DFMain() {
    global routePriorityOrder, cursePriorityOrder, shrinePriorityOrder, Dose_DungeonDefaultsSessionApplied
try {
    DirCreate(DoseDungeonSettingsDirectory())
    AA_BuildAdvancedPanel()
    DFAssert(DoseReleaseVersion()="3.9","release version is 3.9")
    before := "[RoutePriority]`nRoom2=Shop`n[CurseProtection]`nCurse2=Wind`n[ShrineProtection]`nShrine2=Armor`n"
    FileAppend(before,DoseDungeonSettingsDirectory() "\RoutePriority.txt","UTF-8")
    LoadDungeonLocal()
    DFAssert(routeDropDowns[1].Text="Shop" && curseDropDowns[1].Text="Wind" && shrineDropDowns[1].Text="Armor",
        "legacy indexed configuration loads each first slot correctly")
    DFAssert(DoseEnsureDungeonDefaults(),"first Dungeon selection applies requested defaults")
    DFAssert(DungeonPriorityList(routePriorityOrder)="Rare_Chest > Chest > Shop > Shrine > Hoard > Boss","requested default route order")
    DFAssert(enabledCurses.Length=0,"requested default has no avoided curses")
    DFAssert(StringJoin(enabledShrines)="Burst, Chaos, Vamparism","requested avoided shrines are active")
    DFAssert(FileExist(DoseDungeonSettingsDirectory() "\DoseDungeonPreset-v2.txt"),"one-time marker is saved")
    DFAssert(FileRead(DoseDungeonSettingsDirectory() "\RoutePriority.beforeDose2.txt","UTF-8")=before,"previous Dungeon file is backed up exactly")
    routeDropDowns[1].Choose("Shop")
    OnRouteDropDownChange(routeDropDowns[1],1)
    curseDropDowns[1].Choose("Wind")
    OnCurseDropDownChange(curseDropDowns[1],1)
    shrineDropDowns[6].Choose("Frenzy")
    OnShrineDropDownChange(shrineDropDowns[6],6)
    DFAssert(!DoseEnsureDungeonDefaults(),"later Dungeon selection does not reset edits")
    DFAssert(routeDropDowns[1].Text="Shop" && curseDropDowns[1].Text="Wind" && shrineDropDowns[6].Text="Frenzy",
        "edited route, curse, and last shrine slot are preserved")
    preset := DoseDungeonDefaults()
    routePriorityOrder := preset.route, cursePriorityOrder := preset.curses, shrinePriorityOrder := preset.shrines
    for row, value in preset.route
        routeDropDowns[row].Choose(value)
    for row, value in preset.curses
        curseDropDowns[row].Choose(value)
    for row, value in preset.shrines
        shrineDropDowns[row].Choose(value)
    Dose_DungeonDefaultsSessionApplied := false
    LoadDungeonLocal()
    DFAssert(routeDropDowns[1].Text="Shop" && curseDropDowns[1].Text="Wind","saved route and curse survive a simulated restart")
    DFAssert(shrineDropDowns[1].Text="Burst" && shrineDropDowns[2].Text="Chaos" && shrineDropDowns[3].Text="Vamparism"
        && shrineDropDowns[6].Text="Frenzy","all shrine rows round-trip without shifting or overflow")
    DFAssert(!DoseEnsureDungeonDefaults() && routeDropDowns[1].Text="Shop","persisted marker preserves customization across restarts")
    DFAssert(FileRead(DoseDungeonSettingsDirectory() "\RoutePriority.beforeDose2.txt","UTF-8")=before,"backup is not overwritten by later edits")
    FileAppend("PASS: " DFChecks " Dungeon default/persistence assertions (synthetic settings only).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
} finally {
    aaMainUI.Destroy()
    try DirDelete(DFTemp,1)
}
}
AA_Card(x,y,w,h,text,panel := "Settings") {
    return AA_PanelPush(aaMainUI.Add("GroupBox",Format("x{} y{} w{} h{} Hidden",x,y,w,h),text),panel)
}
AA_Btn(*) {
    throw Error("No extra buttons expected in default/persistence tests")
}
AddToLog(*) {
}
