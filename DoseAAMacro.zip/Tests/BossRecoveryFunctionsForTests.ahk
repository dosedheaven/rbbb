; Generated production finish caller only; no Main/private startup.
CheckForFinishDungeonV2() {
    ; The old finish handler treated a post-boss Enter button as completion and
    ; restarted without checking whether that button ever worked. Use the same
    ; bounded entrance confirmation/recovery flow instead.
    if DungeonBossExitPending {
        entranceVisible := WF_FindText(&X,&Y,250,340,550,495,0.20,0.20,EnterDungeon)
        if (WF_LastIssue!="")
            return false
        if entranceVisible {
            AddToLog("Post-boss entrance detected; verifying entry before restarting")
            return DungeonWaitForEntrance()
        }
    }
    ; Check for the finish dungeon popup
    if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.10, 0.10, FinishDungeon) or (ok := FT(&X, &Y, 310, 395, 495, 440, 0.10, 0.10, EnterDungeon)) or (ok := FT(&X, &Y, 370, 225, 545, 300, 0.10, 0.10, DungeonDeath))) {
        AddToLog("Detected dungeon finish Continuing...")
        ; Click the Finish button
        if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.20, 0.20, FinishDungeon)){
            AddToLog("Detected Finish dungeon text clicking....")
            sleep 2000
            FixClick(344,251)
            sleep 1000
            FixClick(322,340)
            sleep 300
            FixClick(666, 145)
            Sleep(2000)
            if (ok := FT(&X, &Y, 126, 56, 675, 230, 0, 0, LobbyText2)) or (ok := FT(&X, &Y, 126, 56, 675, 230, 0, 0, LobbyText)){
                ClickReturnToLobby()
            }
        }

        if (ok := FT(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath)){
            ClickDungeonDeathContinue()
            ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
            Sleep(1000)
        }

        if (!dungeonDeathBroken) {
            ; Click Dungeon Death if needed
            ClickDungeonDeathContinue()
            Sleep(1500)
            ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
            Sleep(1000)
        }
        return true
    }
}
