#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\Lib\Engine\Pause.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\AppInfo.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk
; Real GDI/FindText/WindowFollow capture and classifier against native synthetic
; shops. Only FixClick is recorded/simulated; no real game input or private IO.
global targetWidth := 816,targetHeight := 638,offsetX := -5,offsetY := 1
global VG := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " VG.Hwnd
global VP := [],VT := [],VOffers := [],VVisible := true,VClicks := [],VLogs := [],VChecks := 0
global VOverlay := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale")
global VFast := {loadMs:100,pollMs:40,settleMs:120,observeMs:1100,scanTries:8,attempts:2,maxActions:12,totalMs:30000,closeMs:1800}
VG.BackColor := "101018",VOverlay.BackColor := "FF0000"
global VHeader := VG.Add("Picture","x190 y205",A_ScriptDir "\Fixtures\ShopNative-Shop.bmp")
Loop 3 {
    VP.Push(VG.Add("Text","x537 y212 w56 h25 BackgroundFFDA18",""))
    VG.SetFont("s9 Bold c000000","DejaVu Sans")
    VT.Push(VG.Add("Text","x540 y216 w45 h18 Center BackgroundTrans","300"))
}
global VHook := VG.Add("Picture","x402 y268",A_ScriptDir "\Fixtures\ShopNative-Fishhook.bmp")
global VHeadSize := 32,VHeadMethod := "nearest",VHideHeadsplitterAfterBuy := false
global VHideAxeAfterBuy := false
global VGolden := VG.Add("Picture","x390 y262 w37 h37",A_ScriptDir "\..\Images\Shop\GoldenFishhook.png")
global VHead := VG.Add("Picture","x390 y264 w32 h32",A_ScriptDir "\Fixtures\ShopNative-Headsplitter-32-nearest.png")
global VAxe := VG.Add("Picture","x397 y268",A_ScriptDir "\Fixtures\ShopNative-Axe.bmp")
global VContinueBack := VG.Add("Text","x420 y385 w170 h40 Background20D52B","")
global VContinue := VG.Add("Picture","x480 y397",A_ScriptDir "\Fixtures\ShopNative-DungeonContinue.bmp")
; Nonbutton coins/text/green shapes must not create purchase candidates.
VG.Add("Text","x610 y181 w12 h17 BackgroundFFDA18","")
VG.Add("Text","x515 y166 w48 h5 BackgroundFFDA18","")
VG.Add("Text","x540 y196 w55 h16 Background18EE45","")
VOffer(id,y,canBuy := true) => {id:id,y:y,canBuy:canBuy}
VAssert(ok,label) {
    global VChecks
    VChecks += 1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
VDraw() {
    global VVisible
    Loop 3 {
        i := A_Index
        VP[i].Visible := i<=VOffers.Length && VVisible
        VT[i].Visible := i<=VOffers.Length && VVisible
        if (i<=VOffers.Length) {
            VP[i].Move(537,VOffers[i].y-13)
            VT[i].Move(540,VOffers[i].y-9)
        }
    }
    VHook.Visible := false,VGolden.Visible := false,VAxe.Visible := false,VHead.Visible := false
    for item in VOffers
        if (item.id="Fishhook" && VVisible) {
            VHook.Move(402,item.y-12)
            VHook.Visible := true
        }
    for item in VOffers {
        if (item.id="Golden Fishhook" && VVisible) {
            VGolden.Move(390,item.y-18)
            VGolden.Visible := true
        }
        if (item.id="Headsplitter" && VVisible && (!VHideHeadsplitterAfterBuy || VClicks.Length=0)) {
            VHead.Value := "*w" VHeadSize " *h" VHeadSize " " A_ScriptDir "\Fixtures\ShopNative-Headsplitter-" VHeadSize "-" VHeadMethod ".png"
            VHead.Move(390,item.y-VHeadSize//2,VHeadSize,VHeadSize)
            VHead.Visible := true
        }
        if (item.id="Axe" && VVisible && (!VHideAxeAfterBuy || VClicks.Length=0)) {
            VAxe.Move(397,item.y-12)
            VAxe.Visible := true
        }
    }
    VHeader.Visible := VVisible,VContinue.Visible := VVisible,VContinueBack.Visible := VVisible
    VG.Show("NA x100 y100 w816 h638")
    for ctrl in VP
        ctrl.Redraw()
    for ctrl in VT
        ctrl.Redraw()
}
VReset(items) {
    global VOffers,VClicks,VLogs,VVisible
    VOffers := items,VClicks := [],VLogs := [],VVisible := true
    VDraw()
    Sleep(180)
}
try {
    VReset([VOffer("Scythe",225),VOffer("Fishhook",280),VOffer("Dagger",335)])
    VAssert(WF_PrepareDungeon() && DungeonShopVisible(),"native Shop reference and calibrated window are recognized")
    beforeCritical := A_IsCritical
    frame := DungeonShopCapture()
    VAssert(IsObject(frame) && frame.w=126 && frame.h=216,"real FindText DIB capture returns the isolated purchase column")
    VAssert(A_IsCritical=beforeCritical,"snapshot copy restores the caller critical state")
    buttons := DungeonShopButtonsFromFrame(frame)
    VAssert(buttons.Length=3,"native gold plates with dark price glyphs yield exactly three buttons")
    VAssert(buttons[1].x=560 && buttons[1].y=225 && buttons[2].y=280 && buttons[3].y=335,"real pixel centers use original shop calibration")
    CoordMode("Mouse","Client")
    VAssert(HandleShop(VFast),"full production shop routine completes the native three/two/one sequence")
    VAssert(VClicks.Length=4 && VClicks[1].id="Fishhook" && VClicks[2].id="Dagger" && VClicks[3].id="Scythe" && VClicks[4].id="Continue","Fishhook then lower remaining item then last item are clicked in order")
    VAssert(Abs(VClicks[1].y-280)<=2 && VClicks[2].y=280 && VClicks[3].y=225,"purchase clicks follow reflow rather than old third-row coordinates")
    VAssert(!VVisible && !VOffers.Length,"shop disappearance is confirmed after all three purchases")
    VAssert(A_CoordModeMouse="Client","shop input retains the caller coordinate mode")

    VReset([VOffer("Only remaining",280)])
    VAssert(HandleShop(VFast) && VClicks[1].y=280 && VClicks.Length=2,"a native last item remaining at middle height is located correctly")
    VReset([VOffer("Affordable",225),VOffer("Too expensive",280,false)])
    VAssert(HandleShop(VFast),"native no-progress purchase tries other items then closes, as authorized")
    VAssert(VOffers.Length=1 && VOffers[1].id="Too expensive" && !VVisible,"unaffordable offer is left without blocking the next dungeon flow")

    VReset([VOffer("Top",225),VOffer("Middle",280),VOffer("Bottom",335)])
    WinMove(300,200,,,rblxID)
    Sleep(150)
    frame := DungeonShopCapture(),buttons := DungeonShopButtonsFromFrame(frame)
    VAssert(buttons.Length=3 && buttons[2].x=560 && buttons[2].y=280,"price capture follows a moved Roblox window with unchanged calibrated centers")
    VOverlay.Show("x800 y400 w150 h180")
    Sleep(120)
    VAssert(!IsObject(DungeonShopCapture()) && InStr(WF_LastIssue,"covered"),"covering windows reject capture instead of becoming empty shops")
    VOverlay.Hide()
    for order in [["Golden Fishhook","Fishhook","Axe"], ["Axe","Golden Fishhook","Fishhook"], ["Fishhook","Axe","Golden Fishhook"]] {
        items := []
        for i,id in order
            items.Push(VOffer(id,225+(i-1)*55))
        VReset(items)
        VAssert(DungeonShopHook(&gx,&gy,"Golden Fishhook"),"exact supplied transparent Golden icon matches native screen")
        VAssert(HandleShop(VFast),"native two-hook/Axe shop completes")
        VAssert(VClicks.Length=3 && VClicks[1].id="Golden Fishhook" && VClicks[2].id="Fishhook" && VClicks[3].id="Continue","native real matching honors both hooks before continuing")
        VAssert(VOffers.Length=1 && VOffers[1].id="Axe","native Axe reference is never clicked despite reflow")
    }
    VReset([VOffer("Axe",280)])
    VAssert(HandleShop(VFast) && VClicks.Length=1 && VClicks[1].id="Continue","native Axe-only shop makes no purchase")
    VReset([VOffer("Fishhook",280)])
    VAssert(!DungeonShopHook(&gx,&gy,"Golden Fishhook"),"white regular Fishhook is not mistaken for Golden")
    VReset([VOffer("Top",225),VOffer("Middle",280),VOffer("Bottom",335)])
    VAssert(!DungeonShopHook(&gx,&gy,"Golden Fishhook"),"gold price plates alone are not a Golden Fishhook")
    VHideAxeAfterBuy := true
    for order in [["Axe","Golden Fishhook","Fishhook"], ["Golden Fishhook","Axe","Fishhook"], ["Golden Fishhook","Fishhook","Axe"]] {
        items := []
        for i,id in order
            items.Push(VOffer(id,225+(i-1)*55))
        VReset(items)
        VAssert(HandleShop(VFast),"native shop finishes after Axe reference disappears during compaction")
        VAssert(VClicks.Length=3 && VClicks[1].id="Golden Fishhook" && VClicks[2].id="Fishhook" && VOffers.Length=1 && VOffers[1].id="Axe","native excluded Axe survives visual loss after purchases")
    }
    VHideAxeAfterBuy := false
    for size in [28,30,32,34,36,38,40] {
        for method in ["nearest","bilinear"] {
            VHeadSize := size,VHeadMethod := method
            VReset([VOffer("Headsplitter",280)])
            VAssert(DungeonShopExcluded({y:280})="Headsplitter","native Headsplitter matches at shop size " size " / " method)
            VAssert(HandleShop(VFast) && VClicks.Length=1 && VClicks[1].id="Continue","native Headsplitter-only offer never receives a buy click")
        }
    }
    VHeadSize := 32,VHeadMethod := "nearest",VHideHeadsplitterAfterBuy := true
    for order in [["Headsplitter","Golden Fishhook","Fishhook"], ["Golden Fishhook","Headsplitter","Fishhook"], ["Golden Fishhook","Fishhook","Headsplitter"]] {
        items := []
        for i,id in order
            items.Push(VOffer(id,225+(i-1)*55))
        VReset(items)
        VAssert(HandleShop(VFast),"native Headsplitter shop completes after the icon stops matching")
        VAssert(VClicks.Length=3 && VClicks[1].id="Golden Fishhook" && VClicks[2].id="Fishhook" && VOffers.Length=1 && VOffers[1].id="Headsplitter","native remembered Headsplitter follows each row change without being bought")
    }
    VHideAxeAfterBuy := true
    VReset([VOffer("Axe",225),VOffer("Headsplitter",280),VOffer("Fishhook",335)])
    VAssert(HandleShop(VFast) && VClicks.Length=2 && VClicks[1].id="Fishhook" && VOffers.Length=2,"native Axe and Headsplitter remain excluded together after both references disappear")
    VHideAxeAfterBuy := false,VHideHeadsplitterAfterBuy := false
    VReset([VOffer("Golden Fishhook",225),VOffer("Fishhook",280),VOffer("Dagger",335)])
    for row in [225,280,335]
        VAssert(DungeonShopExcluded({y:row})="","hook and plain rows are not falsely identified as Headsplitter or Axe")
    FileAppend("PASS: " VChecks " native shop-window assertions (real capture/classifier/flow; click simulation).`n","*")
    VG.Destroy(),VOverlay.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    VG.Destroy(),VOverlay.Destroy()
    ExitApp(1)
}
FixClick(x,y,*) {
    global VVisible
    if (A_CoordModeMouse!="Screen")
        throw Error("shop input did not select Screen mode")
    FT_GetOffset(&dx,&dy)
    cx := x-dx,cy := y-dy
    if (cx>=470 && cx<=550 && cy>=395 && cy<=425) {
        VClicks.Push({id:"Continue",x:cx,y:cy})
        VVisible := false
        VDraw()
        return
    }
    for i,item in VOffers {
        if (Abs(cx-560)<=3 && Abs(cy-item.y)<=3) {
            VClicks.Push({id:item.id,x:cx,y:cy})
            if item.canBuy {
                VOffers.RemoveAt(i)
                if (VOffers.Length>1)
                    for j,remaining in VOffers
                        remaining.y := 225+(j-1)*55
                VDraw()
            }
            return
        }
    }
    throw Error("shop clicked outside a live purchase/Continue button: " cx "," cy)
}
sizeDown(*) => WinMove(,,targetWidth,targetHeight,rblxID)
AddToLog(message) => VLogs.Push(message)
