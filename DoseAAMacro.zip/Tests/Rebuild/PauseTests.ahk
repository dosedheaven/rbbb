#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Pause.ahk
#Include %A_ScriptDir%\..\..\Lib\Functions\Timers.ahk
global Signals:=A_Args[1],NG:=Gui(,"Dose Pause Test"),C:=0,Refreshes:=0,PausedRefreshes:=0,Progress:=0
DoseSession.traceRoot:=Signals "\Trace"
NG.Add("Button","w100 h30","Resume").OnEvent("Click",ResumeRun)
NG.Show("x100 y100 w180 h80")
WriteSignal("hwnd",NG.Hwnd)
class MacroLoopState {
    static Active:=true
}
DoseSession.phase:="Results",DoseSession.results:=DoseResultsState(A_TickCount,5000,1000)
global BeforeDeadline:=DoseSession.results.deadline,BeforeTick:=DoseActiveTick()
TimerManager.Start("Stage",5000)
SetTimer(RequestPause,-80)
Loop 20 {
    Progress+=1,WriteSignal("progress",Progress)
    Sleep(20)
}
Assert(!DoseSession.paused,"GUI callback resumes paused worker")
Assert(DoseSession.pauseTotal>=250,"wall time spent paused is accounted")
Assert(DoseSession.results.deadline>=BeforeDeadline+250,"result deadline shifts with pause")
Assert(TimerManager.GetRemaining("Stage")>4000,"named deadline also shifts with pause")
DoseSession.phase:="Map movement",DoseSession.pauseRequested:=true
WriteSignal("phase","checkpoint")
DosePauseCheckpoint()
Assert(!DoseSession.paused && !DoseSession.pauseRequested,"queued movement pause resumes from its checkpoint")
Assert(PausedRefreshes>=2 && Refreshes>=4,"console is explicitly refreshed while timers are paused")
FileAppend("PASS: " C " native pause/resume assertions (actual AHK thread pause, GUI callback, clocks and manual UI refresh).`n","*")
NG.Destroy()
ExitApp(0)

RequestPause() {
    DoseSetPaused(true,true)
    WriteSignal("phase","paused")
}
ResumeRun(*) {
    DoseSetPaused(false,true)
    WriteSignal("phase","running")
}
Assert(ok,label) {
    global C
    C+=1
    if !ok {
        FileAppend("FAIL: " label "`n","*")
        ExitApp(1)
    }
}
WriteSignal(name,value) {
    path:=Signals "\" name ".txt"
    try FileDelete(path)
    FileAppend(value,path)
}
WF_PrepareDungeon() => true
AddToLog(*) => 0
DoseConsoleTick() {
    global Refreshes,PausedRefreshes
    Refreshes+=1
    if DoseSession.paused
        PausedRefreshes+=1
}
AA_StyleTick() => 0
