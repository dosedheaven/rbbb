#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\..\Lib\Engine\DungeonScreens.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\ResultsForTests.ahk
global C:=0,mode:="Dungeon",inChallengeMode:=false,PlacementSelection:={Text:"Dungeon"},ModeDropdown:={Text:"Dungeon"}
 global Wins:=0,loss:=0,stageStartTime:=A_TickCount-1000,successfulCoordinates:=[],maxedCoordinates:=[]
 global TOutcome:="win",TNav:=true,TVariant:=1,TNext:=false,TXp:=false,TUnit:=false,TPending:=false,TChest:=false,TBlocked:=false
 global TScene:="Waiting",TEntry:=false
 global TOutcomeAt:=0,TStarted:=0,TWebhooks:=0,TWebhookFail:=false,TInputs:=[],TLogs:=[],WF_LastIssue:="",BossRoomCompleted:=false,rblxID:="ahk_id 0"
 global Fast:={timeoutMs:1500,outcomeMs:100,pollMs:5,retryMs:15,rescanMs:30,maxRescans:0}
DoseSession.traceRoot:=A_Temp "\DoseCoreTests-" A_TickCount
class MacroStop extends Error {
}
class TestHandoff extends Error {
    __New(step) {
        super.__New(step.Name)
    }
}
class StageGuard {
    static Disarm(*) => 0
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
Reset() {
    global
    mode:="Dungeon",inChallengeMode:=false,PlacementSelection.Text:="Dungeon",ModeDropdown.Text:="Dungeon"
    TScene:="Waiting",TEntry:=false
    Wins:=0,loss:=0,TOutcome:="win",TNav:=true,TVariant:=1,TNext:=false,TXp:=false,TUnit:=false,TPending:=false,TChest:=false,TBlocked:=false
    TOutcomeAt:=0,TStarted:=A_TickCount,TWebhooks:=0,TWebhookFail:=false,TInputs:=[],TLogs:=[],WF_LastIssue:="",BossRoomCompleted:=false
    DoseSession.results:=0,DoseSession.recoveries:=0,DoseSession.stageId:=0,DoseSession.stageStarted:=A_TickCount
    DoseSession.stageMode:="",DoseSession.stageProfile:=""
}
Run() {
    try DoseProcessStageResults(Fast)
    catch TestHandoff as step
        return step.Message
    catch MacroStop
        return "Stopped"
    return "Returned"
}
try {
    for variant in [1,2] {
        for challenge in [false,true] {
            Reset(),TVariant:=variant,inChallengeMode:=challenge
            Assert(Run()="MonitorDungeonEnd","either Return variant reaches Dungeon navigation with Challenge on/off")
            Assert(Wins=1 && loss=0 && TWebhooks=1 && !TInputs.Length,"win and webhook recorded once without leaderboard click loop")
            Assert(Run()="MonitorDungeonEnd" && Wins=1 && TWebhooks=1,"re-entered processor cannot duplicate result or webhook")
        }
    }
    Reset(),TOutcomeAt:=30
    Assert(Run()="MonitorDungeonEnd" && Wins=1 && TWebhooks=1,"delayed victory is captured before navigation")
    Reset(),TOutcome:=""
    Assert(Run()="MonitorDungeonEnd" && Wins=0 && loss=0 && TWebhooks=0,"Return-only screen proceeds without fabricating loss/webhook")
    Reset(),TOutcome:="loss"
    Assert(Run()="MonitorDungeonEnd" && Wins=0 && loss=1 && TWebhooks=1,"verified defeat follows same one-result lifecycle")
    Reset(),TWebhookFail:=true
    Assert(Run()="MonitorDungeonEnd" && Wins=1 && TWebhooks=1,"webhook failure cannot trap results")
    Assert(Run()="MonitorDungeonEnd" && TWebhooks=1,"uncertain delivery is not blindly retried")
    Reset(),TOutcome:="",TNav:=false,TPending:=true
    Assert(Run()="DoseResumeChestSession" && !TInputs.Length && !TWebhooks,"reward lock wins over results handling")
    Reset(),TChest:=true
    Assert(Run()="DoseResumeChestSession" && !Wins && !TInputs.Length,"visible chest heading wins over background victory/Return")
    Reset(),TNav:=false,TOutcome:="",TBlocked:=true
    Assert(Run()="RejoinPrivateServer" && !TInputs.Length && !TWebhooks,"blocked screen reaches bounded recovery with no guessed click")
    Reset(),TNav:=false,TOutcome:=""
    Assert(Run()="RejoinPrivateServer" && !TInputs.Length,"unknown results cannot wait forever")
    Reset(),TNav:=false,TOutcome:="",BossRoomCompleted:=true
    Assert(Run()="Stopped" && !TInputs.Length,"unknown boss-reward screen never rejoins away from potential rewards")
    Reset(),TNav:=false,TNext:=true
    Assert(Run()="MonitorDungeonEnd" && Wins=1 && TInputs.Length=1 && TInputs[1]="Next","Next prompt is dismissed after recording, then navigation verified")
    Reset(),TNav:=false,TXp:=true
    Assert(Run()="MonitorDungeonEnd" && Wins=1 && TInputs.Length=1 && TInputs[1]="Center","XP reward is dismissed after recording")
    Reset(),TNav:=false,TUnit:=true
    Assert(Run()="MonitorDungeonEnd" && Wins=1 && TInputs.Length=1 && TInputs[1]="Unit","overlay closes at its detected point before routing")
    Reset(),mode:="Story"
    Assert(Run()="MonitorEndScreen","Story retains its mode-specific result options")
    Reset(),mode:="Contract"
    Assert(Run()="HandleContractEnd","Contract retains its mode-specific result options")
    Reset(),mode:="Portal"
    Assert(Run()="HandlePortalReJoin","Portal retains its mode-specific result options")
    Reset(),DoseSession.stageId:=1,DoseSession.stageMode:="Dungeon",mode:="Story"
    Assert(Run()="MonitorDungeonEnd","active stage mode survives unrelated UI selection changes")
    Reset(),TOutcome:="",TNav:=false,TScene:="Route"
    try DoseResumeAfterReturn()
    catch TestHandoff as step
        Assert(step.Message="LookForDungeonRooms","unexpected return resumes a recognized route through existing priorities")
    Assert(!TInputs.Length,"route reconciliation never invents a fallback room click")
    Reset(),TOutcome:="",TNav:=false,TEntry:=true,inChallengeMode:=true
    try DoseResumeAfterReturn()
    catch TestHandoff as step
        Assert(step.Message="ChallengeMode","pre-open Challenge menu is resumed instead of walking again")
    Reset(),TOutcome:="",TNav:=false,DoseSession.recoveries:=3
    try DoseResumeAfterReturn()
    catch MacroStop
        Assert(!TInputs.Length,"repeated unknown progress stops at a bounded reconciliation limit")
    Reset(),TScene:="Route"
    Assert(Run()="LookForDungeonRooms" && Wins=1 && TWebhooks=1,"an already-open route cannot be mistaken for a replay results page")
    FileAppend("PASS: " C " rebuilt results-flow assertions; actual controller, synthetic references/input/network effects.`n","*")
    DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for entry in TLogs
        FileAppend(entry "`n","*")
    ExitApp(1)
}
WF_PrepareDungeon() {
    global WF_LastIssue
    WF_LastIssue:=TBlocked ? "simulated cover" : ""
    return !TBlocked
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    X:=400,Y:=140
    if text=VictoryText
        return TOutcome="win" && A_TickCount-TStarted>=TOutcomeAt
    if text=DefeatText
        return TOutcome="loss"
    if text=LobbyText
        return TNav && TVariant=1
    if text=LobbyText2
        return TNav && TVariant=2
    if text=NextText {
        X:=400,Y:=430
        return TNext
    }
    if text=XpText
        return TXp
    if text=UnitExit {
        X:=325,Y:=220
        return TUnit
    }
    return false
}
WF_RobloxClick(x,y) {
    global TNav,TNext,TUnit
    if y=430
        TInputs.Push("Next"),TNext:=false,TNav:=true
    else if y=220
        TInputs.Push("Unit"),TUnit:=false,TNav:=true
    else
        throw Error("unexpected input " x "," y)
    return true
}
DungeonChestExitBlocked() => TPending
DungeonChestMenuVisible() => TChest
ChallengeClickClient(*) {
    global TXp,TNav
    TInputs.Push("Center"),TXp:=false,TNav:=true
    return true
}
; Override only the game's client-size dependency in center click via a dummy
; native window below? Flow tests avoid that dependency by using an extracted
; center adapter, replaced in preparation with a deterministic stub.
DoseSendResultWebhook(win,duration) {
    global TWebhooks
    TWebhooks+=1
    if TWebhookFail
        throw Error("simulated webhook failure")
}
FormatStageTime(*) => "00:00:01"
AddToLog(message) => TLogs.Push(message)
CheckForLobbyText() => false
NextStep(step) {
    throw TestHandoff(step)
}
MonitorDungeonEnd() => 0
HandleContractEnd() => 0
HandlePortalReJoin() => 0
MonitorEndScreen() => 0
CheckLobby() => 0
RejoinPrivateServer() => 0

ChallengeEntryMenuVisible() => TEntry
ChallengeMode() => 0
DungeonEntranceScene(&X,&Y,&layout) {
    X:=0,Y:=0,layout:="3:Available"
    return TScene
}
LookForDungeonRooms() => 0

CheckDungeonSpecials() => true
