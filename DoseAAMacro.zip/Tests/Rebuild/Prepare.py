"""Extract actual production bodies for isolated tests; no user data is read."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent

def function(path, name):
    source = (ROOT / path).read_text(encoding='utf-8-sig')
    match = re.search(r'^' + name + r'\([^\n]*\)\s*\{.*?^\}', source, re.M | re.S)
    if not match:
        raise ValueError(name)
    return match[0]

def without(source, names):
    for name in names:
        source, count = re.subn(r'^' + name + r'\([^\n]*\)\s*\{.*?^\}', '', source, flags=re.M | re.S)
        if count != 1:
            raise ValueError(name)
    return source

results = (ROOT / 'Lib/Engine/Results.ahk').read_text()
native = without(results, ['DoseSendResultWebhook'])
(OUT / 'ResultsNativeForTests.ahk').write_text('; Actual controller; external webhook adapter replaced.\n' + native)
flow = without(native, ['DoseGameCenterClick'])
flow += '\nDoseGameCenterClick() => ChallengeClickClient(0,0)\n'
(OUT / 'ResultsForTests.ahk').write_text('; Actual controller; external webhook and client-size adapters replaced.\n' + flow)
movement = '\n\n'.join(function('Lib/Game/MapMovement.ahk', n) for n in ['MoveForStrangeTown', 'MoveForCursedFestival'])
(OUT / 'MovementForTests.ahk').write_text('; Actual production map routes.\n' + movement + '\n')
(OUT / 'ChestStateForTests.ahk').write_text('; Actual state constructor.\n' + function('Lib/Modes/Dungeon/DungeonChestOpening.ahk', 'DungeonChestNewState') + '\n')
connection = without((ROOT / 'Lib/Engine/Connection.ahk').read_text(), ['DosePrivateServerLink', 'DoseOpenServerLink'])
(OUT / 'ConnectionForTests.ahk').write_text('; Actual connection service; private-file and launch adapters replaced.\n' + connection)
(ROOT / 'Tests/ChestStartFunctionsForTests.ahk').write_text('; Actual start dispatcher.\n' + function('Lib/GameMango.ahk', 'StartSelectedMode') + '\n')
(ROOT / 'Tests/BossChestPriorityFunctionsForTests.ahk').write_text('; Actual end-navigation owner.\n' + function('Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk', 'MonitorDungeonEnd') + '\n')
p = ROOT / 'Tests/NativeChestFunctionsForTests.ahk'
s = p.read_text()
s = re.sub(r'^HandleChestScreen\([^\n]*\)\s*\{.*?^\}', lambda m: function('Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk', 'HandleChestScreen'), s, flags=re.M | re.S)
p.write_text(s)
names = ['ChallengeMode', 'ChallengeStartPromptVisible', 'ChallengePlayHereVisible', 'ChallengeEntryMenuVisible', 'ChallengeSelectPlayNow', 'ChallengeClickClient', 'ChallengeConfirmSoloDeparture']
(ROOT / 'Tests/ChallengeFunctionsForTests.ahk').write_text('; Actual Challenge functions.\n' + '\n\n'.join(function('Lib/GameMango.ahk', n) for n in names) + '\n')
print('Prepared actual rebuild helpers without Main/private startup.')

nav = function('Lib/GameMango.ahk', 'MonitorEndScreen').replace('Sleep(3000)', 'Sleep(1)').replace('Sleep(2000)', 'Sleep(1)').replace('Sleep(1500)', 'Sleep(1)')
(OUT / 'NavigationForTests.ahk').write_text('; Actual mode navigation; only sleeps shortened for deterministic tests.\n' + nav + '\n')
