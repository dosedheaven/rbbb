#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Functions\ScreenActions.ahk
; Actual bounded helper/conversion; reference, clock and input effects simulated.
global C:=0,NTime:=1,NReads:=0,NInputs:=[],NReady:=true,NPending:=false,NInputOK:=true
 global NMode:="AfterClick",NTarget:="Primary",NSequence:=[],NRegionOK:=true
DoseSession.traceRoot:=A_Temp "\DoseInputBounds-" A_TickCount
class NHandoff extends Error {
}
class NRecovery extends Error {
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
Reset() {
    global
    NTime:=1,NReads:=0,NInputs:=[],NReady:=true,NPending:=false,NInputOK:=true
    NMode:="AfterClick",NTarget:="Primary",NSequence:=[],NRegionOK:=true
}
Invoke(x:=0,y:=0,dx:=0,dy:=0,secondary:="",right:=false) {
    try {
        if right
            result:=RightClickUntilGone(x,y,0,0,800,600,"Primary",dx,dy,secondary)
        else
            result:=ClickUntilGone(x,y,0,0,800,600,"Primary",dx,dy,secondary)
        return result ? "Done" : "Returned"
    } catch NHandoff {
        return "Chest"
    } catch NRecovery {
        return "Recovery"
    }
}
try {
    Reset(),NMode:="Sequence",NSequence:=[false,false]
    Assert(Invoke()="Done" && NReads=2 && !NInputs.Length,"two absent observations complete without a click")
    Reset()
    Assert(Invoke()="Done" && NInputs.Length=1 && NInputs[1].x=100 && NInputs[1].y=200,"template-based click uses its detected coordinates")
    Reset()
    Assert(Invoke(0,0,-4,-35)="Done" && NInputs[1].x=96 && NInputs[1].y=165,"existing explicit client offsets remain compatible")
    Reset()
    Assert(Invoke(400,300)="Done" && NInputs[1].x=400 && NInputs[1].y=300,"existing explicit client action point remains compatible")
    Reset(),NTarget:="Secondary"
    Assert(Invoke(0,0,0,0,"Secondary")="Done" && NInputs.Length=1,"alternate reference can drive the same bounded helper")
    Reset(),NMode:="Sequence",NSequence:=[true,false,true,false,false]
    Assert(Invoke()="Done" && NInputs.Length=2,"one blank frame cannot complete a still-present control")
    Reset(),NMode:="Always"
    Assert(Invoke()="Recovery" && NInputs.Length=6,"ignored clicks have a strict six-attempt bound")
    Reset(),NPending:=true
    Assert(Invoke()="Chest" && !NReads && !NInputs.Length,"pending chest owner blocks scanning and navigation input")
    Reset(),NReady:=false
    Assert(Invoke()="Recovery" && !NReads && !NInputs.Length,"unready window cannot receive navigation input")
    Reset(),NInputOK:=false
    Assert(Invoke()="Recovery" && !NInputs.Length,"refused matched input reaches recovery without counting a click")
    Reset()
    Assert(Invoke(0,0,0,0,"",true)="Done" && NInputs.Length=1 && NInputs[1].button="Right","right-click uses validated conversion and its original button")
    Reset(),NRegionOK:=false
    Assert(Invoke(0,0,0,0,"",true)="Recovery" && !NInputs.Length,"changed right-click region produces no input")
    FileAppend("PASS: " C " bounded-navigation input assertions; actual helper/conversion, simulated references/clock/input.`n","*")
    DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
DoseActiveTick() => NTime
Sleep(ms) {
    global NTime
    NTime+=ms
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global NReads
    NReads+=1,X:=100,Y:=200
    return NMode="Always" ? true : NMode="Sequence" ? (NSequence.Length ? NSequence.RemoveAt(1) : false) : text=NTarget && !NInputs.Length
}
FixClick(x,y,button:="Left") => NInputs.Push({x:x,y:y,button:button})
WF_RobloxClick(x,y) {
    if !NInputOK
        return false
    FixClick(x,y)
    return true
}
WF_RobloxRegion(x,y,*) => {left:x+50,top:y+50}
WF_RegionUnchanged(*) => NRegionOK
WF_PrepareDungeon() => NReady
DungeonChestExitBlocked() => NPending
DoseResumeChestSession() => 0
NextStep(*) {
    throw NHandoff("Chest owns input")
}
DoseRecoverSession(*) {
    throw NRecovery("Expected bounded recovery")
}
DoseCaptureFailure(*) => 0
