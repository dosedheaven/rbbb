# Rebuild verification tools

The macro needs AutoHotkey v2 on Windows. Python is optional and is used only for these development tools. Tests never launch Main's startup, target Roblox, inspect personal settings or send webhooks. Native-window fixtures should run on an unused desktop; run them sequentially so they do not cover each other.

Run the full current non-console suite:

    python Tests/Rebuild/Run.py --ahk "C:/Program Files/AutoHotkey/v2/AutoHotkey64.exe"

Use --only followed by suite stems for a targeted rerun, for example PolicyTests ResultsFlowTests. The full suite includes a real two-minute chest-recovery wait and production room-selection waits; allow several minutes. AHK_EXE can specify the Windows executable. Linux validation can use --runner with an isolated Wine/AHK wrapper that sets its own display/prefix and /ErrorStdOut.

Render and audit the actual console with synthetic settings/game/services:

    python Tests/Rebuild/RunConsole.py --theme Ethereal --ahk "C:/Program Files/AutoHotkey/v2/AutoHotkey64.exe"

Repeat with Akatsuki and at each display scale you intend to support. Windows scaling must be set before starting the AHK process. The console runner coordinates fixture-ready markers automatically; it does not change system DPI. Temporary console output goes to PreviewOutput. Runtime/counter/input assertions and settings round trips are performed by AHK; game responses and network effects are simulated.

Prepare.py and the older Prepare*Tests.py scripts regenerate isolated helpers from actual application functions. Only explicit external boundaries (webhooks, capture/launch adapters, private-file startup, or client sizing in non-native flow tests) are replaced. NavigationForTests shortens sleeps without changing decision branches. Native tests retain the real FindText patterns and game-coordinate conversion. FullSourceSyntax checks every application include with ExitApp before startup.

Current run records are in Verification. Tests/History contains earlier release evidence and superseded layout checks; those records do not certify v4.1. Test fixtures contain cropped reference controls, not full personal screenshots. See VERIFICATION.md for scope and current counts.
