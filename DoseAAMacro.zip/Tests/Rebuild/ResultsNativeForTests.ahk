; Actual controller; external webhook adapter replaced.
#Requires AutoHotkey v2.0

; One observation contract for placement, upgrading and monitoring. Both Return
; references use the same region. No click occurs while collecting evidence.
DoseEmptyResultsEvidence(kind:="None") {
    return {kind:kind,outcome:"",navigation:false,next:false,xp:false,unit:false,points:Map()}
}

DoseResultsEvidence() {
    global WF_LastIssue
    e:=DoseEmptyResultsEvidence()
    if DungeonChestExitBlocked() {
        e.kind:="Chest"
        return e
    }
    if !WF_PrepareDungeon() {
        return DoseEmptyResultsEvidence("Blocked")
    }
    if DungeonChestMenuVisible() {
        e.kind:="Chest"
        return e
    }
    if WF_LastIssue!="" {
        return DoseEmptyResultsEvidence("Blocked")
    }
    header:=DoseDungeonMenuHeader()
    if header!=""
        return DoseEmptyResultsEvidence(header)
    probes:=[
        ["win",150,175,500,285,VictoryText], ["win",150,175,500,285,VictoryText2],
        ["win",150,175,500,285,VictoryTextApril],
        ["loss",150,175,500,285,DefeatText], ["loss",150,175,500,285,DefeatText2],
        ["navigation",80,85,739,224,LobbyText], ["navigation",80,85,739,224,LobbyText2],
        ["xp",575,145,641,210,XpText], ["next",260,390,500,470,NextText],
        ["unit",300,190,370,260,UnitExit]]
    for p in probes {
        if WF_FindText(&X,&Y,p[2],p[3],p[4],p[5],0,0,p[6]) {
            if p[1]="win" || p[1]="loss" {
                ; Contradictory outcome pixels are not resolved by probe order.
                if e.outcome!="" && e.outcome!=p[1] {
                    return DoseEmptyResultsEvidence("Blocked")
                }
                e.outcome:=p[1]
            } else {
                e.%p[1]%:=true,e.points[p[1]]:={x:X,y:Y}
            }
        }
        if WF_LastIssue!="" {
            return DoseEmptyResultsEvidence("Blocked")
        }
    }
    e.kind:=e.outcome!="" ? "Outcome" : e.navigation ? "Navigation" : e.xp ? "Results" : e.next ? "Next" : e.unit ? "Unit" : "None"
    return e
}

DoseRouteStageEnd(source:="stage") {
    e:=DoseResultsEvidence()
    if e.kind="Chest"
        return NextStep(DoseResumeChestSession)
    if e.kind="Shop" || e.kind="Shrine"
        return NextStep(DoseResumeDungeonMenu)
    if e.outcome!="" || e.navigation || e.xp || e.next {
        DoseSession.ExpectResults(source,e)
        return NextStep(DoseProcessStageResults)
    }
    return false
}

DoseResultsOptions(overrides:=0) {
    o:={timeoutMs:45000,outcomeMs:8000,pollMs:350,retryMs:1200,rescanMs:10000,maxRescans:2}
    if IsObject(overrides)
        for name,value in overrides.OwnProps()
            if o.HasOwnProp(name)
                o.%name%:=value
    return o
}

DoseProcessStageResults(overrides:=0) {
    global successfulCoordinates,maxedCoordinates
    o:=DoseResultsOptions(overrides),state:=DoseSession.ExpectResults("processor",0,o)
    successfulCoordinates:=[],maxedCoordinates:=[]
    StageGuard.Disarm("Stage")
    AddToLog("Results controller: preserving detected stage end; checking outcome and navigation")
    Loop {
        e:=DoseResultsEvidence(),now:=A_TickCount,action:=state.Decide(e,now,o.retryMs)
        switch action {
            case "Chest": return NextStep(DoseResumeChestSession)
            case "Menu": return NextStep(DoseResumeDungeonMenu)
            case "Record","RecordUnknown":
                DoseRecordStageResult(state,action="RecordUnknown" ? "unknown" : state.outcome)
            case "Route":
                DoseSession.Progress("Results handled; navigation confirmed")
                known:=DoseDungeonScreenStep()
                if IsObject(known)
                    return NextStep(known)
                return DoseRouteResultsNavigation()
            case "CloseUnit","Next":
                key:=action="Next" ? "next" : "unit"
                if e.points.Has(key) {
                    if DoseClickResultControl(key) {
                        state.Acted(now),DoseSession.Progress("Results " key " click")
                    }
                }
            case "Dismiss":
                if DoseGameCenterClick() {
                    state.Acted(now),DoseSession.Progress("Results reward dismissal")
                }
            case "Recover":
                DoseCaptureFailure("Results transition",e.kind)
                if state.rescans<o.maxRescans {
                    state.rescans+=1,state.deadline:=now+o.rescanMs,state.actions:=0
                    AddToLog("Results rescan " state.rescans "/" o.maxRescans "; no guessed navigation")
                } else
                    return DoseRecoverSession("Results remained unconfirmed")
        }
        Sleep(o.pollMs)
    }
}

DoseRecordStageResult(state,outcome) {
    global Wins,loss,stageStartTime
    if state.recorded
        return
    ; Claim before logging/network. Re-entry cannot count a result or attempt a
    ; webhook twice. Network delivery cannot be made exactly-once by this client.
    state.recorded:=true
    duration:=FormatStageTime(A_TickCount-(IsSet(stageStartTime) ? stageStartTime : DoseSession.stageStarted))
    if outcome="unknown" {
        AddToLog("Result navigation confirmed but outcome unreadable; no fabricated win/loss or webhook")
        DoseSession.Trace("outcome","unknown")
        DoseCaptureFailure("Unreadable outcome","Navigation verified; stats/webhook skipped")
        return
    }
    if outcome="win"
        Wins+=1
    else
        loss+=1
    AddToLog((outcome="win" ? "Victory" : "Defeat") " detected - Stage Length: " duration)
    DoseSession.Trace("outcome",outcome)
    state.webhookAttempted:=true
    try {
        DoseSendResultWebhook(outcome="win",duration)
    } catch as err {
        if Type(err)="MacroNextStep" || Type(err)="MacroStop"
            throw err
        AddToLog("Win/result recorded; webhook attempt failed: " err.Message)
    }
}



DoseRouteResultsNavigation() {
    global mode
    activeMode:=DoseSession.stageId>0 && DoseSession.stageMode!="" ? DoseSession.stageMode : mode
    switch activeMode {
        case "Dungeon": return NextStep(MonitorDungeonEnd)
        case "Contract": return NextStep(HandleContractEnd)
        case "Portal": return NextStep(HandlePortalReJoin)
        default: return NextStep(MonitorEndScreen)
    }
}

DoseGameCenterClick() {
    global rblxID
    if DungeonChestExitBlocked() || DungeonChestMenuVisible()
        return false
    if !WF_FindText(&X,&Y,575,145,641,210,0,0,XpText)
        return false
    try {
        WinGetClientPos(,,&w,&h,rblxID)
        return ChallengeClickClient(w//2,h//2)
    }
    return false
}

DoseResumeChestSession() {
    DoseSession.phase:="Chest rewards"
    if !HandleChestScreen() {
        DoseCaptureFailure("Chest owner","Rewards remain pending")
        throw MacroStop("Chest rewards remain pending; state retained. Start again to resume; no entry/rejoin sent.")
    }
    DoseSession.Progress("Chest owner released after verified exit")
    return LookForDungeonRooms()
}

DoseRecoverSession(reason) {
    global BossRoomCompleted
    if DungeonChestExitBlocked()
        return NextStep(DoseResumeChestSession)
    if BossRoomCompleted
        throw MacroStop(reason "; boss rewards may remain. No lobby/rejoin input sent.")
    DoseSession.recoveries+=1
    if DoseSession.recoveries>3
        throw MacroStop(reason "; automatic recovery limit reached. See Logs/SessionTrace.tsv.")
    AddToLog(reason " - recovery " DoseSession.recoveries "/3")
    if CheckForLobbyText()
        return NextStep(CheckLobby)
    return NextStep(RejoinPrivateServer)
}

DoseCaptureFailure(context,detail:="") {
    global rblxID
    DoseSession.Trace("failure",context " / " detail)
    try {
        folder:=A_ScriptDir "\Logs\Diagnostics"
        if !DirExist(folder)
            DirCreate(folder)
        ; Rotate three local game-only captures; no external upload is performed.
        DoseSession.diagnosticSequence+=1
        slot:=Mod(DoseSession.diagnosticSequence-1,3)+1
        if !WF_PrepareDungeon()
            return
        WinGetClientPos(&x,&y,&w,&h,rblxID)
        FindText().SavePic(folder "\LastFailure-" slot ".bmp",x,y,x+w-1,y+h-1)
    }
}

DoseResumeAfterReturn() {
    global mode,inChallengeMode
    DoseSession.phase:="Recovering"
    DoseCaptureFailure("Step returned",DoseSession.step)
    if DungeonChestExitBlocked()
        return NextStep(DoseResumeChestSession)
    DoseSession.recoveries+=1
    if DoseSession.recoveries>3
        throw MacroStop("No verified progress after three reconciliations; last screen saved locally. No unsafe fallback click.")
    known:=DoseDungeonScreenStep()
    if IsObject(known)
        return NextStep(known)
    e:=DoseResultsEvidence()
    if e.kind="Chest"
        return NextStep(DoseResumeChestSession)
    if e.outcome!="" || e.navigation || e.xp || e.next {
        DoseSession.ExpectResults("step reconciliation",e)
        return NextStep(DoseProcessStageResults)
    }
    if inChallengeMode && ChallengeEntryMenuVisible()
        return NextStep(ChallengeMode)
    if mode="Dungeon" && e.kind!="Blocked" {
        scene:=DungeonEntranceScene(&X,&Y,&layout)
        if scene="Route" || scene="Enter" {
            AddToLog("Recovery: dungeon screen recognized; re-running existing selection policies")
            return NextStep(LookForDungeonRooms)
        }
    }
    ; The shared recovery routine applies its own final retry limit and protects
    ; possible boss rewards. Compensate its accounting for this reconciliation.
    DoseSession.recoveries-=1
    return DoseRecoverSession("Step ended without a verified next screen")
}

DoseClickResultControl(key) {
    if DungeonChestExitBlocked() || DungeonChestMenuVisible()
        return false
    if !WF_PrepareDungeon()
        return false
    rect:=key="unit" ? [300,190,370,260] : [260,390,500,470]
    text:=key="unit" ? UnitExit : NextText
    if !WF_FindText(&X,&Y,rect[1],rect[2],rect[3],rect[4],0,0,text)
        return false
    return WF_RobloxClick(X,Y)
}
