; Actual production map routes.
MoveForStrangeTown() {
    if (ModeDropdown.Text = "Fool's Hunt" or ModeDropdown.Text = "Raid" or ModeDropdown.Text = "Dungeon") {
        if DoseMovementAngle(StrangeTownAngle,[34,483,82,512]) {
            AddToLog("Strange Town angle: matched; left route")
            /*SendInput ("{a down}") ; Move To Center Garden
            Sleep (1600)
            SendInput ("{a up}")
            KeyWait "a"
            Sleep (1000)
            SendInput ("{w down}")
            Sleep (600)
            SendInput ("{w up}")
            KeyWait "w"
            Sleep (1000)*/
            SendInput ("{a down}")
            Sleep (2500)
            SendInput ("{a up}")
            KeyWait "a"
            Sleep (1000)
        } else {
            AddToLog("Strange Town angle: stable alternate; right route")
            SendInput ("{d down}")
            Sleep (2500)
            SendInput ("{d up}")
            KeyWait "d"
            Sleep (1000)
        }
    }
}

MoveForCursedFestival() {
    if (ModeDropdown.Text = "Fool's Hunt") {
        if (ok := FT(&X, &Y, 47, 213, 107, 257, 0.15, 0.15, CursedFestivalAngle)) {
            SendInput ("{d down}")
            Sleep (1800)
            SendInput ("{d up}")
            KeyWait "d"
            Sleep (1000)
            SendInput ("{s down}")
            Sleep (800)
            SendInput ("{s up}")
            KeyWait "s"
            Sleep (1000)
        } else {
            SendInput ("{a down}")
            Sleep (1800)
            SendInput ("{a up}")
            KeyWait "a"
            Sleep (1000)
            SendInput ("{w down}")
            Sleep (800)
            SendInput ("{w up}")
            KeyWait "w"
            Sleep (1000)
        }
    } else {
         if DoseMovementAngle(FestivalAngle,[560,285,615,350]) {
            AddToLog("Cursed Festival angle: matched; right route")
            SendInput ("{d down}")
            Sleep (1800)
            SendInput ("{d up}")
            KeyWait "d"
            Sleep (1000)
        } else {
            AddToLog("Cursed Festival angle: stable alternate; left route")
            SendInput ("{a down}")
            Sleep (1800)
            SendInput ("{a up}")
            KeyWait "a"
            Sleep (1000)
        }
    }
}
