"""Render and audit the real console using isolated fixture services/settings."""
from pathlib import Path
import argparse
import os
import subprocess
import sys
import time
from Run import HERE, win


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--theme', choices=['Akatsuki', 'Ethereal'], default='Ethereal')
    parser.add_argument('--ahk', default=os.environ.get('AHK_EXE', r'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'))
    parser.add_argument('--runner')
    parser.add_argument('--output', type=Path, default=HERE / 'PreviewOutput')
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, str(HERE / 'PrepareConsole.py'), args.theme, str(output)], check=True)
    command = [args.runner] if args.runner else [args.ahk, '/ErrorStdOut']
    logfile = output / 'Console.log'
    with logfile.open('w', encoding='utf-8') as stream:
        process = subprocess.Popen(command + [win(output / 'RebuildUIPreview.ahk')], stdout=stream, stderr=stream)
        deadline = time.monotonic() + 180
        done = set()
        try:
            while process.poll() is None and time.monotonic() < deadline:
                for stage in ['main', 'Advanced', 'Settings', 'Placement', 'Movement', 'Debug', 'Scheduler', 'Cards', 'Guide']:
                    if stage not in done and (output / f'rebuild-{stage}-ready.txt').exists():
                        (output / f'rebuild-{stage}-advance.txt').touch()
                        done.add(stage)
                time.sleep(.1)
            if process.poll() is None:
                raise RuntimeError('Console test timed out; inspect Console.log')
            status = process.wait()
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=10)
    text = logfile.read_text(encoding='utf-8', errors='replace')
    if status or 'PASS: 2885 rebuilt console assertions' not in text or 'FAIL:' in text:
        raise RuntimeError('Console test failed; inspect Console.log')
    print('\n'.join(line for line in text.splitlines() if line.startswith(('PASS:', 'DPI:'))))


if __name__ == '__main__':
    main()
