#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\..\Lib\Engine\Pause.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Persistence.ahk
#Include %A_ScriptDir%\ChestStateForTests.ahk
global C:=0,NG:=Gui("-Caption +ToolWindow"),rblxID:="ahk_id " NG.Hwnd
 global DoseChestState:=0,DungeonChestExitLocked:=false,NHeader:=true,NLobby:=false,NLogs:=[]
 global PlacementSelection:={Text:"Dungeon"},inChallengeMode:=false,BossRoomCompleted:=false,NScene:="Waiting",NArmed:=0
 global TestRoot:=A_Temp "\DosePersistence-" A_TickCount,OwnedSettings:=false
DoseSession.traceRoot:=TestRoot "\Trace"
NG.Show("x100 y100 w816 h638 NA")
class MacroStop extends Error {
}
class MacroLoopState {
    static Active:=false
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
try {
    if DirExist(A_ScriptDir "\Settings")
        throw Error("Refusing to overwrite existing test Settings directory")
    DirCreate(A_ScriptDir "\Settings"),OwnedSettings:=true
    DirCreate(TestRoot "\Original\CustomMovement")
    FileAppend("Enabled1=1`n",TestRoot "\Original\Configuration.txt")
    FileAppend("synthetic movement",TestRoot "\Original\CustomMovement\Map.txt")
    Assert(DoseBackupSettings(TestRoot "\Original",TestRoot "\Backup"),"backup captures the complete prior settings folder")
    Assert(FileRead(TestRoot "\Backup\CustomMovement\Map.txt")="synthetic movement","recordings are backed up along with configuration")
    FileAppend("Enabled2=1",TestRoot "\Original\Configuration.txt")
    Assert(!DoseBackupSettings(TestRoot "\Original",TestRoot "\Backup"),"one-time backup is never overwritten by later saves")
    Assert(FileRead(TestRoot "\Backup\Configuration.txt")="Enabled1=1`n","backup retains original configuration bytes")
    DoseChestState:=DungeonChestNewState(),DungeonChestExitLocked:=true
    DoseChestState.phase:="Reward",DoseChestState.owedClicks:=2,DoseChestState.commonOpens:=3
    DoseSaveChestCheckpoint()
    Assert(IniRead(A_ScriptDir "\Settings\RuntimeChest.ini","Chest","Owed",-1)=2,"pending pair is written durably")
    DoseChestState:=0,DungeonChestExitLocked:=false
    DoseRestoreChestCheckpoint()
    Assert(DungeonChestExitLocked && DoseChestState.owedClicks=2 && DoseChestState.commonOpens=3,"reload restores reward debt and exclusive owner")
    DoseChestState.owedClicks:=1,DoseSaveChestCheckpoint(),DoseChestState:=0,DungeonChestExitLocked:=false,NHeader:=false
    DoseRestoreChestCheckpoint()
    Assert(DungeonChestExitLocked && DoseChestState.owedClicks=1,"same-process reward overlay can resume the remaining dismissal")
    DoseChestState.owedClicks:=0,DoseChestState.phase:="Reward",DoseChestState.rewardChain:=true
    DoseSaveChestCheckpoint(),DoseChestState:=0,DungeonChestExitLocked:=false
    DoseRestoreChestCheckpoint()
    Assert(DungeonChestExitLocked && DoseChestState.rewardChain,"opaque delayed reward chain survives reload even after its nominal pair")
    DoseChestState.owedClicks:=1,DoseSaveChestCheckpoint()
    DoseChestState:=0,DungeonChestExitLocked:=false,NLobby:=true
    try {
        DoseRestoreChestCheckpoint()
        throw Error("lobby must not accept an old opaque-reward checkpoint")
    } catch MacroStop {
        Assert(!DungeonChestExitLocked,"unrelated lobby screen gets no restored input owner")
    }
    NLobby:=false,NHeader:=true,DoseChestState:=DungeonChestNewState(),DungeonChestExitLocked:=false
    DoseChestState.phase:="Complete",DoseSaveChestCheckpoint(),DoseChestState:=0
    DoseRestoreChestCheckpoint()
    Assert(!DungeonChestExitLocked && !IsObject(DoseChestState),"completed session never relocks entry on startup")
    IniWrite(1,A_ScriptDir "\Settings\RuntimeChest.ini","Chest","Pending")
    IniWrite(99,A_ScriptDir "\Settings\RuntimeChest.ini","Chest","Owed")
    try {
        DoseRestoreChestCheckpoint()
        throw Error("invalid debt must stop")
    } catch MacroStop {
        Assert(!DungeonChestExitLocked,"corrupt checkpoint cannot produce input")
    }
    NHeader:=false,NScene:="Enter",NArmed:=0
    DoseChestState:=DungeonChestNewState(),DoseChestState.phase:="Verified",DungeonChestExitLocked:=true,BossRoomCompleted:=true
    DoseSaveChestCheckpoint(),DoseChestState:=0,DungeonChestExitLocked:=false,BossRoomCompleted:=false
    DoseRestoreChestCheckpoint()
    Assert(!DungeonChestExitLocked && DoseChestState.phase="Complete" && NArmed=1,"verified exit reload retains boss recovery before rewriting its checkpoint")
    Assert(IniRead(A_ScriptDir "\Settings\RuntimeChest.ini","Chest","BossExit",0)=1,"reconciled checkpoint still records completed boss")
    NHeader:=true,NScene:="Waiting",DoseChestState:=DungeonChestNewState(),DoseChestState.owedClicks:=2
    DungeonChestExitLocked:=true,BossRoomCompleted:=true,DoseSaveChestCheckpoint()
    DoseChestState:=0,DungeonChestExitLocked:=false,BossRoomCompleted:=false
    DoseRestoreChestCheckpoint()
    Assert(DungeonChestExitLocked && BossRoomCompleted,"pending-reward reload preserves completed boss through later saves")
    MacroLoopState.Active:=true,DoseSession.stageId:=1,DoseSession.stageProfile:="Challenge"
    Assert(DoseUnitPrefix()="Challenge","active Auto Challenge retains its dedicated profile")
    PlacementSelection.Text:="Dungeon"
    Assert(DoseUnitPrefix()="Challenge","viewing Dungeon during a paused Challenge cannot change active units")
    DoseSession.stageProfile:="Dungeon"
    Assert(DoseUnitPrefix()="Dungeon","ordinary active stage retains its selected profile")
    MacroLoopState.Active:=false,PlacementSelection.Text:="Fool's Hunt"
    Assert(DoseUnitPrefix()="event","inactive event profile maps to existing saved field names")
    inChallengeMode:=true
    Assert(DoseUnitPrefix()="Challenge","dedicated Challenge setup does not depend on the Auto Challenge checkbox mid-run")
    FileAppend("PASS: " C " persistence/profile assertions; actual checkpoint/backup code with synthetic files and native test PID only.`n","*")
    NG.Destroy(),DirDelete(TestRoot,1),DirDelete(A_ScriptDir "\Settings",1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    if OwnedSettings
        DirDelete(A_ScriptDir "\Settings",1)
    NG.Destroy()
    ExitApp(1)
}
DungeonChestExitBlocked() => DungeonChestExitLocked
DungeonChestMenuVisible() => NHeader
WF_PrepareDungeon() => true
CheckForLobbyText() => NLobby
AddToLog(message) => NLogs.Push(message)

DungeonEntranceScene(&X,&Y,&layout) {
    X:=400,Y:=300,layout:=""
    return NScene
}
DungeonArmBossExitRecovery() {
    global NArmed
    NArmed+=1
}
