"""Build an isolated console test from production UI; saved settings/services are replaced."""
from pathlib import Path
import re,sys,ast
def body(s, name):
    m = re.search('^' + re.escape(name) + '\\([^\\n]*\\)\\s*\\{', s, re.M)
    assert m, name
    sub = s[m.end() - 1:]
    masked = []
    quote = None
    block = False
    i = 0
    while i < len(sub):
        c = sub[i]
        if block:
            if sub.startswith('*/', i):
                masked.extend('  ')
                i += 2
                block = False
            else:
                masked.append('\n' if c == '\n' else ' ')
                i += 1
        elif quote:
            if c == '`':
                masked.extend('  ')
                i += 2
            elif c == quote:
                masked.append(' ')
                i += 1
                quote = None
            else:
                masked.append('\n' if c == '\n' else ' ')
                i += 1
        elif c in '"\'':
            quote = c
            masked.append(' ')
            i += 1
        elif sub.startswith('/*', i):
            block = True
            masked.extend('  ')
            i += 2
        elif c == ';':
            j = sub.find('\n', i)
            j = len(sub) if j < 0 else j
            masked.extend(' ' * (j - i))
            i = j
        else:
            masked.append(c)
            i += 1
    depth = 0
    for i, c in enumerate(masked):
        depth += (c == '{') - (c == '}')
        if depth == 0:
            return sub[:i + 1]
    raise AssertionError(name)
preview_theme = sys.argv[1] if len(sys.argv)>1 else "Akatsuki"
assert preview_theme in ["Akatsuki", "Ethereal"]

root=Path(__file__).resolve().parents[2]
out=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path(__file__).resolve().parent / 'PreviewOutput'
out.mkdir(parents=True,exist_ok=True)
def win(p): return str(p) if sys.platform=='win32' else 'Z:'+str(p).replace('/','\\')
def no_includes(text): return re.sub(r'^#Include[^\n]*\n','',text,flags=re.M)
gui=no_includes((root/'Lib/GUI.ahk').read_text(encoding='utf-8-sig'))
a=gui.index('; [Optimised] keep the log')
b=gui.index('global WebhookURLFile',a)
gui=gui[:a]+gui[b:]
for name in ['Logs','Settings']:
    block=f'if !DirExist(A_ScriptDir "\\{name}") {{\n    DirCreate(A_ScriptDir "\\{name}")\n}}\n'
    assert block in gui
    gui=gui.replace(block,'',1)
for name in ['setupOutputFile','readInSettings','AA_LoadPanelSettings','CenterMacroWindow','SetupDraggableGui','forceRobloxSize']:
    gui=re.sub(r'^'+name+r'\(\)[ \t]*(?:;[^\n]*)?\n','',gui,flags=re.M)
gui=gui.replace('global DoseBackdrop := DoseBuildBackdrop(aaMainUI)',
    'global DoseBackdrop := DoseBuildBackdrop(aaMainUI,DoseThemeArtworkPath(AA_ThemeName(),"'+win(root/'Images/UI')+'"))')
gui=gui.replace('global DoseIconTypeface := DoseIconFont()', 'global DoseIconTypeface := DoseIconFont("'+win(root/'Images/UI/Fonts/DejaVuSans.ttf')+'")')
gui=gui.replace('DoseBuildThemeSignature(aaMainUI)', 'DoseBuildThemeSignature(aaMainUI,DoseThemeArtworkPath(AA_ThemeName(),"'+win(root/'Images/UI')+'"))')
gui=gui.replace('global DoseWallpaperFile := DoseThemeWallpaperPath()',
    'global DoseWallpaperFile := DoseThemeWallpaperPath("'+win(root/'Images/UI')+'")')
events=no_includes((root/'Lib/GuiEvents.ahk').read_text(encoding='utf-8-sig'))
config=no_includes((root/'Lib/Modes/Dungeon/DungeonConfig.ahk').read_text(encoding='utf-8-sig'))
includes=['Lib/Engine/Pause.ahk','Lib/Engine/ChallengeSchedule.ahk','Lib/Engine/Session.ahk','Lib/Engine/Persistence.ahk','Lib/AppInfo.ahk','Lib/Modes/Dungeon/DungeonChestOpening.ahk','Lib/Modes/Dungeon/DungeonEntrance.ahk','Lib/Modes/Dungeon/DungeonDefaults.ahk','Lib/Tools/Image.ahk',
          'Lib/Tools/Utilities.ahk','Lib/Tools/WindowFollow.ahk','Lib/GuiStyle.ahk','Lib/GuiSkin.ahk',
          'Lib/GuiPanels.ahk','Lib/GuiDashboard.ahk','Lib/Scheduler.ahk','Lib/Game/CardPicker.ahk','Lib/Modes/Dungeon/RoutePriorityPicker.ahk',
          'Lib/Modes/Dungeon/CursePriorityPicker.ahk','Lib/Modes/Dungeon/ShrinePriorityPicker.ahk',
          'Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk']
builders=''
for module,name in [('Lib/Game/CustomMovement.ahk','CM_BuildPanel'),('Lib/Game/CustomPlacement.ahk','CP_BuildPanel')]:
    src=(root/module).read_text(encoding='utf-8-sig')
    builders += name+'() '+body(src,name)+'\n'
cm=(root/'Lib/Game/CustomMovement.ahk').read_text(encoding='utf-8-sig')
builders += re.search(r'global CM_Maps := \[.*?\]',cm,re.S)[0]+'\n'
builders += no_includes((root/'Lib/GuiGuide.ahk').read_text(encoding='utf-8-sig')).replace('img := A_ScriptDir "\\Images\\"','img := "'+win(root/'Images')+'\\"')
dt=(root/'Lib/Tools/DetectionTester.ahk').read_text(encoding='utf-8-sig')
for name in ['DT_BuildQuickTest','DT_BuildSection']:
    declaration=re.search(r'^'+name+r'\([^\n]*\)',dt,re.M)[0]
    builders += declaration+' '+body(dt,name)+'\n'
cfg=(root/'Lib/Config.ahk').read_text(encoding='utf-8-sig')
for name in ['setupFilePath','readInSettings','SaveSettings']:
    declaration=re.search(r'^'+name+r'\([^\n]*\)',cfg,re.M)[0]
    part=declaration+' '+body(cfg,name)
    part=part.replace('try DoseBackupSettings()', r'try DoseBackupSettings(PUIConfigRoot, PUITemp "\Backup")')
    part=part.replace('A_ScriptDir "\\Settings\\Configuration.txt"','PUIConfigRoot "\\Configuration.txt"').replace('A_ScriptDir "\\Settings"','PUIConfigRoot')
    builders += part+'\n'
header='#Requires AutoHotkey v2.0\n#SingleInstance Off\n#Warn All, StdOut\n#Warn LocalSameAsGlobal, Off\n'
header+='\n'.join('#Include '+win(root/p) for p in includes)+'\n'
prelude=r'''
SetWorkingDir("ROOT")
global PUITemp := A_Temp "\DoseUIPreview-" A_TickCount
DirCreate(PUITemp)
DoseSession.traceRoot:=PUITemp "\Trace"
Dose_DungeonSettingsRoot := PUITemp "\Settings"
AA_ThemeFile := PUITemp "\Theme.txt"
global SchedFile := PUITemp "\Schedule.txt", CardPick_File := PUITemp "\CardPicker.txt"
global DT_Presets := ["Synthetic test"], DT_Names := Map("FindText",[],"Image",[])
global PUIConfigRoot := PUITemp "\Config"
DirCreate(PUIConfigRoot)
OnError(PUIError)
global PUITheme := "PREVIEW_THEME"
FileAppend(PUITheme,AA_ThemeFile,"UTF-8")
DoseIconFont("ICON_FONT_PATH")
if (PUITheme="Akatsuki")
    DoseHeadingFont("HEADING_FONT_PATH")
global SendActivityLogsCache := "0", PUIChecks := 0, debugMessages := false
global PUIGame := Gui("-Caption +ToolWindow -DPIScale")
PUIGame.BackColor := "0B1220"
PUIGame.SetFont("s20 Bold c34415F","Segoe UI")
PUIGame.Add("Text","x145 y250 w540 h40 Center BackgroundTrans","GAME VIEWPORT")
PUIGame.SetFont("s10 c7483A5","Segoe UI")
PUIGame.Add("Text","x145 y300 w540 h50 Center BackgroundTrans","UI preview only — no Roblox session`nCapture area and game coordinates are unchanged")
PUIGame.Show("x100 y100 w816 h638")
OnExit(PUICleanup)
'''.replace('ROOT',win(root)).replace('PREVIEW_THEME',preview_theme).replace('HEADING_FONT_PATH',win(root/'Images/UI/Fonts/NewRocker-Regular.ttf')).replace('ICON_FONT_PATH',win(root/'Images/UI/Fonts/DejaVuSans.ttf'))
driver=r'''
currentOutputFile := PUITemp "\PreviewLog.txt"
rblxID := "ahk_id " PUIGame.Hwnd
WinMove(20,40,,,aaMainUIHwnd)
WinMove(15,41,,,rblxID)
Sleep(150)
PUIAssert(modeSelectionGroup.Visible,"unconfirmed mode selector retained")
PUIAssert(currentVersion="4.1","release version")
FileAppend("DPI: " A_ScreenDPI "`n","*")
robloxHolder.GetPos(&hx,&hy,&hw,&hh)
PUIAssert(hx=3 && hy=33 && hw=797 && hh=597,"viewport physical geometry retained")
PUIAssert(targetWidth=816 && targetHeight=638 && offsetX=-5 && offsetY=1,"calibration unchanged")
for modeName in ControlGetItems(ModeDropdown) {
    FileAppend("MODE: " modeName "`n","*")
    ModeDropdown.Choose(modeName),OnModeChange()
    for field in [StoryDropdown,StoryActDropdown,LegendDropDown,LegendActDropdown,RaidDropdown,RaidActDropdown,InfinityCastleDropdown,PortalDropdown,PortalJoinDropdown,ContractPageDropdown,ContractJoinDropdown]
        try field.Choose(1)
    OnConfirmClick()
    PUIAssert(confirmClicked,"mode confirmation: " modeName)
    PUIAuditRunOptions()
}
ModeDropdown.Choose("Dungeon"),OnModeChange(),OnConfirmClick()
PlacementSelection.Choose("Dungeon"),ToggleMode()
FileAppend("CHECK: settings round trip`n","*")
PUISettingsRoundTrip()
FileAppend("CHECK: console controls`n","*")
DoseConsoleTick()
PUIAuditText()
MacroLoopState.Active:=true,DoseSession.paused:=false,DoseConsoleTick()
PUIAssert(!PlacementSelection.Enabled && !AA_Switches[1].pill.Enabled,"running locks native and decorated setting controls")
PUIAssert(DoseConsolePause.Enabled && DoseConsoleStop.Enabled,"pause and stop remain usable during a run")
MacroLoopState.Active:=true,DoseSession.paused:=true,DoseConsoleTick()
PUIAssert(PlacementSelection.Enabled && AA_Switches[1].pill.Enabled,"paused run allows editing native and decorated controls")
PUIAssert(!DoseConsoleChangeMode.Enabled,"active stage mode cannot be changed underneath its controller")
MacroLoopState.Active:=false,DoseSession.paused:=false,DoseConsoleTick()
PUIAssert(DoseConsoleChangeMode.Enabled && DoseConsoleRun.Enabled,"stopped console exposes mode selection and Start")
ControlClick(DoseConsoleChangeMode.Hwnd,,,,,"NA")
PUIAssert(ModeDropdown.Visible && ConfirmButton.Visible,"Change button restores mode selection without reloading")
ModeDropdown.Choose("Dungeon"),OnModeChange(),OnConfirmClick()
DoseConsoleTick()
FileAppend("ready","__OUTPUT_ROOT__\rebuild-main-ready.txt")
PUIWait("__OUTPUT_ROOT__\rebuild-main-advance.txt")
for name in ["Advanced","Settings","Placement","Movement","Debug","Scheduler","Cards","Guide"] {
    AA_ShowPanel(name)
    Sleep(100)
    PUIAssert(AA_ActivePanel=name,"panel opens: " name)
    if name="Placement"
        PUIAuditMapSelector(CP_MapList)
    if name="Movement"
        PUIAuditMapSelector(CM_MapList)
    if name="Guide" {
        Loop 5 {
            AA_GuideShowPage(A_Index)
            PUIAuditText()
        }
    } else
        PUIAuditText()
    FileAppend("ready","__OUTPUT_ROOT__\rebuild-" name "-ready.txt")
    PUIWait("__OUTPUT_ROOT__\rebuild-" name "-advance.txt")
}
AA_ShowPanel("")
FileAppend("PASS: " PUIChecks " rebuilt console assertions (actual UI/config controls; isolated settings/game/services).`n","*")
ExitApp(0)

PUIAuditRunOptions() {
    checks := [NextLevelBox,ReturnLobbyBox,MatchMaking,TeamSwap,SaveChestsBox,StopAfterDefeat,
        DenyShrines,PrioritiseFutureRareChests,NewPlacementMethod,NoMovement,BringUnits,PortalSwap]
    visible := []
    for ctrl in checks
        if ctrl.Visible
            visible.Push(ctrl)
    for ctrl in [PhysicalTeamText,PhysicalTeam,MagicTeamText,MagicTeam,placementSaveBtn,EditMaps,EditCardPrio,EditRoute]
        if ctrl.Visible
            visible.Push(ctrl)
    for i,first in visible {
        first.GetPos(&x,&y,&w,&h)
        PUIAssert(x>=960 && x+w<=1520 && y>=760 && y+h<=914,"visible run option stays in card: " first.Text)
        Loop visible.Length-i
            PUISeparate(first,visible[i+A_Index],"simultaneously visible run options do not overlap")
    }
    for target in checks {
        if !target.Visible
            continue
        snapshot := []
        for ctrl in checks
            snapshot.Push({ctrl:ctrl,value:ctrl.Value,visible:ctrl.Visible})
        target.GetPos(&tx,&ty)
        ControlClick("x" (tx+7) " y" (ty+9),aaMainUIHwnd,,,,"NA Pos")
        Sleep(40)
        for item in snapshot {
            PUIAssert(item.ctrl.Visible=item.visible,"clicking an option does not reveal/hide another")
            PUIAssert(item.ctrl.Value=(item.ctrl=target ? !item.value : item.value),"coordinate click toggles only the intended checkbox")
        }
        ControlClick("x" (tx+7) " y" (ty+9),aaMainUIHwnd,,,,"NA Pos")
        Sleep(40)
        for item in snapshot
            PUIAssert(item.ctrl.Value=item.value,"second click restores original option value")
    }
}
PUIAuditMapSelector(ctrl) {
    original := ctrl.Value
    PUIAssert(ctrl.Visible && original>0,"map selector displays a selected map")
    info := Buffer(64,0)
    NumPut("UInt",64,info)
    PUIAssert(DllCall("user32\GetComboBoxInfo","Ptr",ctrl.Hwnd,"Ptr",info),"map selector exposes native arrow/list information")
    PUIAssert(NumGet(info,28,"Int")>NumGet(info,20,"Int"),"map selector arrow has a nonzero clickable width")
    ctrl.GetPos(&x,&y,&w,&h)
    ControlClick("x" (x+w-8) " y" (y+h//2),aaMainUIHwnd,,,,"NA Pos")
    Sleep(120)
    PUIAssert(SendMessage(0x157,0,0,ctrl.Hwnd),"clicking the map arrow opens the actual popup list")
    listHwnd := NumGet(info,56,"Ptr")
    PUIAssert(DllCall("user32\GetWindowLongW","Ptr",listHwnd,"Int",-16,"UInt") & 0x200000,"long map list has its native scrollbar")
    ControlSend("{End}{Enter}",ctrl.Hwnd)
    Sleep(80)
    PUIAssert(ctrl.Value=ControlGetItems(ctrl).Length,"map list can select its last entry without clipping")
    PUIAssert(!SendMessage(0x157,0,0,ctrl.Hwnd),"map list closes after selection")
    ctrl.Choose(original)
}

PUISettingsRoundTrip() {
    global AA_UnitProfiles, PUIConfigRoot, PlaceSpeed, SaveChestsBox, StopAfterDefeat, DenyShrines
    saved := [], options := [[PlaceSpeed,3],[SaveChestsBox,1],[StopAfterDefeat,1],[DenyShrines,1]]
    for group,names in AA_UnitProfiles {
        Loop 6 {
            i := A_Index
            for k,name in names {
                controlName := name i
                ctrl := %controlName%
                if (ctrl.Type="CheckBox")
                    ctrl.Value := Mod(i+group+k,2)
                else
                    ctrl.Choose(Mod(i+group,3)+1)
                saved.Push({ctrl:ctrl,value:ctrl.Value,text:ctrl.Text,hwnd:ctrl.Hwnd})
            }
        }
    }
    for option in options {
        option[1].Value := option[2]
        saved.Push({ctrl:option[1],value:option[1].Value,text:option[1].Text,hwnd:option[1].Hwnd})
    }
    SaveSettings()
    PUIAssert(FileExist(PUIConfigRoot "\Configuration.txt"),"actual SaveSettings writes only synthetic configuration")
    for entry in saved {
        if (entry.ctrl.Type="CheckBox")
            entry.ctrl.Value := !entry.value
        else
            entry.ctrl.Choose(1)
    }
    readInSettings()
    for entry in saved
        PUIAssert(entry.ctrl.Hwnd=entry.hwnd && entry.ctrl.Value=entry.value,"original profile/option control survives actual settings save/load: " entry.ctrl.Name)
    for profile in ["Default","Challenge","Contract","Dungeon","Raid","Fool's Hunt"] {
        FileAppend("PROFILE: " profile "`n","*")
        PlacementSelection.Choose(profile)
        ToggleMode()
        AA_ShowPanel("Settings")
        AA_ShowPanel("")
        for entry in saved
            PUIAssert(entry.ctrl.Hwnd=entry.hwnd && entry.ctrl.Value=entry.value,"profile navigation preserves original setting value")
    }
    PlacementSelection.Choose("Dungeon"), ToggleMode()
    AA_ShowPanel("")
    AA_SwitchSync(AA_Switches[1])
}
PUISeparate(first,second,label) {
    first.GetPos(&x,&y,&w,&h)
    second.GetPos(&xx,&yy,&ww,&hh)
    PUIAssert(x+w<=xx || xx+ww<=x || y+h<=yy || yy+hh<=y,label)
}
PUIAuditText() {
    ; Actual native font and word-wrap metrics, against each visible text box.
    ; Logs intentionally elide older lines; their full values remain on hover.
    global aaMainUI, AA_FlatBtns, process1,process2,process3,process4,process5,process6,process7
    logs := Map(process1.Hwnd,1,process2.Hwnd,1,process3.Hwnd,1,process4.Hwnd,1,process5.Hwnd,1,process6.Hwnd,1,process7.Hwnd,1)
    for hwnd,ctl in aaMainUI {
        if (!ctl.Visible || ctl.Type!="Text" || ctl.Text="" || logs.Has(hwnd) || AA_FlatBtns.Has(hwnd))
            continue
        ctl.GetPos(&x,&y,&w,&h)
        if (w<28 || y<31) ; small icon glyphs and titlebar handled separately
            continue
        font := SendMessage(0x31,0,0,ctl.Hwnd)
        dc := DllCall("user32\GetDC","Ptr",ctl.Hwnd,"Ptr")
        previous := DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",font,"Ptr")
        rect := Buffer(16,0)
        NumPut("Int",w,"Int",h,rect,8)
        text := ctl.Text
        flags := 0x410 ; DT_CALCRECT | DT_WORDBREAK
        style := DllCall("user32\GetWindowLongW","Ptr",hwnd,"Int",-16,"UInt")
        if (style & 0x200) ; vertical-center single-line controls
            flags := 0x420
        height := DllCall("user32\DrawTextW","Ptr",dc,"Str",text,"Int",-1,"Ptr",rect,"UInt",flags)
        DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",previous,"Ptr")
        DllCall("user32\ReleaseDC","Ptr",ctl.Hwnd,"Ptr",dc)
        if (height>h || NumGet(rect,8,"Int")>w)
            FileAppend("CLIP: " text " h=" h " needs=" height " w=" w " needs=" NumGet(rect,8,"Int") "`n","*")
        PUIAssert(height<=h && NumGet(rect,8,"Int")<=w,"visible label fits: " text)
    }
}
PUIError(err,*) {
    FileAppend("ERROR: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
PUIControlFace(control) {
    font := SendMessage(0x31,0,0,control.Hwnd)
    dc := DllCall("user32\GetDC","Ptr",control.Hwnd,"Ptr")
    previous := DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",font,"Ptr")
    faceBuffer := Buffer(256,0)
    DllCall("gdi32\GetTextFaceW","Ptr",dc,"Int",128,"Ptr",faceBuffer)
    DllCall("gdi32\SelectObject","Ptr",dc,"Ptr",previous,"Ptr")
    DllCall("user32\ReleaseDC","Ptr",control.Hwnd,"Ptr",dc)
    return StrGet(faceBuffer,"UTF-16")
}

PUIAssert(ok,label) {
    global PUIChecks
    PUIChecks += 1
    if !ok {
        FileAppend("FAIL: " label "`n","*")
        ExitApp(1)
    }
}
PUIWait(path) {
    Loop 1200 {
        if FileExist(path)
            return
        Sleep(100)
    }
    throw Error("Preview capture wait timed out")
}
PUICleanup(*) {
    try DirDelete(PUITemp,1)
}
class MacroLoopState {
    static Active := false
}
StartMacro(*) => 0
TogglePause(*) => 0
ChallengeClickClient(*) => false
DoseRecoverSession(*) => false
DoseResumeChestSession(*) => false
DoseRouteStageEnd(*) => false
LoadKeybindSettings(*) {
}
SaveKeybindSettings(*) {
}
GetMapForFarming(*) => "synthetic farm map"
LoadFoolsConfig(*) => 0
SaveWinterLocal(*) => 0
SaveMapSkipLocal(*) => 0
SaveWebhookSettings(*) {
    throw Error("No webhooks in UI preview")
}
AA_SaveFailsafeSettings(*) {
}
AA_ImportUnitConfig(*) {
}
AA_ExportUnitConfig(*) {
}
ExportConfigCode(*) {
}
CM_StartRecording(*) => 0
CM_DeleteRecording(*) => 0
CM_StatusText(*) => "Synthetic preview only"
CM_SaveUseSetting(*) => 0
CM_ImportMovement(*) => 0
CM_ExportMovement(*) => 0
CM_OnRecordedPick(*) => 0
CM_ReadUseSetting(*) => false
CM_RefreshPanel(*) => 0
CP_StartRecording(*) => 0
CP_DeleteSpots(*) => 0
CP_RefreshPanel(*) => 0
CP_SaveUseSetting(*) => 0
CP_OnRecordedPick(*) => 0
CP_ReadUseSetting(*) => false
DT_Init(*) {
}
DT_ChooseImage(*) => 0
DT_RunPreset(*) => 0
DT_FillNames(*) => 0
DT_SelectName(*) => 0
DT_FillFromCode(*) => 0
DT_Test(*) => 0
DT_SaveOverride(*) => 0
DT_ResetOverride(*) => 0
'''
for p in out.glob('rebuild-*-ready.txt'):p.unlink()
for p in out.glob('rebuild-*-advance.txt'):p.unlink()
(out/'RebuildUIPreview.ahk').write_text(header+events+'\n'+config+'\n'+builders+'\n'+prelude+'\n'+gui+'\n'+driver.replace('__OUTPUT_ROOT__',win(out)),encoding='utf-8')
print('Prepared isolated preview from actual GUI, events, styles, panels and config functions; game/services and private settings startup excluded.')
