#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\NavigationForTests.ahk
global C:=0,mode:="Story",inChallengeMode:=false,challengeStartTime:=0,FW_EndScreenTimeoutMs:=1000
 global StoryActDropdown:={Text:"1"},StoryDropdown:={Text:"Synthetic"},ReturnLobbyBox:={Value:0},MatchMaking:={Value:0}
 global ChallengeBox:={Value:0},NextLevelBox:={Value:1},PortalSwap:={Value:0}
 global NEvents:=[],NSchedule:=false,NDue:=false,NKind:="Navigation",NIterations:=0
class NHandoff extends Error {
    __New(step) {
        super.__New(step.Name)
    }
}
class StageGuard {
    static Arm(*) => 0
    static Disarm(*) => 0
    static Check(*) {
        global NIterations
        NIterations+=1
        if NIterations>2
            throw NHandoff(Stopped)
    }
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
Run(outcome:="win",selected:="Story") {
    global mode,NEvents,NIterations
    mode:=selected,NEvents:=[],NIterations:=0
    DoseSession.results:={outcome:outcome}
    try MonitorEndScreen()
    catch NHandoff as step
        return step.Message
    return "Returned"
}
Events() {
    value:=""
    for item in NEvents
        value.=(value="" ? "" : ",") item
    return value
}
try {
    Assert(Run()="RestartStage" && Events()="Next","verified Story win uses Next Level")
    Assert(Run("loss")="RestartStage" && Events()="Replay","Story loss replays")
    Assert(Run("")="RestartStage" && Events()="Replay","unreadable outcome cannot advance a Story act")
    StoryActDropdown.Text:="Infinity",ReturnLobbyBox.Value:=1
    Assert(Run()="CheckLobby" && Events()="Return","Story Infinity return waits for lobby rather than loading a nonexistent map")
    ReturnLobbyBox.Value:=0,PortalSwap.Value:=1
    Assert(Run()="CheckLobby" && Events()="Swap,Return","Story Infinity alternate farm swaps before return")
    PortalSwap.Value:=0,StoryActDropdown.Text:="1"
    for selected in ["Raid","Fool's Hunt","Winter Event","Other"] {
        ReturnLobbyBox.Value:=1
        Assert(Run("win",selected)="CheckLobby" && Events()="Return",selected " retains Return to Lobby")
        ReturnLobbyBox.Value:=0
        Assert(Run("win",selected)="RestartStage" && Events()="Replay",selected " retains Replay")
    }
    Assert(Run("win","Infinity Castle")="RestartStage" && Events()="Replay","Infinity Castle continues using its existing next-floor action")
    Assert(Run("loss","Infinity Castle")="RestartStage" && Events()="Replay","Infinity Castle defeat restarts")
    Assert(Run("win","Cursed Womb")="CheckLobby" && Events()="Return","Cursed Womb returns")
    inChallengeMode:=true
    Assert(Run("win","Raid")="CheckLobby" && !inChallengeMode && Events()="Lobby" && A_TickCount-challengeStartTime<1000,"Challenge completion resets cooldown and returns to selected mode")
    ChallengeBox.Value:=1,NDue:=true
    Assert(Run("win","Raid")="CheckLobby" && inChallengeMode && Events()="Lobby","due Challenge takes the solo lobby route after results")
    inChallengeMode:=false,NSchedule:=true
    Assert(Run("win","Raid")="CheckLobby" && !inChallengeMode && Events()="Lobby","schedule retains precedence at a completed ordinary stage")
    NSchedule:=false,NKind:="Chest"
    Assert(Run()="DoseResumeChestSession" && Events()="","foreground chest rewards prevent generic result navigation")
    NKind:="Shop"
    Assert(Run()="DoseResumeDungeonMenu" && Events()="","foreground dungeon menu owns the screen")
    NKind:="Blocked"
    Assert(Run()="Stopped" && Events()="","unreadable screen produces no blind dismissal or replay click")
    FileAppend("PASS: " C " mode-navigation assertions; actual adapter with shortened sleeps and synthetic game/settings/network effects.`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
DoseResultsEvidence() => {kind:NKind,navigation:NKind="Navigation",next:false,xp:false,unit:false}
ScheduleTick() => NSchedule
DoseAutoChallengeDue() => NDue
AddToLog(*) => 0
ClickUntilGone(*) => NEvents.Push("Lobby")
ClickNextLevel() => NEvents.Push("Next")
ClickReplay() => NEvents.Push("Replay")
ClickReturnToLobby() => NEvents.Push("Return")
SwitchActiveFarm() => NEvents.Push("Swap")
GetMapForFarming(*) => "Synthetic"
Reconnect() => 0
NextStep(step) {
    throw NHandoff(step)
}
RestartStage() => 0
CheckLobby() => 0
MonitorDungeonEnd() => 0
DoseResumeChestSession() => 0
DoseResumeDungeonMenu() => 0
DoseProcessStageResults() => 0
Stopped() => 0
