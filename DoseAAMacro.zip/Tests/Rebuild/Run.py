"""Isolated regressions. Python is only needed to develop/test, not run the macro.

Windows: python Tests/Rebuild/Run.py --ahk "C:/Program Files/AutoHotkey/v2/AutoHotkey64.exe"
Linux/Wine validation: --runner /path/to/an/isolated/wine-ahk-wrapper
Run GUI fixtures serially on an unused desktop. They never target Roblox.
"""
from pathlib import Path
import argparse
import os
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def win(path):
    path = str(Path(path).resolve())
    return path if os.name == 'nt' else 'Z:' + path.replace('/', '\\')


def run(command, logfile, timeout=90):
    with logfile.open('w', encoding='utf-8') as stream:
        process = subprocess.Popen(command, stdout=stream, stderr=stream)
        try:
            status = process.wait(timeout=timeout)
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=10)
    output = logfile.read_text(encoding='utf-8', errors='replace')
    if status or 'FAIL:' in output or 'FATAL:' in output or '==> Error:' in output:
        raise RuntimeError(f'{logfile.name}: failed; inspect this isolated test log')
    return output


def pause_test(command, output):
    with tempfile.TemporaryDirectory(prefix='DosePauseTest-') as temporary:
        signals = Path(temporary)
        logfile = output / 'PauseTests.log'
        with logfile.open('w', encoding='utf-8') as stream:
            process = subprocess.Popen(command + [win(HERE / 'PauseTests.ahk'), win(signals)], stdout=stream, stderr=stream)
            try:
                deadline = time.monotonic() + 60
                for phase in ['paused', 'checkpoint']:
                    while time.monotonic() < deadline:
                        marker = signals / 'phase.txt'
                        if marker.exists() and marker.read_text() == phase:
                            break
                        if process.poll() is not None:
                            raise RuntimeError('Pause fixture exited early')
                        time.sleep(.025)
                    else:
                        raise RuntimeError('Pause phase timed out')
                    before = (signals / 'progress.txt').read_text()
                    time.sleep(.35)
                    if (signals / 'progress.txt').read_text() != before:
                        raise RuntimeError('Paused worker advanced')
                    hwnd = int((signals / 'hwnd.txt').read_text())
                    helper = signals / 'Resume.ahk'
                    helper.write_text('#Requires AutoHotkey v2.0\n#SingleInstance Off\n'
                                      f'ControlClick("Resume","ahk_id {hwnd}",,,,"NA")\nExitApp(0)\n')
                    subprocess.run(command + [win(helper)], check=True, timeout=15, stdout=stream, stderr=stream)
                status = process.wait(timeout=20)
            finally:
                if process.poll() is None:
                    process.terminate()
                    process.wait(timeout=10)
        text = logfile.read_text(encoding='utf-8', errors='replace')
        if status or 'PASS:' not in text or 'FAIL:' in text:
            raise RuntimeError('Pause test failed; inspect PauseTests.log')
        return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ahk', default=os.environ.get('AHK_EXE', r'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'))
    parser.add_argument('--runner', help='Optional executable wrapper that already adds /ErrorStdOut')
    parser.add_argument('--output', type=Path, default=HERE / 'Verification')
    parser.add_argument('--only', nargs='+', help='Optional suite stems for targeted reruns')
    args = parser.parse_args()
    command = [args.runner] if args.runner else [args.ahk, '/ErrorStdOut']
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    for name in ['PrepareChestTests.py', 'PrepareShopTests.py', 'PrepareEntranceTests.py', 'PrepareDefaultsTests.py', 'PrepareBossRecoveryTests.py', 'Rebuild/Prepare.py']:
        subprocess.run([sys.executable, str(ROOT / 'Tests' / name)], check=True, cwd=ROOT)
    syntax = ROOT / '_DoseSyntaxCheck.ahk'
    if syntax.exists():
        raise RuntimeError('Refusing to overwrite an existing syntax-check file')
    try:
        syntax.write_text('#Requires AutoHotkey v2.0\n#SingleInstance Off\n#Warn All, StdOut\n#Warn LocalSameAsGlobal, Off\nExitApp(0)\n#Include %A_ScriptDir%\\Main.ahk\n')
        run(command + [win(syntax)], output / 'FullSourceSyntax.log')
    finally:
        syntax.unlink(missing_ok=True)
    suites = [
        'Rebuild/PolicyTests', 'Rebuild/ResultsFlowTests', 'Rebuild/ResultsNativeTests',
        'Rebuild/NavigationTests', 'Rebuild/ReferenceInputNativeTests', 'Rebuild/InputBoundsTests', 'Rebuild/MovementTests', 'Rebuild/PersistenceTests',
        'Rebuild/LifecycleTests', 'Rebuild/ConnectionTests', 'Rebuild/ChestIntegrationTests',
        'DungeonLogicTests', 'WindowDetectionTests', 'RoutePriorityPanelTests', 'DungeonDefaultsTests', 'DungeonEntranceTests',
        'DungeonBossRecoveryTests', 'DungeonBossRecoveryWindowTests', 'DungeonChestTests',
        'ChestOverlayWindowTests', 'ChestExitGuardTests', 'BossChestPriorityTests',
        'ChestStartResumeTests', 'ShopPriorityTests', 'ShopWindowTests',
        'ChallengeSoloTests', 'ChallengeSoloWindowTests', 'AnimeThemeTests',
        'ChestRecoveryRealTimingTests',
    ]
    if args.only:
        known={Path(suite).name for suite in suites}|{'PauseTests','Python'}
        if set(args.only)-known:
            raise ValueError('Unknown suite name')
        suites=[suite for suite in suites if Path(suite).name in args.only]
    for suite in suites:
        print('RUN: '+suite,flush=True)
        log = output / (Path(suite).name + '.log')
        text = run(command + [win(ROOT / 'Tests' / (suite + '.ahk'))], log,
                   timeout=300 if suite in ['ChestRecoveryRealTimingTests','DungeonLogicTests'] else 90)
        if 'PASS:' not in text:
            raise RuntimeError(f'{suite} did not report completion')
        print('\n'.join(line for line in text.splitlines() if line.startswith(('PASS:', 'REAL RESCAN'))), flush=True)
    if not args.only or 'PauseTests' in args.only:
        print(pause_test(command, output).strip(), flush=True)
    if not args.only or 'Python' in args.only:
        text = run([sys.executable, '-m', 'unittest', 'discover', '-s', str(ROOT / 'Tests'), '-p', 'test_*.py'], output / 'Python.log')
        print(text.strip(), flush=True)
    print('PASS: requested offline suites completed; this does not verify a live Roblox run.', flush=True)


if __name__ == '__main__':
    main()
