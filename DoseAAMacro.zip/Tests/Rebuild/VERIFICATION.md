# v4.1 verification record

All listed suites completed against the packaged application source. ApplicationManifest.json records its SHA-256 hashes; SuiteCounts.json maps assertion counts to the corresponding current log files.

AutoHotkey v2 runs under Wine on an isolated Xvfb desktop. Native fixtures use real FindText/GDI/window calibration while game transitions and input/network effects are simulated. Private settings/log startup is excluded. A Segoe UI substitute is used only in the test prefix; bundled fonts load privately. No live Roblox account/server or external webhook delivery was tested.

| Suite | Assertions |
| --- | ---: |
| PolicyTests | 76 |
| ResultsFlowTests | 34 |
| ResultsNativeTests | 11 |
| NavigationTests | 22 |
| InputBoundsTests | 12 |
| ReferenceInputNativeTests | 7 |
| MovementTests | 18 |
| PersistenceTests | 19 |
| LifecycleTests | 6 |
| ConnectionTests | 13 |
| ChestIntegrationTests | 8 |
| DungeonLogicTests | 205 |
| WindowDetectionTests | 74 |
| RoutePriorityPanelTests | 26 |
| DungeonDefaultsTests | 14 |
| DungeonEntranceTests | 35 |
| DungeonBossRecoveryTests | 38 |
| DungeonBossRecoveryWindowTests | 10 |
| DungeonChestTests | 47 |
| ChestOverlayWindowTests | 7 |
| ChestExitGuardTests | 12 |
| BossChestPriorityTests | 7 |
| ChestStartResumeTests | 8 |
| ShopPriorityTests | 125 |
| ShopWindowTests | 74 |
| ChallengeSoloTests | 32 |
| ChallengeSoloWindowTests | 21 |
| AnimeThemeTests | 25 |
| ChestRecoveryRealTimingTests | 50 |
| PauseTests | 6 |
| Console-Ethereal-100 | 2885 |
| Console-Akatsuki-125 | 2885 |
| Console-Akatsuki-150 | 2885 |
| Python reliability tests | 91 |

FullSourceSyntax.log is empty: all application includes parsed with no warnings/errors before startup. Some isolated fixture logs warn about intentionally omitted unused hooks; they are not full-application parse warnings.

UI combinations: Ethereal at 100% (96 DPI), Akatsuki at 125% (120 DPI) and Akatsuki at 150% (144 DPI), each with 2,885 assertions. The preview builds the actual GUI, event handlers, panels and settings save/load functions. It tests all six profiles, original control handles/values, all mode options, independent coordinate checkbox clicks, native map arrows/scrolling, run/pause locks, panel navigation and text bounds. Captures were visually inspected. This is not proof that Roblox itself renders all references identically at each scale; the calibrated game size and Guide recommendations still apply.

The production chest-recovery rescan occurred at 120,762 ms, and the complete simulated chest session finished at 137,963 ms with both rows empty and one verified Continue. The real reward pair had a 2,007 ms gap, followed by 3,262 ms of full-menu quiet. Tests retain production timing in this check; several other fixtures use shorter, explicit budgets.

Additional input tests caught and corrected a case-insensitive x/X, y/Y collision in the shared navigation helper. Native tests confirm matched, explicit-point, explicit-offset and right-button behavior at the actual fixture window location. Results deadlines no longer discard fresh positively recognized navigation evidence; unknown/blocked screens still have bounded recovery.

The v4.0 baseline reproduction is preserved under Tests/History/v4.0-results-freeze-baseline.log (26 native diagnostic assertions). Historical records and old layout checks under Tests/History do not certify this release.

Known limits: no live three-hour dungeon, real server teleport, in-game physics, arbitrary changed/scaled game artwork or network delivery guarantee. Recognition remains dependent on the calibrated game UI. Aures Maul and Solar Cleaver still have no captured exclusion references. Recovery preserves possible boss/chest work and may stop visibly instead of guessing.

Reproduce using Run.py and RunConsole.py as documented in README.md. Python is optional for development only; the macro itself runs with AutoHotkey v2.
