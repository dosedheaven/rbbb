#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\ChallengeSchedule.ahk
global Checks:=0
Assert(ok,label) {
    global Checks
    Checks+=1
    if !ok
        throw Error(label)
}
Evidence(kind:="None",outcome:="",nav:=false,next:=false,xp:=false,unit:=false) {
    return {kind:kind,outcome:outcome,navigation:nav,next:next,xp:xp,unit:unit}
}
try {
    state:=DoseResultsState(100,500,200)
    Assert(state.Decide(Evidence("Navigation","",true),110)="Wait","Return alone never fabricates a win or loss")
    Assert(state.Decide(Evidence("Outcome","win"),120)="Wait","single outcome label without corroboration is held")
    Assert(state.Decide(Evidence("Outcome","win"),140)="Record","stable outcome is recorded")
    state.recorded:=true
    Assert(state.Decide(Evidence("Navigation","",true),150)="Route","navigation follows recorded outcome without requiring XP")
    Assert(state.Decide(Evidence("Chest","win",true),160)="Chest","chest owner overrides background outcome/navigation")
    Assert(state.Decide(Evidence("Blocked","win",true),180)="Wait","blocked screen cannot send input")
    state:=DoseResultsState(0,500,200)
    Assert(state.Decide(Evidence("Navigation","win",true),50)="Record","win and navigation corroborate in one observation")
    state:=DoseResultsState(0,500,200)
    Assert(state.Decide(Evidence("Navigation","",true),210)="RecordUnknown","unreadable outcome is explicit after grace period")
    state.recorded:=true
    Assert(state.Decide(Evidence("Navigation","",true),220)="Route","unknown outcome can progress without false defeat")
    state:=DoseResultsState(0,500,200)
    Assert(state.Decide(Evidence(),501)="Recover","unknown screen has a deadline")
    Assert(state.Decide(Evidence("Chest"),501)="Chest","timeout never steals pending chests")
    state:=DoseResultsState(0,500,200)
    Assert(state.Decide(Evidence("Unit","",false,false,false,true),10)="CloseUnit","unit overlay can be closed at a detected location")
    state.Acted(10)
    Assert(state.Decide(Evidence("Unit","",false,false,false,true),20,100)="Wait","ignored click respects retry interval")
    Assert(state.Decide(Evidence("Unit","",false,false,false,true),120,100)="CloseUnit","retry becomes eligible after interval")
    Loop 5
        state.Acted(20+A_Index)
    Assert(state.Decide(Evidence("Unit","",false,false,false,true),200,100)="Wait","overlay has bounded input attempts")
    state:=DoseResultsState(0,500,200)
    state.Shift(1000)
    Assert(state.Decide(Evidence(),501)="Wait","pause shifts deadline")
    Assert(state.Decide(Evidence(),1501)="Recover","shifted deadline still expires")
    state:=DoseResultsState(0,500,200),state.recorded:=true
    Assert(state.Decide(Evidence("Next","",false,true),50)="Next","recorded results can dismiss a Next prompt")
    Assert(state.Decide(Evidence("Results","",false,false,true),50)="Dismiss","recorded XP-only results can dismiss rewards")
    ; Exhaustive owner and action invariants across outcomes/overlays/time.
    for outcome in ["","win","loss"]
        for nav in [false,true]
            for next in [false,true]
                for xp in [false,true] {
                    s:=DoseResultsState(0,500,200)
                    Assert(s.Decide(Evidence("Chest",outcome,nav,next,xp),900)="Chest","chest wins every evidence combination")
                    s:=DoseResultsState(0,500,200)
                    Assert(s.Decide(Evidence("Blocked",outcome,nav,next,xp),100)="Wait","blocked combinations produce no action")
                }
    s:=DoseResultsState(0,500,200)
    s.Observe(Evidence("Outcome","win"),10),s.Observe(Evidence("Outcome","win"),20),s.recorded:=true
    s.Observe(Evidence("Outcome","loss"),30),s.Observe(Evidence("Outcome","loss"),40)
    Assert(s.outcome="win","recorded outcome cannot change underneath mode-navigation decisions")
    s:=DoseResultsState(0,500,200),s.recorded:=true
    Assert(s.Decide(Evidence("Navigation","",true),900)="Route","a fresh verified navigation screen takes precedence over a stale watchdog deadline")
    s:=DoseResultsState(0,500,200)
    Assert(s.Decide(Evidence("Navigation","win",true),900)="Record","late corroborated outcome is preserved rather than discarded by the watchdog")
    s:=DoseResultsState(0,500,200)
    s.Observe(Evidence("Blocked","win",true),10)
    Assert(s.outcome="","partial blocked evidence cannot be cached as a win")
    Assert(!DoseChallengeEligible(1799999,0,true,false,false),"Challenge is not due before thirty minutes")
    Assert(DoseChallengeEligible(1800000,0,true,false,false),"Challenge becomes eligible at thirty minutes")
    Assert(!DoseChallengeEligible(1800000,0,true,false,true),"boss reward ownership defers a due Challenge")
    Assert(!DoseChallengeEligible(1800000,0,true,true,false),"active Challenge cannot schedule a second Challenge")
    Assert(!DoseChallengeEligible(1800000,0,false,false,false),"disabled Auto Challenge remains disabled")
    FileAppend("PASS: " Checks " result-policy assertions; pure state transitions, no game/input/network.`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.Line "`n","*")
    ExitApp(1)
}
