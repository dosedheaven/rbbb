#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Framework\MacroLoop.ahk
global C:=0,Calls:=[],Records:=[],Locked:=false,Failure:=false,Restored:=0,StopRecovery:=false
DoseSession.traceRoot:=A_Temp "\DoseLifecycle-" A_TickCount
class MacroStop extends Error {
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
try {
    RunMacroLoop(ReturningStep)
    Assert(Calls.Length=2 && Calls[1]="reconcile" && Calls[2]="verified","a returned step reconciles and proceeds instead of silently stopping")
    Assert(!MacroLoopState.Active && DoseSession.phase="Stopped","clean stop always releases lifecycle active flag")
    Calls:=[],Failure:=true
    RunMacroLoop(ErrorStep)
    Assert(Calls.Length=1 && Calls[1]="verified","runtime errors use existing error recovery adapter")
    Assert(!MacroLoopState.Active,"error recovery exit clears active flag")
    Calls:=[],Failure:=false,Restored:=0,StopRecovery:=false
    RunMacroLoop(ReturningStep)
    Assert(Restored=1,"pending chest checkpoint is reconciled once at run startup")
    Calls:=[],StopRecovery:=true
    RunMacroLoop(ErrorStep)
    Assert(!MacroLoopState.Active && !Calls.Length,"recovery policy stop is caught without an unhandled error or extra input")
    FileAppend("PASS: " C " lifecycle dispatcher assertions; actual macro loop with isolated steps and services.`n","*")
    DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.Line "`n","*")
    ExitApp(1)
}
ReturningStep() => false
DoseResumeAfterReturn() {
    Calls.Push("reconcile")
    return NextStep(VerifiedStep)
}
VerifiedStep() {
    Calls.Push("verified")
    throw MacroStop("expected test completion")
}
ErrorStep() {
    throw Error("simulated runtime failure")
}
DoseRestoreChestCheckpoint() {
    global Restored
    Restored+=1
}
FW_OnMacroStart() => 0
FW_HandleStepError(*) {
    if StopRecovery
        throw MacroStop("expected recovery-policy stop")
    return VerifiedStep
}
FW_Log(message) => Records.Push(message)
