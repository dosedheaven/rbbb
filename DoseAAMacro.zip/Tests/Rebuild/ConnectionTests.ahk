#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Pause.ahk
#Include %A_ScriptDir%\ConnectionForTests.ahk
global C:=0,rblxID:="synthetic",FW_ReconnectTimeoutMs:=30000,BossRoomCompleted:=false
 global TWindow:=true,TReady:=true,TDisconnected:=false,TPending:=false,TLobby:=true,TLaunches:=0,TNotifications:=0,TResets:=0,TLogs:=[]
DoseSession.traceRoot:=A_Temp "\DoseConnectionTests-" A_TickCount
class MacroStop extends Error {
}
class THandoff extends Error {
    __New(step) {
        super.__New(step.Name)
    }
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
Reset() {
    global TWindow,TReady,TDisconnected,TPending,TLobby,TLaunches,TNotifications,TResets,TLogs,BossRoomCompleted
    TWindow:=true,TReady:=true,TDisconnected:=false,TPending:=false,TLobby:=true,TLaunches:=0,TNotifications:=0,TResets:=0,TLogs:=[],BossRoomCompleted:=false
    DoseConnectionState.Reset()
}
Rejoin() {
    try DoseRejoin({attemptMs:150,pollMs:1,launchMs:1,maxAttempts:2})
    catch THandoff as step
        return step.Message
    catch MacroStop
        return "Stopped"
    return "Returned"
}
try {
    Reset()
    Assert(!DoseConnectionCheck() && !TLaunches && !TNotifications,"normal screen produces no connection action")
    Reset(),TDisconnected:=true
    Assert(!DoseConnectionCheck() && !TNotifications,"single disconnect label cannot launch a server")
    DoseConnectionState.lastCheck:=0
    try DoseConnectionCheck()
    catch THandoff as step
        Assert(step.Message="RejoinPrivateServer" && TNotifications=1,"second confirmed disconnect routes to one connection owner")
    DoseConnectionState.lastCheck:=0
    try DoseConnectionCheck()
    catch THandoff
        Assert(TNotifications=1,"incident notification is not duplicated")
    Reset(),TDisconnected:=true,TPending:=true,DoseConnectionState.hits:=1
    try DoseConnectionCheck()
    catch MacroStop
        Assert(!TLaunches,"disconnect with pending chests never launches another server")
    Reset()
    Assert(Rejoin()="StartSelectedMode" && TLaunches=1 && TResets=1,"two lobby observations confirm one launch and reset old boss recovery")
    Reset(),TLobby:=false
    Assert(Rejoin()="Stopped" && TLaunches=2,"missing lobby has bounded launches and an explicit stop")
    Reset(),TPending:=true
    Assert(Rejoin()="Stopped" && !TLaunches,"manual rejoin also honors chest ownership")
    Reset(),TWindow:=false,DoseConnectionState.missingSince:=DoseActiveTick()-16000
    try DoseConnectionCheck()
    catch THandoff as step
        Assert(step.Message="RejoinPrivateServer","missing window has a bounded grace period")
    Reset(),TReady:=false,TDisconnected:=true
    Assert(!DoseConnectionCheck() && !TNotifications && !TLaunches,"covered window cannot trigger detection or input")
    FileAppend("PASS: " C " connection-service assertions; actual service with simulated window/reference/launch effects, no private settings or network.`n","*")
    DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
WinExist(*) => TWindow
WF_PrepareDungeon() => TReady
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    X:=400,Y:=200
    return text=Disconnect || text=DisconnectOld ? TDisconnected : text=AreaText ? TLobby : false
}
DungeonChestExitBlocked() => TPending
DosePrivateServerLink() => "synthetic-server"
DoseOpenServerLink(link) {
    global TLaunches
    Assert(link="synthetic-server","saved server selection is passed through unchanged")
    TLaunches+=1
}
sendDCWebhook() {
    global TNotifications
    TNotifications+=1
}
forceRobloxSize() => 0
DungeonClearBossExitRecovery() {
    global TResets
    TResets+=1
}
DoseCaptureFailure(*) => 0
AddToLog(message) => TLogs.Push(message)
NextStep(step) {
    throw THandoff(step)
}
RejoinPrivateServer() => 0
StartSelectedMode() => 0
