; Actual mode navigation; only sleeps shortened for deterministic tests.
MonitorEndScreen() {
    global mode, StoryDropdown, StoryActDropdown, ReturnLobbyBox, MatchMaking, challengeStartTime, inChallengeMode

    lastResult:=IsObject(DoseSession.results) ? DoseSession.results.outcome : ""
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(1)  
        StageGuard.Check("EndScreen", "end screen not handled")   ; [Framework]
        
        evidence:=DoseResultsEvidence()
        if evidence.kind="Chest"
            return NextStep(DoseResumeChestSession)
        if evidence.kind="Shop" || evidence.kind="Shrine"
            return NextStep(DoseResumeDungeonMenu)
        if !evidence.navigation && (evidence.next || evidence.xp || evidence.unit)
            return NextStep(DoseProcessStageResults)
        ; Navigation adapters send only their mode-specific action, after the
        ; shared controller has recorded the outcome and verified the screen.
        if evidence.navigation {
            AddToLog("Found Lobby Text - Current Mode: " (inChallengeMode ? "Challenge" : mode))
            Sleep(1)
            if (!inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                 AddToLog("Challenge completed - returning to " mode " mode")
                inChallengeMode := false
                challengeStartTime := A_TickCount
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Check if it's time for challenge mode
            if (!inChallengeMode && ChallengeBox.Value) {
                if (DoseAutoChallengeDue()) {
                    AddToLog("30 minutes passed - switching to Challenge mode")
                    inChallengeMode := true
                    challengeStartTime := A_TickCount
                    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                    return NextStep(CheckLobby)
                }
            }

            if (mode = "Story") {
                AddToLog("Handling Story mode end")
                if (StoryActDropdown.Text != "Infinity") {
                    if (NextLevelBox.Value && lastResult = "win") {
                        AddToLog("Next level")
                        ClickNextLevel()
                    } else {
                        AddToLog("Replay level")
                        ClickReplay()
                    }
                } else {
                    if (PortalSwap.Value && GetMapForFarming(StoryDropdown.Text) != "no map found") {
                        SwitchActiveFarm()
                        Sleep(1)
                        ClickReturnToLobby()
                        return NextStep(CheckLobby)
                    } else if (ReturnLobbyBox.Value) {
                        AddToLog("Return to lobby")
                        ClickReturnToLobby()
                        return NextStep(CheckLobby)
                    } else {
                        AddToLog("Story Infinity replay")
                        ClickReplay()
                    }
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Raid") {
                AddToLog("Handling Raid end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replay raid")
                    ClickReplay()
                    return NextStep(RestartStage)
                }
            }
            else if (mode = "Dungeon") {
                AddToLog("Handling Dungeon end")
                return NextStep(MonitorDungeonEnd)
            }
            else if (mode = "Infinity Castle") {
                AddToLog("Handling Infinity Castle end")
                if (lastResult = "win") {
                    AddToLog("Next floor")
                    ClickReplay() ; Uses the replay coords for next level
                } else {
                    AddToLog("Restart floor")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Cursed Womb") {
                AddToLog("Handling Cursed Womb End")
                AddToLog("Returning to lobby")
                ClickReturnToLobby()
                return NextStep(CheckLobby)
            }
            else if (mode = "Fool's Hunt") {
                AddToLog("Handling Fool's Hunt end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Winter Event") {
                AddToLog("Handling Winter Event end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else {
                AddToLog("Handling end case")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                    return NextStep(RestartStage)
                }
            }
        }
        Reconnect()
    }
}
