; Actual state constructor.
DungeonChestNewState() {
    return {phase:"Menu",owedClicks:0,lastClaim:0,claimClicks:0,rewardChain:false,
        verified:false,lastProgress:DoseActiveTick(),lastRecovery:0,recoveries:0,commonOpens:0,rareOpens:0}
}
