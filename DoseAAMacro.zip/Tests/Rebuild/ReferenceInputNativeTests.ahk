#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Pause.ahk
#Include %A_ScriptDir%\..\..\Lib\Functions\ScreenActions.ahk
global C:=0,NG:=Gui("-Caption +ToolWindow -DPIScale"),rblxID:="ahk_id " NG.Hwnd
 global targetWidth:=816,targetHeight:=638,offsetX:=-5,offsetY:=1,NInputs:=[]
NG.BackColor:="161621"
global NReturn:=NG.Add("Picture","x195 y104",A_ScriptDir "\..\Fixtures\LobbyText.bmp")
NG.Show("x250 y180 w816 h638")
DoseSession.traceRoot:=A_Temp "\DoseNativeReference-" A_TickCount
class MacroLoopState {
    static Active:=false
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
Prepare() {
    global NInputs
    NInputs:=[],NReturn.Visible:=true,NReturn.Redraw()
    CoordMode("Mouse","Client")
    Sleep(100)
}
try {
    Prepare()
    Assert(WF_PrepareDungeon() && FT(&mx,&my,80,85,739,224,0,0,LobbyText),"actual native reference is recognized through the shared calibration")
    FT_GetOffset(&dx,&dy),WinGetClientPos(&left,&top,,,rblxID)
    expectedX:=mx+dx-left,expectedY:=my+dy-top
    Assert(ClickUntilGone(0,0,80,85,739,224,LobbyText) && NInputs.Length=1,"natural matched navigation completes after one input and two absent observations")
    Assert(NInputs[1].x=expectedX && NInputs[1].y=expectedY,"natural matched input lands at the real game-client reference position")
    Prepare()
    Assert(ClickUntilGone(400,300,80,85,739,224,LobbyText) && NInputs[1].x=400 && NInputs[1].y=300,"search outputs cannot overwrite an explicit client action point")
    Prepare()
    Assert(ClickUntilGone(0,0,80,85,739,224,LobbyText,-4,-35) && NInputs[1].x=mx-4 && NInputs[1].y=my-35,"explicit legacy offsets keep their original client semantics")
    Prepare()
    Assert(RightClickUntilGone(0,0,80,85,739,224,LobbyText) && NInputs[1].x=expectedX && NInputs[1].y=expectedY && NInputs[1].button="Right","right-button matched navigation uses the same real window conversion")
    Assert(A_CoordModeMouse="Client","native input conversion restores its caller's coordinate mode")
    FileAppend("PASS: " C " native shared-input assertions (actual FindText/calibration/conversion; input effects simulated).`n","*")
    NG.Destroy(),DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    NG.Destroy()
    ExitApp(1)
}
FixClick(x,y,button:="Left") {
    if A_CoordModeMouse="Screen" {
        WinGetClientPos(&left,&top,,,rblxID)
        x-=left,y-=top
    }
    NInputs.Push({x:x,y:y,button:button})
    NReturn.Visible:=false,NReturn.Redraw()
}
DungeonChestExitBlocked() => false
DoseResumeChestSession() => 0
NextStep(*) {
    throw Error("No handoff expected in native reference fixture")
}
DoseRecoverSession(*) {
    throw Error("Native reference input did not complete")
}
DoseCaptureFailure(*) => 0
sizeDown(*) => WinMove(,,targetWidth,targetHeight,rblxID)
