#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Movement.ahk
#Include %A_ScriptDir%\MovementForTests.ahk
global C:=0,ModeDropdown:={Text:"Dungeon"},TMatches:=[],TDefault:=true,TInputs:=[],TSleeps:=[],TThrow:=false,TReady:=true,WF_LastIssue:=""
DoseSession.traceRoot:=A_Temp "\DoseMovementTests-" A_TickCount
class MacroStop extends Error {
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
Reset(match:=true) {
    global TMatches,TDefault,TInputs,TSleeps,TThrow,TReady,WF_LastIssue
    TMatches:=[],TDefault:=match,TInputs:=[],TSleeps:=[],TThrow:=false,TReady:=true,WF_LastIssue:=""
    ModeDropdown.Text:="Dungeon"
}
try {
    Reset(),TMatches:=[true,false,true,true,true]
    Assert(DoseMovementAngle(FestivalAngle,[560,285,615,350]),"a single bad sample cannot flip a stable positive angle")
    Reset(false),TMatches:=[false,true,false,false,false]
    Assert(!DoseMovementAngle(FestivalAngle,[560,285,615,350]),"alternate angle requires consecutive clean misses")
    Reset(),WF_LastIssue:="blocked"
    try {
        DoseMovementAngle(FestivalAngle,[560,285,615,350])
        throw Error("blocked angle should stop")
    } catch MacroStop {
        Assert(!TInputs.Length,"blocked angle sends no direction")
    }
    for mapName in ["Cursed Festival","Strange Town"] {
        for positive in [true,false] {
            Reset(positive)
            DoseRunMapMovement(mapName)
            direction:=mapName="Cursed Festival" ? (positive ? "d" : "a") : (positive ? "a" : "d")
            Assert(TInputs[1]="{" direction " down}","correct Dungeon route branch for " mapName)
            expected:=mapName="Cursed Festival" ? 1800 : 2500
            Assert(HasSleep(expected),"established movement duration retained for " mapName)
            Assert(TInputs[TInputs.Length]="{down up}","wrapper releases every movement key after " mapName)
        }
    }
    Reset(),TThrow:=true
    try DoseRunMapMovement("Strange Town")
    catch as err {
        Assert(err.Message="simulated interruption","route interruption propagates")
        Assert(TInputs[TInputs.Length]="{down up}","all movement keys released even on interruption")
    }
    Reset(),TReady:=false
    try DoseRunMapMovement("Cursed Festival")
    catch MacroStop {
        Assert(!TInputs.Length,"unprepared window receives no movement")
    }
    FileAppend("PASS: " C " movement branching/input-release assertions (actual routes/controller; detection, timing and key effects simulated).`n","*")
    DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.Line "`n","*")
    ExitApp(1)
}
HasSleep(duration) {
    for value in TSleeps
        if value=duration
            return true
    return false
}
Sleep(ms) => TSleeps.Push(ms)
SendInput(keys) {
    TInputs.Push(keys)
    if TThrow && InStr(keys," down}")
        throw Error("simulated interruption")
}
KeyWait(*) => 0
WF_PrepareDungeon() => TReady
WF_FindText(*) {
    if WF_LastIssue!=""
        return false
    return TMatches.Length ? TMatches.RemoveAt(1) : TDefault
}
FT(*) => TDefault
HandleMapMovement(name) {
    if name="Strange Town"
        MoveForStrangeTown()
    else
        MoveForCursedFestival()
}
AddToLog(*) => 0

DoseReleaseMovementKeys() {
    for key in ["w","a","s","d","space","left","right","up","down"]
        SendInput("{" key " up}")
}
DosePauseCheckpoint() => 0
