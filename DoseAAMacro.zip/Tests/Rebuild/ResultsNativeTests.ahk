#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\..\Lib\Engine\DungeonScreens.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\ResultsNativeForTests.ahk
OnError(NFatal)
FileAppend("Native test starting`n","*")
global NG:=Gui("-Caption +ToolWindow -DPIScale"),rblxID:="ahk_id " NG.Hwnd
 global targetWidth:=816,targetHeight:=638,offsetX:=-5,offsetY:=1
 global C:=0,mode:="Dungeon",Wins:=0,loss:=0,stageStartTime:=A_TickCount-1000,successfulCoordinates:=[],maxedCoordinates:=[]
 global BossRoomCompleted:=false,NPending:=false,NWebhooks:=0,NClicks:=[],NLogs:=[]
NG.BackColor:="161621"
global NReturn:=NG.Add("Picture","x195 y104",A_ScriptDir "\..\Fixtures\LobbyText.bmp")
global NXp:=NG.Add("Picture","x585 y154 Hidden",A_ScriptDir "\..\Fixtures\Results-XpText.bmp")
global NVictory:=NG.Add("Picture","x324 y194",A_ScriptDir "\..\Fixtures\Results-VictoryText.bmp")
NG.Show("x100 y100 w816 h638")
DoseSession.traceRoot:=A_Temp "\DoseNativeResults-" A_TickCount
class MacroStop extends Error {
}
class NHandoff extends Error {
    __New(step) {
        super.__New(step.Name)
    }
}
class StageGuard {
    static Disarm(*) => 0
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
NRunNative() {
    try DoseProcessStageResults({timeoutMs:2000,outcomeMs:500,pollMs:30,maxRescans:0})
    catch NHandoff as step
        return step.Message
    return "Returned"
}
try {
    for variant in [1,2] {
        DoseSession.results:=0,DoseSession.stageId:=0,Wins:=0,NWebhooks:=0,NClicks:=[]
        w:=variant=1 ? 65 : 71
        NReturn.Move(195,variant=1 ? 104 : 139,w,25)
        NReturn.Value:="*w" w " *h25 " A_ScriptDir "\..\Fixtures\" (variant=1 ? "LobbyText.bmp" : "LobbyText2.bmp")
        NReturn.Redraw(),NVictory.Redraw()
        Sleep(120)
        e:=DoseResultsEvidence()
        Assert(e.navigation && e.outcome="win" && !e.xp,"actual native outcome + Return variant recognized without XP")
        Assert(NRunNative()="MonitorDungeonEnd","same native scene that stalls old monitor reaches Dungeon navigation")
        Assert(Wins=1 && NWebhooks=1 && !NClicks.Length,"native result counted and webhook adapter attempted once without repeated clicks")
        Assert(NRunNative()="MonitorDungeonEnd" && Wins=1 && NWebhooks=1,"native repeated handoff remains idempotent")
    }
    DoseSession.results:=0,Wins:=0,NWebhooks:=0,NClicks:=[]
    NReturn.Visible:=false,NXp.Visible:=true,NXp.Redraw()
    Assert(NRunNative()="MonitorDungeonEnd" && Wins=1 && NWebhooks=1,"native XP-only result reaches navigation after dismissal")
    Assert(NClicks.Length=1 && NClicks[1].x=408 && NClicks[1].y=319,"native dismissal uses actual game client center through production input conversion")
    NClicks:=[]
    NPending:=true
    Assert(NRunNative()="DoseResumeChestSession" && !NClicks.Length,"pending chest ownership overrides native background results")
    FileAppend("PASS: " C " native rebuilt results assertions (real FindText/window/reference pixels; game/network effects simulated).`n","*")
    NG.Destroy(),DirDelete(DoseSession.traceRoot,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for entry in NLogs
        FileAppend(entry "`n","*")
    NG.Destroy()
    ExitApp(1)
}
DungeonChestExitBlocked() => NPending
DungeonChestMenuVisible() => false
DoseSendResultWebhook(*) {
    global NWebhooks
    NWebhooks+=1
}
FormatStageTime(*) => "00:00:01"
AddToLog(message) => NLogs.Push(message)
FixClick(x,y,*) {
    WinGetClientPos(&left,&top,&w,&h,rblxID)
    cx:=x-left,cy:=y-top
    NClicks.Push({x:cx,y:cy})
    if cx=w//2 && cy=h//2 {
        NXp.Visible:=false,NReturn.Visible:=true
        NXp.Redraw(),NReturn.Redraw()
    } else
        throw Error("Unexpected native results click")
}

CheckForLobbyText() => false
NextStep(step) {
    throw NHandoff(step)
}
MonitorDungeonEnd() => 0
HandleContractEnd() => 0
HandlePortalReJoin() => 0
MonitorEndScreen() => 0
CheckLobby() => 0
RejoinPrivateServer() => 0
sizeDown(*) => WinMove(,,targetWidth,targetHeight,rblxID)

NFatal(err,*) {
    FileAppend("FATAL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}

ChallengeClickClient(x,y) {
    global rblxID
    try {
        hwnd := WinExist(rblxID),point := Buffer(8,0)
        NumPut("Int",x,"Int",y,point)
        if !hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int")
            return false
        FT_GetOffset(&dx,&dy)
        return WF_RobloxClick(NumGet(point,0,"Int")-dx,NumGet(point,4,"Int")-dy)
    } catch {
        return false
    }
}

DungeonEntranceScene(&X,&Y,&layout) => "Waiting"
LookForDungeonRooms() => 0
CheckDungeonSpecials() => true
