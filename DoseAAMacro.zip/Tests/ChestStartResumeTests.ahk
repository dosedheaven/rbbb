#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\ChestStartFunctionsForTests.ahk
global QChecks := 0,QLocked := true,QWorks := true,QHandles := 0,QLooks := 0,QClicks := 0,QModes := 0,QChat := 0,QSwaps := 0
 global ModeDropdown := {Text:"Dungeon"},ChallengeBox := {Value:0},inChallengeMode := false,firstStartup := false,challengeStartTime := 0
QAssert(ok,label) {
    global QChecks
    QChecks += 1
    if !ok
        throw Error(label)
}
QReset(locked,works) {
    global QLocked,QWorks,QHandles,QLooks,QClicks,QModes,QChat,QSwaps
    QLocked := locked,QWorks := works,QHandles := 0,QLooks := 0,QClicks := 0,QModes := 0,QChat := 0,QSwaps := 0
}
try {
    QAssert(StartSelectedMode(),"start resumes a pending Dungeon chest session")
    QAssert(QHandles=1 && QLooks=1 && !QClicks && !QChat && !QModes,"no generic start/lobby clicks occur before the resumed chest handler succeeds")
    QReset(true,false)
    QAssert(!StartSelectedMode(),"failed chest resume stops the dispatcher")
    QAssert(QHandles=1 && !QLooks && !QClicks && !QModes,"failed resume cannot enter another dungeon")
    QReset(false,true)
    StartSelectedMode()
    QAssert(!QHandles && QClicks=2 && QChat=1 && QModes=1 && QSwaps=1,"ordinary unlocked Dungeon start retains its original setup/dispatch")
    FileAppend("PASS: " QChecks " pending-chest start-dispatch assertions (actual start dispatcher; services/input simulated).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
DungeonChestExitBlocked() => QLocked
HandleChestScreen(*) {
    global QHandles,QLocked
    QHandles += 1
    if QWorks
        QLocked := false
    return QWorks
}
LookForDungeonRooms() {
    global QLooks
    QLooks += 1
    return true
}
FixClick(*) {
    global QClicks
    QClicks += 1
}
CloseChat() {
    global QChat
    QChat += 1
}
DungeonMode() {
    global QModes
    QModes += 1
}
Sched_RunPendingTeamSwap() {
    global QSwaps
    QSwaps += 1
}
AddToLog(*) => 0
