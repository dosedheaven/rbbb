#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\ChestStartFunctionsForTests.ahk
global C:=0,Locked:=false,Known:=0,Results:=false,Due:=false,Lobby:=true
 global Clicks:=0,Chats:=0,Swaps:=0,Modes:=0,Challenges:=0
 global ModeDropdown:={Text:"Dungeon"},ChallengeBox:={Value:0},inChallengeMode:=false,firstStartup:=false,challengeStartTime:=0
class THandoff extends Error {
    __New(step) {
        super.__New(step.Name)
    }
}
Assert(ok,label) {
    global C
    C+=1
    if !ok
        throw Error(label)
}
Reset() {
    global
    Locked:=false,Known:=0,Results:=false,Due:=false,Lobby:=true
    Clicks:=0,Chats:=0,Swaps:=0,Modes:=0,Challenges:=0,inChallengeMode:=false,firstStartup:=false,ChallengeBox.Value:=0
}
Invoke() {
    try StartSelectedMode()
    catch THandoff as step
        return step.Message
    return "Returned"
}
try {
    Reset(),Locked:=true
    Assert(Invoke()="DoseResumeChestSession" && !Clicks && !Chats,"pending chest owner precedes generic start input")
    Reset(),Known:=LookForDungeonRooms
    Assert(Invoke()="LookForDungeonRooms" && !Clicks,"already-open room screen resumes without generic clicks")
    Reset(),Results:=true
    Assert(Invoke()="DoseProcessStageResults" && !Clicks,"existing results resume through the single controller")
    Reset()
    Assert(Invoke()="Returned" && Clicks=2 && Chats=1 && Swaps=1 && Modes=1,"ordinary Dungeon retains setup and its existing mode adapter")
    Reset(),Due:=true
    Assert(Invoke()="Returned" && Challenges=1 && !Modes && inChallengeMode,"due Challenge starts at a verified lobby")
    Reset(),Due:=true,Lobby:=false
    Assert(Invoke()="Returned" && Modes=1 && !Challenges,"due timer cannot interrupt an unverified lobby state")
    Reset(),ChallengeBox.Value:=1,firstStartup:=true
    Assert(Invoke()="Returned" && Challenges=1 && !firstStartup,"first-run Auto Challenge remains supported")
    Reset(),Due:=true,Locked:=true
    Assert(Invoke()="DoseResumeChestSession" && !inChallengeMode && !Clicks,"due Challenge cannot steal reward ownership")
    FileAppend("PASS: " C " rebuilt start-dispatch assertions (actual dispatcher; screen/input services simulated).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.Line "`n","*")
    ExitApp(1)
}
DungeonChestExitBlocked() => Locked
DoseDungeonScreenStep() => Known
DoseRouteStageEnd(*) {
    if Results
        NextStep(DoseProcessStageResults)
    return false
}
DoseAutoChallengeDue() => Due
CheckForLobbyText() => Lobby
FixClick(*) {
    global Clicks
    Clicks+=1
}
CloseChat() {
    global Chats
    Chats+=1
}
Sched_RunPendingTeamSwap() {
    global Swaps
    Swaps+=1
}
DungeonMode() {
    global Modes
    Modes+=1
}
ChallengeMode() {
    global Challenges
    Challenges+=1
}
NextStep(step) {
    throw THandoff(step)
}
DoseResumeChestSession() => 0
DoseProcessStageResults() => 0
LookForDungeonRooms() => 0
AddToLog(*) => 0
