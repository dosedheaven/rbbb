"""Extract production chest wrappers/caller without Main or private startup."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
source = (root/'Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk').read_text()
parts = ['; Generated production functions; offline chest tests only.\n']
for name in ['CheckDungeonSpecials','IsChestScreenVisible','IsCommonChestDone',
             'IsRareChestDone','HandleChestScreen','ClaimChestReward']:
    match = re.search(r'^'+name+r'\([^\n]*\)\s*\{.*?^\}',source,re.M|re.S)
    assert match,name
    parts.append(match[0]+'\n\n')
(root/'Tests/ChestFunctionsForTests.ahk').write_text(''.join(parts))
print('Prepared actual chest functions and special-screen caller without Main.')
