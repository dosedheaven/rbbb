#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\..\Lib\Framework\MacroLoop.ahk
; Actual image/window/close/return flow. Exact-pattern synthetic fixtures, never
; a real Roblox client. FixClick records and simulates control transitions only.
class MacroStop extends Error {
}
global BGame := Gui("-Caption +ToolWindow -DPIScale"), BMacro := Gui("+AlwaysOnTop -Caption -DPIScale")
global BOverlay := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale")
global rblxID := "ahk_id " BGame.Hwnd, aaMainUIHwnd := BMacro.Hwnd
global targetWidth := 816,targetHeight := 638,offsetX := -5,offsetY := 1
global robloxHolder := BMacro.Add("Text","x3 y33 w797 h597 Background303030")
global BChecks := 0,BEvents := [],BState := "Enter",BVariant := 1
global BEnter := BGame.Add("Picture","x365 y355",A_ScriptDir "\Fixtures\EnterDungeon.bmp")
global BClose := BGame.Add("Picture","x655 y174",A_ScriptDir "\Fixtures\DungeonRedX.bmp")
global BReturn := BGame.Add("Picture","x305 y120 Hidden",A_ScriptDir "\Fixtures\LobbyText.bmp")
global BArea := BGame.Add("Picture","x751 y513 Hidden",A_ScriptDir "\Fixtures\AreaText.bmp")
global BFast := {pollMs:30,retryMs:100,closeMs:1200,lobbyMs:2000,maxCloseClicks:3,maxLobbyClicks:3}
BGame.BackColor := "101010",BMacro.BackColor := "0B0C10",BOverlay.BackColor := "FF0000"
MacroLoopState.Active := true
BAssert(ok,label) {
    global BChecks
    BChecks += 1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
BReset(variant := 1) {
    global BEvents,BState,BVariant
    BEvents := [],BState := "Enter",BVariant := variant
    BEnter.Visible := BClose.Visible := true
    BReturn.Visible := BArea.Visible := false
    BReturn.Move(,,variant=1 ? 65 : 71,25)
    BReturn.Value := A_ScriptDir "\Fixtures\" (variant=1 ? "LobbyText.bmp" : "LobbyText2.bmp")
    DungeonArmBossExitRecovery()
    BRepaint()
    Sleep(80)
}
BRun() {
    try DungeonRecoverBossEntrance(BFast)
    catch MacroNextStep as handoff {
        BAssert(handoff.Step.Name="CheckLobby" && BState="Lobby","real macro handoff requires native detected lobby")
        return true
    }
    return false
}
try {
    BGame.Show("x100 y100 w816 h638"),BMacro.Show("x105 y99 w1800 h930")
    WinSetTransColor("303030",BMacro)
    BReset()
    CoordMode("Mouse","Client")
    BAssert(BRun(),"native first Return to Lobby pattern completes recovery")
    BAssert(BEvents.Length=2 && BEvents[1].kind="close" && BEvents[2].kind="return","real recognized X precedes return control")
    BAssert(!DungeonBossExitPending && !DungeonBossExitRecoveries,"native lobby completion clears recovery authorization")
    BAssert(A_CoordModeMouse="Client","recovery input restores the caller mouse coordinate mode")
    oldX := BEvents[1].x,oldY := BEvents[1].y
    WinMove(50,50,,,rblxID),WinMove(55,49,,,"ahk_id " aaMainUIHwnd)
    BReset(2)
    BAssert(BRun(),"second native return pattern works after moving the game/macro")
    BAssert(BEvents[1].x=oldX-50 && BEvents[1].y=oldY-50,"recovery click follows the actual moved window")
    BReset()
    BClose.Visible := false
    WinRedraw(rblxID)
    BAssert(!DungeonRecoverBossEntrance({pollMs:20,closeMs:120,lobbyMs:150}) && !BEvents.Length,
        "missing native X produces no guessed close or return click")
    BReset()
    BOverlay.Show("x400 y390 w200 h160")
    Sleep(80)
    BAssert(!DungeonRecoverBossEntrance(BFast) && !BEvents.Length,"opaque native overlay blocks all recovery input")
    BOverlay.Hide()
    FileAppend("PASS: " BChecks " native post-boss recovery window/image assertions.`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
} finally {
    BOverlay.Destroy(),BMacro.Destroy(),BGame.Destroy()
}
FixClick(x,y,*) {
    global BState
    if (A_CoordModeMouse!="Screen")
        throw Error("recovery wrapper must deliver screen coordinates")
    ctrl := BState="Enter" ? BClose : BReturn
    WinGetPos(&cx,&cy,&cw,&ch,"ahk_id " ctrl.Hwnd)
    if !(ctrl.Visible && x>=cx && x<cx+cw && y>=cy && y<cy+ch)
        throw Error("matched click did not land inside the visible native control")
    if (BState="Enter") {
        BEvents.Push({kind:"close",x:x,y:y})
        BEnter.Visible := BClose.Visible := false
        BReturn.Visible := true,BState := "Closed"
    } else if (BState="Closed") {
        BEvents.Push({kind:"return",x:x,y:y})
        BReturn.Visible := false,BArea.Visible := true,BState := "Lobby"
    } else
        throw Error("unexpected extra recovery input")
    BRepaint()
}
BRepaint() {
    DllCall("user32\RedrawWindow","Ptr",BGame.Hwnd,"Ptr",0,"Ptr",0,"UInt",0x185)
    DllCall("user32\RedrawWindow","Ptr",BMacro.Hwnd,"Ptr",0,"Ptr",0,"UInt",0x185)
    Sleep(80)
}
AddToLog(message) {
    FileAppend("TRACE: " message "`n","*")
}
CheckLobby(*) {
    throw Error("must hand off through the macro loop")
}
moveRobloxWindow(*) {
    throw Error("no main GUI startup in native recovery test")
}
sizeDown(*) {
    WinMove(,,targetWidth,targetHeight,rblxID)
}
