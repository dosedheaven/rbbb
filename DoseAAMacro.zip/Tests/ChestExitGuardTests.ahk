#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\Lib\Engine\Pause.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk
global GChecks := 0,GReads := 0,GInputs := 0,GLogs := [],WF_LastIssue := ""
GAssert(ok,label) {
    global GChecks
    GChecks += 1
    if !ok
        throw Error(label)
}
DungeonChestExitLocked := true
try {
    GAssert(!DungeonStartEntrance(),"startup blocked by unfinished chest owner")
    GAssert(!DungeonWaitForEntrance(20,1,1,1),"Enter Dungeon blocked by unfinished chest owner")
    GAssert(!DungeonOpenEntranceMenu(),"opening dungeon menu blocked by unfinished chest owner")
    GAssert(!DungeonArmBossExitRecovery(),"arming boss recovery blocked by unfinished chest owner")
    GAssert(!DungeonRecoverBossEntrance(),"boss lobby recovery blocked by unfinished chest owner")
    GAssert(!LookForDungeonRooms(),"route/early Enter check blocked by unfinished chest owner")
    GAssert(!CheckForFinishDungeon(),"old finish handler blocked by unfinished chest owner")
    GAssert(!CheckForFinishDungeonV2(),"current finish handler blocked by unfinished chest owner")
    GAssert(!ClickDungeonContinue(),"old Continue path blocked by unfinished chest owner")
    GAssert(!ClickUntilGoneFinishDungeon(0,0,0,0,800,600,DungeonContinue),"broad finish click loop blocked by unfinished chest owner")
    GAssert(!ClickFinishDungeonText(),"finish-text fallback blocked by unfinished chest owner")
    GAssert(!GReads && !GInputs,"blocked legacy paths do not even inspect ambiguous labels or send input")
    FileAppend("PASS: " GChecks " chest exit-lock assertions (actual entrance, route and legacy finish functions).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
AddToLog(message) => GLogs.Push(message)
FT(*) {
    global GReads
    GReads += 1
    throw Error("legacy label scan escaped chest lock")
}
WF_FindText(*) {
    global GReads
    GReads += 1
    throw Error("entry label scan escaped chest lock")
}
WF_RobloxClick(*) {
    global GInputs
    GInputs += 1
    throw Error("entry input escaped chest lock")
}
FixClick(*) {
    global GInputs
    GInputs += 1
    throw Error("legacy input escaped chest lock")
}
