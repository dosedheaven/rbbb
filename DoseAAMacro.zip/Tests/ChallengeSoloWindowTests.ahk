#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\ChallengeFunctionsForTests.ahk
; Real supplied Start/Cancel pixels and production detection/controller/window conversion.
; FixClick records transitions only; no actual mouse input or private settings IO.
global targetWidth := 816,targetHeight := 638,offsetX := -5,offsetY := 1
global NG := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " NG.Hwnd
global NState := "Pad",NWorks := true,NChecks := 0,NClicks := [],NMoves := 0,NLogs := [],NDisarms := 0
global NShiftX := 0,NShiftY := 0,NSoloAt := 0,NStartAt := 0
global FW_EntranceTimeoutMs := 180000,MatchMaking := {Value:1}
NG.BackColor := "151525"
global NCancel := NG.Add("Picture","x370 y541",A_ScriptDir "\Fixtures\ChallengeNative-Cancel.bmp")
global NMatch := NG.Add("Picture","x430 y306",A_ScriptDir "\Fixtures\ChallengeNative-Matchmaking.bmp")
global NArea := NG.Add("Picture","x751 y513",A_ScriptDir "\Fixtures\AreaText.bmp")
global NButtons := NG.Add("Picture","x285 y419",A_ScriptDir "\Fixtures\ChallengeStart-Buttons.png")
global NCancelOnly := NG.Add("Picture","x333 y498",A_ScriptDir "\Fixtures\ChallengeStart-CancelOnly.png")
global NOpen := NG.Add("Text","x350 y420 w100 h30 Center Background44AA55","PLAY")
global NSolo := NG.Add("Text","x280 y310 w100 h30 Center Background44AA55","PLAY NOW")
NG.Show("x100 y100 w816 h638")
class NHandoff extends Error {
    __New(name) {
        super.__New(name)
    }
}
class StageGuard {
    static Arm(*) => 0
    static Check(*) => 0
    static Disarm(*) {
        global NDisarms
        NDisarms += 1
    }
}
NDraw() {
    NCancel.Visible := NState="Pad" || NState="Choice"
    NMatch.Visible := NState="Choice",NSolo.Visible := NState="Choice"
    NArea.Visible := NState="Pad" || NState="Choice",NOpen.Visible := NState="Pad"
    NButtons.Move(285+NShiftX,419+NShiftY)
    NButtons.Visible := NState="Confirm"
    NCancelOnly.Visible := NState="CancelOnly"
    NG.Show("NA")
    for control in [NCancel,NMatch,NArea,NOpen,NSolo,NButtons,NCancelOnly]
        control.Redraw()
}
NReset(state,works:=true,sx:=0,sy:=0) {
    global NState,NWorks,NClicks,NShiftX,NShiftY,NSoloAt,NStartAt
    NState := state,NWorks := works,NClicks := [],NShiftX := sx,NShiftY := sy,NSoloAt := 0,NStartAt := 0
    NDraw()
    Sleep(100)
}
NAssert(ok,label) {
    global NChecks
    NChecks += 1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
NRun() {
    try {
        ChallengeMode({menuMs:1000,departureMs:1600,pollMs:40,choiceSettleMs:0,startRetryMs:200,maxStartClicks:3})
        return "Stopped"
    } catch NHandoff as handoff {
        return handoff.Message
    }
}
try {
    NReset("Confirm")
    NAssert(WF_PrepareDungeon() && ChallengeStartPromptVisible(&X,&Y),"supplied screenshot Start text detected by actual FindText")
    NAssert(ChallengeEntryMenuVisible(),"Start queue recognized without old Cancel/Areas cues")
    NAssert(NRun()="RestartStage" && NState="Loading","already-open supplied Start queue launches")
    NAssert(NClicks.Length=1 && NClicks[1].kind="Start" && !NMoves,"pre-open queue needs only detected Start, no movement or solo clicks")
    NReset("Pad")
    NAssert(ChallengeEntryMenuVisible(),"original queue menu still recognized")
    NAssert(NRun()="RestartStage" && NState="Loading","pad -> choice -> supplied Start -> loading")
    NAssert(NClicks.Length=3 && NClicks[1].kind="Open" && NClicks[2].kind="Solo" && NClicks[3].kind="Start","correct sequence without legacy/trailing clicks")
    NAssert(NStartAt-NSoloAt<1000,"Start handled promptly once its pixels appear")
    NReset("Choice")
    NAssert(NRun()="RestartStage" && NClicks.Length=2 && NClicks[1].kind="Solo","pre-open choice skips pad opener")
    NReset("Confirm",true,25,-12)
    NAssert(ChallengeStartPromptVisible(&shiftX,&shiftY) && shiftX-X=25 && shiftY-Y=-12,"Start match follows shifted screenshot exactly")
    NAssert(NRun()="RestartStage" && NClicks.Length=1 && NClicks[1].kind="Start","shifted button clicked at fresh detected location")
    NReset("Confirm",false)
    NAssert(NRun()="Stopped" && NState="Confirm","unchanged Start queue never hands off to map loading")
    NAssert(NClicks.Length=3,"ignored Start has bounded retries only, no Cancel or Matchmake")
    NReset("CancelOnly")
    NAssert(!ChallengeStartPromptVisible(&cancelX,&cancelY),"actual Cancel text cannot match Start")
    NAssert(NClicks.Length=0 && NMoves=0 && NDisarms=5,"negative detection sends no input; every controller guard is cleared")
    FileAppend("PASS: " NChecks " native Challenge Start assertions (supplied Start/Cancel pixels, actual FindText/window conversion/controller; input/game transitions simulated).`n","*")
    NG.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for message in NLogs
        FileAppend(message "`n","*")
    for recorded in NClicks
        FileAppend(recorded.kind " " recorded.x "," recorded.y "`n","*")
    NG.Destroy()
    ExitApp(1)
}
DungeonChestExitBlocked() => false
ChallengeMovement() {
    global NMoves
    NMoves += 1
    throw Error("menu was visible; movement must not repeat")
}
FixClick(x,y,*) {
    global NState,NSoloAt,NStartAt
    WinGetClientPos(&gx,&gy,,,rblxID)
    cx := x-gx,cy := y-gy
    if (cx=400 && cy=435 && NState="Pad") {
        NClicks.Push({kind:"Open",x:cx,y:cy})
        NState := "Choice",NDraw()
        return
    }
    if (cx=330 && cy=325 && NState="Choice") {
        NClicks.Push({kind:"Solo",x:cx,y:cy})
        NSoloAt := A_TickCount,NState := "Confirm",NDraw()
        return
    }
    px := cx-5,py := cy+1
    if (NState="Confirm" && px>=300+NShiftX && px<=472+NShiftX && py>=429+NShiftY && py<=487+NShiftY) {
        NClicks.Push({kind:"Start",x:cx,y:cy})
        NStartAt := A_TickCount
        if NWorks
            NState := "Loading",NDraw()
        return
    }
    throw Error("unexpected/Cancel/matchmaking action " cx "," cy " in " NState)
}
PlayHere(*) => NUnexpected("shared PlayHere")
ClickStartStory(*) => NUnexpected("legacy Start offset")
FindMatch(*) => NUnexpected("matchmaking")
NUnexpected(message) {
    throw Error(message)
}
Reconnect() => 0
AddToLog(message) => NLogs.Push(message)
NextStep(step) {
    throw NHandoff(step.Name)
}
RestartStage() => 0
sizeDown(*) => WinMove(,,targetWidth,targetHeight,rblxID)
