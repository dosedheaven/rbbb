#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\ChallengeFunctionsForTests.ahk
; Actual menu pixel detection, actual Challenge/PlayHere flow and window prep.
; FixClick records model transitions; it never clicks Roblox or the desktop.
global targetWidth := 816,targetHeight := 638,offsetX := -5,offsetY := 1
 global NG := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " NG.Hwnd
 global NState := "Pad",NWorks := true,NChecks := 0,NClicks := [],NMoves := 0,NLogs := [],NDisarms := 0
 global FW_EntranceTimeoutMs := 180000,MatchMaking := {Value:1}
NG.BackColor := "151525"
global NCancel := NG.Add("Picture","x370 y541",A_ScriptDir "\Fixtures\ChallengeNative-Cancel.bmp")
global NMatch := NG.Add("Picture","x430 y306",A_ScriptDir "\Fixtures\ChallengeNative-Matchmaking.bmp")
global NArea := NG.Add("Picture","x751 y513",A_ScriptDir "\Fixtures\AreaText.bmp")
global NOpen := NG.Add("Text","x350 y420 w100 h30 Center Background44AA55","PLAY")
global NSolo := NG.Add("Text","x280 y310 w100 h30 Center Background44AA55","PLAY NOW")
NG.Show("x100 y100 w816 h638")
class NHandoff extends Error {
    __New(name) {
        super.__New(name)
    }
}
class StageGuard {
    static Arm(*) => 0
    static Check(*) => 0
    static Disarm(*) {
        global NDisarms
        NDisarms += 1
    }
}
NDraw() {
    NCancel.Visible := NState="Pad" || NState="Choice"
    NMatch.Visible := NState="Choice",NSolo.Visible := NState="Choice"
    NArea.Visible := NState!="Loading",NOpen.Visible := NState="Pad"
    NG.Show("NA")
    for control in [NCancel,NMatch,NArea,NOpen,NSolo]
        control.Redraw()
}
NAssert(ok,label) {
    global NChecks
    NChecks += 1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
NRun() {
    try {
        ChallengeMode({menuMs:1000,departureMs:700,pollMs:40})
        return "Stopped"
    } catch NHandoff as handoff {
        return handoff.Message
    }
}
try {
    NDraw()
    Sleep(150)
    NAssert(WF_PrepareDungeon() && ChallengeEntryMenuVisible(),"native queue Cancel reference is recognized")
    NAssert(NRun()="RestartStage" && NState="Loading","native pad -> choice -> solo sequence reaches loading")
    NAssert(NClicks.Length=3 && NClicks[1].x=400 && NClicks[2].x=330 && NClicks[3].x=330 && !NMoves,"existing solo actions run once and no repeat movement occurs")
    NState := "Choice",NClicks := [],NDraw()
    Sleep(150)
    NCancel.Visible := false
    NAssert(ChallengeEntryMenuVisible(),"native Matchmaking text also recognizes an already-open choice popup")
    NAssert(NRun()="RestartStage" && !NMoves,"choice-only popup launches solo without walking away")
    NState := "Choice",NWorks := false,NClicks := [],NDraw()
    Sleep(150)
    NAssert(NRun()="Stopped" && NState="Choice","unchanged native popup cannot be mistaken for a successful launch")
    NAssert(NClicks.Length=3 && NDisarms=3,"failed launch adds no matchmaking/retry clicks and clears its entrance guard")
    FileAppend("PASS: " NChecks " native Challenge menu assertions (real Cancel/Matchmaking/Areas pixels and actual shared solo routine; input/game transitions simulated).`n","*")
    NG.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for message in NLogs
        FileAppend(message "`n","*")
    NG.Destroy()
    ExitApp(1)
}
DungeonChestExitBlocked() => false
ChallengeMovement() {
    global NMoves
    NMoves += 1
    throw Error("menu was visible; movement must not repeat")
}
FixClick(x,y,*) {
    global NState
    NClicks.Push({x:x,y:y})
    if (x=400 && y=435) {
        if NState="Pad"
            NState := "Choice",NDraw()
        return
    }
    if (x=330 && y=325) {
        if (NState="Choice" && NWorks)
            NState := "Loading",NDraw()
        return
    }
    throw Error("unexpected/matchmaking action " x "," y)
}
ClickStartStory() => 0
Reconnect() => 0
AddToLog(message) => NLogs.Push(message)
NextStep(step) {
    throw NHandoff(step.Name)
}
RestartStage() => 0
sizeDown(*) => WinMove(,,targetWidth,targetHeight,rblxID)
