; Generated production shop functions; offline tests only.
CheckDungeonSpecials(chestOptions := 0) {
    AddToLog("Checking for dungeon shop, shrine, open chest")
    
    ; Give time for special elements to appear
    Sleep(2000)
    
    foundShop := false
    foundShrine := false
    foundChest := false

    ; Check the area for shop, shrine, or chest
    Loop 5 {
        ; Check for shop
        if (!foundShop && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shop)) {
            AddToLog("Found Shop")
            Sleep(1000)
            if !HandleShop()
                return false
            Sleep(1000)
            foundShop := true
        }
        Sleep(1000)
        ; Check for shrine
        if (!foundShrine && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shrine)) {
            if (DenyShrines.Value) {
                AddToLog("Found Shrine, Denying")
                ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
            } else {
                ShrinePriority()
            }
            Sleep(1000)
            foundShrine := true
        }
        Sleep(1000)
        ; Check for Chest Opening
        if (!foundChest && IsChestScreenVisible()) {
            AddToLog("Found Chest Opening")
            if !HandleChestScreen(chestOptions)
                return false
            foundChest := true
        }
        
        ; If all elements are found, exit early
        if (foundShop && foundShrine && foundChest)
            break

        Sleep(1000)  ; Wait and check again
    }
    
    if (!foundShop && !foundShrine && !foundChest)
        AddToLog("No shop, shrine, or chest opening found")
    return true
}

HandleShop(overrides := 0) {
    global WF_LastIssue
    options := DungeonShopOptions(overrides)
    if !WF_PrepareDungeon() {
        AddToLog("Shop window not ready; no purchases attempted")
        return false
    }
    AddToLog("Handling shop: Golden Fishhook, then Fishhook; never buy Axe or Headsplitter; remaining buttons bottom to top")
    Sleep(options.loadMs)
    if !DungeonShopVisible() {
        AddToLog("Shop header not confirmed; no purchases attempted")
        return false
    }
    state := {actions:0, deadline:A_TickCount+options.totalMs}
    buttons := DungeonShopReadStable(options)
    if !IsObject(buttons)
        return DungeonShopFailure("initial purchase-button scan")
    AddToLog("Shop: " buttons.Length " visible gold purchase buttons")
    if !DungeonShopRememberExclusions(buttons,state)
        return DungeonShopFailure("initial never-buy scan")
    blocked := Map()
    for hookName in ["Golden Fishhook", "Fishhook"] {
        hookFound := false
        Loop 3 {
            if DungeonShopHook(&hookX,&hookY,hookName) {
                hookFound := true
                break
            }
            if (WF_LastIssue != "")
                return DungeonShopFailure(hookName " search")
            Sleep(options.pollMs)
        }
        if hookFound {
            row := DungeonShopHookRow(buttons,hookX,hookY,hookName)
            if row {
                result := DungeonShopBuy(buttons,row,options,state,hookName)
                if !result.ok
                    return false
                buttons := result.buttons
                if (!result.progress && !result.changed)
                    blocked[result.row] := true
            } else {
                if (hookName="Golden Fishhook") {
                    AddToLog("Golden Fishhook found without an active purchase button; checking other items")
                    continue
                }
                ; Keep the known-working Fishhook click even when its button is
                ; disabled or the gold shape is not detected. Never claim success.
                AddToLog(hookName " found without a recognized active gold button; trying its existing purchase point first")
                if !DungeonShopVisible()
                    return DungeonShopFailure(hookName " fallback header recheck")
                if !DungeonShopHook(&hookX,&hookY,hookName) {
                    if (WF_LastIssue!="")
                        return DungeonShopFailure(hookName " fallback recheck")
                } else {
                    excluded := DungeonShopExcluded({y:hookY})
                    if (WF_LastIssue!="")
                        return DungeonShopFailure("hook fallback exclusion check")
                    if excluded {
                        AddToLog("Shop skip: " excluded " is never-buy")
                        continue
                    }
                    if !DungeonShopClick(hookX+150,hookY,hookName " first")
                        return false
                    state.actions += 1
                }
                if !DungeonShopMoveOffButtons()
                    return DungeonShopFailure("moving off purchase button")
                Sleep(options.settleMs)
                buttons := DungeonShopReadStable(options)
                if !IsObject(buttons)
                    return DungeonShopFailure("post-" hookName " scan")
                AddToLog(hookName " purchase not independently confirmed; checking other available items")
            }
        } else
            AddToLog(hookName " not detected after 3 checks; using visible purchase buttons")
    }

    while (buttons.Length && state.actions < options.maxActions && A_TickCount < state.deadline) {
        row := 0
        Loop buttons.Length {
            candidate := buttons.Length-A_Index+1
            if !blocked.Has(candidate) {
                row := candidate
                break
            }
        }
        if !row
            break
        result := DungeonShopBuy(buttons,row,options,state)
        if !result.ok
            return false
        buttons := result.buttons
        if (result.progress || result.changed)
            blocked := Map()
        else
            blocked[row] := true
    }
    if buttons.Length
        AddToLog("Shop: " buttons.Length " purchase buttons remain (excluded or possibly unaffordable); continuing as configured")
    else
        AddToLog("Shop: no active gold purchase buttons detected; checking Continue")
    return DungeonShopClose(options)
}

DungeonShopOptions(overrides := 0) {
    options := {loadMs:1500,pollMs:200,settleMs:500,observeMs:2500,
        scanTries:8,attempts:3,maxActions:12,totalMs:60000,closeMs:8000}
    if IsObject(overrides) {
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    }
    return options
}

DungeonShopFailure(context) {
    global WF_LastIssue
    AddToLog("Shop " context " failed: " WF_LastIssue "; no later purchase or Continue sent")
    return false
}

DungeonShopVisible() {
    return WF_FindText(&X,&Y,110,120,420,280,0,0,Shop)
}

DungeonShopFishhook(&X,&Y) {
    return WF_FindText(&X,&Y,184,118,623,523,0,0,Fishhook)
}

DungeonShopHook(&X,&Y,kind) {
    if (kind="Golden Fishhook")
        return WF_FindText(&X,&Y,184,118,623,523,0,0,GoldenFishhook)
    return DungeonShopFishhook(&X,&Y)
}

DungeonShopHookRow(buttons,x,y,kind) {
    if !buttons.Length
        return 0
    return DungeonShopButtonAt(buttons,kind="Golden Fishhook" ? buttons[1].x : x+150,y)
}

DungeonShopExcluded(button) {
    for reference in [["Headsplitter",Headsplitter],["Axe",Axe]] {
        if WF_FindText(&X,&Y,365,Max(118,button.y-34),450,Min(523,button.y+34),0,0,reference[2])
            return reference[1]
        if (WF_LastIssue!="")
            return ""
    }
    return ""
}

DungeonShopRememberExclusions(buttons,state,removedRow := 0) {
    if !state.HasOwnProp("excluded") {
        state.excluded := Map(),state.exclusionCount := buttons.Length
    } else if (buttons.Length!=state.exclusionCount) {
        remembered := Map()
        if (removedRow>=1 && buttons.Length=state.exclusionCount-1) {
            for row,name in state.excluded {
                if (row=removedRow)
                    continue
                remembered[row>removedRow ? row-1 : row] := name
            }
        } else if state.excluded.Count {
            ; Unknown/externally changed removal: don't guess which remaining
            ; item was the excluded one. Skip remaining offers for this visit.
            for row,button in buttons
                remembered[row] := "Excluded item (layout changed unexpectedly)"
        }
        state.excluded := remembered,state.exclusionCount := buttons.Length
    }
    for row,button in buttons {
        excluded := DungeonShopExcluded(button)
        if (WF_LastIssue!="")
            return false
        if excluded
            state.excluded[row] := excluded
    }
    return true
}

DungeonShopGold(color) {
    r := (color>>16)&255,g := (color>>8)&255,b := color&255
    return r>=185 && g>=125 && b<=130 && r+25>=g && g>=b+45 && r>=b+80
}

DungeonShopButtonsFromFrame(frame) {
    w := frame.w,h := frame.h,mask := Buffer(w*h,0),buttons := []
    Loop w*h
        if DungeonShopGold(NumGet(frame.pixels,(A_Index-1)*4,"UInt"))
            NumPut("UChar",1,mask,A_Index-1)
    Loop w*h {
        seed := A_Index-1
        if !NumGet(mask,seed,"UChar")
            continue
        queue := [seed],head := 1,count := 0,minX := w,minY := h,maxX := -1,maxY := -1
        NumPut("UChar",0,mask,seed)
        while (head<=queue.Length) {
            index := queue[head],head += 1
            px := Mod(index,w),py := index//w
            minX := Min(minX,px),maxX := Max(maxX,px),minY := Min(minY,py),maxY := Max(maxY,py)
            count += 1
            for dy in [-1,0,1] {
                ny := py+dy
                if (ny<0 || ny>=h)
                    continue
                for dx in [-1,0,1] {
                    nx := px+dx
                    if (nx<0 || nx>=w || (dx=0 && dy=0))
                        continue
                    next := ny*w+nx
                    if NumGet(mask,next,"UChar") {
                        NumPut("UChar",0,mask,next)
                        queue.Push(next)
                    }
                }
            }
        }
        bw := maxX-minX+1,bh := maxY-minY+1
        ; Connected gold plate, not the small coin glyph or yellow item text.
        if (minX=0 || minY=0 || maxX=w-1 || maxY=h-1 || bw<40 || bw>90 || bh<14 || bh>38
            || bw<bh*1.4 || bw>bh*5 || count<bw*bh*0.40)
            continue
        button := {x:frame.x+Round((minX+maxX)/2),y:frame.y+Round((minY+maxY)/2),w:bw,h:bh}
        pos := 1
        while (pos<=buttons.Length && buttons[pos].y<button.y)
            pos += 1
        buttons.InsertAt(pos,button)
    }
    return buttons
}

DungeonShopSameButtons(a,b) {
    if (a.Length!=b.Length)
        return false
    for i,button in a
        if (Abs(button.x-b[i].x)>3 || Abs(button.y-b[i].y)>3 || Abs(button.w-b[i].w)>3 || Abs(button.h-b[i].h)>3)
            return false
    return true
}

DungeonShopReadStable(options) {
    global WF_LastIssue
    previous := 0,streak := 0
    Loop options.scanTries {
        if !DungeonShopVisible() {
            if (WF_LastIssue="")
                WF_LastIssue := "Shop header is not visible"
            return false
        }
        frame := DungeonShopCapture()
        if !IsObject(frame)
            return false
        buttons := DungeonShopButtonsFromFrame(frame)
        if (buttons.Length>3) {
            WF_LastIssue := "More than three purchase-button candidates; refusing ambiguous clicks"
            return false
        }
        for i,button in buttons {
            if (i>1 && (Abs(button.x-buttons[1].x)>16 || button.y-buttons[i-1].y<30)) {
                WF_LastIssue := "Purchase-button column is ambiguous"
                return false
            }
        }
        streak := IsObject(previous) && DungeonShopSameButtons(previous,buttons) ? streak+1 : 1
        if (streak >= (buttons.Length ? 2 : 3))
            return buttons
        previous := buttons
        Sleep(options.pollMs)
    }
    WF_LastIssue := "Shop purchase layout did not settle"
    return false
}

DungeonShopButtonAt(buttons,x,y) {
    for i,button in buttons
        if (Abs(button.x-x)<=button.w//2 && Abs(button.y-y)<=button.h//2+3)
            return i
    return 0
}

DungeonShopBuy(before,row,options,state,fishhook := false) {
    global WF_LastIssue
    description := fishhook ? fishhook " first" : "remaining item"
    Loop options.attempts {
        if (state.actions>=options.maxActions || A_TickCount>=state.deadline)
            break
        fresh := DungeonShopReadStable(options)
        if !IsObject(fresh) {
            DungeonShopFailure(description " recheck")
            return {ok:false}
        }
        if !DungeonShopSameButtons(before,fresh) {
            if fishhook {
                if DungeonShopHook(&hookX,&hookY,fishhook) {
                    newRow := DungeonShopHookRow(fresh,hookX,hookY,fishhook)
                    if newRow
                        before := fresh,row := newRow
                    else
                        return {ok:true,progress:false,changed:true,buttons:fresh,row:row}
                } else {
                    if (WF_LastIssue!="") {
                        DungeonShopFailure("moved Fishhook recheck")
                        return {ok:false}
                    }
                    return {ok:true,progress:false,changed:true,buttons:fresh,row:row}
                }
            } else
                return {ok:true,progress:false,changed:true,buttons:fresh,row:row}
        }
        if !DungeonShopRememberExclusions(fresh,state) {
            DungeonShopFailure("live never-buy scan")
            return {ok:false}
        }
        x := fresh[row].x,y := fresh[row].y
        if fishhook {
            if !DungeonShopHook(&hookX,&hookY,fishhook) {
                if (WF_LastIssue!="") {
                    DungeonShopFailure("Fishhook recheck")
                    return {ok:false}
                }
                return {ok:true,progress:false,changed:false,buttons:fresh,row:row}
            }
            x := fishhook="Golden Fishhook" ? fresh[row].x : hookX+150,y := hookY
            if (DungeonShopButtonAt(fresh,x,y)!=row) {
                WF_LastIssue := "Fishhook moved outside its confirmed purchase row"
                DungeonShopFailure("Fishhook row recheck")
                return {ok:false}
            }
        }
        excluded := DungeonShopExcluded({y:y})
        if (WF_LastIssue!="") {
            DungeonShopFailure("never-buy exclusion recheck")
            return {ok:false}
        }
        if state.excluded.Has(row)
            excluded := state.excluded[row]
        if excluded {
            state.excluded[row] := excluded
            AddToLog("Shop skip: " excluded " is never-buy; no purchase click sent")
            return {ok:true,progress:false,changed:false,buttons:fresh,row:row}
        }
        if !DungeonShopClick(x,y,description)
            return {ok:false}
        state.actions += 1
        if !DungeonShopMoveOffButtons() {
            DungeonShopFailure("purchase hover reset")
            return {ok:false}
        }
        Sleep(options.settleMs)
        observed := A_TickCount
        while (A_TickCount-observed<options.observeMs && A_TickCount<state.deadline) {
            after := DungeonShopReadStable(options)
            if !IsObject(after) {
                DungeonShopFailure("post-purchase scan")
                return {ok:false}
            }
            hookGone := true
            if fishhook {
                hookGone := !DungeonShopHook(&hookX,&hookY,fishhook)
                if (WF_LastIssue!="") {
                    DungeonShopFailure("Fishhook completion check")
                    return {ok:false}
                }
            }
            if (after.Length<before.Length && hookGone) {
                if !DungeonShopRememberExclusions(after,state,row) {
                    DungeonShopFailure("post-purchase never-buy scan")
                    return {ok:false}
                }
                AddToLog("Shop " description ": visible purchase buttons " before.Length " -> " after.Length "; re-scanning next item")
                return {ok:true,progress:true,changed:true,buttons:after}
            }
            Sleep(options.pollMs)
        }
        AddToLog("Shop " description " purchase not confirmed; attempt " A_Index "/" options.attempts)
    }
    AddToLog("Shop " description " still unconfirmed (possibly unaffordable); trying other items before Continue")
    return {ok:true,progress:false,changed:false,buttons:before,row:row}
}

DungeonShopClose(options) {
    global WF_LastIssue
    started := A_TickCount,lastClick := 0,clicks := 0,absent := 0
    while (A_TickCount-started<options.closeMs) {
        visible := DungeonShopVisible()
        if (WF_LastIssue!="")
            return DungeonShopFailure("close confirmation")
        absent := visible ? 0 : absent+1
        if (absent>=2) {
            AddToLog("Shop closed; returning to dungeon flow")
            return true
        }
        if (visible && clicks<3 && (!lastClick || A_TickCount-lastClick>=options.observeMs)) {
            if WF_FindText(&X,&Y,350,345,630,500,0,0,DungeonContinue) {
                if !DungeonShopClick(X,Y,"close shop")
                    return false
                clicks += 1,lastClick := A_TickCount
            } else if (WF_LastIssue!="")
                return DungeonShopFailure("Continue search")
        }
        Sleep(options.pollMs)
    }
    AddToLog("Shop Continue did not close the menu; no room selection attempted")
    return false
}

DungeonShopClick(x, y, description) {
    if !WF_RobloxClick(x, y) {
        AddToLog("Shop input refused for " description "; no later purchases attempted")
        return false
    }
    AddToLog("Shop purchase/action click sent: " description "; purchase/buff not independently confirmed")
    return true
}

