; Actual start dispatcher.
StartSelectedMode() {
    if DungeonChestExitBlocked()
        return NextStep(DoseResumeChestSession)
    known:=DoseDungeonScreenStep()
    if IsObject(known)
        return NextStep(known)
    DoseRouteStageEnd("start reconciliation")
    global inChallengeMode, firstStartup, challengeStartTime
    FixClick(400,340)
    FixClick(400,390)
    CloseChat()

    ; Also check at a verified lobby after final-boss rewards. Normal floor
    ; switches remain in the mode-specific end-navigation adapters.
    if (!firstStartup && DoseAutoChallengeDue() && CheckForLobbyText()) {
        AddToLog("Challenge due at lobby - entering before the next farming run")
        inChallengeMode:=true
        challengeStartTime:=A_TickCount
    }

    if (ChallengeBox.Value && firstStartup) {
        AddToLog("Auto Challenge enabled - starting with challenge")
        inChallengeMode := true
        firstStartup := false
        challengeStartTime := A_TickCount  ; Set initial challenge time
        ChallengeMode()
        return
    }

    if (!inChallengeMode)
        Sched_RunPendingTeamSwap()   ; [Scheduler team swap] equip the scheduled step's team while still in the lobby

    ; If we're in challenge mode, do challenge
    if (inChallengeMode) {
        AddToLog("Starting Challenge Mode")
        ChallengeMode()
        return
    }    
    else if (ModeDropdown.Text = "Story") {
        StoryMode()
    }
    else if (ModeDropdown.Text = "Legend") {
        LegendMode()
    }
    else if (ModeDropdown.Text = "Raid") {
        RaidMode()
    }
    else if (ModeDropdown.Text = "Infinity Castle") {
        InfinityCastleMode()
    }
    else if (ModeDropdown.Text = "Contract") {
        if (contractsEnabled) {
            ContractMode()
        } else {
            AddToLog("Contracts are is not currently in Anime Adventures!")
        }
    }
    else if (ModeDropdown.Text = "Fool's Hunt") {
        FoolsEvent()
    }
    else if (ModeDropdown.Text = "Winter Event") {
        if (isWinter) {
            WinterEvent()
        } else {
            AddToLog("The Winter Event is not currently in Anime Adventures!")
        }
    }
    else if (ModeDropdown.Text = "Cursed Womb") {
        CursedWombMode()
    }
    else if (ModeDropdown.Text = "Portal") {
        PortalMode()
    }
    else if (ModeDropdown.Text = "Dungeon") {
        DungeonMode()
    }
}
