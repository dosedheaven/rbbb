#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\NativeChestFunctionsForTests.ahk
; Real native header/Continue pixels, WindowFollow and client conversion.
; Inventory and game transitions are simulated; FixClick never clicks a game.
global targetWidth := 816,targetHeight := 638,offsetX := -5,offsetY := 1
 global NG := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " NG.Hwnd
 global NC := 0,NCommon := 1,NRare := 1,NRewards := 0,NEvents := [],NClaimTimes := [],NLogs := []
 global NVisible := true,NBackgroundChecks := 0,NCountDuringPair := 0
 global BossRoomCompleted := true,SaveChestsForBoss := true,DenyShrines := {Value:1}
NG.BackColor := "161621"
global NHeader := NG.Add("Picture","x190 y205",A_ScriptDir "\Fixtures\ChestNative-Header.bmp")
global NContinue := NG.Add("Picture","x460 y405",A_ScriptDir "\Fixtures\ShopNative-DungeonContinue.bmp")
global NLobby := NG.Add("Picture","x400 y110",A_ScriptDir "\Fixtures\LobbyText.bmp")
global NOverlay := NG.Add("Text","x265 y255 w295 h230 Center Background34304C cFFFFFF","REWARD 1 / 2")
NG.Show("x100 y100 w816 h638")
NDraw() {
    NHeader.Visible := NVisible,NContinue.Visible := NVisible && NRewards=0
    NOverlay.Visible := NVisible && NRewards>0
    NOverlay.Text := NRewards=2 ? "REWARD 1 / 2" : "REWARD 2 / 2"
    NG.Show("NA")
    NHeader.Redraw(),NContinue.Redraw(),NOverlay.Redraw()
}
NAssert(ok,label) {
    global NC
    NC += 1
    if !ok
        throw Error(label " / " WF_LastIssue)
}
NDraw()
try {
    NAssert(WF_PrepareDungeon() && DungeonChestMenuReady(),"native chest heading and exact Continue are recognized")
    opts := {pollMs:40,afterOpenMs:100,claimClickMs:2000,rewardSettleMs:150,
        departMs:1200,claimMs:10000,totalMs:30000,maxRecoveries:0,continueMs:1200}
    NAssert(HandleChestScreen(opts),"complete native overlay sequence drains both chest types")
    NAssert(NEvents.Length=7 && NEvents[1]="open Common" && NEvents[2]="center" && NEvents[3]="center"
        && NEvents[4]="open Rare" && NEvents[5]="center" && NEvents[6]="center" && NEvents[7]="continue",
        "only Open/center/center repeat followed by one Continue can occur")
    NAssert(NClaimTimes[2]-NClaimTimes[1]>=2000 && NClaimTimes[4]-NClaimTimes[3]>=2000,"both native reward pairs preserve the two-second gap")
    NAssert(NBackgroundChecks=4,"real heading and Lobby pixels remain recognizable during every center click")
    NAssert(!NCommon && !NRare && !NRewards && !NCountDuringPair,"inventory is exhausted with no zero-count read inside an owed pair")
    NAssert(!DungeonChestExitBlocked() && DungeonBossExitPending,"entry unlocks only after the verified Continue closes the chest menu")
    FileAppend("PASS: " NC " native chest-overlay assertions (real header/Continue/Lobby pixels and input conversion; game counts/click transitions simulated).`n","*")
    NG.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for message in NLogs
        FileAppend(message "`n","*")
    NG.Destroy()
    ExitApp(1)
}
IsCommonChestDone() {
    global NCountDuringPair
    if IsObject(DoseChestState) && DoseChestState.owedClicks {
        NCountDuringPair += 1
        throw Error("numeric count queried while rewards still owed")
    }
    return NCommon=0
}
IsRareChestDone() => NRare=0
FixClick(x,y,*) {
    global NCommon,NRare,NRewards,NVisible,NBackgroundChecks
    WinGetClientPos(&gx,&gy,&w,&h,rblxID)
    cx := x-gx,cy := y-gy
    if (cx=565 && (cy=260 || cy=320)) {
        if NRewards
            throw Error("another Open escaped before both rewards")
        kind := cy=260 ? "Common" : "Rare"
        if kind="Common"
            NCommon -= 1
        else
            NRare -= 1
        NRewards := 2,NEvents.Push("open " kind)
        NDraw()
        return
    }
    if (cx=w//2 && cy=h//2) {
        if !DungeonChestMenuVisible()
            throw Error("native background-heading regression not actually present")
        if !FT(&lx,&ly,80,85,739,224,0,0,LobbyText)
            throw Error("native background Lobby label not actually present")
        NBackgroundChecks += 1
        NEvents.Push("center"),NClaimTimes.Push(A_TickCount)
        if NRewards
            NRewards -= 1
        NDraw()
        return
    }
    if (cx>=460 && cx<=535 && cy>=400 && cy<=465) {
        if (NRewards || NCommon || NRare || DungeonChestExitBlocked() && !DoseChestState.verified)
            throw Error("Continue escaped before completed pairs/zero proof")
        NEvents.Push("continue"),NVisible := false,NDraw()
        return
    }
    throw Error("forbidden top/entry click " cx "," cy)
}
sizeDown(*) => WinMove(,,targetWidth,targetHeight,rblxID)
AddToLog(message) => NLogs.Push(message)
ClickDungeonContinue(*) {
    throw Error("legacy Continue escaped chest owner")
}
CheckForReturnToLobby() => true
HandleShop(*) {
    throw Error("Shop escaped chest owner")
}
ShrinePriority(*) {
    throw Error("Shrine escaped chest owner")
}
NextStep(*) {
    throw Error("handoff escaped chest owner")
}
