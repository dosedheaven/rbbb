#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\ChallengeFunctionsForTests.ahk
; Production Challenge flow AND unchanged shared PlayHere routine; fake game IO.
global TChecks := 0,TState := "Lobby",TAfterWalk := "Pad",TWalks := 0,TClicks := [],TLogs := []
 global TReady := true,TBlocked := false,TBlockedAfterWalk := false,TLocked := false,WF_LastIssue := ""
 global TSoloWorks := true,TConfirmNeeded := false,TStarts := 0,TMatches := 0,TTarget := "",TDelay := 0
 global TChoiceHasCancel := true,TClosedButLobby := false,TBlankAreas := 0,TVoteAfter := false,TAreaInVote := false
 global TArms := 0,TDisarms := 0,TReconnects := 0,FW_EntranceTimeoutMs := 180000
 global MatchMaking := {Value:1}
 global TFast := {menuMs:100,departureMs:150,pollMs:5}
class THandoff extends Error {
    __New(name) {
        super.__New(name)
    }
}
class StageGuard {
    static Arm(*) {
        global TArms
        TArms += 1
    }
    static Disarm(*) {
        global TDisarms
        TDisarms += 1
    }
    static Check(*) => 0
}
TAssert(ok,label) {
    global TChecks
    TChecks += 1
    if !ok
        throw Error(label)
}
TReset(state := "Lobby") {
    global
    TState := state,TAfterWalk := "Pad",TWalks := 0,TClicks := [],TLogs := []
    TReady := true,TBlocked := false,TBlockedAfterWalk := false,TLocked := false,WF_LastIssue := ""
    TSoloWorks := true,TConfirmNeeded := false,TStarts := 0,TMatches := 0,TTarget := "",TDelay := 0
    TChoiceHasCancel := true,TClosedButLobby := false,TBlankAreas := 0,TVoteAfter := false,TAreaInVote := false
    TArms := 0,TDisarms := 0,TReconnects := 0,MatchMaking.Value := 1
}
TRun() {
    try {
        ChallengeMode(TFast)
        return "Stopped"
    } catch THandoff as handoff {
        return handoff.Message
    }
}
try {
    TReset()
    TAssert(TRun()="RestartStage","area movement then solo launch reaches the loading step")
    TAssert(TWalks=1 && TClicks.Length=3 && TClicks[1].x=400 && TClicks[2].x=330 && TClicks[3].x=330,"actual shared solo sequence runs once after entry")
    TAssert(!TMatches && TStarts=1 && TDisarms=1,"matchmaking is never chosen and entrance guard is disarmed on handoff")
    TReset("Choice"),TChoiceHasCancel := false
    TAssert(TRun()="RestartStage" && !TWalks,"already-open Play Now/Matchmake popup is handled without walking out of it")
    TAssert(TClicks[2].x=330 && !TMatches,"choice-only popup still selects the left solo option")
    TReset("Pad")
    TAssert(TRun()="RestartStage" && !TWalks,"already-open queue menu skips repeated movement")
    TReset(),TAfterWalk := "Waiting",TDelay := 3
    TAssert(TRun()="RestartStage" && TWalks=1,"delayed menu gets time to appear without repeating the A movement")
    TReset("Pad"),MatchMaking.Value := 0
    TAssert(TRun()="RestartStage" && !TMatches,"solo choice does not depend on another mode's Matchmaking checkbox")
    TReset("Pad"),TConfirmNeeded := true
    TAssert(TRun()="RestartStage" && TStarts=1 && TState="Loading","existing solo routine also handles its normal Start confirmation")
    TReset("Choice"),TSoloWorks := false
    TAssert(TRun()="Stopped" && TClicks.Length=3 && !TTarget,"ignored Play Now cannot falsely hand off to map loading")
    TAssert(!TWalks && !TMatches && TDisarms=1,"failed solo launch neither walks again nor switches to matchmaking")
    TReset(),TAfterWalk := "Lobby"
    TAssert(TRun()="Stopped" && TWalks=1 && !TClicks.Length,"missing menu stops after one movement with no guessed solo click")
    TReset(),TReady := false
    TAssert(TRun()="Stopped" && !TWalks && !TClicks.Length && !TArms,"invalid game window receives no movement or menu input")
    TReset(),TBlockedAfterWalk := true
    TAssert(TRun()="Stopped" && TWalks=1 && !TClicks.Length,"covered window after movement receives no Play Now input")
    TReset(),TLocked := true
    TAssert(TRun()="Stopped" && !TWalks && !TClicks.Length,"pending boss chests keep priority over a direct Challenge call")
    TReset("Choice"),TClosedButLobby := true,TBlankAreas := 1
    TAssert(TRun()="Stopped" && !TTarget,"one absent Areas sample cannot turn a closed popup into a confirmed departure")
    TReset("Pad"),TVoteAfter := true,TAreaInVote := true
    TAssert(TRun()="RestartStage" && TState="Vote","positive vote UI confirms the loaded stage even if a lobby-like reference remains")
    FileAppend("PASS: " TChecks " Challenge solo flow assertions (actual Challenge/PlayHere code; screens/input/services simulated).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for message in TLogs
        FileAppend(message "`n","*")
    ExitApp(1)
}
DungeonChestExitBlocked() => TLocked
WF_PrepareDungeon() => TReady
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,TState,TDelay,TBlankAreas
    WF_LastIssue := TBlocked ? "synthetic covering window" : "",X := x1,Y := y1
    if TBlocked
        return false
    if (text=ModeCancel && TState="Waiting") {
        TDelay -= 1
        if TDelay<=0
            TState := "Pad"
    }
    if (text=ModeCancel)
        return TState="Pad" || TState="Confirm" || (TChoiceHasCancel && TState="Choice")
    if (text=MatchMakingText)
        return TState="Choice"
    if (text=VoteStart)
        return TState="Vote"
    if (text=AreaText) {
        if (TState="StuckLobby" && TBlankAreas) {
            TBlankAreas -= 1
            return false
        }
        return TState="Lobby" || TState="Pad" || TState="Choice" || TState="Confirm" || TState="StuckLobby" || (TAreaInVote && TState="Vote")
    }
    throw Error("Unexpected Challenge reference")
}
ChallengeMovement() {
    global TWalks,TState,TBlocked
    TWalks += 1,TState := TAfterWalk,TBlocked := TBlockedAfterWalk
}
FixClick(x,y,*) {
    global TState,TMatches
    TClicks.Push({x:x,y:y})
    if (x=400 && y=435) {
        if TState="Pad"
            TState := "Choice"
        return
    }
    if (x=330 && y=325) {
        if (TState="Choice" && TSoloWorks)
            TState := TClosedButLobby ? "StuckLobby" : TConfirmNeeded ? "Confirm" : TVoteAfter ? "Vote" : "Loading"
        return
    }
    TMatches += 1
    throw Error("unexpected or matchmaking button click")
}
ClickStartStory() {
    global TStarts,TState
    TStarts += 1
    if TState="Confirm"
        TState := "Loading"
}
FindMatch(*) {
    global TMatches
    TMatches += 1
    throw Error("Matchmaking must not be selected for Challenge")
}
Reconnect() {
    global TReconnects
    TReconnects += 1
}
AddToLog(message) => TLogs.Push(message)
NextStep(step) {
    global TTarget
    TTarget := step.Name
    throw THandoff(step.Name)
}
RestartStage() => 0
