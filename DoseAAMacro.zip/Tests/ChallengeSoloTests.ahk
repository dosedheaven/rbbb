#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\ChallengeFunctionsForTests.ahk
; Actual Challenge controller, fresh Start matching decisions and native client
; conversion. Game/reference/input effects are simulated; no private IO.
global TG := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " TG.Hwnd
 global TChecks := 0,TState := "Lobby",TAfterWalk := "Pad",TWalks := 0,TClicks := [],TLogs := []
 global TReady := true,TBlocked := false,TBlockedAfterWalk := false,TLocked := false,WF_LastIssue := ""
 global TSoloWorks := true,TStartWorks := true,TStartInputOK := true,TStarts := 0,TSolos := 0,TOpens := 0,TMatches := 0,TTarget := "",TDelay := 0
 global TChoiceHasCancel := true,TConfirmOldCues := false,TClosedButLobby := false,TVoteAfter := false,TAreaInVote := false
 global TArms := 0,TDisarms := 0,FW_EntranceTimeoutMs := 180000,MatchMaking := {Value:1}
 global TStartTimes := [],TSoloAt := 0,TStartDelay := 0,TPendingStartAt := 0,TNeverStart := false,TLegacyOnly := false
 global TStartReads := 0,TLoseStartOnRead := 0,TOpenActual := false
 global TFast := {menuMs:150,departureMs:250,pollMs:5,choiceSettleMs:0,startRetryMs:20,maxStartClicks:3}
TG.Show("x100 y100 w816 h638")
class THandoff extends Error {
    __New(name) {
        super.__New(name)
    }
}
class StageGuard {
    static Arm(*) {
        global TArms
        TArms += 1
    }
    static Disarm(*) {
        global TDisarms
        TDisarms += 1
    }
    static Check(*) => 0
}
TAssert(ok,label) {
    global TChecks
    TChecks += 1
    if !ok
        throw Error(label)
}
TReset(state := "Lobby") {
    global
    TState := state,TAfterWalk := "Pad",TWalks := 0,TClicks := [],TLogs := []
    TReady := true,TBlocked := false,TBlockedAfterWalk := false,TLocked := false,WF_LastIssue := ""
    TSoloWorks := true,TStartWorks := true,TStartInputOK := true,TStarts := 0,TSolos := 0,TOpens := 0,TMatches := 0,TTarget := "",TDelay := 0
    TChoiceHasCancel := true,TConfirmOldCues := false,TClosedButLobby := false,TVoteAfter := false,TAreaInVote := false
    TArms := 0,TDisarms := 0,TStartTimes := [],TSoloAt := 0,TStartDelay := 0,TPendingStartAt := 0,TNeverStart := false,TLegacyOnly := false
    TStartReads := 0,TLoseStartOnRead := 0,TOpenActual := false,MatchMaking.Value := 1
}
TRun() {
    try {
        ChallengeMode(TFast)
        return "Stopped"
    } catch THandoff as handoff {
        return handoff.Message
    }
}
try {
    TReset()
    TAssert(TRun()="RestartStage","walk -> Play Now -> Start -> loading completes")
    TAssert(TWalks=1 && TOpens=1 && TSolos=1 && TStarts=1 && TClicks.Length=3,"one opener, one solo selection and one matched Start; no trailing click")
    TAssert(TStartTimes[1]-TSoloAt<500,"Start is handled immediately without the old 1200 ms delay")
    TAssert(TClicks[3].x=385 && TClicks[3].y=457,"Start uses its found center without a legacy -35 offset")
    TAssert(!TMatches && TDisarms=1,"solo-only policy and entrance guard cleanup are retained")
    TReset("Confirm")
    TAssert(TRun()="RestartStage" && TStarts=1 && !TWalks && !TSolos && !TOpens,"already-open Start queue skips movement and Play Now")
    TAssert(TClicks.Length=1,"pre-existing queue receives only the matched Start click")
    TReset("Choice"),TChoiceHasCancel := false
    TAssert(TRun()="RestartStage" && TSolos=1 && TStarts=1 && !TWalks && !TOpens,"already-open choice goes straight to solo and then Start")
    TReset("Pad")
    TAssert(TRun()="RestartStage" && !TWalks,"queue menu never repeats the A movement")
    TReset(),TAfterWalk := "Waiting",TDelay := 3
    TAssert(TRun()="RestartStage" && TWalks=1,"delayed entry menu is awaited after one movement")
    TReset("Pad"),MatchMaking.Value := 0
    TAssert(TRun()="RestartStage" && TStarts=1 && !TMatches,"other modes' Matchmaking setting does not select Challenge matchmaking")
    TReset("Choice"),TStartDelay := 60
    TAssert(TRun()="RestartStage" && TStarts=1,"blank gap between solo and Start cannot hand off early")
    TAssert(TStartTimes[1]-TSoloAt>=60,"delayed Start must actually appear before it is clicked")
    TReset("Choice"),TNeverStart := true
    TAssert(TRun()="Stopped" && !TTarget && !TStarts,"all old cues absent still cannot confirm departure before Start")
    TReset("Confirm"),TStartWorks := false
    TAssert(TRun()="Stopped" && TStarts=3 && !TTarget,"unresponsive Start has bounded retries and no loading handoff")
    TAssert(TStartTimes[2]-TStartTimes[1]>=20 && TStartTimes[3]-TStartTimes[2]>=20,"Start retries respect their interval")
    TAssert(!TMatches && TClicks.Length=3,"unresponsive Start never clicks Cancel or retries Play Now")
    TReset("Confirm"),TStartInputOK := false
    TAssert(TRun()="Stopped" && !TStarts && !TTarget,"refused Start input cannot advance")
    TReset("Choice"),TSoloWorks := false
    TAssert(TRun()="Stopped" && TSolos=1 && !TStarts && !TTarget,"ignored solo selection cannot advance to Start/loading")
    TReset(),TAfterWalk := "Lobby"
    TAssert(TRun()="Stopped" && TWalks=1 && !TClicks.Length,"missing entry menu gets no guessed play clicks")
    TReset(),TReady := false
    TAssert(TRun()="Stopped" && !TWalks && !TClicks.Length && !TArms,"unprepared window receives no input")
    TReset(),TBlockedAfterWalk := true
    TAssert(TRun()="Stopped" && TWalks=1 && !TClicks.Length,"covered window after movement gets no play input")
    TReset(),TLocked := true
    TAssert(TRun()="Stopped" && !TWalks && !TClicks.Length,"unfinished boss chests keep priority")
    TReset("Confirm"),TLegacyOnly := true
    TAssert(TRun()="RestartStage" && TStarts=1,"older Start lettering reference is supported")
    TReset("Choice"),TVoteAfter := true,TAreaInVote := true
    TAssert(TRun()="RestartStage" && !TStarts,"positive vote UI supports an already-started/auto-started stage")
    TReset("Confirm"),TLoseStartOnRead := 2
    TAssert(ChallengeConfirmSoloDeparture(TFast) && !TClicks.Length && TState="Vote","a Start lost by the fresh recheck is never clicked stale")
    TReset("ActualChoice")
    TAssert(TRun()="RestartStage" && !TWalks && !TOpens && TSolos=1 && TStarts=1,"current Play Here popup resumes directly without movement/opener")
    TAssert(TClicks.Length=2 && TClicks[1].x=335 && TClicks[1].y=352,"current Play Here uses its detected center, not legacy client point")
    TReset(),TAfterWalk := "ActualChoice"
    TAssert(TRun()="RestartStage" && TWalks=1 && !TOpens && TStarts=1,"current Play Here popup appearing after movement is recognized")
    TReset("ActualChoice"),TSoloWorks := false
    TAssert(TRun()="Stopped" && TSolos=1 && !TStarts && !TMatches,"ignored current Play Here cannot hand off or choose Find Match")
    TReset("Pad"),TOpenActual := true
    TAssert(TRun()="RestartStage" && TOpens=1 && TSolos=1 && TStarts=1,"new Play Here popup opened from older pad layout is recognized before solo click")
    TAssert(TClicks[2].x=335 && TClicks[2].y=352 && !TMatches,"new popup after opener also uses detected solo center")
    FileAppend("PASS: " TChecks " Challenge menu/Start flow assertions (actual controller/client conversion; game/reference/input effects simulated).`n","*")
    TG.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    for message in TLogs
        FileAppend(message "`n","*")
    FileAppend("STATE: " TState " open=" TOpens " solo=" TSolos " start=" TStarts " target=" TTarget "`n","*")
    TG.Destroy()
    ExitApp(1)
}
DungeonChestExitBlocked() => TLocked
WF_PrepareDungeon() => TReady
FT_GetOffset(&dx,&dy) {
    WinGetPos(&x,&y,,,rblxID)
    dx := x+5,dy := y-1
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,TState,TDelay,TStartReads
    if (TState="WaitingStart" && !TNeverStart && A_TickCount>=TPendingStartAt)
        TState := "Confirm"
    WF_LastIssue := TBlocked ? "synthetic covering window" : "",X := x1,Y := y1
    if TBlocked
        return false
    if (text=ChallengeStartText || text=StartStoryButton) {
        if (text=ChallengeStartText && TLegacyOnly)
            return false
        if TState="Confirm" {
            TStartReads += 1
            if (TLoseStartOnRead && TStartReads=TLoseStartOnRead) {
                TState := "Vote"
                return false
            }
            X := 380,Y := 458
            return true
        }
        return false
    }
    if (text=ChallengePlayHereText) {
        X := 330,Y := 353
        return TState="ActualChoice"
    }
    if (text=ModeCancel && TState="Waiting") {
        TDelay -= 1
        if TDelay<=0
            TState := "Pad"
    }
    if (text=ModeCancel)
        return TState="Pad" || (TConfirmOldCues && TState="Confirm") || (TChoiceHasCancel && TState="Choice")
    if (text=MatchMakingText)
        return TState="Choice"
    if (text=VoteStart)
        return TState="Vote"
    if (text=AreaText)
        return TState="Lobby" || TState="Pad" || TState="Choice" || TState="StuckLobby" || (TAreaInVote && TState="Vote")
    throw Error("Unexpected Challenge reference")
}
ChallengeMovement() {
    global TWalks,TState,TBlocked
    TWalks += 1,TState := TAfterWalk,TBlocked := TBlockedAfterWalk
}
WF_RobloxClick(x,y) {
    global TState,TMatches,TStarts,TSolos,TOpens,TSoloAt,TPendingStartAt
    x += 5,y -= 1
    if (x=385 && y=457) {
        if !TStartInputOK
            return false
        TClicks.Push({x:x,y:y}),TStarts += 1,TStartTimes.Push(A_TickCount)
        if TStartWorks
            TState := "Loading"
        return true
    }
    TClicks.Push({x:x,y:y})
    if (x=400 && y=435) {
        TOpens += 1
        if TState="Pad"
            TState := TOpenActual ? "ActualChoice" : "Choice"
        return true
    }
    if ((x=330 && y=325) || (x=335 && y=352)) {
        TSolos += 1,TSoloAt := A_TickCount
        if ((TState="Choice" || TState="ActualChoice") && TSoloWorks) {
            TState := TVoteAfter ? "Vote" : TClosedButLobby ? "StuckLobby" : TStartDelay || TNeverStart ? "WaitingStart" : "Confirm"
            TPendingStartAt := A_TickCount+TStartDelay
        }
        return true
    }
    TMatches += 1
    throw Error("unexpected, Cancel, or matchmaking click " x "," y)
}
PlayHere(*) {
    throw Error("legacy delayed solo/Start routine must not be used by Challenge")
}
ClickStartStory(*) {
    throw Error("legacy -35 Start helper must not be used by Challenge")
}
FindMatch(*) {
    throw Error("Matchmake must not be used by Challenge")
}
Reconnect() => 0
AddToLog(message) => TLogs.Push(message)
NextStep(step) {
    global TTarget
    TTarget := step.Name
    throw THandoff(step.Name)
}
RestartStage() => 0
