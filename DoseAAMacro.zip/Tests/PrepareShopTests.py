"""Extract production shop functions with only capture/cursor mocked in tests."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
source=(root/'Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk').read_text()
names=re.findall(r'^(HandleShop|DungeonShop\w*|CheckDungeonSpecials)\([^\n]*\)\s*\{',source,re.M)
parts=['; Generated production shop functions; offline tests only.\n']
for name in names:
    if name in ['DungeonShopCapture','DungeonShopMoveOffButtons']:
        continue
    match=re.search(r'^'+name+r'\([^\n]*\)\s*\{.*?^\}',source,re.M|re.S)
    assert match,name
    parts.append(match[0]+'\n\n')
(root/'Tests/ShopFunctionsForTests.ahk').write_text(''.join(parts))
print('Prepared actual shop flow/classifier/caller; screen capture and cursor reset isolated.')
