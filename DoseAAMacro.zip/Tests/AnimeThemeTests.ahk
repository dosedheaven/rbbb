#Requires AutoHotkey v2.0
; Current single-theme regression suite; replaces retired two-theme assertions.
#Include %A_ScriptDir%\AkatsukiThemeTests.ahk
