#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\Lib\Engine\Pause.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\ChestFunctionsForTests.ahk
; Actual engine/wrappers/client conversion; simulated screens/input, no private IO.
global CGame := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " CGame.Hwnd
global CChecks := 0,WF_LastIssue := "",DenyShrines := {Value:1}
global CFast := {pollMs:1,afterOpenMs:0,departMs:60,claimMs:1000,claimClickMs:1,
    rewardSettleMs:20,totalMs:6000,maxRecoveries:0,maxOpenClicks:6,continueMs:200}
global CNormal := 0,CRare := 0,CPhase := "Menu",CEvents := [],CLogs := []
global CContinues := 0,CClaims := 0,COpens := 0,CClaimAttempts := 0,CFailClaimAt := 0,CClaimTimes := []
global CRewards := 0,CDrops := [],CDefaultDrops := 2,CClaimWorks := true,COpenMisses := 0
 global CHeaderBehind := true,CEmptyBehind := true,CBackgroundLobby := true,CBackgroundEnter := true
 global CUnknownCommon := false,CUnknownRare := false,CReady := true,CBlocked := false,CInputOK := true
 global CContinuePresent := true,CContinueWorks := true,CResumeOnRecovery := false,CRealStart := 0
 global CTransientZero := 0
global CEmptyReadsPending := 0,CLegacyFinish := 0,CLegacyTop := 0,CNextRewardAt := 0,CGap := 0
 global BossRoomCompleted := true,SaveChestsForBoss := true
CGame.Show("x100 y100 w816 h638")
CAssert(ok,label) {
    global CChecks
    CChecks += 1
    if !ok
        throw Error(label)
}
CReset(common := 0,rare := 0) {
    global
    CNormal := common,CRare := rare,CPhase := "Menu",CEvents := [],CLogs := []
    CContinues := 0,CClaims := 0,COpens := 0,CClaimAttempts := 0,CFailClaimAt := 0,CClaimTimes := []
    CRewards := 0,CDrops := [],CDefaultDrops := 2,CClaimWorks := true,COpenMisses := 0
    CHeaderBehind := true,CEmptyBehind := true,CBackgroundLobby := true,CBackgroundEnter := true
    CUnknownCommon := false,CUnknownRare := false,CReady := true,CBlocked := false,CInputOK := true
    CContinuePresent := true,CContinueWorks := true,CResumeOnRecovery := false,CRealStart := 0
    CTransientZero := 0
    CEmptyReadsPending := 0,CLegacyFinish := 0,CLegacyTop := 0,CNextRewardAt := 0,CGap := 0
    BossRoomCompleted := true,SaveChestsForBoss := true,WF_LastIssue := ""
    DoseChestState := 0,DungeonChestExitLocked := false
    DungeonClearBossExitRecovery()
}
CCount(name) {
    n := 0
    for event in CEvents
        if event=name
            n += 1
    return n
}
CHasLog(word) {
    for message in CLogs
        if InStr(message,word)
            return true
    return false
}
try {
    ; Main regression: menu heading/zero counters and Lobby/Enter labels can show
    ; behind rewards. The Continue control is covered until rewards are gone.
    CReset(2,2)
    CAssert(HandleChestScreen(CFast),"background headings/empty counters cannot skip mandatory pairs")
    CAssert(COpens=4 && CClaims=8 && CNormal=0 && CRare=0,"each chest gets two actual center clicks")
    CAssert(CContinues=1 && CPhase="Done" && !DungeonChestExitBlocked(),"only verified exit unlocks entry")
    CAssert(DungeonBossExitPending && !BossRoomCompleted,"boss entrance recovery arms only after verified chest exit")
    CAssert(!CLegacyTop && !CLegacyFinish && !CEmptyReadsPending,"no top/finish action or empty proof runs while dismissals are owed")
    for start in [1,4,7,10]
        CAssert(InStr(CEvents[start],"open ") && CEvents[start+1]="center" && CEvents[start+2]="center","Open is immediately followed by its required center pair")
    CNormal := 1,CPhase := "Menu",BossRoomCompleted := true
    CAssert(HandleChestScreen(CFast) && COpens=5 && CClaims=10 && CContinues=2 && DoseChestState.commonOpens=1,"a completed session cannot leak counters/pair state into a new chest room")
    CReset(1,0),CTransientZero := 2
    CAssert(HandleChestScreen(CFast) && COpens=1 && CClaims=2,"two transient zero readings cannot skip a remaining chest")
    CReset(2,2),CDrops := [1,2,1,2]
    CAssert(HandleChestScreen(CFast) && CClaims=8 && CContinues=1,"mixed one/two-item chests always receive the requested pair")
    CReset(1,1),CHeaderBehind := false
    CAssert(HandleChestScreen(CFast) && CClaims=4,"fully hidden menu rewards also work")
    CReset(1,0),CBackgroundLobby := false,CBackgroundEnter := false
    CAssert(HandleChestScreen(CFast) && CClaims=2,"normal reward layout also works")
    CReset(1,1),COpenMisses := 1
    CAssert(HandleChestScreen(CFast) && COpens=3 && CClaims=6,"missed Open still finishes its pair before retrying Open")
    CReset(1,0),COpenMisses := 100
    CAssert(!HandleChestScreen(CFast) && CNormal=1 && !CContinues,"ignored Opens stop at the configured bounded cap")
    CAssert(DungeonChestExitBlocked() && !DungeonBossExitPending,"unopened chests keep entry locked")
    CReset(0,2)
    CAssert(HandleChestScreen(CFast) && !CCount("open Common") && CCount("open Rare")=2,"empty Common does not skip Rare")
    CReset(2,0)
    CAssert(HandleChestScreen(CFast) && !CCount("open Rare") && CCount("open Common")=2,"empty Rare does not skip Common")
    CReset()
    CAssert(HandleChestScreen(CFast) && COpens=0 && CClaims=0 && CContinues=1,"initially empty rows still need joint proof but no extra inputs")
    CReset(1,0),CClaimWorks := false
    CAssert(!HandleChestScreen(CFast) && CRewards=2 && !CContinues,"background zero counts cannot exit while rewards cover Continue")
    CAssert(DungeonChestExitBlocked() && !CLegacyTop && !CLegacyFinish,"failed rewards cannot invoke old top/finish helpers")
    CAssert(CClaims<=40 && COpens=1,"stuck reward inputs remain bounded without reopening its chest")
    CReset(1,0),CFailClaimAt := 2
    CAssert(!HandleChestScreen(CFast) && CClaims=1 && DoseChestState.owedClicks=1,"refused second click remains explicitly owed")
    CAssert(!DungeonWaitForEntrance(20,1,1,1) && !DungeonOpenEntranceMenu(),"pending second reward blocks real entrance functions")
    CAssert(!DungeonArmBossExitRecovery() && !DungeonBossExitPending,"pending reward cannot arm post-boss recovery")
    CFailClaimAt := 0
    CAssert(HandleChestScreen(CFast) && CClaims=2 && COpens=1 && CContinues=1,"retry resumes exactly the remaining click before inspecting zero counts")
    CReset(1,0),CInputOK := false
    CAssert(!HandleChestScreen(CFast) && !COpens && !CContinues,"refused Open sends no follow-up input")
    CReset(1,0),CReady := false
    CAssert(!HandleChestScreen(CFast) && !CEvents.Length,"invalid game window sends no input")
    CReset(1,0),CBlocked := true
    CAssert(!HandleChestScreen(CFast) && !CEvents.Length,"covered/unreadable window sends no input")
    CReset(),CUnknownCommon := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"unrecognized Common zero blocks final exit")
    CReset(),CUnknownRare := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"unrecognized Rare zero blocks final exit")
    CReset(1,0),CContinuePresent := false
    CAssert(!HandleChestScreen(CFast) && !COpens && !CContinues,"heading alone never qualifies as an accessible chest menu")
    CReset(),CContinueWorks := false
    CAssert(!HandleChestScreen(CFast) && CContinues=1 && DungeonChestExitBlocked(),"ignored Continue gets one click only and no finish/entry fallback")
    CAssert(!DungeonWaitForEntrance(20,1,1,1) && !DungeonBossExitPending,"unclosed chest menu cannot enable entrance recovery")
    CReset(3,2),BossRoomCompleted := false
    CAssert(HandleChestScreen(CFast) && !COpens && !CClaims && CContinues=1,"intermediate save-for-boss keeps every chest")
    CReset(1,0),BossRoomCompleted := false,SaveChestsForBoss := false
    CAssert(HandleChestScreen(CFast) && CClaims=2 && CContinues=1 && !DungeonBossExitPending,"explicit non-saving option uses serial drain without arming boss recovery")
    CReset(1,0),CDefaultDrops := 3
    CAssert(HandleChestScreen(CFast) && CClaims=4 && !CRewards,"an extra reward triggers another bounded pair rather than entering a dungeon")
    CReset(1,0),CGap := 25
    gap := DungeonChestOptions(CFast),gap.rewardSettleMs := 70
    CAssert(HandleChestScreen(gap) && !CRewards && CContinues=1,"brief menu exposure between two drops cannot advance to another Open")
    CReset(1,1),CClaimWorks := false,CResumeOnRecovery := true
    recovery := DungeonChestOptions(CFast)
    recovery.claimMs := 120,recovery.recoveryIdleMs := 180,recovery.recoveryPollMs := 2,recovery.maxRecoveries := 2
    CAssert(HandleChestScreen(recovery) && CContinues=1 && CHasLog("resuming pending reward claim"),"inactivity rescan resumes pending center clicks without entering/closing other screens")
    CReset(1,0),CClaimWorks := false
    recovery := DungeonChestOptions(CFast)
    recovery.claimMs := 120,recovery.recoveryIdleMs := 180,recovery.recoveryPollMs := 2,recovery.maxRecoveries := 2
    CAssert(!HandleChestScreen(recovery) && !CContinues && DungeonChestExitBlocked() && CHasLog("attempts exhausted"),"permanent reward failure exhausts bounded rescans while entry stays locked")
    CReset(),CPhase := "Unknown"
    CAssert(!HandleChestScreen(recovery) && !CEvents.Length,"unknown screen with no owned Open receives no guessed clicks")
    CReset(1,0)
    CAssert(!HandleChestScreen({totalMs:1,maxRecoveries:0,afterOpenMs:0,pollMs:1}) && !CContinues,"total deadline cannot bypass the locked exit")
    CReset(),CPhase := "Reward",CRewards := 2
    nativeStart := A_TickCount
    CAssert(ClaimChestReward() && CClaims=2,"production sequence dismisses two rewards despite background heading/Lobby/Enter")
    CAssert(CClaimTimes[2]-CClaimTimes[1]>=2000,"production pair has the full two-second gap")
    CAssert(A_TickCount-CClaimTimes[2]>=3000,"full-menu confirmation waits three seconds after the pair")
    CAssert(!CLegacyTop && !CContinues,"reward routine sends no top/Continue input")
    FileAppend("SERIAL PAIR TIMING PASS: " (CClaimTimes[2]-CClaimTimes[1]) "ms gap; full-menu quiet=" (A_TickCount-CClaimTimes[2]) "ms.`n","*")
    FileAppend("PASS: " CChecks " serial chest assertions (actual engine/guards, simulated screens/input, native client conversion).`n","*")
    CGame.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    FileAppend("STATE: normal=" CNormal " rare=" CRare " rewards=" CRewards " phase=" CPhase " opens=" COpens " claims=" CClaims " continue=" CContinues "`n","*")
    for event in CEvents
        FileAppend("EVENT: " event "`n","*")
    for message in CLogs
        FileAppend("LOG: " message "`n","*")
    CGame.Destroy()
    ExitApp(1)
}
CTick() {
    global CNextRewardAt,CPhase
    if (CNextRewardAt && A_TickCount>=CNextRewardAt)
        CPhase := "Reward",CNextRewardAt := 0
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,CEmptyReadsPending,CTransientZero
    CTick()
    WF_LastIssue := CBlocked ? "simulated covering window" : "",X := x1,Y := y1
    if CBlocked
        return false
    if (text=ChestRoom || text=ChestRoomLuck)
        return CPhase="Menu" || (CHeaderBehind && CPhase="Reward")
    if (text=DungeonContinue) {
        if (e1!=0.03 || e0!=0.03)
            throw Error("Continue matching left its explicit bounded tolerance")
        X := 495,Y := 430
        return CContinuePresent && CPhase="Menu"
    }
    if (text=EmptyCommonChest || text=EmptyRareChest) {
        if (IsObject(DoseChestState) && DoseChestState.owedClicks) {
            CEmptyReadsPending += 1
            throw Error("empty counts inspected with reward clicks still owed")
        }
        if (e1!=0.000001 || e0!=0.000001)
            throw Error("zero matching became permissive")
        if (text=EmptyCommonChest && CTransientZero) {
            CTransientZero -= 1
            return true
        }
        common := text=EmptyCommonChest
        return (CPhase="Menu" || CEmptyBehind) && (common ? !CUnknownCommon && CNormal=0 : !CUnknownRare && CRare=0)
    }
    if (text=EnterDungeon)
        return CBackgroundEnter
    if (text=AreaText)
        return false
    throw Error("Unexpected chest reference")
}
WF_RobloxClick(x,y) {
    global CPhase,CNormal,CRare,CRewards,COpens,CClaims,CClaimAttempts,CNextRewardAt,COpenMisses,CLegacyTop
    CTick()
    if !CInputOK
        return false
    if (x=560 && (y=261 || y=321)) {
        if (CRewards || CNextRewardAt)
            throw Error("next Open escaped before rewards were dismissed")
        kind := y=261 ? "Common" : "Rare"
        CEvents.Push("open " kind),COpens += 1
        if COpenMisses {
            COpenMisses -= 1
            return true
        }
        if (kind="Common")
            CNormal -= 1
        else
            CRare -= 1
        CRewards := CDrops.Length ? CDrops.RemoveAt(1) : CDefaultDrops
        CPhase := "Reward"
        return true
    }
    WinGetClientPos(,,&w,&h,rblxID)
    if (x=w//2-5 && y=h//2+1) {
        CClaimAttempts += 1
        if (CFailClaimAt && CClaimAttempts=CFailClaimAt)
            return false
        CEvents.Push("center"),CClaims += 1,CClaimTimes.Push(A_TickCount)
        if (CClaimWorks && CPhase="Reward") {
            CRewards -= 1
            if !CRewards
                CPhase := "Menu"
            else if CGap
                CPhase := "Menu",CNextRewardAt := A_TickCount+CGap
        }
        return true
    }
    if (x=495 && y=430) {
        CDoContinue(false)
        return true
    }
    CLegacyTop += 1
    throw Error("Forbidden chest-session click at " x "," y)
}
CDoContinue(saving) {
    global CContinues,CPhase
    if (!saving && (CRewards || CNextRewardAt || CNormal || CRare || CPhase!="Menu"))
        throw Error("Continue escaped with unhandled chest rewards")
    CEvents.Push("continue"),CContinues += 1
    if CContinueWorks
        CPhase := "Done"
}
WF_PrepareDungeon() => CReady
FT_GetOffset(&dx,&dy) {
    WinGetPos(&x,&y,,,rblxID)
    dx := x+5,dy := y-1
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text,args*) {
    X := x1,Y := y1
    return (text=ChestRoom || text=ChestRoomLuck) && CPhase="Menu"
}
ClickDungeonContinue() => CDoContinue(true)
CheckForReturnToLobby() => CBackgroundLobby
CheckForFinishDungeonV2() {
    global CLegacyFinish
    CLegacyFinish += 1
    throw Error("Legacy finish escaped into chest owner")
}
AddToLog(message) {
    global CClaimWorks
    CLogs.Push(message)
    if (CResumeOnRecovery && InStr(message,"Chest inactivity recovery 1/")) {
        CClaimWorks := true
        if CRealStart
            FileAppend("REAL RESCAN at " (A_TickCount-CRealStart) "ms: " message "`n","*")
    }
}
NextStep(*) {
    throw Error("No dungeon/lobby handoff allowed inside chest owner")
}
HandleShop(*) {
    throw Error("Shop escaped chest test")
}
ShrinePriority(*) {
    throw Error("Shrine escaped chest test")
}
ClickUntilGone(*) {
    throw Error("Generic finish/entry click loop escaped chest test")
}
