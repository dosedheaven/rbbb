; Generated production functions; offline chest tests only.
CheckDungeonSpecials(chestOptions := 0) {
    if DungeonChestExitBlocked()
        return HandleChestScreen(chestOptions)

    AddToLog("Checking for dungeon shop, shrine, open chest")
    
    ; Give time for special elements to appear
    Sleep(2000)
    
    foundShop := false
    foundShrine := false
    foundChest := false

    ; Check the area for shop, shrine, or chest
    Loop 5 {
        ; Check for shop
        if (!foundShop && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shop)) {
            AddToLog("Found Shop")
            Sleep(1000)
            if !HandleShop()
                return false
            Sleep(1000)
            foundShop := true
        }
        Sleep(1000)
        ; Check for shrine
        if (!foundShrine && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shrine)) {
            if (DenyShrines.Value) {
                AddToLog("Found Shrine, Denying")
                ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
            } else {
                ShrinePriority()
            }
            Sleep(1000)
            foundShrine := true
        }
        Sleep(1000)
        ; Check for Chest Opening
        if (!foundChest && IsChestScreenVisible()) {
            AddToLog("Found Chest Opening")
            if !HandleChestScreen(chestOptions)
                return false
            foundChest := true
        }
        
        ; If all elements are found, exit early
        if (foundShop && foundShrine && foundChest)
            break

        Sleep(1000)  ; Wait and check again
    }
    
    if (!foundShop && !foundShrine && !foundChest)
        AddToLog("No shop, shrine, or chest opening found")
    return true
}

IsChestScreenVisible() {
    return FT(&X, &Y, 140, 200, 375, 250, 0, 0, ChestRoom) or FT(&X, &Y, 358, 238, 604, 261, 0, 0, ChestRoomLuck)
}



HandleChestScreen(options := 0) {
    global BossRoomCompleted,SaveChestsForBoss,DungeonChestExitLocked
    shouldOpen := BossRoomCompleted || !SaveChestsForBoss || DungeonChestExitBlocked()
    if !shouldOpen {
        AddToLog("Saving chests for boss room - clicking continue")
        ClickDungeonContinue()
        return true
    }
    DungeonChestExitLocked := true
    DungeonClearBossExitRecovery()
    AddToLog("Chest engine v3.7: serial Open -> center -> 2s -> center; entry LOCKED")
    try {
        if !WF_PrepareDungeon() || !DungeonOpenAllChestsWithRecovery(options)
            return false
        if !DungeonChestContinueVerified(options) {
            AddToLog("Chest exit not verified; no Enter Dungeon or finish handler allowed")
            return false
        }
    } catch as err {
        DungeonChestExitLocked := true
        AddToLog("Chest state stopped at line " err.Line "; entry remains locked")
        return false
    }
    if BossRoomCompleted {
        DungeonArmBossExitRecovery()
        BossRoomCompleted := false
    }
    return true
}

ClaimChestReward(options := 0) {
    return DungeonClaimChestReward(options)
}

