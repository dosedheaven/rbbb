#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\ChestFunctionsForTests.ahk
; Actual production drain/claim/wrapper/caller. Screen and input are simulated;
; client conversion uses a real native window. No private files or game startup.
global CGame := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " CGame.Hwnd
global CChecks := 0, WF_LastIssue := "", BossRoomCompleted := true, SaveChestsForBoss := true
global DenyShrines := {Value:1}, CNormal := 0, CRare := 0, CPhase := "Menu", CEvents := []
global CContinues := 0, CFinishChecks := 0, CReconnects := 0, COpenMisses := 0
global CInputOK := true, CReady := true, CClaimWorks := true, CBlocked := false, CLogs := []
global CUnknownCommon := false, CUnknownRare := false, CFalseEmpty := 0, CDelay := 0
global CPending := "", CClaimClicks := 0, CRefillCommon := false, CEmptyChecks := Map()
global CFinalChanged := false, CCommonReads := 0, CThrowRead := false, COverlay := false
global CRewardSequence := []
global CRewardsPerChest := 1,CRewardsLeft := 0,CRewardGapMs := 0,CNextRewardAt := 0,CStallSecond := false,CClaimTimes := []
global CCloseWorks := false, CResumeOnRecovery := false, CUnexpectedEntrance := false, CUnexpectedLobby := false
global CFast := {pollMs:1,afterOpenMs:0,departMs:120,claimMs:180,claimClickMs:1,
    totalMs:6000,stalledClicks:2,maxOpenClicks:20,emptySamples:3,maxRecoveries:0,rewardSettleMs:10}
CGame.Show("x100 y100 w816 h638")
CReset(normal := 0,rare := 0) {
    global CNormal,CRare,CPhase,CEvents,CContinues,CFinishChecks,CReconnects,COpenMisses
    global CInputOK,CReady,CClaimWorks,CBlocked,CLogs,CUnknownCommon,CUnknownRare,CFalseEmpty,CDelay
    global CPending,CClaimClicks,CRefillCommon,CEmptyChecks,CFinalChanged,CCommonReads,CThrowRead
    global CRewardSequence,CRewardsPerChest,CRewardsLeft,CRewardGapMs,CNextRewardAt,CStallSecond,CClaimTimes
    global BossRoomCompleted,SaveChestsForBoss,WF_LastIssue,COverlay,CCloseWorks,CResumeOnRecovery,CUnexpectedEntrance,CUnexpectedLobby
    CNormal := normal, CRare := rare, CPhase := "Menu", CEvents := [], CLogs := []
    CContinues := 0,CFinishChecks := 0,CReconnects := 0,COpenMisses := 0
    CInputOK := true,CReady := true,CClaimWorks := true,CBlocked := false
    CUnknownCommon := false,CUnknownRare := false,CFalseEmpty := 0,CDelay := 0
    CPending := "",CClaimClicks := 0,CRefillCommon := false,CEmptyChecks := Map()
    CFinalChanged := false,CCommonReads := 0,CThrowRead := false,COverlay := false,CCloseWorks := false
    BossRoomCompleted := true,SaveChestsForBoss := true,WF_LastIssue := ""
    CRewardSequence := []
    CRewardsPerChest := 1,CRewardsLeft := 0,CRewardGapMs := 0,CNextRewardAt := 0,CStallSecond := false,CClaimTimes := []
    CResumeOnRecovery := false,CUnexpectedEntrance := false,CUnexpectedLobby := false
    DungeonClearBossExitRecovery()
}
CAssert(ok,label) {
    global CChecks
    CChecks += 1
    if !ok
        throw Error(label)
}
CHasLog(text) {
    for l in CLogs
        if InStr(l,text)
            return true
    return false
}
CCount(kind) {
    n := 0
    for e in CEvents
        if (e=kind)
            n += 1
    return n
}
try {
    CReset(2,3)
    global CRealStart := 0
    CAssert(HandleChestScreen(CFast),"boss end drains both chest types successfully")
    CAssert(CNormal=0 && CRare=0 && CCount("open Common")=2 && CCount("open Rare")=3,"every simulated chest is opened, not just one per row")
    CAssert(CContinues=1 && !BossRoomCompleted && CReconnects=1,"successful drain unlocks Continue once and resets boss state afterward")
    CAssert(DungeonBossExitPending && DungeonBossExitRecoveries=0,"only a verified final boss drain arms entrance recovery")
    CAssert(CHasLog("All chests confirmed empty") && CEmptyChecks["Common"]>=6 && CEmptyChecks["Rare"]>=6,"each row and the joint final check require repeated positive empty evidence")
    CAssert(CEvents[1]="open Common" && CEvents[2]="claim" && CEvents[7]="open Rare","Common is drained before Rare and each reward is handled")

    CReset(1,1),COpenMisses := 1
    CAssert(HandleChestScreen(CFast),"one missed Open click is retried instead of called empty")
    CAssert(CCount("open Common")=2 && CHasLog("no confirmed transition"),"missed-click retry is observable and still drains the row")

    CReset(1,1),COpenMisses := 100
    CAssert(!HandleChestScreen(CFast),"persistently ignored Open clicks fail the chest pass")
    CAssert(CNormal=1 && CRare=1 && CContinues=0 && CFinishChecks=0 && !CReconnects,"failed opening cannot Continue, finish, or reconnect into another dungeon")
    CAssert(BossRoomCompleted && !CHasLog("All chests confirmed empty"),"failed opening retains boss state and never claims completion")

    CReset(0,2)
    CAssert(HandleChestScreen(CFast) && !CCount("open Common") && CCount("open Rare")=2,"empty Common does not prevent draining Rare")
    CReset(2,0)
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=2 && !CCount("open Rare"),"empty Rare does not prevent draining Common")
    CReset()
    CAssert(HandleChestScreen(CFast) && CEvents.Length=1 && CEvents[1]="continue","both initially empty needs evidence but no opening clicks")

    CReset(1,0),CClaimWorks := false
    CAssert(!HandleChestScreen(CFast) && CPhase="Reward","an unclaimed reward is not treated as a completed chest pass")
    CAssert(!CContinues && CRare=0 && CHasLog("claim timed out"),"reward timeout cannot unlock Continue even if stored chest counts are zero")
    CReset(1,0),CInputOK := false
    CAssert(!HandleChestScreen(CFast) && !CContinues && CNormal=1,"refused Open input leaves the chest and blocks Continue")
    CReset(1,0),CReady := false
    CAssert(!HandleChestScreen(CFast) && !CEvents.Length,"unprepared game window causes no opening or Continue input")
    CAssert(!DungeonBossExitPending,"failed chest preparation cannot arm lobby recovery")
    CReset(1,0),CBlocked := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"obscured chest screen cannot be interpreted as empty")

    CReset(),CUnknownCommon := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"missing Common empty reference blocks completion even when simulated count is zero")
    CReset(),CUnknownRare := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"missing Rare empty reference blocks completion")
    CReset(1,0),CFalseEmpty := 1
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=1,"one transient false-empty sample cannot skip a remaining Common chest")
    CReset(1,0),CDelay := 3
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=1,"delayed opening animation is awaited before retrying")

    CReset(0,1),CRefillCommon := true
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=1 && CCount("open Rare")=1,"joint final verification catches and drains a newly appearing Common chest")
    CReset(),CFinalChanged := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"empty evidence disappearing during joint verification cannot unlock Continue")
    CReset(1,0),CThrowRead := true
    CAssert(!HandleChestScreen(CFast) && !CContinues && !CReconnects,"unexpected matching error is contained without framework recovery skipping the chest pass")

    CReset(3,2),BossRoomCompleted := false
    CAssert(HandleChestScreen(CFast) && CContinues=1 && !CCount("open Common") && !CCount("open Rare"),"save-for-boss still preserves intermediate chests")
    CAssert(!DungeonBossExitPending,"saving intermediate chests never arms boss lobby recovery")
    CReset(1,0),BossRoomCompleted := false,SaveChestsForBoss := false
    CAssert(HandleChestScreen(CFast) && CNormal=0 && CContinues=1,"explicitly disabling chest saving retains the existing option behavior")

    CReset(1,0),COverlay := true
    CAssert(!HandleChestScreen(CFast) && !CContinues && CHasLog("overlay did not clear"),"lobby-like/token overlay is not falsely reported as successful claiming")
    CReset(1,0),COverlay := true,CCloseWorks := true
    CAssert(HandleChestScreen(CFast) && CContinues=1,"overlay dismissal must actually return the chest menu before continuing")

    CReset(),CPhase := "Reward",CClaimWorks := false
    CAssert(!ClaimChestReward({pollMs:1,claimMs:2500,claimClickMs:1}) && CClaimClicks=40,"reward clicking remains bounded and does not declare a missing menu returned")
    CReset(2,0)
    CAssert(!HandleChestScreen({rewardSettleMs:0,maxRecoveries:0,pollMs:1,afterOpenMs:0,departMs:120,claimMs:180,claimClickMs:1,totalMs:6000,maxOpenClicks:1}),"opening cap blocks remaining chests rather than Continue")
    CAssert(CNormal=1 && !CContinues,"opening cap never abandons the remaining chest automatically")

    CReset(1,0)
    CAssert(HandleChestScreen({rewardSettleMs:0,maxRecoveries:0,pollMs:1,afterOpenMs:0,departMs:120,claimMs:180,claimClickMs:1,totalMs:6000,maxOpenClicks:1}) && CContinues=1,"the final allowed Open click can still be followed by positive empty verification")
    CReset(1,0)
    CAssert(!HandleChestScreen({rewardSettleMs:0,maxRecoveries:0,totalMs:1,afterOpenMs:0,pollMs:1}) && !CContinues,"overall chest deadline never unlocks Continue without verification")
    CReset(0,1),COpenMisses := 100
    CAssert(!HandleChestScreen(CFast) && !CContinues && CRare=1,"Rare failure blocks Continue even after Common was confirmed empty")
    CAssert(!CCount("claim"),"a menu that never departed does not trigger blind reward claiming")
    CReset(1,0),CInputOK := false
    CAssert(!CheckDungeonSpecials(CFast) && !CContinues,"actual special-screen caller propagates a chest-opening failure")
    CReset(1,1),CReady := false
    DungeonArmBossExitRecovery()
    CAssert(!HandleChestScreen(CFast) && !DungeonBossExitPending,"a stale prior authorization is cleared before an unverified boss chest pass")
    recovery := {pollMs:1,afterOpenMs:0,departMs:30,claimMs:30,claimClickMs:1,totalMs:1500,
        stalledClicks:2,maxOpenClicks:20,emptySamples:3,rewardSettleMs:10,recoveryIdleMs:80,recoveryPollMs:2,maxRecoveries:2}
    CReset(1,1),COpenMisses := 2
    began := A_TickCount
    CAssert(HandleChestScreen(recovery),"stalled Open clicks recover after a positive menu rescan")
    CAssert(A_TickCount-began>=80 && CHasLog("Chest inactivity recovery 1/2"),"no-progress grace expires before a rescan sends another opening attempt")
    CAssert(!CNormal && !CRare && CContinues=1 && DungeonBossExitPending,"recovered pass still drains both rows and arms exit only after empty verification")
    CReset(1,1),CClaimWorks := false,CResumeOnRecovery := true
    CAssert(HandleChestScreen(recovery) && CHasLog("resuming pending reward claim"),"a stuck reward can become responsive on the inactivity rescan")
    CAssert(CContinues=1 && !CNormal && !CRare,"reward recovery returns to the menu and opens remaining chests before Continue")
    CReset(2,1),CPhase := "Unknown"
    CAssert(!HandleChestScreen(recovery) && !CEvents.Length,"unknown screen without pending reward receives no guessed input")
    CAssert(CHasLog("recovery 2/2") && CHasLog("attempts exhausted") && !CContinues,"unknown screen recovery is bounded and explicitly logs why it stopped")
    CReset(1,0),CClaimWorks := false,CUnexpectedEntrance := true
    CAssert(!HandleChestScreen(recovery) && CHasLog("unexpected entrance"),"entrance appearing before empty verification forbids recovery claiming or entry")
    CAssert(!CContinues && !DungeonBossExitPending,"unexpected entrance cannot bypass pending chests/rewards")
    CReset(1,0),CClaimWorks := false,CUnexpectedLobby := true
    CAssert(!HandleChestScreen(recovery) && !CHasLog("resuming pending reward claim"),"lobby marker forbids added recovery claim input")
    CReset(1,0),CClaimWorks := false
    CAssert(!HandleChestScreen(recovery) && !CContinues && CHasLog("recovery 2/2"),"permanently unresponsive reward exhausts bounded recovery without Continue")
    CReset(2,1),CPhase := "Reward"
    early := DungeonChestOptions(recovery)
    early.session := {phase:"Reward",lastProgress:A_TickCount,lastRecovery:0,recoveries:0}
    SetTimer(CRestoreMenu,-20)
    CAssert(DungeonChestResumeAfterStall(early,A_TickCount+1000) && !early.session.recoveries,
        "a delayed reward menu can return during observation without waiting for the inactivity alarm")
    CAssert(CNormal=2 && CRare=1 && !CContinues,"passive observation does not consume or skip stored chests")
    queue := {pollMs:1,afterOpenMs:0,departMs:120,claimMs:800,claimClickMs:1,totalMs:6000,
        stalledClicks:2,maxOpenClicks:20,emptySamples:3,maxRecoveries:0,rewardSettleMs:50}
    CReset(2,2),CRewardsPerChest := 2,CRewardGapMs := 30
    CAssert(HandleChestScreen(queue),"two separate drops per chest survive an interim visible-menu gap")
    CAssert(CClaimClicks>=8 && !CRewardsLeft && !CNormal && !CRare && CContinues=1,
        "both drops from every Common/Rare chest finish before another Open or Continue")
    CReset(1,1),CRewardsPerChest := 3,CRewardGapMs := 25
    CAssert(HandleChestScreen(queue) && CClaimClicks>=8,"queue handling supports additional pairs when more rewards appear")
    CReset(1,0),CRewardsPerChest := 2,CRewardGapMs := 25,CStallSecond := true
    CAssert(!HandleChestScreen(queue) && CRewardsLeft=1 && !CContinues,"an undismissable second reward blocks Continue even after stored chest count reaches zero")
    CAssert(BossRoomCompleted && !DungeonBossExitPending,"unfinished second reward cannot arm post-boss exit")
    CReset(1,0),CRewardsPerChest := 50
    CAssert(!HandleChestScreen(queue) && CClaimClicks=40 && !CContinues,"long/stuck reward queues retain the existing click bound")
    CReset(1,0),CRewardsPerChest := 2,CRewardGapMs := 80
    late := DungeonChestOptions(queue)
    late.recoveryIdleMs := 40,late.recoveryPollMs := 2,late.maxRecoveries := 2,late.claimMs := 800
    CAssert(HandleChestScreen(late) && CClaimClicks>=2 && CContinues=1,
        "a second reward arriving after the initial quiet period retains recoverable chest context")
    CAssert(CHasLog("resuming pending reward claim"),"late reward uses the existing guarded recovery claim path")
    CReset(2,2),CRewardSequence := [1,2,1,2]
    CAssert(HandleChestScreen(CFast) && CClaimClicks=8 && CContinues=1,"mixed one/two-drop chests each get exactly two center clicks when rewards appear immediately")
    CAssert(CEvents[1]="open Common" && CEvents[4]="open Common" && CEvents[7]="open Rare" && CEvents[10]="open Rare","no next chest Open appears inside the preceding two-click pair")
    CReset(),CPhase := "Reward",CRewardsLeft := 2,CRewardGapMs := 750
    nativeStart := A_TickCount
    CAssert(ClaimChestReward() && CClaimClicks=2,"production claim timing dismisses two sequential reward screens")
    nativeQuiet := A_TickCount-CClaimTimes[CClaimTimes.Length]
    CAssert(nativeQuiet>=3000,"production return proof waits three quiet seconds after the final reward claim")
    CAssert(!CContinues && !CCount("open Common") && !CCount("open Rare"),"claiming alone never opens another chest or leaves the chest stage")
    CAssert(CClaimTimes.Length=2 && CClaimTimes[2]-CClaimTimes[1]>=2000,"production reward clicks are separated by at least two seconds")
    FileAppend("PAIR TIMING PASS: two-drop click gap=" (CClaimTimes[2]-CClaimTimes[1]) "ms; final menu quiet=" nativeQuiet "ms.`n","*")
    CReset(),CPhase := "Reward",CRewardsLeft := 1
    CAssert(ClaimChestReward() && CClaimClicks=2 && CPhase="Menu","single-drop chest still gets the requested harmless second center click")
    CAssert(CClaimTimes[2]-CClaimTimes[1]>=2000,"single-drop pair retains the two-second interval")
    FileAppend("DOUBLE/SINGLE-DROP TIMING PASS: " (A_TickCount-nativeStart) " ms; 2 claims; final quiet=" nativeQuiet " ms.`n","*")
    CReset(1,1),COpenMisses := 4
    CRealStart := A_TickCount
    CAssert(HandleChestScreen(),"production defaults recover from four ignored Open attempts")
    CAssert(A_TickCount-CRealStart>=120000,"production rescan respects the two-minute no-progress interval")
    CAssert(!CNormal && !CRare && CContinues=1 && DungeonBossExitPending,"real-timing recovery drains both chest types before Continue")
    CAssert(CHasLog("Chest inactivity recovery 1/2"),"real-timing case exercises the configured inactivity recovery")
    FileAppend("REAL-TIMING PASS: " (A_TickCount-CRealStart) " ms; Common/Rare empty; Continue once; boss recovery armed.`n","*")
    FileAppend("PASS: " CChecks " chest-drain assertions (production flow, mocked screen/input, native client conversion).`n","*")
    CGame.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    CGame.Destroy()
    ExitApp(1)
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,CDelay,CPending,CPhase,CFalseEmpty,CCommonReads,CNextRewardAt
    WF_LastIssue := CBlocked ? "simulated covering window" : "",X := x1,Y := y1
    if CBlocked
        return false
    if (text=ChestRoom || text=ChestRoomLuck) {
        if (CNextRewardAt && A_TickCount>=CNextRewardAt)
            CPhase := "Reward",CNextRewardAt := 0
        if (CPending!="" && CDelay>0) {
            CDelay -= 1
            if (CDelay=0)
                CPhase := "Reward",CPending := ""
        }
        return CPhase="Menu"
    }
    if (text=EmptyCommonChest || text=EmptyRareChest) {
        if CThrowRead
            throw Error("simulated matching API failure")
        if (e1!=0.000001 || e0!=0.000001)
            throw Error("empty reference tolerance can accept a different count")
        kind := text=EmptyCommonChest ? "Common" : "Rare"
        CEmptyChecks[kind] := CEmptyChecks.Has(kind) ? CEmptyChecks[kind]+1 : 1
        if (kind="Common") {
            CCommonReads += 1
            if (CFinalChanged && CCommonReads>=4)
                return false
            if CFalseEmpty {
                CFalseEmpty -= 1
                return true
            }
            return CPhase="Menu" && !CUnknownCommon && CNormal=0
        }
        return CPhase="Menu" && !CUnknownRare && CRare=0
    }
    if (text=EnterDungeon)
        return CUnexpectedEntrance
    if (text=AreaText)
        return CUnexpectedLobby
    throw Error("Unexpected chest screen reference")
}
WF_RobloxClick(x,y) {
    global CNormal,CRare,CPhase,COpenMisses,CClaimClicks,CRefillCommon,CPending,CRewardsLeft,CNextRewardAt,CClaimWorks,CRewardSequence
    if !CInputOK
        return false
    if (x=560 && (y=261 || y=321)) {
        kind := y=261 ? "Common" : "Rare"
        if (CRewardsLeft || CNextRewardAt)
            throw Error("another Open was attempted before the preceding reward queue finished")
        CEvents.Push("open " kind)
        count := kind="Common" ? CNormal : CRare
        if (COpenMisses>0) {
            COpenMisses -= 1
            return true
        }
        if count {
            CRewardsLeft := CRewardSequence.Length ? CRewardSequence.RemoveAt(1) : CRewardsPerChest
            if (kind="Common")
                CNormal -= 1
            else {
                CRare -= 1
                if CRefillCommon
                    CNormal += 1,CRefillCommon := false
            }
            if CDelay
                CPending := kind
            else
                CPhase := "Reward"
        }
        return true
    }
    WinGetClientPos(,,&clientW,&clientH,rblxID)
    if (x=clientW//2-5 && y=clientH//2+1) {
        CEvents.Push("claim"),CClaimClicks += 1
        CClaimTimes.Push(A_TickCount)
        if (CClaimWorks && CPhase="Reward") {
            if CRewardsLeft
                CRewardsLeft -= 1
            if CRewardsLeft {
                if CRewardGapMs
                    CPhase := "Menu",CNextRewardAt := A_TickCount+CRewardGapMs
                else
                    CPhase := "Reward"
                if CStallSecond
                    CClaimWorks := false
            } else
                CPhase := "Menu"
        }
        return true
    }
    if (x=485 && y=121) {
        CEvents.Push("overlay close")
        if CCloseWorks
            CPhase := "Menu",CRewardsLeft := 0,CNextRewardAt := 0
        return true
    }
    throw Error("Unexpected chest click at " x "," y)
}
WF_PrepareDungeon() => CReady
FT_GetOffset(&dx,&dy) {
    WinGetPos(&x,&y,,,rblxID)
    dx := x+5,dy := y-1
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text,args*) {
    X := x1,Y := y1
    return (text=ChestRoom || text=ChestRoomLuck) && CPhase="Menu"
}
ClickDungeonContinue() {
    global CContinues
    if (CRewardsLeft || CNextRewardAt)
        throw Error("Continue escaped while an extra reward was still pending")
    if (BossRoomCompleted && (CNormal || CRare || CPhase!="Menu"))
        throw Error("Continue escaped with unhandled chests/reward")
    CContinues += 1,CEvents.Push("continue")
}
CheckForReturnToLobby() => COverlay
CheckForFinishDungeonV2() {
    global CFinishChecks
    CFinishChecks += 1
    return false
}
Reconnect() {
    global CReconnects
    CReconnects += 1
}
AddToLog(message) {
    global CClaimWorks
    CLogs.Push(message)
    if (CRealStart && InStr(message,"Chest inactivity recovery"))
        FileAppend("REAL RESCAN at " (A_TickCount-CRealStart) " ms: " message "`n","*")
    if (CResumeOnRecovery && InStr(message,"Chest inactivity recovery 1/"))
        CClaimWorks := true
}
CRestoreMenu() {
    global CPhase
    CPhase := "Menu"
}
NextStep(*) {
    throw Error("No game handoff is allowed in chest tests")
}
StartSelectedMode(*) {
}
HandleShop(*) {
    throw Error("Shop handling is outside chest tests")
}
ShrinePriority(*) {
    throw Error("Shrine handling is outside chest tests")
}
ClickUntilGone(*) {
    throw Error("Unexpected generic click in chest tests")
}
