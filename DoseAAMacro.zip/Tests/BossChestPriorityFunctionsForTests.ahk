; Production end-screen monitor; offline tests only.
MonitorDungeonEnd() {
    if DungeonChestExitBlocked() {
        if !HandleChestScreen()
            return false
        return LookForDungeonRooms()
    }
    global mode, Wins, loss, challengeStartTime, inChallengeMode, BossRoomCompleted

    failed := false
    
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(3000)  
        StageGuard.Check("EndScreen", "dungeon end screen not handled")   ; [Framework]
        FixClick(560, 560)  ; Move click

        ; Check for unit exit UI element
        if (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }
        
        if (ok := FT(&X, &Y, 150, 180, 350, 260, 0, 0, DefeatText) or (ok:=FT(&X, &Y, 319, 176, 492, 279, 0, 0, DefeatText2))) {
            failed := true
        }

        ; Check for next text UI element
        if (ok := FT(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
        }

        ; Check for returning to lobby
        if (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            if (!BossRoomCompleted && !inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                AddToLog("Challenge completed - returning to " mode " mode")
               inChallengeMode := false
               challengeStartTime := A_TickCount
               ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
               return NextStep(CheckLobby)
           }

           ; Check if it's time for challenge mode
           if (!BossRoomCompleted && !inChallengeMode && ChallengeBox.Value) {
               timeElapsed := A_TickCount - challengeStartTime
               if (timeElapsed >= 1800000) {
                   AddToLog("30 minutes passed - switching to Challenge mode")
                   inChallengeMode := true
                   challengeStartTime := A_TickCount
                   ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                   return NextStep(CheckLobby)
               }
           }

            if (StopAfterDefeat.Value && failed) {
                AddToLog("Dungeon run failed, stopping to save lives...")
                ClickReturnToLobby()
                SendFinalWebhookBeforeExit()
                CheckForLobby()
                Sleep(2000)
                return Reload()
            } else  {
                AddToLog("Dungeon run completed, clicking replay")
            
                ; Click replay button
                ClickReplay()
                ClickUntilGone(0, 0, 0, 0, 1000, 1000, OpenDungeon, 0, -35)
                
                ; After clicking replay, check for shop/shrine/chest
                if !CheckDungeonSpecials()
                    return false

                Sleep(2500)
    
                if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    return NextStep(StartSelectedMode)
                }
                
                ; Start a new dungeon run
                AddToLog("Starting next dungeon")
                return LookForDungeonRooms()
            }
            Reconnect()
        }
    }
}
