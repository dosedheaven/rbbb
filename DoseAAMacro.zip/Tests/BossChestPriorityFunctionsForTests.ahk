; Actual end-navigation owner.
MonitorDungeonEnd() {
    if DungeonChestExitBlocked() {
        if !HandleChestScreen()
            return false
        return LookForDungeonRooms()
    }
    global mode, Wins, loss, challengeStartTime, inChallengeMode, BossRoomCompleted

    failed := IsObject(DoseSession.results) && DoseSession.results.outcome="loss"
    
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(3000)  
        StageGuard.Check("EndScreen", "dungeon end screen not handled")   ; [Framework]
        evidence:=DoseResultsEvidence()
        if evidence.kind="Chest"
            return NextStep(DoseResumeChestSession)
        if evidence.kind="Shop" || evidence.kind="Shrine"
            return NextStep(DoseResumeDungeonMenu)
        known:=DoseDungeonScreenStep()
        if IsObject(known)
            return NextStep(known)
        if !evidence.navigation && (evidence.next || evidence.xp || evidence.unit)
            return NextStep(DoseProcessStageResults)
        if evidence.navigation {
            if (!BossRoomCompleted && !inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                AddToLog("Challenge completed - returning to " mode " mode")
               inChallengeMode := false
               challengeStartTime := A_TickCount
               ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
               return NextStep(CheckLobby)
           }

           ; Check if it's time for challenge mode
           if (!BossRoomCompleted && !inChallengeMode && ChallengeBox.Value) {
               if (DoseAutoChallengeDue()) {
                   AddToLog("30 minutes passed - switching to Challenge mode")
                   inChallengeMode := true
                   challengeStartTime := A_TickCount
                   ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                   return NextStep(CheckLobby)
               }
           }

            if (StopAfterDefeat.Value && failed) {
                AddToLog("Dungeon run failed, stopping to save lives...")
                ClickReturnToLobby()
                SendFinalWebhookBeforeExit()
                CheckForLobby()
                Sleep(2000)
                return Reload()
            } else  {
                AddToLog("Dungeon run completed, clicking replay")
            
                ; Click replay button
                ClickReplay()
                ClickUntilGone(0, 0, 0, 0, 1000, 1000, OpenDungeon, 0, -35)
                
                ; After clicking replay, check for shop/shrine/chest
                if !CheckDungeonSpecials()
                    return false

                Sleep(2500)
    
                if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    return NextStep(StartSelectedMode)
                }
                
                ; Start a new dungeon run
                AddToLog("Starting next dungeon")
                return LookForDungeonRooms()
            }
            Reconnect()
        }
    }
}
