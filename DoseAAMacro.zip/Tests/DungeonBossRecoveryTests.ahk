#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Framework\MacroLoop.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\BossRecoveryFunctionsForTests.ahk
; Actual recovery/entrance/finish functions and real MacroNextStep handoff.
; All image matching, game state and input simulated; no Main/GUI/private files.
class MacroStop extends Error {
}
global RChecks := 0, RPhase := "Enter", REvents := [], RLogs := [], WF_LastIssue := ""
global RReady := true, RBlocked := false, RClickOK := true, RCloseFound := true, RCloseWorks := true
global RReturnFound := true, RReturnWorks := true, RUnknownConfirm := false, RPattern := 1
global RRouteAfter := 0, REntered := 0, RLoadPolls := 0, RLoadRequired := 2, RHandOff := 0
global RDisappearX := false, RXReads := 0, RLegacy := 0, RSceneReads := 0, RRouteFrames := 0
global RFast := {pollMs:1,retryMs:1,closeMs:150,lobbyMs:250,maxCloseClicks:3,maxLobbyClicks:3}
global dungeonDeathBroken := false
MacroLoopState.Active := true
RReset(armed := true) {
    global RPhase,REvents,RLogs,WF_LastIssue,RReady,RBlocked,RClickOK,RCloseFound,RCloseWorks
    global RReturnFound,RReturnWorks,RUnknownConfirm,RPattern,RRouteAfter,REntered,RLoadPolls
    global RLoadRequired,RHandOff,RDisappearX,RXReads,RLegacy,RSceneReads,RRouteFrames
    RPhase := "Enter", REvents := [],RLogs := [],WF_LastIssue := ""
    RReady := true,RBlocked := false,RClickOK := true,RCloseFound := true,RCloseWorks := true
    RReturnFound := true,RReturnWorks := true,RUnknownConfirm := false,RPattern := 1
    RRouteAfter := 0,REntered := 0,RLoadPolls := 0,RLoadRequired := 2,RHandOff := 0
    RDisappearX := false,RXReads := 0,RLegacy := 0,RSceneReads := 0,RRouteFrames := 0
    DungeonClearBossExitRecovery()
    if armed
        DungeonArmBossExitRecovery()
}
RAssert(ok,label) {
    global RChecks
    RChecks += 1
    if !ok
        throw Error(label)
}
RCount(kind) {
    n := 0
    for event in REvents
        if (event.kind=kind)
            n += 1
    return n
}
RHasLog(fragment) {
    for line in RLogs
        if InStr(line,fragment)
            return true
    return false
}
RRunHandoff(action) {
    global RHandOff
    try action.Call()
    catch MacroNextStep as handoff {
        RAssert(handoff.Step.Name="CheckLobby","actual macro handoff targets normal lobby detector")
        RAssert(RPhase="Lobby" && !DungeonBossExitPending,"handoff requires positively verified lobby and cleared recovery state")
        RHandOff += 1
        return true
    }
    return false
}
try {
    RReset(false)
    RAssert(!DungeonRecoverBossEntrance(RFast) && !REvents.Length,"no chest-clear authorization means no recovery input")
    RReset(),RReady := false
    RAssert(!DungeonRecoverBossEntrance(RFast) && !REvents.Length,"missing game preparation prevents recovery")
    RReset(),RBlocked := true
    RAssert(!DungeonRecoverBossEntrance(RFast) && !REvents.Length,"obscured entrance cannot trigger close/lobby clicks")
    RReset(),RPhase := "Unknown"
    RAssert(!DungeonRecoverBossEntrance(RFast) && !REvents.Length,"changed/unrecognized entrance receives no recovery input")
    RReset(),RClickOK := false
    RAssert(!DungeonRecoverBossEntrance(RFast) && !RCount("return"),"refused X input cannot advance to lobby return")
    RReset(),RCloseFound := false
    RAssert(!DungeonRecoverBossEntrance(RFast) && !REvents.Length,"missing X never causes a guessed close or lobby click")
    RReset(),RCloseWorks := false
    RAssert(!DungeonRecoverBossEntrance(RFast),"unresponsive X times out without treating a click as closure")
    RAssert(RCount("close")=3 && !RCount("return") && !RHandOff,"X attempts are capped and no underlying result button is clicked")
    RAssert(!DungeonRecoverBossEntrance(RFast) && RCount("close")=3,"failed recovery cannot loop into another attempt for the same boss")
    RAssert(!DungeonWaitForEntrance(60,1,1,6,1) && !RCount("enter"),"failed recovery receives no additional entrance click budget")
    RReset(),RDisappearX := true
    RAssert(!DungeonRecoverBossEntrance(RFast) && !REvents.Length,"X lost by the immediate recheck is not clicked stale")
    RReset(),RReturnFound := false
    RAssert(!DungeonRecoverBossEntrance(RFast) && RCount("close")=1 && !RCount("return") && !RHandOff,
        "missing Return to Lobby stops after verified menu closure")
    RReset(),RReturnWorks := false
    RAssert(!DungeonRecoverBossEntrance(RFast) && RCount("return")=3 && !RHandOff,
        "return clicks are capped and do not imply lobby arrival")
    RReset(),RUnknownConfirm := true
    RAssert(!DungeonRecoverBossEntrance(RFast) && RCount("return")=1 && !RHandOff,
        "unknown confirmation dialog is not blindly accepted or treated as the lobby")
    RReset()
    RAssert(RRunHandoff(DungeonRecoverBossEntrance.Bind(RFast)),"known X/return flow hands off only after lobby verification")
    RAssert(RCount("close")=1 && RCount("return")=1 && RLoadPolls>=2,"full recovery closes once, returns once, and waits through loading")
    RAssert(REvents[1].kind="close" && REvents[2].kind="return","X closure precedes Return to Lobby")
    RAssert(REvents[1].x=667 && REvents[1].y=191,"X click uses fresh detected coordinates")
    RReset(),RPattern := 2
    RAssert(RRunHandoff(DungeonRecoverBossEntrance.Bind(RFast)),"second existing Return to Lobby reference is supported")

    ; Scaled no-progress interval exercises timing without waiting 30s per case.
    ; Production default remains 30000 ms and normal startup remains 6/45s.
    RReset(false)
    RAssert(!DungeonWaitForEntrance(160,1,1,6,10),"ordinary startup timeout does not arm boss lobby recovery")
    RAssert(RCount("enter")=6 && !RCount("close") && !RCount("return"),"normal startup keeps its existing six-click cap")
    RReset(),RRouteAfter := 2
    RAssert(DungeonWaitForEntrance(500,1,1,6,100),"successful post-boss entry continues without taking the lobby detour")
    RAssert(RCount("enter")=2 && !RCount("close") && !DungeonBossExitPending,"confirmed route clears recovery authorization")
    RReset()
    RAssert(RRunHandoff(DungeonWaitForEntrance.Bind(500,1,1,6,100)),"five unresponsive post-boss attempts trigger verified lobby recovery")
    RAssert(RCount("enter")=5 && RCount("close")=1 && RCount("return")=1,"post-boss startup caps input at five before recovery")
    firstEnter := 0,firstClose := 0
    for event in REvents {
        if (event.kind="enter" && !firstEnter)
            firstEnter := event.time
        if (event.kind="close" && !firstClose)
            firstClose := event.time
    }
    RAssert(firstClose-firstEnter>=100,"no-progress grace period elapses from first Enter before menu exit")
    RReset(),RRouteAfter := 5
    RAssert(DungeonWaitForEntrance(500,1,1,6,200) && !RCount("close"),"route arriving after the last allowed click cancels the fallback")
    RReset(),RBlocked := true
    RAssert(!DungeonWaitForEntrance(100,1,1,6,1) && !REvents.Length,"window failure is never interpreted as an unresponsive Enter screen")
    RReset(),RRouteAfter := 1
    RAssert(CheckForFinishDungeonV2() && !RLegacy && RHasLog("verifying entry"),
        "actual legacy finish caller routes armed Enter through confirmation before reporting completion")
    RAssert(!DungeonBossExitPending && !RCount("close"),"finish caller accepts actual successful entry without lobby recovery")
    RReset(),RPhase := "Closed"
    RAssert(!CheckForFinishDungeonV2() && RLegacy>0,"non-Enter finish handling retains legacy checks")
    RReset(),RBlocked := true
    RAssert(!CheckForFinishDungeonV2() && !RLegacy,"obscured armed finish cannot fall through into legacy blind actions")
    FileAppend("PASS: " RChecks " post-boss recovery assertions (production flow/handoff; screen/input simulated).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}

WF_PrepareDungeon() {
    global WF_LastIssue
    WF_LastIssue := RReady ? "" : "simulated preparation failure"
    return RReady
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,RXReads,RLoadPolls,RPhase,RSceneReads
    X := 400,Y := 420,WF_LastIssue := RBlocked ? "simulated covering window" : ""
    if RBlocked
        return false
    if (text=EnterDungeon) {
        RSceneReads += 1
        return RPhase="Enter"
    }
    if (text=DungeonDeath || text=DungeonDeathContinue)
        return false
    if (text=DungeonRedX) {
        RXReads += 1
        X := RXReads=1 ? 666 : 667,Y := RXReads=1 ? 190 : 191
        return RPhase="Enter" && RCloseFound && (!RDisappearX || RXReads=1)
    }
    if (text=AreaText) {
        if (RPhase="Loading") {
            RLoadPolls += 1
            if (RLoadPolls>=RLoadRequired)
                RPhase := "Lobby"
        }
        return RPhase="Lobby"
    }
    if (text=LobbyText || text=LobbyText2) {
        X := 350,Y := 152
        return RPhase="Closed" && RReturnFound && text=(RPattern=1 ? LobbyText : LobbyText2)
    }
    throw Error("unexpected recovery pattern")
}
WF_RobloxClick(x,y) {
    global RPhase,REntered
    if !RClickOK
        return false
    if (y=420) {
        REvents.Push({kind:"enter",x:x,y:y,time:A_TickCount})
        REntered += 1
        if (RRouteAfter && REntered>=RRouteAfter)
            RPhase := "Route"
    } else if (y=191) {
        REvents.Push({kind:"close",x:x,y:y,time:A_TickCount})
        if RCloseWorks
            RPhase := "Closed"
    } else if (y=152) {
        REvents.Push({kind:"return",x:x,y:y,time:A_TickCount})
        if RUnknownConfirm
            RPhase := "Unknown"
        else if RReturnWorks
            RPhase := "Loading"
    } else
        throw Error("unexpected recovery input")
    return true
}
DungeonScanRooms(&diagnostic) {
    diagnostic := "synthetic recovery route"
    return RPhase="Route" ? [{index:3,type:"Available"}] : []
}
DungeonValidLayout(rooms) => rooms.Length=1 && rooms[1].index=3
AddToLog(line) => RLogs.Push(line)
CheckLobby(*) {
    throw Error("lobby handoff must escape to the macro loop, not run recursively")
}
FT(*) {
    global RLegacy
    RLegacy += 1
    return false
}
FixClick(*) {
    throw Error("legacy input escaped post-boss entrance handling")
}
ClickDungeonDeathContinue(*) {
    throw Error("legacy death input escaped post-boss entrance handling")
}
