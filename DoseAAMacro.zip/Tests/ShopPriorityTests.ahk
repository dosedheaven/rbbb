#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\ShopFunctionsForTests.ahk
; Real production gold-component classifier, stable scans, Fishhook ordering,
; retry/skip/closing and caller. Independent simulated BGRA shop frames/input.
global SHideHeadsplitterAfterBuy := false,SHeadsplitterError := false
global SHideAxeAfterBuy := false
global SExcludedError := false
global SChecks := 0,SItems := [],SEvents := [],SLogs := [],SVisible := true,SReady := true
 global SCaptureOK := true,SInputOK := true,SContinueOK := true,SContinuePresent := true
 global SFailAt := 0,SInputCount := 0,SHookAfter := 1,SHookReads := 0,SDelay := 0,SPending := ""
 global SWrongCapture := false,SHoverOK := true,SJitter := false,SFrameCount := 0
 global WF_LastIssue := "",DenyShrines := {Value:1},SKeepLast := true,SBlockAfterClick := false
 global SFast := {loadMs:0,pollMs:1,settleMs:0,observeMs:100,scanTries:6,attempts:2,maxActions:12,totalMs:15000,closeMs:250}
SOffer(id,y,affordable := true,gold := true) => {id:id,y:y,affordable:affordable,gold:gold}
SReset(hookRow := 2) {
    global SItems,SEvents,SLogs,SVisible,SReady,SCaptureOK,SInputOK,SContinueOK,SContinuePresent
    global SFailAt,SInputCount,SHookAfter,SHookReads,SDelay,SPending,SWrongCapture,SHoverOK
    global SJitter,SFrameCount,WF_LastIssue,SKeepLast,SBlockAfterClick
    SItems := []
    for i,id in ["Scythe","Dagger","Extra"]
        SItems.Push(SOffer(i=hookRow ? "Fishhook" : id,225+(i-1)*55))
    SEvents := [],SLogs := [],SVisible := true,SReady := true,SCaptureOK := true,SInputOK := true
    SContinueOK := true,SContinuePresent := true,SFailAt := 0,SInputCount := 0
    SHookAfter := 1,SHookReads := 0,SDelay := 0,SPending := "",SWrongCapture := false,SHoverOK := true
    SJitter := false,SFrameCount := 0,WF_LastIssue := "",SKeepLast := true,SBlockAfterClick := false
}
SAssert(ok,label) {
    global SChecks
    SChecks += 1
    if !ok
        throw Error(label)
}
SHasLog(text) {
    for l in SLogs
        if InStr(l,text)
            return true
    return false
}
SCount(kind) {
    n := 0
    for e in SEvents
        if (e.kind=kind)
            n += 1
    return n
}
SRemove(id) {
    global SPending
    for i,item in SItems {
        if (item.id=id) {
            SItems.RemoveAt(i)
            break
        }
    }
    if (SItems.Length>1 || !SKeepLast)
        for i,item in SItems
            item.y := 225+(i-1)*55
    SPending := ""
}
try {
    for hookRow in [1,2,3] {
        SReset(hookRow)
        SAssert(HandleShop(SFast),"Fishhook row " hookRow " shop completes")
        SAssert(SEvents[1].id="Fishhook","Fishhook is first in every original row")
        SAssert(!SItems.Length && SCount("buy")=3 && SCount("continue")=1,"all three offers are bought and shop closes once")
    }
    SReset(2)
    SAssert(HandleShop(SFast),"provided middle-Fishhook sequence completes")
    SAssert(SEvents[1].y=280 && SEvents[2].y=280 && SEvents[3].y=225,"3 -> 2 -> 1 reflow clicks Fishhook, lower remaining button, then last upper button")
    SAssert(SHasLog("3 -> 2") && SHasLog("2 -> 1") && SHasLog("1 -> 0"),"each observed button-count reduction is logged")
    SReset(0)
    SAssert(HandleShop(SFast) && SEvents[1].y=335 && SEvents[2].y=280 && SEvents[3].y=225,"no Fishhook buys visible offers bottom to top")
    SReset(0),SItems := [SOffer("Scythe",225),SOffer("Dagger",280)]
    SAssert(HandleShop(SFast) && SEvents[1].y=280 && SEvents[2].y=225,"two-offer shop does not click an absent third row")
    SReset(0),SItems := [SOffer("Scythe",280)]
    SAssert(HandleShop(SFast) && SEvents[1].y=280 && SCount("buy")=1,"a lone remaining item can stay in the middle instead of moving to top")
    SReset(0),SItems := []
    SAssert(HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=1,"already empty shop sends no purchase clicks")
    SReset(2),SHookAfter := 3
    SAssert(HandleShop(SFast) && SEvents[1].id="Fishhook","late Fishhook still precedes generic offers")
    SReset(2),SDelay := 3
    SAssert(HandleShop(SFast) && SCount("buy")=3,"delayed item removal is awaited without duplicate purchases")

    SReset(0),SItems[3].affordable := false
    SAssert(HandleShop(SFast),"unaffordable bottom item does not stop the macro")
    SAssert(SItems.Length=1 && SItems[1].id="Extra" && SCount("continue")=1,"other affordable items are bought before continuing with one remaining offer")
    SAssert(SHasLog("possibly unaffordable") && !SHasLog("buttons 1 -> 0"),"remaining unaffordable offer is not falsely reported as bought")
    SReset(2),SItems[2].affordable := false
    SAssert(HandleShop(SFast) && SEvents[1].id="Fishhook","unaffordable Fishhook is attempted first")
    SAssert(SItems.Length=1 && SItems[1].id="Fishhook" && SCount("continue")=1,"failed Fishhook allows other offers then Continue, as authorized")
    SReset(2),SItems[2].affordable := false,SItems[2].gold := false
    SAssert(HandleShop(SFast) && SEvents[1].id="Fishhook" && SCount("continue")=1,"Fishhook retains its existing first click even without an active gold plate")
    SReset(0)
    for item in SItems
        item.affordable := false
    SAssert(HandleShop(SFast) && SCount("continue")=1 && SInputCount<=12,"all unaffordable offers have bounded attempts then Continue")

    SReset(2),SInputOK := false
    SAssert(!HandleShop(SFast) && !SCount("continue"),"refused Fishhook input prevents later purchases and closing")
    SReset(0),SFailAt := 2
    SAssert(!HandleShop(SFast) && SCount("buy")=1 && !SCount("continue"),"refused later input stops before any further item or Continue")
    SReset(0),SReady := false
    SAssert(!HandleShop(SFast) && SInputCount=0,"unprepared game receives no input")
    SReset(0),SCaptureOK := false
    SAssert(!HandleShop(SFast) && SInputCount=0,"unreadable capture is never treated as an empty shop")
    SReset(0),SBlockAfterClick := true
    SAssert(!HandleShop(SFast) && !SCount("continue"),"post-click window failure cannot close the unresolved shop")
    SReset(0),SHoverOK := false
    SAssert(!HandleShop(SFast) && SCount("buy")=1 && !SCount("continue"),"failed hover reset prevents unverified continuation")
    SReset(0),SVisible := false
    SAssert(!HandleShop(SFast) && !SInputCount,"missing shop header receives no purchases")
    SReset(0),SContinuePresent := false
    SAssert(!HandleShop(SFast) && !SCount("continue"),"missing Continue is not clicked blindly")
    SReset(0),SContinueOK := false
    SAssert(!HandleShop(SFast) && SVisible,"a still-visible shop is not reported closed")

    SReset(0),SJitter := true
    SAssert(!HandleShop(SFast) && !SInputCount,"an unsettled purchase layout receives no input")
    SReset(0),SItems := []
    frame := DungeonShopCapture()
    SAssert(!DungeonShopButtonsFromFrame(frame).Length,"small coins, thin yellow text and green decoration are rejected")
    SReset(0)
    frame := DungeonShopCapture(),buttons := DungeonShopButtonsFromFrame(frame)
    SAssert(buttons.Length=3 && buttons[1].x=560 && buttons[1].y=225,"gold plates with black price holes retain correct component centers")
    SReset(0),SItems.Push(SOffer("Fourth",320))
    for i,item in SItems
        item.y := 185+(i-1)*45
    SAssert(!HandleShop(SFast) && !SInputCount,"ambiguous extra purchase candidates cannot trigger clicks")

    SReset(2),SInputOK := false
    SAssert(!CheckDungeonSpecials() && !SCount("continue"),"actual special-screen caller propagates shop failure")
    ; Every ordering of the two hooks and the excluded Axe, with live row reflow.
    for order in [["Golden Fishhook","Fishhook","Axe"], ["Golden Fishhook","Axe","Fishhook"],
        ["Fishhook","Golden Fishhook","Axe"], ["Fishhook","Axe","Golden Fishhook"],
        ["Axe","Golden Fishhook","Fishhook"], ["Axe","Fishhook","Golden Fishhook"]] {
        SReset(0),SItems := []
        for i,id in order
            SItems.Push(SOffer(id,225+(i-1)*55))
        SAssert(HandleShop(SFast),"both hooks plus Axe complete in every row permutation")
        SAssert(SEvents[1].id="Golden Fishhook" && SEvents[2].id="Fishhook","Golden precedes regular Fishhook regardless of original positions")
        SAssert(SItems.Length=1 && SItems[1].id="Axe" && SCount("buy")=2 && SCount("continue")=1,"Axe never receives a purchase click after either hook moves the rows")
        SAssert(SHasLog("Axe is never-buy"),"excluded Axe is explicitly logged")
    }
    for axeRow in [1,2,3] {
        SReset(0),SItems[axeRow].id := "Axe"
        SAssert(HandleShop(SFast) && SCount("buy")=2 && SItems.Length=1 && SItems[1].id="Axe","generic no-hook shop skips Axe in each row after compaction")
    }
    SReset(0),SItems := [SOffer("Axe",280)]
    SAssert(HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=1,"Axe-only shop continues without any purchase click")
    SReset(0),SItems := [SOffer("Axe",225),SOffer("Axe",280),SOffer("Dagger",335)]
    SAssert(HandleShop(SFast) && SCount("buy")=1 && SItems.Length=2,"multiple Axe offers remain excluded independently")
    SReset(0),SItems := [SOffer("Golden Fishhook",225,false),SOffer("Fishhook",280),SOffer("Axe",335)]
    SAssert(HandleShop(SFast) && SItems.Length=2 && SCount("continue")=1,"unaffordable Golden Fishhook allows affordable Fishhook then Continue")
    for e in SEvents
        SAssert(e.id!="Axe","unaffordable hook fallback cannot buy Axe")
    SReset(0),SItems := [SOffer("Golden Fishhook",225),SOffer("Dagger",280),SOffer("Scythe",335)]
    SAssert(HandleShop(SFast) && SEvents[1].id="Golden Fishhook" && SCount("buy")=3,"Golden-only priority retains bottom-up purchases for other items")
    SReset(0),SItems := [SOffer("Golden Fishhook",225,false,false),SOffer("Fishhook",280),SOffer("Axe",335)]
    SAssert(HandleShop(SFast) && SEvents[1].id="Fishhook" && SCount("buy")=1,"Golden without an active plate is skipped without guessing coordinates")
    SReset(0),SExcludedError := true
    SAssert(!HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=0,"failed exclusion capture sends neither purchase nor Continue")
    SExcludedError := false
    SReset(2),SItems[2].gold := false,SExcludedError := true
    SAssert(!HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=0,"failed fallback exclusion capture cannot bypass the never-buy guard")
    SExcludedError := false
    for order in [["Axe","Golden Fishhook","Fishhook"], ["Golden Fishhook","Axe","Fishhook"], ["Golden Fishhook","Fishhook","Axe"]] {
        SReset(0),SItems := [],SHideAxeAfterBuy := true
        for i,id in order
            SItems.Push(SOffer(id,225+(i-1)*55))
        SAssert(HandleShop(SFast),"shop completes when Axe reference stops matching after the first purchase")
        SAssert(SCount("buy")=2 && SItems.Length=1 && SItems[1].id="Axe","remembered Axe follows row compaction without relying on a fresh match")
        SAssert(SEvents[1].id="Golden Fishhook" && SEvents[2].id="Fishhook","remembered exclusions retain hook priority")
        SHideAxeAfterBuy := false
    }
    for order in [["Headsplitter","Golden Fishhook","Fishhook"], ["Headsplitter","Fishhook","Golden Fishhook"],
        ["Golden Fishhook","Headsplitter","Fishhook"], ["Golden Fishhook","Fishhook","Headsplitter"],
        ["Fishhook","Headsplitter","Golden Fishhook"], ["Fishhook","Golden Fishhook","Headsplitter"]] {
        SReset(0),SItems := [],SHideHeadsplitterAfterBuy := true
        for i,id in order
            SItems.Push(SOffer(id,225+(i-1)*55))
        SAssert(HandleShop(SFast),"Headsplitter/hook shop completes in every original row order")
        SAssert(SCount("buy")=2 && SItems.Length=1 && SItems[1].id="Headsplitter","remembered Headsplitter is never clicked after its reference disappears during compaction")
        SAssert(SEvents[1].id="Golden Fishhook" && SEvents[2].id="Fishhook","Headsplitter exclusion retains Golden then regular Fishhook priority")
        SAssert(SHasLog("Headsplitter is never-buy"),"Headsplitter exclusion is named in the log")
        SHideHeadsplitterAfterBuy := false
    }
    for row in [1,2,3] {
        SReset(0),SItems[row].id := "Headsplitter",SHideHeadsplitterAfterBuy := true
        SAssert(HandleShop(SFast) && SCount("buy")=2 && SItems.Length=1 && SItems[1].id="Headsplitter","no-hook shop preserves remembered Headsplitter in every original position")
        SHideHeadsplitterAfterBuy := false
    }
    for order in [["Axe","Headsplitter","Fishhook"], ["Headsplitter","Golden Fishhook","Axe"], ["Dagger","Axe","Headsplitter"]] {
        SReset(0),SItems := [],SHideAxeAfterBuy := true,SHideHeadsplitterAfterBuy := true
        for i,id in order
            SItems.Push(SOffer(id,225+(i-1)*55))
        SAssert(HandleShop(SFast) && SCount("buy")=1 && SItems.Length=2,"Axe and Headsplitter remain excluded together after the allowed offer is removed")
        for e in SEvents
            SAssert(e.id!="Axe" && e.id!="Headsplitter","neither excluded item receives a purchase click")
        SHideAxeAfterBuy := false,SHideHeadsplitterAfterBuy := false
    }
    SReset(0),SItems := [SOffer("Headsplitter",280)]
    SAssert(HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=1,"Headsplitter-only shop continues without buying")
    SReset(0),SItems := [SOffer("Axe",225),SOffer("Headsplitter",280)]
    SAssert(HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=1,"fully excluded shop continues without buying either item")
    SReset(0),SHeadsplitterError := true
    SAssert(!HandleShop(SFast) && SCount("buy")=0 && SCount("continue")=0,"unreadable Headsplitter exclusion scan refuses input instead of falling through to Axe")
    SHeadsplitterError := false
    FileAppend("PASS: " SChecks " dynamic shop assertions (production classifier/flow/caller; simulated BGRA/input).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
DungeonShopCapture() {
    global WF_LastIssue,SFrameCount,SDelay,SCaptureOK
    if !SCaptureOK {
        WF_LastIssue := "simulated covering window"
        return false
    }
    if (SPending!="" && SDelay>0) {
        SDelay -= 1
        if !SDelay
            SRemove(SPending)
    }
    SFrameCount += 1
    frame := {pixels:Buffer(126*216*4,0),w:126,h:216,x:500,y:160}
    for item in SItems {
        if !item.gold
            continue
        cy := item.y+(SJitter ? Mod(SFrameCount,2)*8 : 0)
        SRect(frame,532,cy-12,56,25,0xFFDA18)
        SRect(frame,540,cy-4,15,8,0x141414)
        SRect(frame,572,cy-6,8,12,0x151515)
    }
    SRect(frame,604,180,12,17,0xFFDA18)
    SRect(frame,510,165,48,5,0xFFDA18)
    SRect(frame,535,195,55,16,0x18EE45)
    return frame
}
SRect(frame,x,y,w,h,color) {
    Loop h {
        py := y-frame.y+A_Index-1
        if (py<0 || py>=frame.h)
            continue
        Loop w {
            px := x-frame.x+A_Index-1
            if (px>=0 && px<frame.w)
                NumPut("UInt",color,frame.pixels,(py*frame.w+px)*4)
        }
    }
}
DungeonShopMoveOffButtons() => SHoverOK
WF_PrepareDungeon() => SReady
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,SHookReads
    WF_LastIssue := "",X := x1,Y := y1
    if (text=Shop)
        return SVisible
    if (text=Headsplitter) {
        if SHeadsplitterError {
            WF_LastIssue := "simulated Headsplitter capture failure"
            return false
        }
        if (SHideHeadsplitterAfterBuy && SCount("buy")>0)
            return false
        for item in SItems
            if (item.id="Headsplitter" && item.y>=y1 && item.y<=y2) {
                X := 404,Y := item.y
                return true
            }
        return false
    }
    if (text=Axe && SHideAxeAfterBuy && SCount("buy")>0)
        return false
    if (text=Axe && SExcludedError) {
        WF_LastIssue := "simulated failed exclusion capture"
        return false
    }
    if (text=GoldenFishhook || text=Axe) {
        for item in SItems
            if ((text=GoldenFishhook && item.id="Golden Fishhook") || (text=Axe && item.id="Axe")) {
                if (item.y>=y1 && item.y<=y2) {
                    X := 404,Y := item.y
                    return true
                }
            }
        return false
    }
    if (text=Fishhook) {
        SHookReads += 1
        if (SHookReads<SHookAfter)
            return false
        for item in SItems
            if (item.id="Fishhook") {
                X := 410,Y := item.y
                return true
            }
        return false
    }
    if (text=DungeonContinue) {
        X := 495,Y := 410
        return SVisible && SContinuePresent
    }
    throw Error("Unexpected shop template")
}
WF_RobloxClick(x,y) {
    global SInputCount,SVisible,SCaptureOK,SPending
    SInputCount += 1
    if (!SInputOK || (SFailAt && SInputCount=SFailAt))
        return false
    if (x=495 && y=410) {
        SEvents.Push({kind:"continue",id:"Continue",x:x,y:y})
        if SContinueOK
            SVisible := false
        return true
    }
    for item in SItems {
        if (Abs(x-560)<=3 && Abs(y-item.y)<=3) {
            SEvents.Push({kind:"buy",id:item.id,x:x,y:y})
            if item.affordable {
                if SDelay
                    SPending := item.id
                else
                    SRemove(item.id)
            }
            if SBlockAfterClick
                SCaptureOK := false
            return true
        }
    }
    throw Error("Stale or invalid shop click at " x "," y)
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text,args*) {
    X := x1,Y := y1
    return text=Shop && SVisible
}
AddToLog(message) => SLogs.Push(message)
IsChestScreenVisible(*) => false
HandleChestScreen(*) {
    throw Error("Chest handling escaped shop-only tests")
}
ShrinePriority(*) {
    throw Error("Shrine handling escaped shop-only tests")
}
ClickUntilGone(*) {
    throw Error("Generic input escaped shop-only tests")
}

DungeonChestExitBlocked() => false
