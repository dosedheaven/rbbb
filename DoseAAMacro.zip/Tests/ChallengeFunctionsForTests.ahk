; Actual Challenge start flow and input conversion; offline tests only.
ChallengeMode(overrides := 0) {
    global FW_EntranceTimeoutMs,WF_LastIssue
    options := {menuMs:30000,departureMs:45000,pollMs:250,choiceSettleMs:250,startRetryMs:1500,maxStartClicks:3}
    if IsObject(overrides)
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    if DungeonChestExitBlocked() {
        AddToLog("Challenge deferred: unfinished boss chests still own the screen")
        return false
    }
    if !WF_PrepareDungeon() {
        AddToLog("Challenge window not ready; no movement or Play Now sent")
        return false
    }
    StageGuard.Arm("Entrance",FW_EntranceTimeoutMs)
    try {
        visible := ChallengeEntryMenuVisible()
        if (WF_LastIssue!="")
            return false
        if !visible {
            AddToLog("Moving to Challenge area")
            ChallengeMovement()
        }
        started := A_TickCount
        Loop {
            if ChallengeEntryMenuVisible()
                break
            if (WF_LastIssue!="") {
                AddToLog("Challenge menu unreadable; no solo/matchmaking input sent")
                return false
            }
            if (A_TickCount-started>=options.menuMs) {
                AddToLog("Challenge menu not found after movement; stopped without walking again")
                return false
            }
            Reconnect()
            StageGuard.Check("Entrance","Challenge menu did not appear")
            Sleep(options.pollMs)
        }
        if !ChallengeStartPromptVisible(&startX,&startY) {
            if (WF_LastIssue!="")
                return false
            AddToLog("Challenge: selecting Play Now (solo)")
            if !ChallengeSelectPlayNow(options)
                return false
        } else
            AddToLog("Challenge Start queue already open; skipping Play Now")
        if !ChallengeConfirmSoloDeparture(options) {
            AddToLog("Challenge solo launch not confirmed; no map-loading handoff")
            return false
        }
        AddToLog("Challenge solo departure confirmed; waiting for the map")
        return NextStep(RestartStage)
    } finally {
        StageGuard.Disarm("Entrance")
    }
}

ChallengeStartPromptVisible(&X,&Y) {
    global WF_LastIssue
    if WF_FindText(&X,&Y,200,350,620,545,0.03,0.03,ChallengeStartText)
        return true
    if (WF_LastIssue!="")
        return false
    return WF_FindText(&X,&Y,200,350,620,545,0.03,0.03,StartStoryButton)
}

ChallengeEntryMenuVisible() {
    global WF_LastIssue
    if ChallengeStartPromptVisible(&X,&Y)
        return true
    if (WF_LastIssue!="")
        return false
    if WF_FindText(&X,&Y,325,520,489,587,0.03,0.03,ModeCancel)
        return true
    if (WF_LastIssue!="")
        return false
    return WF_FindText(&X,&Y,230,200,610,470,0.03,0.03,MatchMakingText)
}

ChallengeSelectPlayNow(options) {
    global WF_LastIssue
    if ChallengeStartPromptVisible(&X,&Y)
        return true
    if (WF_LastIssue!="")
        return false
    choice := WF_FindText(&X,&Y,230,200,610,470,0.03,0.03,MatchMakingText)
    if (WF_LastIssue!="")
        return false
    if !choice {
        if !ChallengeClickClient(400,435)
            return false
        Sleep(options.choiceSettleMs)
        if ChallengeStartPromptVisible(&X,&Y)
            return true
        if (WF_LastIssue!="")
            return false
    }
    return ChallengeClickClient(330,325)
}

ChallengeClickClient(x,y) {
    global rblxID
    try {
        hwnd := WinExist(rblxID),point := Buffer(8,0)
        NumPut("Int",x,"Int",y,point)
        if !hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int")
            return false
        FT_GetOffset(&dx,&dy)
        return WF_RobloxClick(NumGet(point,0,"Int")-dx,NumGet(point,4,"Int")-dy)
    } catch {
        return false
    }
}

ChallengeConfirmSoloDeparture(options) {
    global WF_LastIssue
    started := A_TickCount,absent := 0,starts := 0,lastStart := 0,limitLogged := false
    while (A_TickCount-started<options.departureMs) {
        if WF_FindText(&X,&Y,301,64,503,154,0.03,0.03,VoteStart)
            return true
        if (WF_LastIssue!="")
            return false
        if ChallengeStartPromptVisible(&X,&Y) {
            absent := 0
            if (starts<options.maxStartClicks && (!lastStart || A_TickCount-lastStart>=options.startRetryMs)) {
                ; Fresh match: click its true calibrated center, with no -35
                ; offset and no inferred coordinate from the uploaded crop.
                if ChallengeStartPromptVisible(&X,&Y) {
                    if !WF_RobloxClick(X,Y)
                        return false
                    starts += 1,lastStart := A_TickCount
                    AddToLog("Challenge: Start click " starts "/" options.maxStartClicks "; waiting for queue departure")
                } else if (WF_LastIssue!="")
                    return false
            } else if (starts>=options.maxStartClicks && !limitLogged) {
                AddToLog("Challenge Start retry limit reached; no Cancel/matchmaking fallback")
                limitLogged := true
            }
        } else {
            if (WF_LastIssue!="")
                return false
            menu := ChallengeEntryMenuVisible()
            if (WF_LastIssue!="")
                return false
            lobby := WF_FindText(&X,&Y,746,514,789,530,0.000001,0.000001,AreaText)
            if (WF_LastIssue!="")
                return false
            ; Blank frames between Play Now and Start must NOT count as joined.
            absent := (starts>0 && !menu && !lobby) ? absent+1 : 0
            if (absent>=2)
                return true
        }
        Reconnect()
        StageGuard.Check("Entrance","Challenge Start/solo queue did not leave the lobby")
        Sleep(options.pollMs)
    }
    return false
}
