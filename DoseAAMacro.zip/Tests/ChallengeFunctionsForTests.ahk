; Actual Challenge flow and shared solo action; offline tests only.
ChallengeMode(overrides := 0) {
    global FW_EntranceTimeoutMs,WF_LastIssue
    options := {menuMs:30000,departureMs:45000,pollMs:250}
    if IsObject(overrides)
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    if DungeonChestExitBlocked() {
        AddToLog("Challenge deferred: unfinished boss chests still own the screen")
        return false
    }
    if !WF_PrepareDungeon() {
        AddToLog("Challenge window not ready; no movement or Play Now sent")
        return false
    }
    StageGuard.Arm("Entrance",FW_EntranceTimeoutMs)
    try {
        visible := ChallengeEntryMenuVisible()
        if (WF_LastIssue!="")
            return false
        if !visible {
            AddToLog("Moving to Challenge area")
            ChallengeMovement()
        }
        started := A_TickCount
        Loop {
            if ChallengeEntryMenuVisible()
                break
            if (WF_LastIssue!="") {
                AddToLog("Challenge menu unreadable; no solo/matchmaking input sent")
                return false
            }
            if (A_TickCount-started>=options.menuMs) {
                AddToLog("Challenge menu not found after movement; stopped without walking again")
                return false
            }
            Reconnect()
            StageGuard.Check("Entrance","Challenge menu did not appear")
            Sleep(options.pollMs)
        }
        AddToLog("Challenge: selecting Play Now (solo)")
        ; Reuse the same solo action used by Story/Legend/Raid. In particular,
        ; never inherit their Matchmaking checkbox or call FindMatch here.
        PlayHere()
        if !ChallengeConfirmSoloDeparture(options) {
            AddToLog("Challenge solo launch not confirmed; no map-loading handoff")
            return false
        }
        AddToLog("Challenge solo departure confirmed; waiting for the map")
        return NextStep(RestartStage)
    } finally {
        StageGuard.Disarm("Entrance")
    }
}

ChallengeEntryMenuVisible() {
    global WF_LastIssue
    if WF_FindText(&X,&Y,325,520,489,587,0.03,0.03,ModeCancel)
        return true
    if (WF_LastIssue!="")
        return false
    return WF_FindText(&X,&Y,230,200,610,470,0.03,0.03,MatchMakingText)
}

ChallengeConfirmSoloDeparture(options) {
    global WF_LastIssue
    started := A_TickCount,absent := 0
    while (A_TickCount-started<options.departureMs) {
        ; Positive vote UI is stronger than an absent lobby/menu sample.
        if WF_FindText(&X,&Y,301,64,503,154,0.03,0.03,VoteStart)
            return true
        if (WF_LastIssue!="")
            return false
        menu := ChallengeEntryMenuVisible()
        if (WF_LastIssue!="")
            return false
        lobby := WF_FindText(&X,&Y,746,514,789,530,0.000001,0.000001,AreaText)
        if (WF_LastIssue!="")
            return false
        absent := (!menu && !lobby) ? absent+1 : 0
        if (absent>=2)
            return true
        Reconnect()
        StageGuard.Check("Entrance","Challenge solo launch did not leave the lobby")
        Sleep(options.pollMs)
    }
    return false
}

PlayHere() {
    FixClick(400, 435)  ; Play Here or Find Match 
    Sleep (500)
    FixClick(330, 325) ;Click Play here
    Sleep (1200)
    ClickStartStory()
    Sleep (500)
    FixClick(330, 325) ;Click Play here
}
