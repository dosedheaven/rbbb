"""Extract production functions for startup tests without Main/private startup."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
parts = ['; Generated production functions; offline tests only.\n']
for rel, name in [
    ('Lib/GameMango.ahk', 'DungeonMode'),
    ('Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk', 'DungeonValidLayout'),
    ('Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk', 'LookForDungeonRooms'),
]:
    source = (root / rel).read_text(encoding='utf-8-sig')
    match = re.search(r'^' + name + r'\([^\n]*\)\s*\{.*?^\}', source, re.M | re.S)
    assert match, name
    function = match[0]
    if name == 'LookForDungeonRooms':
        function = function.replace('LookForDungeonRooms()', 'DungeonLookForRoomsUnderTest()', 1)
    parts.append(function + '\n\n')
(root / 'Tests/EntranceFunctionsForTests.ahk').write_text(''.join(parts))
print('Prepared actual entrance wrapper/layout validator without game startup.')
