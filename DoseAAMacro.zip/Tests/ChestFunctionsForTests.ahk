; Generated production functions; offline chest tests only.
CheckDungeonSpecials(chestOptions := 0) {
    AddToLog("Checking for dungeon shop, shrine, open chest")
    
    ; Give time for special elements to appear
    Sleep(2000)
    
    foundShop := false
    foundShrine := false
    foundChest := false

    ; Check the area for shop, shrine, or chest
    Loop 5 {
        ; Check for shop
        if (!foundShop && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shop)) {
            AddToLog("Found Shop")
            Sleep(1000)
            if !HandleShop()
                return false
            Sleep(1000)
            foundShop := true
        }
        Sleep(1000)
        ; Check for shrine
        if (!foundShrine && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shrine)) {
            if (DenyShrines.Value) {
                AddToLog("Found Shrine, Denying")
                ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
            } else {
                ShrinePriority()
            }
            Sleep(1000)
            foundShrine := true
        }
        Sleep(1000)
        ; Check for Chest Opening
        if (!foundChest && IsChestScreenVisible()) {
            AddToLog("Found Chest Opening")
            if !HandleChestScreen(chestOptions)
                return false
            foundChest := true
        }
        
        ; If all elements are found, exit early
        if (foundShop && foundShrine && foundChest)
            break

        Sleep(1000)  ; Wait and check again
    }
    
    if (!foundShop && !foundShrine && !foundChest)
        AddToLog("No shop, shrine, or chest opening found")
    return true
}

IsChestScreenVisible() {
    return FT(&X, &Y, 140, 200, 375, 250, 0, 0, ChestRoom) or FT(&X, &Y, 358, 238, 604, 261, 0, 0, ChestRoomLuck)
}

IsCommonChestDone() {
    ; An empty-slot reference must not tolerate a different remaining count.
    return WF_FindText(&X, &Y, 357, 265, 407, 315, 0.000001, 0.000001, EmptyCommonChest)
}

IsRareChestDone() {
    return WF_FindText(&X, &Y, 353, 324, 408, 379, 0.000001, 0.000001, EmptyRareChest)
}

HandleChestScreen(options := 0) {
    global BossRoomCompleted, SaveChestsForBoss
    
    ; Determine if we should open chests now
    shouldOpenChests := BossRoomCompleted || !SaveChestsForBoss
    
    if (shouldOpenChests) {
        if BossRoomCompleted
            DungeonClearBossExitRecovery()
        AddToLog("Opening all available chests")
        
        if !WF_PrepareDungeon() {
            AddToLog("Chest opening window not ready; no Continue sent")
            return false
        }
        try {
            if !DungeonOpenAllChestsWithRecovery(options)
                return false
        } catch as err {
            AddToLog("Chest opening stopped after an unexpected error at line " err.Line "; no Continue sent")
            return false
        }

        if (BossRoomCompleted) {
            DungeonArmBossExitRecovery()
            BossRoomCompleted := false
            ClickDungeonContinue()
        } else {
            ClickDungeonContinue()
            if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    NextStep(StartSelectedMode)
                }
        }

        } else {
            AddToLog("Saving chests for boss room - clicking continue")
            ClickDungeonContinue()
            if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    NextStep(StartSelectedMode)
                }
        }
        Sleep(1000)
        Reconnect()
        return true
}

ClaimChestReward(options := 0) {
    return DungeonClaimChestReward(options)
}

