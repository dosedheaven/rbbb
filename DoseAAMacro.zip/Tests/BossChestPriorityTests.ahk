#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\Engine\Session.ahk
#Include %A_ScriptDir%\..\Lib\Engine\ChallengeSchedule.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\BossChestPriorityFunctionsForTests.ahk
global PPending := false,PChestWorks := false,PResumes := 0,PRoutes := 0
global PChecks := 0,PScheduleCalls := 0,PScheduleDue := true,PLobbyClicks := 0,PLogs := []
global mode := "Dungeon",Wins := 0,loss := 0,challengeStartTime := A_TickCount-1800001
 global inChallengeMode := false,BossRoomCompleted := true,ChallengeBox := {Value:1},StopAfterDefeat := {Value:0}
 global FW_EndScreenTimeoutMs := 1
class StageGuard {
    static Arm(*) => 0
    static Disarm(*) => 0
    static Check(*) => 0
}
PAssert(ok,label) {
    global PChecks
    PChecks += 1
    if !ok
        throw Error(label)
}
PInvoke() {
    try MonitorDungeonEnd()
    catch as err
        return err.Message
    return "No handoff"
}
try {
    PPending := true
    PAssert(!MonitorDungeonEnd() && PResumes=1 && !PRoutes && !PLobbyClicks && !PScheduleCalls,"unfinished chest failure resumes its owner before any end-screen/lobby actions")
    PChestWorks := true
    PAssert(MonitorDungeonEnd()="ResumedRooms" && PResumes=2 && PRoutes=1 && !PLobbyClicks,"completed pending chest resumes route selection without replay/entry clicks")
    PPending := false
    PAssert(PInvoke()="BossRewards","due schedule/Challenge cannot leave before boss rewards")
    PAssert(!PScheduleCalls && !PLobbyClicks && !inChallengeMode,"boss flag defers both scheduling and Challenge without consuming their pending state")
    BossRoomCompleted := false,PScheduleDue := false
    PAssert(PInvoke()="Lobby" && inChallengeMode,"ordinary floor still switches to a due Challenge after its end screen")
    PAssert(PScheduleCalls=1 && PLobbyClicks=1,"ordinary-floor Challenge retains its original lobby route")
    inChallengeMode := false,PScheduleDue := true
    PAssert(PInvoke()="Lobby" && PScheduleCalls=2 && PLobbyClicks=2,"ordinary-floor schedule still takes its original lobby route")
    FileAppend("PASS: " PChecks " boss chest priority assertions (actual end-screen monitor, simulated schedule/Challenge/input).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
ScheduleTick() {
    global PScheduleCalls
    PScheduleCalls += 1
    return PScheduleDue
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text,args*) {
    X := x1,Y := y1
    return text=LobbyText
}
FixClick(*) => 0
ClickReplay() {
    throw Error("BossRewards")
}
ClickUntilGone(*) {
    global PLobbyClicks
    PLobbyClicks += 1
}
NextStep(*) {
    throw Error("Lobby")
}
CheckLobby() => 0
AddToLog(message) => PLogs.Push(message)

DungeonChestExitBlocked() => PPending
HandleChestScreen(*) {
    global PResumes
    PResumes += 1
    return PChestWorks
}
LookForDungeonRooms() {
    global PRoutes
    PRoutes += 1
    return "ResumedRooms"
}

DoseResultsEvidence() => {kind:"Navigation",navigation:true,next:false,xp:false,unit:false}
DoseDungeonScreenStep() => 0
DoseResumeChestSession() => 0
DoseResumeDungeonMenu() => 0
DoseProcessStageResults() => 0
