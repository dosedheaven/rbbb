from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
src=(root/'Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk').read_text()
name='CheckForFinishDungeonV2'
match=re.search(r'^'+name+r'\([^\n]*\)\s*\{.*?^\}',src,re.M|re.S)
assert match
(root/'Tests/BossRecoveryFunctionsForTests.ahk').write_text(
    '; Generated production finish caller only; no Main/private startup.\n'+match[0]+'\n')
print('Prepared production post-boss finish caller without game startup.')
