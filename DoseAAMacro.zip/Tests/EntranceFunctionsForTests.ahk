; Generated production functions; offline tests only.
DungeonMode() {
    AddToLog("Entering Dungeon Mode")
    if !DungeonStartEntrance()
        return false
    return LookForDungeonRooms()
}

DungeonValidLayout(rooms) {
    ids := Map()
    for room in rooms {
        if (ids.Has(room.index) || room.index < 1 || room.index > 5)
            return false
        ids[room.index] := true
    }
    if !ids.Count
        return false
    ; A missed/locked neighbor must not invalidate a confirmed card. The room's
    ; own border/icon still must be verified; never mix 2-card and 3-card positions.
    if (ids.Has(4) || ids.Has(5))
        return !ids.Has(1) && !ids.Has(2) && !ids.Has(3)
    return true
}

DungeonLookForRoomsUnderTest() {
    if DungeonChestExitBlocked() {
        AddToLog("Chest session unfinished; LookForDungeonRooms refused")
        return false
    }
    global SaveChestsForBoss
    SaveChestsForBoss := SaveChestsBox.Value = 1
    AddToLog("Dungeon detector: Dose v" DoseReleaseVersion())
    AddToLog("Curse exclusions: " (DungeonHasCurseExclusions() ? "active" : "none; all curses allowed"))
    if !WF_PrepareDungeon() {
        AddToLog("Dungeon window check failed: " WF_LastIssue)
        return false
    }
    ; Replay/recovery can return to the large startup Enter Dungeon screen.
    ; Resolve it before shop/shrine/room scans, using the same confirmed flow.
    if WF_FindText(&X,&Y,250,340,550,495,0.20,0.20,EnterDungeon) {
        AddToLog("Dungeon entrance still visible; resuming Enter Dungeon")
        if !DungeonWaitForEntrance()
            return false
    }
    ; Special screens can change the visible route. Handle them BEFORE scanning.
    if !CheckDungeonSpecials()
        return false
    previousLayout := ""
    Loop 3 {
        foundRooms := DungeonScanRooms(&diagnostics), layout := ""
        for room in foundRooms
            layout .= room.index ":" room.type ";"
        ; Require two consecutive equal border snapshots, not a partial animation.
        if (DungeonValidLayout(foundRooms) && layout = previousLayout) {
            DungeonClearBossExitRecovery()
            AddToLog("Dungeon layout: " layout)
            return SelectBestRoom(foundRooms.Length, foundRooms)
        }
        previousLayout := layout
        if (A_Index < 3)
            Sleep(120)
    }
    AddToLog("Dungeon scan detail: " diagnostics)
    AddToLog("Dungeon detection stopped: no stable compatible room candidates; no room clicked. See scan detail above for window rejection versus missing marker patterns.")
    return false
}

