# Keep saved settings when updating

1. In the old version, click Save and close the macro.
2. Extract the new DoseAAMacro.zip into a separate folder.
3. Before starting the new version, copy the entire old `Anime Adventures (Framework)/Settings` folder into the new `Anime Adventures (Framework)` folder. Merge folders/replace files if Windows asks. Copy its subfolders too.
4. Start the new Main.ahk and check your saved options.

The v3.3 to v3.4 update uses the same configuration format. Copying the entire folder keeps configuration, unit profiles, Dungeon preferences and their existing preset marker, custom placements, custom movement recordings, keybinds, schedule and other saved options. Keep the old installation as your backup. Copying only Configuration.txt misses settings stored in other files.

Do not copy the old Lib or Main.ahk over the new version, because that would restore old program code. Release ZIPs have an empty Settings directory and do not include your private settings or logs.

For later versions, use the same process unless that release explicitly documents a configuration migration.
