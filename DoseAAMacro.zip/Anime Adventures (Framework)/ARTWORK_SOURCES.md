# Akatsuki artwork — v2.7

Source: user-provided 31575.jpg inside 31575.zip, supplied for this dashboard. The file is bundled unchanged as Images/UI/DoseAkatsuki.jpg. No artist/source URL was supplied, and no ownership of the artwork is claimed by Dose.

Original format: JPEG, 1920x1080, 294599 bytes.

SHA-256: 14f7cab7c7a7a4b3bd0cb3ab3a8ea4651f0d53972fca59381be7d9fa98795735

The interface renders a full group banner and a separate Itachi/Pain close-up from this same original file. Cropping occurs at runtime; the bundled image bytes are not edited. No generated anime artwork or runtime network download is used.

Older theme artwork files are retained as inactive historical assets. Akatsuki is the only selectable theme.


# Faded Itachi wallpaper — v3.1

Source: user-provided download.webp inside download.zip, supplied for the background behind this dashboard. No artist/source URL was supplied, and no ownership of the artwork is claimed.

Original: WebP, 860x484, preserved unchanged as Images/UI/Originals/DoseItachiBackdrop.webp. SHA-256: f7fcf57b79d05699b920115a3bab48e9be632b87ef5f715eb1a874ff8ba8ccf5.

Images/UI/DoseItachiBackdrop.png is a Windows-compatible, lossless format conversion with identical decoded RGB pixels. Runtime crops share the existing 1800x930 dashboard canvas, with low opacity over dark surface colors. Decoration excludes the Roblox viewing rectangle and keeps existing control positions and settings. The original group banner/portrait asset is unchanged.
