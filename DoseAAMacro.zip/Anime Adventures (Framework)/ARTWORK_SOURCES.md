# Artwork sources — v2.5

These are existing third-party anime wallpapers from the public [dharmx/walls collection](https://github.com/dharmx/walls), pinned to commit 6bf4d733ebf2b484a37c17d742eb47e5139e6a14. They were not generated for this update. The collection does not identify an individual artist for these files; no ownership of the artwork is claimed by Dose. Character names describe the depicted characters, not artist attribution.

Original files are copied unchanged into the app. Proportional cropping and background dimming happen only when the interface draws them. No runtime network access is needed.

## Tokyo Ghoul / Ken Kaneki

Bundled file: Images/UI/DoseKaneki.jpg

[Original source](https://raw.githubusercontent.com/dharmx/walls/6bf4d733ebf2b484a37c17d742eb47e5139e6a14/anime/a_cartoon_of_a_man_with_a_mask.jpg)

SHA-256: 0b86250c5ae93054e1baaa95d955e7d67f2942b397b57f61bdbe97b13367f16f

## Astral / Juuzou Suzuya

Bundled file: Images/UI/DoseJuuzou.png

[Original source](https://raw.githubusercontent.com/dharmx/walls/6bf4d733ebf2b484a37c17d742eb47e5139e6a14/anime/a_cartoon_of_a_girl_with_white_hair_and_black_eyes.png)

SHA-256: 2d0b539145df498db7c6729ad08b10e3587daa029f7ff077c30a9d69509ac29d
