# Akatsuki artwork — v2.7

Source: user-provided 31575.jpg inside 31575.zip, supplied for this dashboard. The file is bundled unchanged as Images/UI/DoseAkatsuki.jpg. No artist/source URL was supplied, and no ownership of the artwork is claimed by Dose.

Original format: JPEG, 1920x1080, 294599 bytes.

SHA-256: 14f7cab7c7a7a4b3bd0cb3ab3a8ea4651f0d53972fca59381be7d9fa98795735

The interface renders a full group banner and a separate Itachi/Pain close-up from this same original file. Cropping occurs at runtime; the bundled image bytes are not edited. No generated anime artwork or runtime network download is used.

Older theme artwork files are retained as inactive historical assets. Akatsuki is the only selectable theme.
