# Shop policy — v3.4

Purchase order is Golden Fishhook, then regular Fishhook, then remaining available items from bottom to top. Golden Fishhook is matched using 59 opaque gold/white pixel samples from the supplied transparent icon. Transparent background pixels are ignored. Its purchase uses the freshly detected gold button in the matching row. Regular Fishhook keeps its existing detector and purchase offset.

Axe is excluded using its existing FindText reference in the live row's icon region. The exclusion is checked immediately before each purchase attempt, including the regular Fishhook no-active-button fallback. A recognized Axe gets no purchase click. Rows are scanned again after purchases, so exclusions follow the current layout instead of remembering old row numbers. A shop containing only excluded offers continues without buying them.

This release excludes Axe only. Aures Maul, Headsplitter and Solar Cleaver do not yet have captured detection references and are not blocked. Golden Fishhook does not add priorities for other shop items.

As before, rejected/unaffordable purchases have bounded retries, then other items are tried and the shop continues. Detection or window/input failures stop the handler without guessing. Purchase observations do not independently verify inventory or buff effects. Keep Roblox visible at its configured size.

No UI/settings, movement, room/rare/future routing, chest-opening, chest-saving, shrine/curses, or post-boss recovery behavior changed. Native tests use synthetic windows and simulated purchase input, not a live Roblox session.
