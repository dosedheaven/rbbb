# Shop repair — v2.4

Fishhook is attempted first using its existing detector and purchase offset. The shop then finds the visible yellow/gold purchase-button plates in the calibrated shop column, rather than clicking the original three row positions.

After every purchase attempt it re-scans. For the supplied sequence this means Fishhook in the middle, then Dagger after it moves into the second row, then Reaper Scythe at the remaining first row. It also supports a lone item still at middle height.

Generic items are attempted from bottom to top. A confirmed visual button-count decrease advances the flow; Fishhook additionally needs its reference to disappear. These observations do not independently verify inventory or a luck buff.

As requested, a purchase that does not go through after bounded attempts is skipped while the other items are tried, then the shop continues. The log says the purchase remains unconfirmed/possibly unaffordable rather than claiming it was bought. No price or coin-balance OCR is performed.

Unreadable/covered windows, ambiguous layouts, refused input, or a Continue that does not close the shop still stop the shop handler and propagate failure. These are different from an in-game purchase being rejected. Keep Roblox visible at the configured size.

No production image reference, UI/theme, movement, room/rare selection, chest-opening, shrine, or startup code changed. Save your existing Settings folder when updating. The next release version will be 2.5.
