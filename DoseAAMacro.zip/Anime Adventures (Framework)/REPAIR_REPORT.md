# Dose AA Macro v3.3

Fixes reward-queue handling for 2x chest drops that show two separate item popups. A temporary return to the chest menu between items no longer completes claiming after only two frames. The menu must remain visible continuously for three seconds; another reward resets that quiet period. The same stable proof is required when accepting a recovered menu and when confirming both stored chest types empty together.

A confirmed chest reward chain retains context after its apparent menu return, until the next Open attempt or joint final empty proof. If another item appears late and stalls the flow, the existing guarded chest recovery can resume claiming instead of treating it as an unrelated unknown screen. Retained context does not let an already-present menu repeatedly bypass inactivity limits. The code does not hardcode exactly two items, so normal single drops and longer reward queues use the same flow.

Chest Open/claim coordinates, input checks, overlay handling, original click/time caps, two-minute inactivity recovery and 15-minute overall chest deadline are unchanged. Intermediate chest saving, positive Common/Rare empty verification and post-boss exit authorization remain required. See CHEST_STALL_RECOVERY.md.

The v3.2 UI repairs, map selectors, settings/profile storage, gameplay/room priorities, shop, shrine/curse policy, movement, Akatsuki wallpaper and Roblox size/viewport/calibration are unchanged. Tests/Regression_Comparison.txt records exact scope. Original license/copyright files remain intact; no Discord invites or author credits are added.

Regression tests simulate sequential double and triple drops, an interim menu gap, a second reward that cannot be dismissed, late reward recovery, bounded claiming and production three-second menu timing. The new double-drop scenario fails on v3.2 and passes on the repair. The full production two-minute inactivity interval is also tested. These are isolated synthetic game/input checks on native AutoHotkey under Wine, not live Roblox validation.

Keep your existing Settings folder when extracting. Personal Settings and Logs are excluded from the ZIP.
