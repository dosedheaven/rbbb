# Dose AA Macro v3.1

Adds the user-supplied wider Itachi image as a dark, faded wallpaper across the existing dashboard surfaces, unit cards, gutters and activity panel. The right-hand group banner and portrait remain unchanged. Labels retain their text/positions and readable foreground colors; dropdowns, switches and other controls retain their settings and callbacks.

The original 860x484 WebP from download.zip is preserved byte-for-byte under Images/UI/Originals/DoseItachiBackdrop.webp. Images/UI/DoseItachiBackdrop.png is a lossless format conversion with identical decoded RGB pixels for Windows picture-loading compatibility. Fading/cropping happens when rendering the interface; no generated replacement artwork is used. Wallpaper surfaces fall back to the existing flat colors if unavailable.

No settings or theme options are added. The 1800x930 dashboard, Roblox 816x638 window, 797x597 transparent viewing rectangle and offsets (-5,1) are unchanged. No dungeon entry/recovery, chest opening, room/rare ranking, shop, shrine/curse, movement, scheduling, input, profile storage or gameplay callbacks change. Tests/Regression_Comparison.txt records exact source scope.

The current native AutoHotkey preview checks the rendered wallpaper, viewport separation, text fit, all six placement profile save/load/navigation paths, all mode options, Settings/Advanced/Debug/Placement/Movement/Scheduler/Cards/Guide panels and window controls. Tests use isolated synthetic settings/game hooks on Wine at 1920x1080/96 DPI, not a live Roblox session; other Windows scaling combinations remain unverified. Earlier runtime-verification records retain their original release labels.

Prior v3.0 optional-credit/invite removals and unchanged license notices are retained. Keep your existing Settings folder when extracting. Personal Settings and Logs are excluded from the ZIP.
