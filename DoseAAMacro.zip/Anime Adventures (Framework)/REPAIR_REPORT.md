# Dose AA Macro v3.0

Removes optional author/contributor comments, historical acknowledgments and donation text from bundled source/documentation, and removes both Discord invitation destinations. Legacy invite callback functions remain as inert return-false handlers, keeping references compatible. The webhook User-Agent label is now DiscordBot (Dose edition); endpoints, payloads and webhook sending are unchanged.

Existing font copyright/license files and the OCR MIT license remain byte-identical. The FindText header remains Edition: Dose as requested. Dose edition branding does not replace the retained copyright notices.

No dungeon entry, recovery, chest opening, route/rare ranking, shop, shrine/curse policy, placement, movement, UI layout or settings logic changes. Version metadata and its test expectation advance from 2.9 to 3.0. Tests/Regression_Comparison.txt records exact scope; existing runtime verification records keep their original release labels.

Keep your existing Settings folder when extracting. Personal Settings and Logs are excluded from the ZIP.
