# Dose AA Macro v2.5

UI presentation update only. Fixes the theme label crossing Mode Select, the Activity divider crossing its heading, cramped footer text and overflowing recording instructions. Unit cards and section frames have matching corner accents. Original input controls, options and callbacks are retained.

Real existing Kaneki and Juuzou wallpapers replace the active backgrounds. They are bundled unchanged, rendered with proportional crops, and paired with crimson/charcoal or mint/teal colors. Text sits on opaque surfaces. See ARTWORK_SOURCES.md and ANIME_THEMES.md.

Long older log lines display an ellipsis instead of a clipped second line. Hover reveals the complete current value; Open log still opens the full file. AddToLog and all seven stored log values are unchanged.

Gameplay code is byte-identical to v2.4: dungeon priorities, rare routing, curse/shrine policy, shop purchases, chest opening and entrance handling are retained. Custom movement/placement changes are limited to explanatory panel labels; their controls, callbacks, recording and replay functions are unchanged. The Roblox viewport, transparency key, game size and click calibration are unchanged.

Validation records are in Tests. Current native AutoHotkey UI checks cover both themes, unconfirmed/confirmed mode selection, panel navigation, switches, text metrics, bundled artwork/fonts, defaults and viewport geometry. Checks use Wine and synthetic windows, not a live Roblox session. Existing gameplay verification records retain their original release labels. Windows display scaling and rendering can differ from this test environment.

The ZIP excludes personal Settings and Logs. Copy your existing Settings folder into the new extracted app before starting it. VERSION.txt, the window title and log header report v2.5.
