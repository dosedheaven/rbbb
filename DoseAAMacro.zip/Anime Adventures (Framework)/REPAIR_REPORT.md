# Dose AA Macro v2.9

Only the five previously listed credit comments in GameMango.ahk, PlacementLogics.ahk, Game/LobbyNavigation.ahk and Tools/FindText.ahk now identify the Dose edition. Version metadata and its test expectation advance from 2.8 to 2.9.

No executable behavior, UI, settings, detection, room selection, shop, shrine, chest opening, movement or recovery code changes from v2.8. Other author comments, links and license notices are unchanged.

The v2.8 post-boss recovery remains included; see BOSS_ENTRANCE_RECOVERY.md. Existing verification records document their original tested releases. Tests/Regression_Comparison.txt verifies this release against the v2.8 ZIP, including identical executable text in the four comment-edited files.

Keep your existing Settings folder when extracting. Personal Settings and Logs are excluded from the ZIP.
