# Dose AA Macro v2.2

This release verifies end-of-run chest draining before allowing Continue. The next delivered release is v2.3. Release version is centralized in Lib/AppInfo.ahk and matches VERSION.txt, window/header/footer and detector logs.

## Confirmed defects addressed

Previously, HandleChestScreen interpreted a chest menu still being visible after an Open click as proof that the row was empty. A missed/ignored click could therefore skip remaining chests. ClaimChestReward could report success on a lobby-like overlay without confirming the chest menu returned. CheckDungeonSpecials ignored the handler's return value, allowing room selection to continue after a failure.

## New chest flow

- Common and Rare are drained separately. Each row needs three consecutive positive matches of its existing empty-slot reference.
- Empty references use window-aware matching with zero allowed pixel errors (a small nonzero tolerance prevents FindText's implicit zero/zero fallback). A different remaining count must not be accepted through a broad percentage tolerance.
- The working legacy client click locations are retained for Common Open, Rare Open, reward claim and the existing possible token-limit overlay dismissal. ClientToScreen and the validated WindowFollow input helper deliver them without guessed title-bar offsets.
- A still-visible menu triggers bounded Open retries, not an empty declaration. The flow waits for a transition and handles the reward, requiring two consecutive chest-menu observations before claiming that the reward menu returned.
- Claim timeouts, refused input, unreadable windows, matching errors and missing empty evidence fail the pass. The special-screen caller propagates that failure; Continue, finish detection and the next-room path do not run on an incomplete opening pass.
- After both rows finish, their empty markers must be visible together for three more checks. If one changes, both rows are checked/drained again, up to three passes.
- Only after this joint verification does the log say "All chests confirmed empty: Common and Rare; Continue unlocked" and permit Continue. Boss state is retained on failure and reset only after successful verification, before the existing Continue flow.

Limits prevent an endless click loop: four ignored Open attempts, 40 claim clicks / 60 seconds per reward, 200 Open clicks per chest type per pass and a 15-minute overall budget. These limits stop progress rather than skip unverified chests. Internal timing parameters are exposed only to offline tests, with no new user-facing options.

With Save Chests For Rukia enabled, intermediate chest screens still save chests for the existing boss/final-room condition. Explicitly turning that option off retains its existing early-opening behavior. This release does not add a new floor-number reader or change the accepted boss-gating policy. It cannot guarantee a random Rukia reward.

## Preserved scope

Compared with v2.1, four existing public application files change: Main.ahk (one helper include), Lib/AppInfo.ahk and VERSION.txt (2.2), and Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk (chest wrappers, empty checks and failure propagation). Lib/Modes/Dungeon/DungeonChestOpening.ahk is new. There are 140 byte-identical other public application files and 40 unchanged other dungeon function bodies.

The v2.1 entrance repair, room and rare/future selection, curse/shrine policy, shop purchases, UI, default settings, and all map movement code are unchanged. The discussed moving shop-button, shrine-scrolling and current-rare matching investigations are not included. The user-rejected floor20-save-fix-8 behavior is not restored.

Hellish City can already be customized through the Custom Map recorder. See HELLISH_CITY_MOVEMENT.md for the exact existing workflow. No recorded movement files were opened or changed, and no new route was supplied.

## Verification

AutoHotkey 2.0.19 ran under Wine 10 on an isolated virtual display:

- 37 chest-flow assertions against production helpers, wrappers and special-screen caller, with independent simulated chest counts/screens/input and real native client-coordinate conversion. Cases include all chests across both rows, one/both initially empty, missed clicks, delayed transitions, unclaimed rewards, failed or ambiguous empty references, joint rechecks, limits, preserved saving options, overlay handling, exception containment and failure propagation.
- 64 real native window/FindText/ImageSearch assertions, including the retained entrance checks, chest/claim coordinate translation, blank-scene rejection by both empty references, coordinate-mode restoration and blocked input. Input is recorded, not delivered.
- 170 production room/dungeon logic assertions, screen/input mocked.
- 33 entrance assertions, screen/input mocked with native client conversion.
- 16 shop-priority assertions, screen/input mocked.
- 26 native Advanced-panel assertions, configuration saving mocked.
- 14 real temporary-file default/configuration assertions.
- 21 rendered-UI assertions using isolated production GUI/events/styles/panels with game/services and unchanged external panels stubbed, including version 2.2 and unchanged game geometry.
- 83 Python source/geometry/policy checks.

Results are recorded in Tests/AutoHotkey_*_Verification.txt, Tests/Linux_Verification.txt and Tests/Regression_Comparison.txt. Other named regression notes concern earlier releases. PrepareChestTests.py regenerates the offline production-wrapper include without Main/private startup.

No live Roblox session was run. The existing empty-slot references were not calibrated against a newly supplied live chest-menu screenshot, so their current sensitivity remains unverified. An unrecognized empty marker will block Continue, requiring a screenshot/reference check rather than silently abandoning chests. Menu return and empty markers are visual evidence, not independent inventory or loot verification.

The original upload and working private Settings/Logs/webhook module were not inspected or changed. The downloadable ZIP contains empty Settings/Logs folders and no personal configuration or logs.
