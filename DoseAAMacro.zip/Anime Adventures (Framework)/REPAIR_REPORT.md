# Dose AA Macro v2.0

This release adds the requested Dungeon defaults and a cosmetic UI refresh to the previously delivered route/shop/future-path repair. Release versions now come from `Lib/AppInfo.ahk`; this bundle is **2.0**, with the next delivered update **2.1**. `VERSION.txt`, the header/window title, startup log, footer badge, and dungeon detector log agree.

## Requested Dungeon defaults

- Route: **Rare_Chest → Chest → Shop → Shrine → Hoard → Boss**.
- Avoided curses: all eight slots **None**.
- Avoided shrines: **Burst, Chaos, Vamparism, None, None, None** (existing option spelling retained).

The preset applies on the first Dungeon selection. It is saved once and later edits are preserved, including across restarts. When an existing Dungeon configuration is present, the preset first retains it as `Settings/RoutePriority.beforeDose2.txt`. The one-time marker is `Settings/DoseDungeonPreset-v2.txt`. Other settings are not part of the preset. If saving/backing up is unavailable, a log explains the session-only application.

The shrine loader previously read the saver’s Shrine2…Shrine7 keys into rows 2…7 instead of 1…6. Its index now matches the existing file format, allowing every requested shrine slot and subsequent custom edits to round-trip correctly. Existing option lists and dropdown event handlers are retained.

## Appearance

The UI uses midnight navy cards, violet accents, cyan highlights, slimmer card borders, icon labels, a Dose footer badge, and original anime artwork. The bottom-left Discord button is removed. A bundled DejaVu font supplies icon glyphs for this process without installing a system font; its license is included. The background is dimmed for log readability and has a plain-color fallback if unavailable.

The application size, transparent Roblox rectangle, capture coordinates, target game size, and offsets are unchanged. Artwork begins at x804, outside the x3…800 game rectangle. Existing buttons retain their callbacks, including the restyled close, minimize, and placement-menu controls. All modes, unit options, panels, and saved-feature controls remain available. Existing accent-theme choices are still honored.

## Gameplay scope

Against the preceding route-shop-future-fix-10 ZIP, gameplay source changes are limited to the requested default route data and detector version text. The main game loop, image patterns, window/input helpers, and debug detector are byte-identical. All remaining dungeon function bodies are unchanged, including shop, shrine, chest-opening, Enter handling, and the repaired selection routine.

Previously delivered behavior is retained: supported single/double/triple layouts; green OPEN, regular, and boss entry; priority normalization; current Rare Chest before future routing at Rare Chest’s configured rank; reachable spatial preview regions; and Fishhook detection/attempts before the existing shop slots 3,2,1. Curse exclusions and shrine-offer rejection still follow the chosen settings. Chest saving/opening uses the user-accepted v7 behavior; the rejected floor20-save-fix-8 change is omitted.

Fishhook tests verify attempt order and input delivery, not an actual purchase or luck buff. Future-path fixtures verify the macro’s spatial mapping, not the live game’s graph or rewards.

## Verification

- **170** production dungeon logic assertions, with screen/input/game hooks mocked.
- **49** real native window/FindText/ImageSearch assertions against synthetic windows.
- **16** shop-priority assertions, including Fishhook-first behavior and failed-input handling.
- **26** actual Advanced-panel assertions using native dropdown controls, saving mocked.
- **14** default/configuration assertions with real file IO in a unique temporary folder: legacy load, exact preset, backup, save/reload, last shrine row, and preservation of later edits.
- **21** isolated rendered-UI assertions using production GUI, event, style, panel and config code: version, defaults, persistence, icon font, game geometry, artwork confinement, native capture acceptance, toolbar navigation, menu hide/show, and minimize/close. Unchanged external panels/services are stubbed; private startup and actual Roblox are excluded.
- **83** Python source/geometry/policy checks, including delimiter checks across the changed sources.

The interpreter is AutoHotkey **2.0.19** via Wine **10**. Main and Advanced views were visually inspected in the isolated UI preview. Native control styling/font fallback can differ on Windows. No live Roblox session was run; these checks cannot establish live gameplay reliability.

Against the original uploaded archive, exactly **13 existing source files** differ and **123 other non-private original files** are byte-identical. Fourteen unrelated original dungeon functions and seven legacy WindowFollow functions are unchanged. The original uploaded ZIP and working private Settings/Logs/webhook module were not edited or inspected; only protected filenames/sizes were checked. The downloadable ZIP has empty Settings/Logs folders and includes no personal configuration or logs.

Current verification records are `Tests/AutoHotkey_*_Verification.txt`, `Tests/Linux_Verification.txt`, and `Tests/Regression_Comparison.txt`. Older named regression notes describe prior repairs. The UI preview uses synthetic fixtures and does not connect to game/private-server/webhook services.
