# Dose AA Macro v3.2

Fixes overlapping run-option checkboxes by packing simultaneously visible options into distinct positions without changing their stored values. Mode changes clear stale Fool's Hunt controls, and Dungeon selection consistently shows its options. The save-chests handler reads its checkbox value directly. Contract team selectors remain separate from the checkboxes and buttons.

Custom Placement and Custom Map preserve native dropdown/list height instead of scaling it as a label; both map selectors show an initial map, readable text and a scrollable native list. Recording/replay callbacks, recorded data, settings and profile storage stay unchanged.

Chest opening now stays active after a transient failure. A session-scoped supervisor watches confirmed progress and rescans after two minutes, with at most two recovery attempts and the existing overall deadline. It can resume a late chest menu or retry an already-pending reward; unexpected entrance/lobby or unknown screens cannot authorize Continue or restart. Both chest types still require positive final empty proof before leaving. See CHEST_STALL_RECOVERY.md. This is not a global game-idle detector.

The Akatsuki/Itachi artwork, dashboard dimensions, Roblox size/viewport/offsets, room/rare/future ranking, shop, shrine/curse rules, movement/placement recording/replay and existing post-boss lobby recovery retain their implementation. Tests/Regression_Comparison.txt records exact scope.

Native verification confirms every mode and tests coordinate clicks on visible run options, their independence/visibility, map popup opening/scrolling/last-entry selection, profile persistence, panel navigation and text fit. The same interaction checks reproduce the overlap on v3.1. Chest checks simulate stalled clicks/rewards, delayed menu return, unknown/lobby/entrance screens, retry/deadline limits and final empty proof. A separate real-time test exercises the full production two-minute interval. These use isolated fake game windows/settings on Wine, not live Roblox; the user's exact reward screen/log remains needed to diagnose any detection mismatch that persists.

Keep your existing Settings folder when extracting. Personal Settings and Logs are excluded from the ZIP. No new author credits or Discord invites are introduced; existing copyright/license notices remain unchanged.
