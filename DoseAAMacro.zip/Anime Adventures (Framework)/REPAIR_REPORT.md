# Dose AA Macro v3.4

Shop-only update: Golden Fishhook is prioritized before regular Fishhook. Axe uses its existing detection reference as a never-buy exclusion, checked again immediately before each purchase and after row compaction. Other eligible items retain bottom-to-top purchase attempts and the authorized try-other-items/Continue behavior when an item cannot be bought.

The supplied transparent Golden Fishhook icon is preserved at Images/Shop/GoldenFishhook.png. Matching ignores transparent pixels and samples the icon's opaque gold/white pixels. Golden purchases use a freshly detected buy button, rather than a fixed point inferred from the uploaded crop.

Aures Maul, Headsplitter and Solar Cleaver remain unsupported exclusions until their references are supplied. No other priority or exclusion is added.

UI, settings formats, viewport calibration, movement, rare/future room selection, shop time/retry bounds, shrines, chest draining/saving, and boss/lobby recovery remain unchanged. See Tests/Regression_Comparison.txt for the exact release comparison and Tests/AutoHotkey_Shop_Verification.txt and Tests/AutoHotkey_ShopWindow_Verification.txt for test results. Tests simulate game screens/input; no live Roblox validation is claimed.

Keep the entire old Settings folder when updating; see UPDATING.md. No personal Settings or Logs are included.
