# Dose AA Macro v2.4

This is a shop-only repair plus release-version metadata. The next delivered update is v2.5. All other application behavior is preserved from v2.3, including both themes and the v2.2 chest-opening checks.

## Reported problem and behavior

The old shop bought Fishhook first, then clicked the original three-item coordinates for slots 3,2,1. Removing Fishhook reflows the other offers, so those stale coordinates could miss a remaining item. The supplied photos show Fishhook removed first, then Dagger from the lower of two remaining rows, with Reaper Scythe left above it.

HandleShop now uses shop-only helpers to capture the price-button column and detect connected gold plates. The detector uses saturated gold color plus button width/height/coverage, excluding small coin glyphs, thin item-name text and the green Continue button. It accepts at most three aligned candidates and requires repeated stable scans. This deliberately detects the common button background, not item-specific art or price digits. Purchase scanning is confined to calibrated x500…625/y160…375, outside the currency counter and Continue button.

Fishhook retains its existing reference/search/tolerance and X+150/Y purchase point. Its matched row is rechecked against visible purchase buttons, then attempted first. If its active gold plate cannot be found, the known working point is freshly rechecked and attempted before generic offers, without claiming independent success. A moved Fishhook row can be followed before input.

After each input the cursor moves outside the purchase column to remove hover effects, and the shop is re-scanned. A stable visible button-count decrease is logged as visual progress; normal Fishhook completion also checks that its marker is gone. Remaining buttons are selected from bottom to top at their current coordinates, supporting three/two/one offers and a final item that stays at middle height. The flow does not read inventory, item prices, coin balances or luck buffs.

The user explicitly chose: if an item still will not buy after a few attempts, try other items and continue. Accordingly, unconfirmed/possibly unaffordable offers are skipped for other offers, with bounded retries and a purchase-action budget. Layout changes clear the temporary skipped-row map so it cannot blindly retain old row coordinates. Remaining offers are logged rather than reported as purchased. Defaults are three attempts per offer, at most 12 purchase actions and a 60-second purchase budget. Continue is separately detected and the shop header must disappear twice; closing has its own bounded retries/deadline.

Covered/missing/moved windows, unavailable capture, ambiguous/unstable layouts or refused input fail explicitly instead of clicking behind an unresolved menu. The existing special-screen caller already propagates failure and is unchanged.

## Scope

Exactly three existing public application files change from v2.3: Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk (HandleShop and 13 new DungeonShop helpers), Lib/AppInfo.ahk and VERSION.txt (2.4 only). All **44 other existing dungeon function bodies**, including DungeonShopClick, are unchanged. There are **147 other byte-identical public application files**.

Main, UI/theme files, all production images, movement, room/current/future-rare selection, chest handling, shrine/curse policy, startup and configuration code are unchanged. Tests and documentation are updated separately. No personal Settings/Logs or webhook module were inspected or changed. The ZIP has empty Settings/Logs folders.

## Verification

AutoHotkey 2.0.19 / Wine 10 / isolated virtual display:

- **39 dynamic shop assertions**, using actual production classifier/stable scans/ordering/retry/skip/closing/caller with independently simulated BGRA frames and input. They cover Fishhook in every row, late Fishhook, 3→2→1 reflow, two/one/zero offers, last item staying in the middle, delayed removal, partial/all unaffordable offers, disabled Fishhook plate, input/capture/hover failures, missing Continue, unresolved closing, unstable/ambiguous layouts and failure propagation.
- **15 native shop-window assertions**, using real FindText references, GDI screenshot capture, color components, window/input wrappers and the complete shop flow on synthetic native shops. Clicks are simulated; they verify the actual Fishhook→Dagger→Scythe order, moving button positions, a final middle-row item, affordable-item attempts around a failed purchase, capture movement/occlusion and critical/mouse-mode restoration.
- **170 production dungeon logic assertions** and **37 chest-drain assertions** passed again with mocked game/screen/input.
- **14 real temporary-file default/configuration assertions** passed with release version 2.4.
- **83 Python source/geometry/policy checks**.

The inline photos were reviewed visually. The native fixtures reproduce their layout sequence using representative gold plates and decoded unchanged FindText references; they are not pixel-exact copies of the uploaded screenshots. No live Roblox session or actual purchase was run. Current live button-color sensitivity and actual inventory/buff application still need validation in-game. Logs distinguish attempted input and visual progress from independently verified purchases.

Current results are Tests/AutoHotkey_Shop_Verification.txt, AutoHotkey_ShopWindow_Verification.txt, AutoHotkey_Logic_Verification.txt, AutoHotkey_Chests_Verification.txt, AutoHotkey_Defaults_Verification.txt, Linux_Verification.txt and Regression_Comparison.txt. Earlier UI/window/theme/entrance records are retained as unchanged-code baselines and were not relabeled as fresh v2.4 executions.
