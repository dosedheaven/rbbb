# Dungeon chest and routing repair — v1.9

This is a separate repaired copy, updated as **curse-reference-fix-4** after reviewing the supplied room-dialog screenshots.

This update adds the existing `CurseOfShop` reference to the curse-identification map. It was previously omitted, so a Shop curse could be rejected as unknown when other curse exclusions were active. The Flight reference was already present. The executable logic test now covers recognizing Shop and allowing it when Wind is excluded; it mocks image matching and does not establish pixel sensitivity. No curse options or user settings were changed.

The user’s latest live log confirms selection, Enter detection, and loading Spirit World with no curse exclusions. Future Rare Chest branch association remains unverified. The new screenshot shows five previews above two current rooms, making the original three fixed search bands questionable. No new branch grouping was guessed. Research attempts could not access the game wikis, search engines, or YouTube from this environment; accessible public macro sources did not establish the preview connections. The inline screenshots are visible for review but unavailable as original image files to the pixel-testing tools, so they have not been incorporated as calibrated references.

The user confirmed that no curses are configured for avoidance. Earlier repairs still required identifying every cursed room and rejected an unidentified curse, unnecessarily stopping both valid routes. This version checks the active exclusion list: an empty list (or only `None`/blank slots) allows cursed rooms without running the curse-name detector. If exclusions are active or the configuration is unavailable, unknown curses remain blocked. The log explicitly reports whether exclusions are active. No personal configuration values were changed.

Future-pattern calls also now prevent FindText's implicit second pass at 5% error when the requested tolerance is zero. A tiny positive tolerance rounds to zero allowed pixel errors without enabling that fallback. An executable test proves the old zero/zero call accepts a one-pixel-changed pattern while the explicit exact call rejects it and still accepts the genuine pattern. This can reduce spurious future matches; it does not prove all three reported paths were false positives.

The preceding layout repair was too strict about complete marker detection. This follow-up accepts stable confirmed subsets within one layout family while continuing to reject mixed positions, unavailable cards, failed icon rechecks, and unsafe curses. Room marker searches now allow a small positional margin; Rare Chest search interiors and click points are unchanged. A completely invisible overlay no longer vetoes visible Roblox regions. Roblox is activated and the existing sizing routine is called when necessary before route scanning. Failures report per-room pattern misses or a specific window/size/coverage reason. The log prints `Dungeon detector: curse-reference-fix-4` to identify this build.

This is a separate repaired copy. Four existing source files were changed. No game, network, webhook, or private-server connection was made. Personal settings and historical logs were not inspected or edited.

## What was confirmed and fixed

1. **Rare Chest assigned to multiple candidates.** The original `SelectBestRoom()` repeated the same `247,325–561,457` image search for every candidate. A single match could label every room rare. Searches now use each detected room's own calibrated interior. Native ImageSearch requires the complete reference to fit within that interior. The supported room layouts have nonoverlapping interiors. The original left/right/center coordinates and tie order are retained.
2. **Future pattern 2 searched LEFT for CENTER and RIGHT.** Both supported patterns now use the same rectangle for the path being tested. All paths receive bounded sampling; an unavailable LEFT path no longer hides a reachable RIGHT path. Explicit card-position metadata covers the centered one-room layout, the two-room left/right layout, and the three-room layout. This uses the existing positional path model; it does not infer diagonal or crossing graph connections.
3. **Coordinate systems were mixed.** Dungeon FindText and PNG searches now share the original screen-coordinate calibration, translated using the actual Roblox window position. Searches validate the real client bounds and virtual desktop, including negative monitor coordinates. They reject a minimized, resized, off-screen, or obscured search region and reject movement during capture. The macro's transparent Roblox holder is allowed. PNG searches temporarily use Screen pixel mode and restore the caller's previous mode in `finally`; room clicks similarly restore Mouse mode and activate the actual Roblox HWND. The legacy FT/FixClick helpers remain unchanged.
4. **Fragile single observations.** Room borders must agree across two consecutive snapshots. Room icons and future paths receive three samples, with two hits required. Sampling adds at most 240 ms of deliberate waiting per group (up to 720 ms for layout + future + current icons), excluding native search time and the existing special-screen handlers. One inconclusive rare hit does not become a normal Chest. A failed PNG search operation disables both chest classifications for that scan.
5. **The two FindText chest patterns were identical.** Decoding the supplied pattern shows the shared 29 × 8 CHEST label. It does not encode rarity. The duplicate RareChest alias is disabled; the color PNG supplies rare evidence, and the generic CHEST label is accepted as normal only when all three successful rare-image searches miss. Other room-type patterns remain unchanged.
6. **Unsafe selection paths.** Unavailable rooms were not filtered, future paths bypassed curse protection, and the fallback could select a previously rejected room or click the center without a candidate. Current priorities and future paths now share eligibility, border revalidation, targeted clicks, and curse rejection. Future markers are rechecked before selection as well. Unknown curses are rejected conservatively when curse exclusions are configured; identifying a curse is unnecessary when all curses are allowed. There is no blind fallback. The configured `Exploding` curse name now matches detection (it previously reported `Explosion`).
7. **Stale route and diagnostics.** Existing shop/shrine/chest handling now runs before collecting room borders. Logs identify candidate index, physical path, border state, confirmed types, rare-hit count, exclusions, and selection reason. Debug mode also logs rare-image match coordinates. A new read-only Debug preset, **Dungeon Rooms / Rare Chests**, runs per-room classification without clicks. The image tester recognizes script-relative absolute-path initializers and uses the same window-aware PNG helper for RareChestImage.

## Reference image

`Images/RareChestImage.png` is unchanged. It is a valid, fully opaque 16 × 12 RGBA PNG with seven colors showing red/gold chest detail. Its small size is a limitation, but there is no labeled normal/rare screenshot set in the upload to justify a replacement or prove live sensitivity/specificity. Matching retains variation `*20`; it is not loosened. Room confinement, repeated evidence, and the existing color detail improve the decision process without inventing a new reference. If live matching still misses, use the existing RareChestImage image override with a representative crop captured at the macro's supported size, rather than immediately raising tolerance.

## Changed existing files

- `Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk`
- `Lib/Tools/WindowFollow.ahk`
- `Lib/Tools/Image.ahk`
- `Lib/Tools/DetectionTester.ahk`

Added: this report, Python/static tests, two offline AutoHotkey harnesses, a synthetic marker fixture, and recorded verification results. No personal configuration was changed. Seventeen unrelated dungeon function bodies (including shop, shrine, chest-opening, and Enter handling) and all seven legacy WindowFollow function bodies were checked unchanged. The remaining 132 non-private original files were byte-identical. Protected settings/log/webhook files were left alone; only their filenames and sizes were checked.

## Verification actually completed

**60 Python checks passed on Linux.** Run again from the project root:

```text
python Tests/test_dungeon_reliability.py
```

These checks use production-source geometry and an independent policy model. They cover the original shared-region bug, full-reference containment, Rare Chest in every supported room position, normal priorities and ties, unavailable/unknown rooms, rejected/allowed curses, future paths including both patterns, image-error and retry decisions, and negative-monitor coordinate translations. They also check quoted strings/comments and balanced AHK delimiters, mode restoration, production call structure, and offline-harness dependencies. Synthetic image tests use the actual unchanged PNG and verify that nonmatching colors do not pass at tolerance 20.

**AutoHotkey execution now completed:** All four changed source files also loaded successfully in the interpreter without executing Main/startup.  AutoHotkey **2.0.19** was run via **Wine 10** in an isolated virtual display. The packaged `Tests/DungeonLogicTests.ahk` passes **64 assertions** against production dungeon functions with game/screen/input hooks mocked. `Tests/WindowDetectionTests.ahk` passes **27 assertions** using real Win32 GUI APIs, the real FindText engine, and native ImageSearch against synthetic windows. The input callback is mocked; no real game clicks, configuration reads, private-server connections, or webhooks occur.

The window suite exercises a transparent macro holder, a fully transparent overlay, an opaque covering window, shifted marker detection, per-room PNG ownership, moved windows, negative outer origins with visible search regions, size repair, and coordinate-mode restoration. A comparison run against the previous ZIP reproduces the invisible-overlay rejection; the updated helper passes the same assertion. The narrow-column test demonstrates a marker missed by the original bounds and found by the expanded bounds. These are reproducible regressions; they do not establish which specific window or pattern condition caused the user's screenshot.

Run the two offline suites with AutoHotkey **v2** on Windows:

```text
"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /ErrorStdOut Tests\DungeonLogicTests.ahk
"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /ErrorStdOut Tests\WindowDetectionTests.ahk
```

Both include production helpers without Main, personal settings, or webhook code. The second creates temporary synthetic GUI windows, changes their focus/size, and then closes them. It does not send mouse input. Recorded outcomes are included under `Tests`.

**Actual Roblox and the user's Windows desktop have not been executed here.** Wine validates syntax and executable helper behavior under its Windows API implementation; it does not prove game icon sensitivity, live animation timing, Windows-specific overlays, mixed-DPI behavior, or end-to-end dungeon entry. The new diagnostic identifies the remaining failure reason if the route still cannot be recognized.

## Safe replacement and Windows checks

1. Stop the macro and back up your entire current installation.
2. Extract the download to a separate folder. Copy **only the four changed files listed above** into their corresponding paths in your existing installation. Keep your existing `Settings`, `Logs`, custom placements/movement, and detection overrides. Do not replace your configuration with defaults.
3. The full-source download includes all application source and image assets, plus empty `Settings`/`Logs` directories. Personal settings and historical logs are intentionally excluded from downloadable archives. The original uploaded archive and extracted personal files remain untouched.
4. Run the offline Windows harness with AutoHotkey **v2**, then launch your existing `Main.ahk` normally. Use the existing normal window size (816 × 638 in this version) and supported display scaling. Keep the relevant Roblox area visible and unobscured. These are screen-based detectors; hidden/minimized capture is not promised.
5. On the route screen, run **Debug → Quick Test → Dungeon Rooms / Rare Chests**. Check logs against actual one-, two-, and three-room screens. Confirm Normal versus Rare with real icons; check both future-pattern variants when available. No room is clicked by this preset. The separate single-image test scans all route cards and does not itself classify rooms.
6. Move Roblox to another visible location and, if available, a monitor with negative coordinates. Focus another nonoverlapping application and repeat the read-only test. Covering the search area should prevent classification, rather than detect the covering application. Mixed display scaling needs live verification.
7. During a supervised run, verify unavailable cards are excluded, avoided curses are dismissed, allowed curses can proceed, future preference obeys protection, configured normal priorities remain in order, and Boss entry/completion behavior remains correct.

**Deliberate conservative behavior:** empty/mixed/unstable candidate sets, ambiguous icons, all-unsuitable candidates, missing images, or unknown curses with active exclusions can stop room selection instead of choosing a default. Inspect the log/read-only preset and restart the macro after the route is visible and stable. No indefinite detection loop was added.

Restore the four backed-up source files to roll back. No settings migration is required. The startup log must show `Dungeon detector: curse-reference-fix-4` and, for the reported configuration, `Curse exclusions: none; all curses allowed`.
