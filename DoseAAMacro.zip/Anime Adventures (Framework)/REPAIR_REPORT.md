# Dose AA Macro v2.1

This release fixes the startup **Enter Dungeon** flow. The next delivered update is **v2.2**. Release version comes from `Lib/AppInfo.ahk`; `VERSION.txt`, header/window title, startup log, footer badge and detector log agree.

## Startup defect and repair

The preceding `DungeonMode` waited fixed delays, checked Enter Dungeon once, clicked a fixed point if matched, and called room selection whether or not entry succeeded. A delayed button or missed click could leave the large green entrance visible while the macro searched for room cards. This is a confirmed code weakness; the exact cause of the reported overnight stop cannot be established without its final log lines or a live reproduction.

`Lib/Modes/Dungeon/DungeonEntrance.ahk` now handles startup:

- Prepare/focus/restore the Roblox window through the existing validated helper.
- Resume an already-visible entrance or route instead of toggling the lobby menu.
- Preserve the original lobby button at client coordinates (85,400), converting it through ClientToScreen and the existing calibrated screen-input helper. No guessed title-bar offset is added.
- Wait for delayed Enter Dungeon or death Continue controls. The supplied Enter Dungeon reference/tolerance are retained; its search rectangle is expanded within the entrance area.
- Re-match immediately before input and click the detected text center, using window-aware input rather than the old fixed point.
- Retry confirmed buttons at 1.5-second intervals, with at most six total action clicks and a 45-second deadline.
- Require two consecutive matching valid route layouts before handing off to room selection. A disappearing button by itself is not treated as success.
- Stop on unreadable/obscured screens or refused input and log the cause. Timeout logs identify the last scene and click count; there is no blind fallback click.

The room-selection entry point also recognizes a reappearing startup Enter Dungeon screen and runs this same entrance handler before special-screen/room scans. Room-dialog Enter remains separate and unchanged.

The routine can time out if the supplied image reference no longer matches the live game, input remains refused, or the expected transition never appears. This repair does not claim universal recovery from an unknown screen or prove the exact overnight cause.

## Preserved behavior

The v2.0 appearance, viewport/calibration, icons/font/artwork and Dungeon defaults are unchanged. Defaults remain Rare_Chest → Chest → Shop → Shrine → Hoard → Boss; all avoided curses None; avoided shrines Burst, Chaos, Vamparism, None, None, None. The one-time `DoseDungeonPreset-v2.txt` marker continues to preserve later custom edits; this release does not reset it.

Shop/Fishhook behavior, shrine handling, chest saving/opening, curse policy, current/future Rare Chest ordering, reward ties, and all room-selection functions are unchanged. The discussed moving-shop-button and shrine-scrolling repairs are not included. The user-rejected floor20-save-fix-8 change remains omitted.

Compared with v2.0, only four existing public application files changed: `Lib/AppInfo.ahk`, `VERSION.txt`, `Lib/GameMango.ahk` (DungeonMode wrapper and helper include), and `Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk` (startup guard). The entrance helper is new. **139 other public application files** are byte-identical. All **44 other dungeon function bodies** and every unrelated lifecycle function are unchanged.

## Verification

AutoHotkey **2.0.19** ran via Wine **10** on an isolated virtual display:

- **33 startup assertions:** delayed/moving/disappearing buttons, missed clicks/retries, click caps/deadlines, blocked/refused input, stable-route confirmation, death Continue, existing screens, native client-coordinate conversion, actual DungeonMode handoff, and recovery before special menus. Screen matching/input are mocked; client conversion uses a real native window. Production wrapper/guard bodies are extracted without Main/private startup.
- **57 native window/image assertions:** real Win32 GUI, FindText and ImageSearch, including the unchanged Enter Dungeon reference rendered as a synthetic bitmap, expanded search, calibrated center clicks, window movement, client conversion, and obscured-entrance rejection. Input is recorded rather than delivered.
- **170 production dungeon logic assertions**, screen/input mocked.
- **16 shop-priority assertions**, screen/input mocked.
- **26 native Advanced-panel assertions**, configuration saving mocked.
- **14 default/configuration assertions**, real IO in synthetic temporary settings only.
- **21 rendered-UI assertions**, isolated production GUI/events/styles/panels with game/services and unchanged external panels stubbed; version 2.1 and existing geometry/controls verified.
- **83 Python source/geometry/policy checks**.

Current results are `Tests/AutoHotkey_*_Verification.txt`, `Tests/Linux_Verification.txt`, and `Tests/Regression_Comparison.txt`. Other named regression notes describe earlier repairs. `PrepareEntranceTests.py` and `PrepareDefaultsTests.py` regenerate offline production-function includes; neither reads private application data.

No live Roblox session was run. Synthetic matching establishes interpreter/window behavior, not current live-game image sensitivity. The original upload and private Settings/Logs/webhook module were not edited or inspected; the downloadable ZIP contains empty Settings/Logs folders without personal configuration or logs.
