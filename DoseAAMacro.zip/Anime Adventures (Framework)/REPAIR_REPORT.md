# Dungeon chest and routing repair — v1.9

This is a separate repaired copy. Four existing source files were changed. No game, network, webhook, or private-server connection was made. Personal settings and historical logs were not inspected or edited.

## What was confirmed and fixed

1. **Rare Chest assigned to multiple candidates.** The original `SelectBestRoom()` repeated the same `247,325–561,457` image search for every candidate. A single match could label every room rare. Searches now use each detected room's own calibrated interior. Native ImageSearch requires the complete reference to fit within that interior. The supported room layouts have nonoverlapping interiors. The original left/right/center coordinates and tie order are retained.
2. **Future pattern 2 searched LEFT for CENTER and RIGHT.** Both supported patterns now use the same rectangle for the path being tested. All paths receive bounded sampling; an unavailable LEFT path no longer hides a reachable RIGHT path. Explicit card-position metadata covers the centered one-room layout, the two-room left/right layout, and the three-room layout. This uses the existing positional path model; it does not infer diagonal or crossing graph connections.
3. **Coordinate systems were mixed.** Dungeon FindText and PNG searches now share the original screen-coordinate calibration, translated using the actual Roblox window position. Searches validate the real client bounds and virtual desktop, including negative monitor coordinates. They reject a minimized, resized, off-screen, or obscured search region and reject movement during capture. The macro's transparent Roblox holder is allowed. PNG searches temporarily use Screen pixel mode and restore the caller's previous mode in `finally`; room clicks similarly restore Mouse mode and activate the actual Roblox HWND. The legacy FT/FixClick helpers remain unchanged.
4. **Fragile single observations.** Room borders must agree across two consecutive snapshots. Room icons and future paths receive three samples, with two hits required. Sampling adds at most 240 ms of deliberate waiting per group (up to 720 ms for layout + future + current icons), excluding native search time and the existing special-screen handlers. One inconclusive rare hit does not become a normal Chest. A failed PNG search operation disables both chest classifications for that scan.
5. **The two FindText chest patterns were identical.** Decoding the supplied pattern shows the shared 29 × 8 CHEST label. It does not encode rarity. The duplicate RareChest alias is disabled; the color PNG supplies rare evidence, and the generic CHEST label is accepted as normal only when all three successful rare-image searches miss. Other room-type patterns remain unchanged.
6. **Unsafe selection paths.** Unavailable rooms were not filtered, future paths bypassed curse protection, and the fallback could select a previously rejected room or click the center without a candidate. Current priorities and future paths now share eligibility, border revalidation, targeted clicks, and curse rejection. Future markers are rechecked before selection as well. Unknown curses are rejected conservatively. There is no blind fallback. The configured `Exploding` curse name now matches detection (it previously reported `Explosion`).
7. **Stale route and diagnostics.** Existing shop/shrine/chest handling now runs before collecting room borders. Logs identify candidate index, physical path, border state, confirmed types, rare-hit count, exclusions, and selection reason. Debug mode also logs rare-image match coordinates. A new read-only Debug preset, **Dungeon Rooms / Rare Chests**, runs per-room classification without clicks. The image tester recognizes script-relative absolute-path initializers and uses the same window-aware PNG helper for RareChestImage.

## Reference image

`Images/RareChestImage.png` is unchanged. It is a valid, fully opaque 16 × 12 RGBA PNG with seven colors showing red/gold chest detail. Its small size is a limitation, but there is no labeled normal/rare screenshot set in the upload to justify a replacement or prove live sensitivity/specificity. Matching retains variation `*20`; it is not loosened. Room confinement, repeated evidence, and the existing color detail improve the decision process without inventing a new reference. If live matching still misses, use the existing RareChestImage image override with a representative crop captured at the macro's supported size, rather than immediately raising tolerance.

## Changed existing files

- `Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk`
- `Lib/Tools/WindowFollow.ahk`
- `Lib/Tools/Image.ahk`
- `Lib/Tools/DetectionTester.ahk`

Added: this report, `Tests/test_dungeon_reliability.py`, `Tests/DungeonLogicTests.ahk`, and recorded Linux test results. No personal configuration was changed. Seventeen unrelated dungeon function bodies (including shop, shrine, chest-opening, and Enter handling) and all seven legacy WindowFollow function bodies were checked unchanged. The remaining 132 non-private original files were byte-identical. Protected settings/log/webhook files were left alone; only their filenames and sizes were checked.

## Verification actually completed

**53 Python checks passed on Linux.** Run again from the project root:

```text
python Tests/test_dungeon_reliability.py
```

These checks use production-source geometry and an independent policy model. They cover the original shared-region bug, full-reference containment, Rare Chest in every supported room position, normal priorities and ties, unavailable/unknown rooms, rejected/allowed curses, future paths including both patterns, image-error and retry decisions, and negative-monitor coordinate translations. They also check quoted strings/comments and balanced AHK delimiters, mode restoration, production call structure, and offline-harness dependencies. Synthetic image tests use the actual unchanged PNG and verify that nonmatching colors do not pass at tolerance 20.

**These are static checks and simulations, not an AutoHotkey interpreter or Roblox run.** AutoHotkey, Wine, and Roblox were unavailable on the repair host. Windows syntax loading, native screen capture/click APIs, mixed-DPI behavior, actual game animations, icon discrimination, and end-to-end dungeon entry remain unverified.

An offline **Windows AutoHotkey v2 harness** is included:

```text
"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /ErrorStdOut Tests\DungeonLogicTests.ahk
```

It includes the actual production dungeon functions and patterns, with mocked game/screen/input hooks. It does not include Main, open settings, or send network requests. It checks production classification, future patterns, selection priorities, unavailable/cursed handling, boss flags, and fallback refusal. It should take approximately 30–45 seconds and print a PASS count or FAIL. **This harness was statically checked but was not executed here.** It does not exercise the native window helpers.

## Safe replacement and Windows checks

1. Stop the macro and back up your entire current installation.
2. Extract the download to a separate folder. Copy **only the four changed files listed above** into their corresponding paths in your existing installation. Keep your existing `Settings`, `Logs`, custom placements/movement, and detection overrides. Do not replace your configuration with defaults.
3. The full-source download includes all application source and image assets, plus empty `Settings`/`Logs` directories. Personal settings and historical logs are intentionally excluded from downloadable archives. The smaller overlay contains just the four replacement files. The original uploaded archive and extracted personal files remain untouched.
4. Run the offline Windows harness with AutoHotkey **v2**, then launch your existing `Main.ahk` normally. Use the existing normal window size (816 × 638 in this version) and supported display scaling. Keep the relevant Roblox area visible and unobscured. These are screen-based detectors; hidden/minimized capture is not promised.
5. On the route screen, run **Debug → Quick Test → Dungeon Rooms / Rare Chests**. Check logs against actual one-, two-, and three-room screens. Confirm Normal versus Rare with real icons; check both future-pattern variants when available. No room is clicked by this preset. The separate single-image test scans all route cards and does not itself classify rooms.
6. Move Roblox to another visible location and, if available, a monitor with negative coordinates. Focus another nonoverlapping application and repeat the read-only test. Covering the search area should prevent classification, rather than detect the covering application. Mixed display scaling needs live verification.
7. During a supervised run, verify unavailable cards are excluded, avoided curses are dismissed, allowed curses can proceed, future preference obeys protection, configured normal priorities remain in order, and Boss entry/completion behavior remains correct.

**Deliberate conservative behavior:** incomplete/unstable layouts, ambiguous icons, all-unsuitable candidates, missing images, or unknown curses can now stop room selection instead of choosing a default. Inspect the log/read-only preset and restart the macro after the route is visible and stable. No indefinite detection loop was added.

Restore the four backed-up source files to roll back. No settings migration is required.
