# Dose AA Macro v2.3

This is a UI-only release. It keeps Astral and adds Tokyo Ghoul, removing the other color-only choices. The next delivered update is v2.4. Version comes from Lib/AppInfo.ahk and matches VERSION.txt and the live header/footer/log version.

## Requested themes

The picker contains exactly **Astral** and **Tokyo Ghoul**. Astral retains the original violet/cyan palette and the exact original DoseArcane.png artwork. The previous saved Arcane name aliases Astral. Removed or unknown saved color names fall back to Astral without overwriting that preference file during reading.

Tokyo Ghoul adds original Kaneki anime artwork with dark charcoal/crimson colors, a red eye motif, matching cards/buttons/dividers/highlights and themed decorative headings. The OFL-licensed New Rocker font is bundled with its license and loaded privately; body labels and input controls retain readable fonts. Existing toolbar icons remain functional and use the matching colorway. The selected theme has a decorative header signature.

The existing theme save/restart handler is byte-identical. Selection saves to the same Theme.txt file. An idle macro keeps its existing restart prompt; an active run saves the preference for a later restart without being reloaded. Missing art/display-font handling remains nonthrowing with a plain-color/readable-font fallback. No runtime image or font downloads are added.

## Preserved scope

Only six existing public application files differ from v2.2: Lib/GUI.ahk, Lib/GuiStyle.ahk, Lib/GuiSkin.ahk, Lib/GuiPanels.ahk, Lib/AppInfo.ahk and VERSION.txt. New files are Tokyo artwork, the display font/license, tests, documentation and verification records. **140 other public application files** are byte-identical.

All gameplay, dungeon/chest/shop/shrine/entrance logic, movement, image references, detection helpers and settings event handlers are byte-identical to v2.2. This retains the verified chest-draining repair and startup repair. The pending shop-button and shrine-scrolling changes are not included.

Every existing main-window and panel OnEvent binding is unchanged. Unit option lists and non-theme settings controls remain unchanged. Unit-card geometry is unchanged; its divider uses the selected palette. The only Settings-panel changes are its Anime Theme label and the two-row theme popup. New decorative text has no click callbacks.

The game window target remains 816×638 with offsets (-5,1), and the transparent holder remains x3/y33/w797/h597. The transparency key remains 303030; palettes avoid it elsewhere. Wallpaper remains x804/y31/w558/h666. Every new decoration stays outside the game rectangle.

## Verification

AutoHotkey 2.0.19 / Wine 10 / isolated virtual display:

- **31 theme assertions:** exact available choices, missing/legacy/retired/invalid preference handling, native picker save/load with actual temporary file IO, theme application, palette contrast/color key, separate packaged art, missing-art fallback, private display-font loading, heading/signature behavior and unchanged deferred application during a run.
- **27 Tokyo Ghoul rendered-UI assertions** and **25 Astral assertions:** actual production GUI/events/styles/panels/config, game viewport geometry, actual window-aware capture acceptance, body-font readability, selected artwork bounds, version 2.3, default selections and persistence, theme picker contents, navigation, placement-menu toggle, minimize and close. Tokyo also checks actual native title/activity font faces.
- **14 default/configuration assertions**, using real synthetic temporary files only.
- **26 native Advanced-panel assertions**, saving mocked.
- **83 Python source/geometry/policy checks**.

Both Main and Advanced views were captured and visually inspected. The UI preview excludes private startup and stubs game/services and unchanged external panel implementations. Wine uses a test-only font substitution for unavailable Segoe UI; actual Windows font metrics/control rendering can differ. No system-font change is made by the distributed app.

Current results: Tests/AutoHotkey_Themes_Verification.txt, AutoHotkey_TokyoUI_Verification.txt, AutoHotkey_AstralUI_Verification.txt, AutoHotkey_UI_Verification.txt, AutoHotkey_Defaults_Verification.txt, AutoHotkey_RoutePanel_Verification.txt, Linux_Verification.txt and Regression_Comparison.txt. Gameplay test records from v2.2 are retained as the unchanged-code baseline; they were not relabeled as new v2.3 executions.

No live Roblox session was run. Binary/source comparisons establish that gameplay code and detection images are unchanged, not a new live gameplay guarantee. Working private Settings/Logs/webhook module and original uploads were not inspected or edited. The ZIP contains empty Settings/Logs folders without personal settings or logs.
