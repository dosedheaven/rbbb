# Dose AA Macro v2.6

Fixes tied current rare-chest rooms being selected in scan order before future paths were checked. All detected current cards are classified first. At the configured Rare Chest priority, future previews are scanned once and reused. Tied current rares prefer a confirmed future rare, then extra confirmed current rewards in the saved priority order. Equal candidates keep a stable order.

A spatially separate CHEST label can contribute an extra Chest tie bonus after two of three samples; the rare's own shared label and neighboring-card labels cannot. The original current-room classifier is unchanged. Candidate evidence and the ranked path order are logged.

Current rares still precede future-only routes at Rare Chest's configured rank. Curse exclusions, current card/icon revalidation, single OPEN/boss cards, ordinary rooms and failed-choice fallbacks retain their existing behavior. RareChest Path off disables future tie scoring. See RARE_ROOM_SELECTION.md for examples and limits.

Only SelectBestRoom, four added tie-comparison/evidence helpers, and version metadata change in the application. All 57 other dungeon function bodies are unchanged from v2.5. Shop buying, shrine policy, chest saving/opening, movement, startup, UI, artwork, detection references, settings and window helpers are retained.

Tests/Regression_Comparison.txt records the scope comparison. Native routing checks use screen/input mocks; image checks use real Win32 windows, FindText and ImageSearch with synthetic fixtures. These checks are not a live Roblox run. Earlier unrelated UI/shop/chest verification records retain their original release labels.

The ZIP excludes personal Settings and Logs. Preserve your existing Settings folder when installing the extracted update. The window and log header report v2.6.
