# Dose AA Macro v2.7

Replaces the cramped layout with a wider 1800x930 Akatsuki dashboard: two columns of unit cards, clear navigation, separate profile/run controls, a wider activity area, rounded surfaces and angled window corners. Your supplied image appears as a full group banner and an Itachi/Pain close-up in the large artwork column. The palette matches its charcoal, crimson and ivory colors. Akatsuki is the only selectable theme.

All original controls and their callbacks are retained. The existing configuration save/load implementation and file formats are unchanged, including all six placement profiles. Roblox's viewing rectangle, window size and offsets stay fixed. Copy your existing Settings folder into the extracted app before starting the update. The layout is designed for 1920x1080 at 100% Windows scaling.

Dungeon priorities, rare-room tie comparison, future routing, shop buying, shrine/curse policy, chest saving/opening, movement, entrance handling, configuration and original GUI event code are byte-identical to v2.6. The application changes are limited to presentation/theme files, a new dashboard layout module, and version metadata. See Tests/Regression_Comparison.txt.

Current native checks cover actual settings save/load on synthetic files, profile/navigation switches, every mode's visible context controls, all panels, text fit, font loading, image rendering and viewport geometry. Check totals and scope are recorded in Tests. Verification uses AutoHotkey 2.0.19 under Wine on an isolated display, not a live Roblox session. Earlier unrelated gameplay verification records keep their original release labels.

The original JPEG is bundled unchanged; see ARTWORK_SOURCES.md for its SHA-256. Rendering crops the image at runtime and does not require network access. Fonts remain process-private. The ZIP excludes personal Settings and Logs. The window and startup log report v2.7.
