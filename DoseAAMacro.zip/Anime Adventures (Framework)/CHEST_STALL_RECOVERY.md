# Chest stall recovery — v3.2

After a failed chest-opening/claim check, the macro keeps the current chest session active instead of immediately returning from the macro. Confirmed Open-to-reward and reward-to-menu transitions record progress; sending a click alone does not reset the inactivity clock.

After 120 seconds without confirmed progress, it validates Roblox and rescans the current screen. A chest menu must match twice before Common/Rare opening restarts. A reward that returns to the chest menu late can resume immediately during passive observation. If a reward was already pending from a confirmed Open transition, recovery may retry the existing claim routine after rejecting a fresh entrance/lobby screen. Unknown screens without that pending-reward context receive no guessed clicks.

There are at most two inactivity recovery attempts within the existing 15-minute overall chest deadline. Missing/blocked windows and unknown screens are logged; recovery does not switch rooms, press Continue, return to the lobby, or rejoin. Exhaustion logs an explicit stopped/unverified message.

All original safeguards remain: save intermediate chests when configured; open boss chests; handle rewards; require both Common and Rare counters positively empty together for three consecutive checks before Continue and post-boss entrance recovery are unlocked. The existing five-Enter/30-second lobby recovery is unchanged and remains disabled until that final empty proof succeeds.

Useful log messages: Chest opening has not completed; Chest inactivity recovery 1/2; Chest recovery: menu confirmed; resuming pending reward claim; attempts exhausted. A timer cannot prove a screen is recognized, so an unknown live reward/menu may still require updated detection rather than an unsafe skip.
