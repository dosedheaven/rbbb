# Chest reward queues and stall recovery — v3.3

After a failed chest-opening/claim check, the macro keeps the current chest session active instead of immediately returning from the macro. Confirmed Open-to-reward and reward-to-menu transitions record progress; sending a click alone does not reset the inactivity clock.

After 120 seconds without confirmed progress, it validates Roblox and rescans the current screen. A chest menu must remain visible continuously for three seconds, with repeated positive samples, before Common/Rare opening restarts. Brief menu flashes between two item popups reset that timer. A pending reward that returns to a stable menu late can resume during passive observation. If a reward was already pending from a confirmed Open transition, recovery may retry the existing claim routine after rejecting a fresh entrance/lobby screen. Unknown screens without that pending-reward context receive no guessed clicks.

There are at most two inactivity recovery attempts within the existing 15-minute overall chest deadline. Missing/blocked windows and unknown screens are logged; recovery does not switch rooms, press Continue, return to the lobby, or rejoin. Exhaustion logs an explicit stopped/unverified message.

All original safeguards remain: save intermediate chests when configured; open boss chests; handle rewards; require both Common and Rare counters positively empty together for three consecutive checks before Continue and post-boss entrance recovery are unlocked. The existing five-Enter/30-second lobby recovery is unchanged and remains disabled until that final empty proof succeeds.

Useful log messages: Chest opening has not completed; Chest inactivity recovery 1/2; Chest recovery: menu confirmed; resuming pending reward claim; attempts exhausted. A timer cannot prove a screen is recognized, so an unknown live reward/menu may still require updated detection rather than an unsafe skip.


2x/sequential drops: the claim loop keeps the same chest reward queue active across temporary menu appearances. It can dismiss normal single drops, two separate drops, or longer sequences within the existing claim limits. Sending a claim click is not proof that an item was received. Late extra-drop context is retained for guarded recovery until the next Open attempt or joint final empty proof. Final Common/Rare empty verification also requires a three-second stable window before Continue is unlocked.
