#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\AppInfo.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; Actual Advanced panel and native dropdown controls, without Main, configuration,
; game startup, file saving, webhooks, or desktop input. Window stays hidden.
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\RoutePriorityPicker.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\CursePriorityPicker.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\ShrinePriorityPicker.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Utilities.ahk
#Include %A_ScriptDir%\..\Lib\GuiPanels.ahk

global aaMainUI := Gui("+ToolWindow -DPIScale")
global uiTheme := ["F2F2F2","181818","E87522","242424","303030","111111","FFC074"]
global AA_CardColor := "242424", debugMessages := false
global PHChecks := 0, PHSaveCalls := 0

PHAssert(condition,label) {
    global PHChecks
    PHChecks += 1
    if !condition
        throw Error(label)
}

PHMain()

PHMain() {
try {
    AA_BuildAdvancedPanel()
    expected := DungeonDefaultRoutePriorities()
    PHAssert(routeDropDowns.Length=6,"all six route dropdowns exist")
    for index, priority in expected
        PHAssert(routeDropDowns[index].Text=priority,"fresh route dropdown " index " follows its default priority")
    for dd in curseDropDowns
        PHAssert(dd.Text="None","fresh curse defaults remain None")
    for row, dd in shrineDropDowns
        PHAssert(dd.Text=DoseDungeonDefaults().shrines[row],"fresh shrine defaults match requested screenshot")
    PHAssert(AA_Panels["Advanced"].Length=46,"advanced panel control count and options preserved")
    routeDropDowns[1].Choose(3)
    OnRouteDropDownChange(routeDropDowns[1],1)
    PHAssert(routePriorityOrder[1]="Hoard","native dropdown change updates the actual runtime preference")
    PHAssert(PHSaveCalls=1,"native dropdown change invokes one mocked save without writing settings")
    order := DungeonEffectiveRoutePriorities(&detail), seen := Map()
    PHAssert(order[1]="Hoard","effective order retains the edited first preference")
    for priority in order
        seen[priority] := true
    PHAssert(order.Length=6 && seen.Count=6,"effective route order remains complete and unique after editing")
    FileAppend("PASS: " PHChecks " native route-panel assertions (configuration saving mocked).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
} finally {
    aaMainUI.Destroy()
}
}

AA_Card(x,y,w,h,text,panel := "Settings") {
    return AA_PanelPush(aaMainUI.Add("GroupBox",Format("x{} y{} w{} h{} Hidden",x,y,w,h),text),panel)
}
AA_Btn(*) {
    throw Error("No extra buttons expected while building only the Advanced panel")
}
SaveDungeonLocal(*) {
    global PHSaveCalls
    PHSaveCalls += 1
}
AddToLog(*) {
}
