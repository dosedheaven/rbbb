# v2.5 UI verification

AutoHotkey 2.0.19 under Wine 10 on an isolated 1920x1080 display at 96 DPI. Segoe UI is substituted with DejaVu Sans in the test environment only; the distributed app does not install fonts or change Windows settings. Bundled icon/display fonts load privately.

The preview constructs the actual main UI, Settings, Advanced, Custom Map, Custom Placement and all five Guide pages from the production source. Private settings/log startup is removed and replaced with temporary synthetic files. Record/replay, game and network callbacks are substituted. Debug, Scheduler and Card contents are placeholders in this preview; toolbar navigation is checked, not their full live behavior.

Checks cover unconfirmed/confirmed mode visibility, header/divider separation, full log hover values, text bounds using native font metrics, footer switch toggles against the original checkbox values, panel navigation, theme/font/assets, defaults persistence and unchanged viewport/game sizing. Screens are also inspected visually. The artwork uses unchanged original files with runtime proportional crops and dimming.

See AutoHotkey_TokyoUI_Verification.txt and AutoHotkey_AstralUI_Verification.txt for current results. AnimeThemeTests.ahk, DungeonDefaultsTests.ahk, RoutePriorityPanelTests.ahk and the 83 Python checks were also rerun for v2.5. Regression_Comparison.txt verifies that all dungeon, shop, chest, startup and detection code is unchanged from v2.4; movement/placement/guide differences are help strings only. Earlier gameplay verification files keep their original release labels.

This is native synthetic-window verification, not a live Roblox run or a test of every Windows display-scale/font combination.
