"""Source-derived geometry and an independent routing model, NOT an AHK runtime.
Run: python Tests/test_dungeon_reliability.py
No Roblox access, credentials, configuration reads, clicks, or dependencies.
"""
from pathlib import Path
from collections import Counter
import itertools
import re
import struct
import unittest
import zlib

ROOT = Path(__file__).resolve().parents[1]
DUNGEON = (ROOT / 'Lib/Modes/Dungeon/Dungeon_FutureRareChest.ahk').read_text(encoding='utf-8-sig')
WINDOW = (ROOT / 'Lib/Tools/WindowFollow.ahk').read_text(encoding='utf-8-sig')
IMAGES = (ROOT / 'Lib/Tools/Image.ahk').read_text(encoding='utf-8-sig')
DEBUG = (ROOT / 'Lib/Tools/DetectionTester.ahk').read_text(encoding='utf-8-sig')


def lex(source):
    """Strip AHK quoted strings/comments for delimiter checks (not a full parser)."""
    out, i, quote, block = [], 0, None, False
    while i < len(source):
        c = source[i]
        if block:
            if source.startswith('*/', i):
                block = False; i += 2
            else:
                i += 1
            continue
        if quote:
            if c == '`':
                i += 2
            elif c == quote:
                quote = None; i += 1
            else:
                if c == '\n':
                    raise AssertionError('Unexpected newline in quoted string')
                i += 1
            continue
        if source.startswith('/*', i):
            block = True; i += 2
        elif c == ';':
            end = source.find('\n', i)
            i = len(source) if end < 0 else end
        elif c in '\"\'':
            quote = c; i += 1
        else:
            out.append(c); i += 1
    if quote or block:
        raise AssertionError('Unclosed string or block comment')
    return ''.join(out)


def function(source, name):
    match = re.search(r'^' + re.escape(name) + r'\([^\n]*\)\s*\{', source, re.M)
    if not match:
        raise AssertionError('Function missing: ' + name)
    # Count braces with quotes/comments stripped, preserving the full suffix.
    suffix = source[match.end()-1:]
    clean = lex(suffix)
    depth = 0
    for i, c in enumerate(clean):
        depth += (c == '{') - (c == '}')
        if depth == 0:
            return clean[:i+1]
    raise AssertionError('Unclosed function: ' + name)


def areas():
    block = DUNGEON[DUNGEON.index('DungeonRoomAreas()'):DUNGEON.index('DungeonBorderText(')]
    result = {}
    for i, row in enumerate(re.findall(r'\{x1:.*?\}', block), 1):
        result[i] = {k: int(v) for k, v in re.findall(r'(\w+): (\d+)', row)}
        result[i]['path'] = re.search(r'path: "(\w+)"', row)[1]
    return result


AREAS = areas()
FUTURE = {m[0]: tuple(map(int, m[1:])) for m in re.findall(
    r'\{path: "(\w+)", x1: (\d+), y1: (\d+), x2: (\d+), y2: (\d+)\}', DUNGEON)}
LAYOUTS = [(3,), (4, 5), (1, 2, 3)]
PRIORITIES = ['Rare_Chest', 'Chest', 'Hoard', 'Shop', 'Shrine', 'Boss']


def valid(ids):
    return bool(ids) and len(ids) == len(set(ids)) and any(set(ids) <= set(x) for x in LAYOUTS)


def png_pixels(path):
    """Decode this supplied 8-bit RGBA PNG using only the standard library."""
    data = path.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    payload, pos = b'', 8
    while pos < len(data):
        n = struct.unpack('>I', data[pos:pos+4])[0]
        kind, body = data[pos+4:pos+8], data[pos+8:pos+8+n]
        assert zlib.crc32(kind+body) & 0xffffffff == struct.unpack('>I', data[pos+8+n:pos+12+n])[0]
        if kind == b'IHDR':
            w, h, bits, color, comp, filt, interlace = struct.unpack('>IIBBBBB', body)
            assert (bits, color, comp, filt, interlace) == (8, 6, 0, 0, 0)
        if kind == b'IDAT': payload += body
        pos += n + 12
    raw = zlib.decompress(payload)
    previous, rows, stride = [0]*(w*4), [], w*4
    for y in range(h):
        f = raw[y*(stride+1)]
        row = list(raw[y*(stride+1)+1:(y+1)*(stride+1)])
        for i in range(stride):
            a, b, c = (row[i-4] if i >= 4 else 0), previous[i], (previous[i-4] if i >= 4 else 0)
            if f == 1: value = a
            elif f == 2: value = b
            elif f == 3: value = (a+b)//2
            elif f == 4:
                p = a+b-c
                distances = (abs(p-a), abs(p-b), abs(p-c))
                value = (a, b, c)[distances.index(min(distances))]
            elif f == 0: value = 0
            else: raise AssertionError('Unknown PNG filter')
            row[i] = (row[i] + value) & 255
        rows.append([tuple(row[i:i+3]) for i in range(0, stride, 4)])
        previous = row
    return rows


TEMPLATE = png_pixels(ROOT/'Images/RareChestImage.png')
TH, TW = len(TEMPLATE), len(TEMPLATE[0])


def rect(index):
    a = AREAS[index]
    return tuple(a[k] for k in ('searchX1','searchY1','searchX2','searchY2'))


def paste(scene, x, y, template=TEMPLATE):
    for yy, row in enumerate(template):
        for xx, color in enumerate(row):
            scene[x+xx, y+yy] = color


def match(scene, box, tolerance=20):
    x1,y1,x2,y2 = box
    # Entire 16x12 reference must fit in THIS room, as with native ImageSearch.
    for y in range(y1,y2-TH+2):
        for x in range(x1,x2-TW+2):
            if all(all(abs(scene.get((x+xx,y+yy), (0,0,0))[k]-color[k]) <= tolerance
                       for k in range(3))
                   for yy,row in enumerate(TEMPLATE) for xx,color in enumerate(row)):
                return True
    return False


def classify(rare, generic=3, image_ok=True):
    if image_ok and rare >= 2: return 'Rare_Chest'
    if image_ok and rare == 0 and generic >= 2: return 'Chest'
    return None


def select(rooms, priorities=PRIORITIES, future=(), curse_exclusions=True):
    """Independent model of production priority/safety policy, not AHK execution."""
    rejected = set()
    def eligible(r):
        return r['id'] not in rejected and r.get('state','Available') in ('Available','Cursed','Opening','Boss')
    def enter(r):
        if not r.get('click_ok',True) or not r.get('recheck',True):
            rejected.add(r['id']); return None
        if curse_exclusions and r.get('state') == 'Cursed' and r.get('curse','unknown') in ('skip','unknown'):
            rejected.add(r['id']); return None
        return r['id']
    if not valid([r['id'] for r in rooms]): return None
    if len(rooms)==1 and rooms[0]['id']==3 and rooms[0].get('state')=='Boss':
        if 'Boss' in rooms[0].get('icons',()): return enter(rooms[0])
        return None
    for path in future:
        for r in rooms:
            if eligible(r) and AREAS[r['id']]['path'] == path:
                chosen = enter(r)
                if chosen: return chosen
    for p in priorities:
        for r in rooms:
            if eligible(r) and p in r.get('icons',()):
                chosen = enter(r)
                if chosen: return chosen
    for r in rooms:
        if (eligible(r) and r.get('normal_confirmed',False)
                and r.get('state','Available') in ('Available','Cursed')
                and not r.get('icons',())):
            chosen = enter(r)
            if chosen: return chosen
    return None


def room(i, icons=(), **kwargs):
    return dict(id=i, icons=icons, **kwargs)


class GeometryTests(unittest.TestCase):
    def test_layout_definitions(self):
        self.assertEqual(len(AREAS),5)
        self.assertEqual([AREAS[i]['clickX'] for i in range(1,6)], [250,555,400,322,477])
    def test_partial_compatible_layouts_remain_usable(self):
        for ids in [(1,),(2,),(4,),(5,),(1,2),(1,3),(2,3)]:
            self.assertTrue(valid(ids),ids)
            rs=[room(i,['Chest']) for i in ids]
            self.assertEqual(select(rs),ids[0])

    def test_layout_acceptance(self):
        for ids in LAYOUTS: self.assertTrue(valid(ids))
    def test_mixed_duplicate_invalid_layouts_rejected(self):
        for ids in [(),(3,4),(1,5),(4,4),(0,),(6,),(1,2,3,4,5)]:
            self.assertFalse(valid(ids),ids)
    def test_asset_decodes_and_is_small_color_reference(self):
        self.assertEqual((TW,TH),(16,12))
        self.assertEqual(len(set(itertools.chain.from_iterable(TEMPLATE))),7)
    def test_each_room_matches_only_its_own_crop(self):
        for layout in LAYOUTS:
            for target in layout:
                with self.subTest(layout=layout,target=target):
                    scene={}; x1,y1,x2,y2=rect(target)
                    paste(scene,(x1+x2-TW)//2,(y1+y2-TH)//2)
                    self.assertEqual([i for i in layout if match(scene,rect(i))],[target])
    def test_expanded_marker_columns_remain_separate(self):
        columns={i:(a['x1']-12,a['x2']+12) for i,a in AREAS.items()}
        for first,second in itertools.combinations(columns,2):
            a,b=columns[first]; c,d=columns[second]
            self.assertTrue(b<c or d<a,(first,second))

    def test_entire_reference_must_fit(self):
        scene={}; x1,y1,x2,y2=rect(3); paste(scene,x2-TW+2,y1)
        self.assertFalse(match(scene,rect(3)))
    def test_original_shared_region_reproduces_bug(self):
        scene={}; paste(scene,250,360)
        original=[i for i in (1,2,3) if match(scene,(247,325,561,457))]
        corrected=[i for i in (1,2,3) if match(scene,rect(i))]
        self.assertEqual(original,[1,2,3]); self.assertEqual(corrected,[1])
    def test_black_scene_no_false_match(self):
        for i in AREAS: self.assertFalse(match({},rect(i)))
    def test_color_variation_inside_limit(self):
        scene={}; shifted=[[tuple(min(255,c+10) for c in p) for p in row] for row in TEMPLATE]
        paste(scene,390,370,shifted); self.assertTrue(match(scene,rect(3)))
    def test_different_color_not_rare(self):
        scene={}; green=[[tuple((c+80)%256 for c in p) for p in row] for row in TEMPLATE]
        paste(scene,390,370,green); self.assertFalse(match(scene,rect(3)))
    def test_future_pattern_geometry(self):
        self.assertEqual(FUTURE,dict(Left=(150,226,329,350),Center=(329,248,489,349),Right=(490,242,657,348)))
    def test_future_pattern2_each_path(self):
        for target,box in FUTURE.items():
            x1,y1,x2,y2=box
            x,y=(x1+x2)//2,(y1+y2)//2
            hits=[p for p,(a,b,c,d) in FUTURE.items() if a <= x <= c and b <= y <= d]
            self.assertEqual(hits,[target])
    def test_window_translation_negative_monitors(self):
        for wx,wy in [(-5,1),(400,200),(-1700,100),(-1200,-800)]:
            dx,dy=wx-(-5),wy-1
            for i in AREAS:
                x1,y1,x2,y2=rect(i)
                sx,sy=x1+dx,y1+dy
                self.assertEqual((sx-dx,sy-dy),(x1,y1))
                # Client origin differs from outer window origin; check conversion.
                cx,cy=wx+8,wy+31
                self.assertEqual((sx-cx,sy-cy),(x1-3,y1-32))


class RoutingTests(unittest.TestCase):
    def test_rare_votes(self):
        self.assertEqual([classify(x) for x in range(4)],['Chest',None,'Rare_Chest','Rare_Chest'])
    def test_both_retry_sequences(self):
        for hits in [(0,1,1),(1,0,1),(1,1,0)]:
            self.assertEqual(classify(sum(hits)),'Rare_Chest')
    def test_image_failure_not_normal_chest(self):
        for hits in range(4): self.assertIsNone(classify(hits,image_ok=False))
    def test_generic_chest_label_not_rare_evidence(self):
        self.assertEqual(classify(0,3),'Chest')
        self.assertIsNone(classify(0,1))
    def test_rare_at_every_layout_position(self):
        for ids in LAYOUTS:
            for target in ids:
                rs=[room(i,['Rare_Chest'] if i==target else ['Chest']) for i in ids]
                self.assertEqual(select(rs),target)
    def test_user_can_prioritize_normal_chest(self):
        rs=[room(4,['Rare_Chest']),room(5,['Chest'])]
        self.assertEqual(select(rs,['Chest','Rare_Chest']),5)
    def test_normal_types_preserve_order(self):
        for first,second in itertools.permutations(PRIORITIES[1:],2):
            rs=[room(4,[second]),room(5,[first])]
            self.assertEqual(select(rs,[first,second]),5)
    def test_ties_preserve_room_scan_order(self):
        self.assertEqual(select([room(1,['Chest']),room(2,['Chest']),room(3,['Chest'])]),1)
    def test_unavailable_rare_excluded(self):
        self.assertEqual(select([room(4,['Rare_Chest'],state='Unavailable'),room(5,['Hoard'])]),5)
    def test_all_unavailable_no_click(self):
        self.assertIsNone(select([room(3,['Rare_Chest'],state='Unavailable')]))
    def test_unknown_room_state_rejected(self):
        self.assertIsNone(select([room(3,['Chest'],state='Unknown')]))
    def test_rejected_curse_does_not_reenter_lower_priority(self):
        rs=[room(4,['Rare_Chest','Chest'],state='Cursed',curse='skip'),room(5,['Hoard'])]
        self.assertEqual(select(rs),5)
    def test_unknown_curse_allowed_when_exclusions_empty(self):
        self.assertEqual(select([room(3,['Chest'],state='Cursed')],curse_exclusions=False),3)
    def test_user_two_cursed_room_future_case_without_exclusions(self):
        rs=[room(4,['Chest'],state='Cursed'),room(5,['Chest'],state='Cursed')]
        self.assertEqual(select(rs,future=['Left','Right'],curse_exclusions=False),4)
    def test_unknown_curse_rejected(self):
        self.assertIsNone(select([room(3,['Rare_Chest'],state='Cursed')]))
    def test_allowed_curse_preserved(self):
        self.assertEqual(select([room(3,['Chest'],state='Cursed',curse='allow')]),3)
    def test_boss_and_opening_preserved(self):
        for state in ['Boss','Opening']:
            self.assertEqual(select([room(3,['Boss'],state=state)]),3)
    def test_future_paths_all_layouts(self):
        for ids in LAYOUTS:
            for target in ids:
                rs=[room(i,['Chest']) for i in ids]
                self.assertEqual(select(rs,future=[AREAS[target]['path']]),target)
    def test_future_unavailable_then_second_path(self):
        rs=[room(1,['Chest'],state='Unavailable'),room(2,['Chest']),room(3,['Hoard'])]
        self.assertEqual(select(rs,future=['Left','Right']),2)
    def test_future_curse_then_priority(self):
        rs=[room(4,['Rare_Chest'],state='Cursed',curse='skip'),room(5,['Hoard'])]
        self.assertEqual(select(rs,future=['Left']),5)
    def test_two_room_no_invented_center_path(self):
        rs=[room(4,['Shop']),room(5,['Hoard'])]
        self.assertEqual(select(rs,future=['Center']),5)
    def test_failed_recheck_does_not_click(self):
        self.assertIsNone(select([room(3,['Rare_Chest'],recheck=False)]))
    def test_failed_click_does_not_enter(self):
        self.assertIsNone(select([room(3,['Chest'],click_ok=False)]))
    def test_no_recognized_icon_no_blind_fallback(self):
        self.assertIsNone(select([room(3)]))
    def test_disabled_priorities_not_fallback(self):
        self.assertIsNone(select([room(3,['Boss'])],['Chest']))
    def test_confirmed_normal_room_all_layouts(self):
        for ids in LAYOUTS:
            self.assertEqual(select([room(i,normal_confirmed=True) for i in ids]),ids[0])
    def test_normal_follows_configured_special_priorities(self):
        self.assertEqual(select([room(4,normal_confirmed=True),room(5,['Rare_Chest'])]),5)
        self.assertEqual(select([room(4,['Chest']),room(5,normal_confirmed=True)],['Hoard']),5)
    def test_normal_requires_eligible_room_state(self):
        for state in ['Unavailable','Opening','Boss','Unknown']:
            self.assertIsNone(select([room(3,state=state,normal_confirmed=True)]))
    def test_normal_obeys_curse_policy(self):
        r=room(3,state='Cursed',normal_confirmed=True)
        self.assertEqual(select([r],curse_exclusions=False),3)
        self.assertIsNone(select([r]))
        self.assertEqual(select([room(4,state='Cursed',curse='skip',normal_confirmed=True),
                                 room(5,normal_confirmed=True)]),5)
    def test_normal_rechecks_and_click_failures(self):
        for flag in ['recheck','click_ok']:
            self.assertIsNone(select([room(3,normal_confirmed=True,**{flag:False})]))
    def test_inconclusive_empty_room_is_not_normal(self):
        self.assertIsNone(select([room(3,normal_confirmed=False)]))
    def test_final_center_boss_precedes_chest_and_future_preferences(self):
        self.assertEqual(select([room(3,['Boss','Chest'],state='Boss')],['Chest'],future=['Center']),3)
        self.assertEqual(select([room(3,['Boss'],state='Boss')],[]),3)
    def test_final_boss_requires_confirmed_icon(self):
        self.assertIsNone(select([room(3,['Chest'],state='Boss')],['Chest'],future=['Center']))
    def test_final_boss_recheck_and_click_errors(self):
        for flag in ['recheck','click_ok']:
            self.assertIsNone(select([room(3,['Boss'],state='Boss',**{flag:False})],[]))
    def test_side_and_multiple_boss_choices_keep_priorities(self):
        self.assertIsNone(select([room(4,['Boss'],state='Boss')],['Chest']))
        self.assertEqual(select([room(1,['Hoard']),room(2,['Boss'],state='Boss'),
                                 room(3,['Chest'])],['Hoard']),1)


class SourceContractTests(unittest.TestCase):
    def test_modified_ahk_delimiters(self):
        window_harness=(ROOT/'Tests/WindowDetectionTests.ahk').read_text()
        for source in [DUNGEON,WINDOW,IMAGES,DEBUG,window_harness,
                       (ROOT/'Lib/GUI.ahk').read_text(), (ROOT/'Lib/GuiEvents.ahk').read_text()]:
            stack=[]
            for c in lex(source):
                if c in '([{': stack.append(c)
                if c in ')]}':
                    self.assertTrue(stack)
                    self.assertEqual(stack.pop(),{')':'(',']':'[','}':'{'}[c])
            self.assertEqual(stack,[])
    def test_production_rare_search_is_per_room(self):
        body=function(DUNGEON,'DungeonRareMatch')
        self.assertIn('area.searchX1',body); self.assertIn('area.searchX2',body)
        self.assertNotRegex(DUNGEON,r'ImageSearch\(&X, &Y, 247, 325')
    def test_future_both_patterns_use_same_path_region(self):
        body=function(DUNGEON,'DungeonFutureRarePaths')
        for p in ['FutureRareChest1','FutureRareChest2']:
            self.assertRegex(body, r'WF_FindText\(&X, &Y, area.x1, area.y1, area.x2, area.y2,\s*0\.000001, 0\.000001, '+p+r'\)')
    def test_dungeon_no_coordmode_mutation(self):
        self.assertNotIn('CoordMode(',lex(DUNGEON))
    def test_offline_ahk_harness_balanced_and_links_external_functions(self):
        harness=(ROOT/'Tests/DungeonLogicTests.ahk').read_text()
        clean=lex(harness)
        stack=[]
        for c in clean:
            if c in '([{': stack.append(c)
            if c in ')]}':
                self.assertEqual(stack.pop(),{')':'(',']':'[','}':'{'}[c])
        self.assertEqual(stack,[])
        definitions=set(re.findall(r'^([A-Za-z_]\w*)\([^\n]*\)\s*\{',lex(DUNGEON)+'\n'+clean,re.M))
        definitions |= set(re.findall(r'^([A-Za-z_]\w*)\([^\n]*\)\s*=>',clean,re.M))
        calls=set(re.findall(r'(?<![\w.])([A-Za-z_]\w*)\(',lex(DUNGEON)))
        self.assertEqual(calls-definitions-{'IsObject','IsSet','Map','Reload','Sleep','Trim'},set())

    def test_wrappers_restore_modes_in_finally(self):
        for name,var in [('WF_ImageSearch','Pixel'),('WF_RobloxClick','Mouse')]:
            raw=WINDOW[WINDOW.index(name+'('):]
            self.assertIn('finally {\n        CoordMode("'+var+'", previousMode)',raw)
    def test_legacy_ft_wrapper_preserved(self):
        self.assertIn('FT_GetOffset(&dx, &dy)',function(WINDOW,'FT'))
        self.assertIn('args*',function(WINDOW,'FT'))
    def test_screen_search_anchored_to_roblox_not_foreground(self):
        self.assertIn('WinGetClientPos(',function(WINDOW,'WF_RobloxRegion'))
        self.assertIn('SysGet(76)',function(WINDOW,'WF_RobloxRegion'))
        self.assertIn('WF_IsMacroHole(',function(WINDOW,'WF_RobloxRegion'))
        self.assertIn('robloxHolder.Hwnd',function(WINDOW,'WF_IsMacroHole'))
    def test_absolute_asset_path_and_disabled_duplicate(self):
        self.assertIn('RareChestImage := A_ScriptDir "\\Images\\RareChestImage.png"',IMAGES)
        self.assertRegex(IMAGES,r'(?m)^RareChest := ""$')
    def test_debug_finds_absolute_path_initializer(self):
        self.assertIn('(?:A_ScriptDir\\s+)?',DEBUG)
        self.assertIn('DT_QuickDungeon()',DEBUG)
    def test_bounded_sampling(self):
        for f in ['LookForDungeonRooms','DungeonDetectRooms','DungeonFutureRarePaths']:
            self.assertIn('Loop 3',function(DUNGEON,f))
            self.assertIn('Sleep(120)',function(DUNGEON,f))
    def test_curse_identification_depends_on_actual_exclusions(self):
        self.assertIn('room.type = "Cursed" && DungeonHasCurseExclusions()',DUNGEON)
        body=function(DUNGEON,'DungeonHasCurseExclusions')
        self.assertIn('Trim(curse)',body)
        self.assertIn('value !=',body)
    def test_future_has_no_implicit_five_percent_retry(self):
        for name in ['DungeonFutureRarePaths','ClickFutureRareChestPath']:
            self.assertNotRegex(function(DUNGEON,name),r'0, 0, FutureRareChest')
            self.assertIn('0.000001, 0.000001',function(DUNGEON,name))

    def test_shop_curse_uses_existing_reference(self):
        self.assertIn('"Shop", CurseOfShop',DUNGEON)

    def test_curse_alias_and_safe_timeout(self):
        self.assertIn('"Exploding", CurseofExplosion',DUNGEON)
        self.assertIn('curseResult.curse = "no curse found"',DUNGEON)
    def test_future_uses_shared_safety(self):
        self.assertIn('DungeonTryEnterRoom(',function(DUNGEON,'ClickFutureRareChestPath'))
        self.assertIn('DungeonRoomEligible(',function(DUNGEON,'ClickFutureRareChestPath'))
    def test_future_marker_rechecked_before_selection(self):
        body=function(DUNGEON,'ClickFutureRareChestPath')
        self.assertIn('stillVisible := WF_FindText(',body)
        self.assertIn('if !stillVisible',body)

    def test_no_hardcoded_fallback_click(self):
        self.assertNotIn('FixClick(',function(DUNGEON,'SelectBestRoom'))
    def test_confirmed_chest_excludes_rare(self):
        self.assertIn('count >= 2',function(DUNGEON,'DungeonDetectRooms'))
        self.assertIn('imageOK && tally[',function(DUNGEON,'DungeonDetectRooms'))
    def test_changed_or_failed_room_is_blacklisted(self):
        self.assertGreaterEqual(function(DUNGEON,'DungeonTryEnterRoom').count('unsafeRooms[room.index] := true'),4)


if __name__=='__main__':
    unittest.main(verbosity=2)
