#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\AppInfo.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; Real shop functions, mocked screen/input only. No game, Main, settings, or network.
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk
global STChecks := 0, STFishAfter := 1, STSearches := 0, STClicks := [], STLogs := []
global STFailAt := 0, STAttempts := 0, STReady := true, STShopVisible := false, STContinueQueries := 0
global DenyShrines := {Value:1}, SaveChestsBox := {Value:1}, debugMessages := false
global WF_LastIssue := "", STSearchIssue := false
STReset(after := 1) {
    global STFishAfter, STSearches, STClicks, STLogs, STFailAt, STAttempts, STReady, STShopVisible, STContinueQueries
    global WF_LastIssue, STSearchIssue
    WF_LastIssue := "", STSearchIssue := false
    STFishAfter := after, STSearches := 0, STClicks := [], STLogs := [], STFailAt := 0
    STAttempts := 0, STReady := true, STShopVisible := false, STContinueQueries := 0
}
STAssert(value,label) {
    global STChecks
    STChecks += 1
    if !value
        throw Error(label)
}
WF_PrepareDungeon() => STReady
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global STSearches, WF_LastIssue
    if (text != Fishhook || x1!=184 || y1!=118 || x2!=623 || y2!=523)
        throw Error("Unexpected shop search")
    STSearches += 1, X := 410, Y := 280
    WF_LastIssue := STSearchIssue ? "Simulated occluded shop" : ""
    if STSearchIssue
        return false
    return STFishAfter && STSearches>=STFishAfter
}
WF_RobloxClick(x,y) {
    global STAttempts
    STAttempts += 1
    if (STFailAt && STAttempts=STFailAt)
        return false
    STClicks.Push([x,y])
    return true
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text,args*) {
    global STContinueQueries
    X := x1, Y := y1
    if (text=Shop)
        return STShopVisible
    if (text=DungeonContinue)
        STContinueQueries += 1
    return false
}
FixClick(*) {
    throw Error("Shop input escaped the window-aware mock")
}
AddToLog(message) => STLogs.Push(message)
NextStep(*) {
    throw Error("No game handoff is allowed in shop tests")
}
RejoinPrivateServer(*) {
    throw Error("No network in shop tests")
}
STMain()
STMain() {
    global STFailAt, STReady, STShopVisible, STSearchIssue
try {
    STReset()
    STAssert(HandleShop(),"normal detected-Fishhook shop completes")
    STAssert(STSearches=1 && STClicks.Length=5,"detected Fishhook adds the existing first purchase before three slots and close")
    STAssert(STClicks[1][1]=560 && STClicks[1][2]=280,"Fishhook first uses its matched X+150/Y point")
    STAssert(STClicks[2][2]=335 && STClicks[3][2]=280 && STClicks[4][2]=225,"remaining slot order stays 3,2,1")
    STAssert(STClicks[5][1]=485 && STClicks[5][2]=410 && STContinueQueries>0,"existing shop closing/Continue flow retained")
    STReset(3)
    STAssert(HandleShop() && STSearches=3,"late Fishhook is detected within the bounded retry")
    STAssert(STClicks[1][2]=280,"late Fishhook still precedes other slots")
    STReset(0)
    STAssert(HandleShop() && STSearches=3,"missing Fishhook does not stall the shop")
    STAssert(STClicks.Length=4 && STClicks[1][2]=335 && STClicks[2][2]=280 && STClicks[3][2]=225,"missing Fishhook preserves legacy three-slot buying")
    STReset(), STFailAt := 1
    STAssert(!HandleShop() && !STClicks.Length,"refused first Fishhook click cannot buy other items first")
    STAssert(STAttempts=1,"no later purchase or close after a refused Fishhook click")
    STReset(0), STFailAt := 1
    STAssert(!HandleShop() && STAttempts=1 && !STClicks.Length,"refused generic purchase cannot advance to later slots")
    STReset(), STReady := false
    STAssert(!HandleShop() && !STSearches && !STAttempts,"unready shop does not search or spend")
    STReset(), STSearchIssue := true
    STAssert(!HandleShop() && STSearches=1 && !STAttempts,"failed Fishhook capture is not treated as a genuine miss before generic buying")
    STReset(), STShopVisible := true, STFailAt := 1
    STAssert(!CheckDungeonSpecials(),"shop input failure propagates instead of selecting behind an unresolved menu")
    STAssert(STAttempts=1 && !STContinueQueries,"failed shop never clicks Continue")
    FileAppend("PASS: " STChecks " shop-priority assertions (screen/input mocked).`n","*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ExitApp(1)
}
}
