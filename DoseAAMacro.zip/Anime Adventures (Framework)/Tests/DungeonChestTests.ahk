#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\ChestFunctionsForTests.ahk
; Actual production drain/claim/wrapper/caller. Screen and input are simulated;
; client conversion uses a real native window. No private files or game startup.
global CGame := Gui("-Caption +ToolWindow -DPIScale"),rblxID := "ahk_id " CGame.Hwnd
global CChecks := 0, WF_LastIssue := "", BossRoomCompleted := true, SaveChestsForBoss := true
global DenyShrines := {Value:1}, CNormal := 0, CRare := 0, CPhase := "Menu", CEvents := []
global CContinues := 0, CFinishChecks := 0, CReconnects := 0, COpenMisses := 0
global CInputOK := true, CReady := true, CClaimWorks := true, CBlocked := false, CLogs := []
global CUnknownCommon := false, CUnknownRare := false, CFalseEmpty := 0, CDelay := 0
global CPending := "", CClaimClicks := 0, CRefillCommon := false, CEmptyChecks := Map()
global CFinalChanged := false, CCommonReads := 0, CThrowRead := false, COverlay := false
global CCloseWorks := false
global CFast := {pollMs:1,afterOpenMs:0,departMs:120,claimMs:180,claimClickMs:1,
    totalMs:6000,stalledClicks:2,maxOpenClicks:20,emptySamples:3}
CGame.Show("x100 y100 w816 h638")
CReset(normal := 0,rare := 0) {
    global CNormal,CRare,CPhase,CEvents,CContinues,CFinishChecks,CReconnects,COpenMisses
    global CInputOK,CReady,CClaimWorks,CBlocked,CLogs,CUnknownCommon,CUnknownRare,CFalseEmpty,CDelay
    global CPending,CClaimClicks,CRefillCommon,CEmptyChecks,CFinalChanged,CCommonReads,CThrowRead
    global BossRoomCompleted,SaveChestsForBoss,WF_LastIssue,COverlay,CCloseWorks
    CNormal := normal, CRare := rare, CPhase := "Menu", CEvents := [], CLogs := []
    CContinues := 0,CFinishChecks := 0,CReconnects := 0,COpenMisses := 0
    CInputOK := true,CReady := true,CClaimWorks := true,CBlocked := false
    CUnknownCommon := false,CUnknownRare := false,CFalseEmpty := 0,CDelay := 0
    CPending := "",CClaimClicks := 0,CRefillCommon := false,CEmptyChecks := Map()
    CFinalChanged := false,CCommonReads := 0,CThrowRead := false,COverlay := false,CCloseWorks := false
    BossRoomCompleted := true,SaveChestsForBoss := true,WF_LastIssue := ""
    DungeonClearBossExitRecovery()
}
CAssert(ok,label) {
    global CChecks
    CChecks += 1
    if !ok
        throw Error(label)
}
CHasLog(text) {
    for l in CLogs
        if InStr(l,text)
            return true
    return false
}
CCount(kind) {
    n := 0
    for e in CEvents
        if (e=kind)
            n += 1
    return n
}
try {
    CReset(2,3)
    CAssert(HandleChestScreen(CFast),"boss end drains both chest types successfully")
    CAssert(CNormal=0 && CRare=0 && CCount("open Common")=2 && CCount("open Rare")=3,"every simulated chest is opened, not just one per row")
    CAssert(CContinues=1 && !BossRoomCompleted && CReconnects=1,"successful drain unlocks Continue once and resets boss state afterward")
    CAssert(DungeonBossExitPending && DungeonBossExitRecoveries=0,"only a verified final boss drain arms entrance recovery")
    CAssert(CHasLog("All chests confirmed empty") && CEmptyChecks["Common"]>=6 && CEmptyChecks["Rare"]>=6,"each row and the joint final check require repeated positive empty evidence")
    CAssert(CEvents[1]="open Common" && CEvents[2]="claim" && CEvents[5]="open Rare","Common is drained before Rare and each reward is handled")

    CReset(1,1),COpenMisses := 1
    CAssert(HandleChestScreen(CFast),"one missed Open click is retried instead of called empty")
    CAssert(CCount("open Common")=2 && CHasLog("no confirmed transition"),"missed-click retry is observable and still drains the row")

    CReset(1,1),COpenMisses := 100
    CAssert(!HandleChestScreen(CFast),"persistently ignored Open clicks fail the chest pass")
    CAssert(CNormal=1 && CRare=1 && CContinues=0 && CFinishChecks=0 && !CReconnects,"failed opening cannot Continue, finish, or reconnect into another dungeon")
    CAssert(BossRoomCompleted && !CHasLog("All chests confirmed empty"),"failed opening retains boss state and never claims completion")

    CReset(0,2)
    CAssert(HandleChestScreen(CFast) && !CCount("open Common") && CCount("open Rare")=2,"empty Common does not prevent draining Rare")
    CReset(2,0)
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=2 && !CCount("open Rare"),"empty Rare does not prevent draining Common")
    CReset()
    CAssert(HandleChestScreen(CFast) && CEvents.Length=1 && CEvents[1]="continue","both initially empty needs evidence but no opening clicks")

    CReset(1,0),CClaimWorks := false
    CAssert(!HandleChestScreen(CFast) && CPhase="Reward","an unclaimed reward is not treated as a completed chest pass")
    CAssert(!CContinues && CRare=0 && CHasLog("claim timed out"),"reward timeout cannot unlock Continue even if stored chest counts are zero")
    CReset(1,0),CInputOK := false
    CAssert(!HandleChestScreen(CFast) && !CContinues && CNormal=1,"refused Open input leaves the chest and blocks Continue")
    CReset(1,0),CReady := false
    CAssert(!HandleChestScreen(CFast) && !CEvents.Length,"unprepared game window causes no opening or Continue input")
    CAssert(!DungeonBossExitPending,"failed chest preparation cannot arm lobby recovery")
    CReset(1,0),CBlocked := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"obscured chest screen cannot be interpreted as empty")

    CReset(),CUnknownCommon := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"missing Common empty reference blocks completion even when simulated count is zero")
    CReset(),CUnknownRare := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"missing Rare empty reference blocks completion")
    CReset(1,0),CFalseEmpty := 1
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=1,"one transient false-empty sample cannot skip a remaining Common chest")
    CReset(1,0),CDelay := 3
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=1,"delayed opening animation is awaited before retrying")

    CReset(0,1),CRefillCommon := true
    CAssert(HandleChestScreen(CFast) && CCount("open Common")=1 && CCount("open Rare")=1,"joint final verification catches and drains a newly appearing Common chest")
    CReset(),CFinalChanged := true
    CAssert(!HandleChestScreen(CFast) && !CContinues,"empty evidence disappearing during joint verification cannot unlock Continue")
    CReset(1,0),CThrowRead := true
    CAssert(!HandleChestScreen(CFast) && !CContinues && !CReconnects,"unexpected matching error is contained without framework recovery skipping the chest pass")

    CReset(3,2),BossRoomCompleted := false
    CAssert(HandleChestScreen(CFast) && CContinues=1 && !CCount("open Common") && !CCount("open Rare"),"save-for-boss still preserves intermediate chests")
    CAssert(!DungeonBossExitPending,"saving intermediate chests never arms boss lobby recovery")
    CReset(1,0),BossRoomCompleted := false,SaveChestsForBoss := false
    CAssert(HandleChestScreen(CFast) && CNormal=0 && CContinues=1,"explicitly disabling chest saving retains the existing option behavior")

    CReset(1,0),COverlay := true
    CAssert(!HandleChestScreen(CFast) && !CContinues && CHasLog("overlay did not clear"),"lobby-like/token overlay is not falsely reported as successful claiming")
    CReset(1,0),COverlay := true,CCloseWorks := true
    CAssert(HandleChestScreen(CFast) && CContinues=1,"overlay dismissal must actually return the chest menu before continuing")

    CReset(),CPhase := "Reward",CClaimWorks := false
    CAssert(!ClaimChestReward({pollMs:1,claimMs:2500,claimClickMs:1}) && CClaimClicks=40,"reward clicking remains bounded and does not declare a missing menu returned")
    CReset(2,0)
    CAssert(!HandleChestScreen({pollMs:1,afterOpenMs:0,departMs:120,claimMs:180,claimClickMs:1,totalMs:6000,maxOpenClicks:1}),"opening cap blocks remaining chests rather than Continue")
    CAssert(CNormal=1 && !CContinues,"opening cap never abandons the remaining chest automatically")

    CReset(1,0)
    CAssert(HandleChestScreen({pollMs:1,afterOpenMs:0,departMs:120,claimMs:180,claimClickMs:1,totalMs:6000,maxOpenClicks:1}) && CContinues=1,"the final allowed Open click can still be followed by positive empty verification")
    CReset(1,0)
    CAssert(!HandleChestScreen({totalMs:1,afterOpenMs:0,pollMs:1}) && !CContinues,"overall chest deadline never unlocks Continue without verification")
    CReset(0,1),COpenMisses := 100
    CAssert(!HandleChestScreen(CFast) && !CContinues && CRare=1,"Rare failure blocks Continue even after Common was confirmed empty")
    CAssert(!CCount("claim"),"a menu that never departed does not trigger blind reward claiming")
    CReset(1,0),CInputOK := false
    CAssert(!CheckDungeonSpecials() && !CContinues,"actual special-screen caller propagates a chest-opening failure")
    CReset(1,1),CReady := false
    DungeonArmBossExitRecovery()
    CAssert(!HandleChestScreen(CFast) && !DungeonBossExitPending,"a stale prior authorization is cleared before an unverified boss chest pass")
    FileAppend("PASS: " CChecks " chest-drain assertions (production flow, mocked screen/input, native client conversion).`n","*")
    CGame.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    CGame.Destroy()
    ExitApp(1)
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global WF_LastIssue,CDelay,CPending,CPhase,CFalseEmpty,CCommonReads
    WF_LastIssue := CBlocked ? "simulated covering window" : "",X := x1,Y := y1
    if CBlocked
        return false
    if (text=ChestRoom || text=ChestRoomLuck) {
        if (CPending!="" && CDelay>0) {
            CDelay -= 1
            if (CDelay=0)
                CPhase := "Reward",CPending := ""
        }
        return CPhase="Menu"
    }
    if (text=EmptyCommonChest || text=EmptyRareChest) {
        if CThrowRead
            throw Error("simulated matching API failure")
        if (e1!=0.000001 || e0!=0.000001)
            throw Error("empty reference tolerance can accept a different count")
        kind := text=EmptyCommonChest ? "Common" : "Rare"
        CEmptyChecks[kind] := CEmptyChecks.Has(kind) ? CEmptyChecks[kind]+1 : 1
        if (kind="Common") {
            CCommonReads += 1
            if (CFinalChanged && CCommonReads>=4)
                return false
            if CFalseEmpty {
                CFalseEmpty -= 1
                return true
            }
            return CPhase="Menu" && !CUnknownCommon && CNormal=0
        }
        return CPhase="Menu" && !CUnknownRare && CRare=0
    }
    throw Error("Unexpected chest screen reference")
}
WF_RobloxClick(x,y) {
    global CNormal,CRare,CPhase,COpenMisses,CClaimClicks,CRefillCommon,CPending
    if !CInputOK
        return false
    if (x=560 && (y=261 || y=321)) {
        kind := y=261 ? "Common" : "Rare"
        CEvents.Push("open " kind)
        count := kind="Common" ? CNormal : CRare
        if (COpenMisses>0) {
            COpenMisses -= 1
            return true
        }
        if count {
            if (kind="Common")
                CNormal -= 1
            else {
                CRare -= 1
                if CRefillCommon
                    CNormal += 1,CRefillCommon := false
            }
            if CDelay
                CPending := kind
            else
                CPhase := "Reward"
        }
        return true
    }
    if (x=555 && y=561) {
        CEvents.Push("claim"),CClaimClicks += 1
        if CClaimWorks
            CPhase := "Menu"
        return true
    }
    if (x=485 && y=121) {
        CEvents.Push("overlay close")
        if CCloseWorks
            CPhase := "Menu"
        return true
    }
    throw Error("Unexpected chest click at " x "," y)
}
WF_PrepareDungeon() => CReady
FT_GetOffset(&dx,&dy) {
    WinGetPos(&x,&y,,,rblxID)
    dx := x+5,dy := y-1
}
FT(&X,&Y,x1,y1,x2,y2,e1,e0,text,args*) {
    X := x1,Y := y1
    return (text=ChestRoom || text=ChestRoomLuck) && CPhase="Menu"
}
ClickDungeonContinue() {
    global CContinues
    if (BossRoomCompleted && (CNormal || CRare || CPhase!="Menu"))
        throw Error("Continue escaped with unhandled chests/reward")
    CContinues += 1,CEvents.Push("continue")
}
CheckForReturnToLobby() => COverlay
CheckForFinishDungeonV2() {
    global CFinishChecks
    CFinishChecks += 1
    return false
}
Reconnect() {
    global CReconnects
    CReconnects += 1
}
AddToLog(message) => CLogs.Push(message)
NextStep(*) {
    throw Error("No game handoff is allowed in chest tests")
}
StartSelectedMode(*) {
}
HandleShop(*) {
    throw Error("Shop handling is outside chest tests")
}
ShrinePriority(*) {
    throw Error("Shrine handling is outside chest tests")
}
ClickUntilGone(*) {
    throw Error("Unexpected generic click in chest tests")
}
