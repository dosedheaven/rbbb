#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\GuiSkin.ahk
#Include %A_ScriptDir%\..\Lib\GuiStyle.ahk
#Include %A_ScriptDir%\..\Lib\GuiDashboard.ahk
; Synthetic theme settings only. Artwork checks remain explicitly pending until
; the original user-supplied image is available as a bundled file.
global AKTemp := A_Temp "\DoseAkatsukiTests-" A_TickCount
DirCreate(AKTemp)
AA_ThemeFile := AKTemp "\Theme.txt"
global AKChecks := 0, AKLogs := [], version := "v2.7"
global uiTheme := ["F2EEE9","0B0C10","C22A44","15161D","303030","0C0D13","FF7181"]
global AKGui := Gui("+ToolWindow -DPIScale")
class MacroLoopState {
    static Active := true
}
AKAssert(ok,label) {
    global AKChecks
    AKChecks += 1
    if !ok
        throw Error(label)
}
try {
    AKAssert(AA_ThemeOrder.Length=1 && AA_ThemeOrder[1]="Akatsuki","one requested theme")
    AKAssert(AA_Themes.Count=1 && AA_Themes.Has("Akatsuki"),"retired themes are not selectable")
    AKAssert(AA_ThemeName()="Akatsuki","missing theme file safely uses Akatsuki")
    for saved in ["","Arcane","Astral","Tokyo Ghoul","Orange","Akatsuki","unknown"] {
        if FileExist(AA_ThemeFile)
            FileDelete(AA_ThemeFile)
        FileAppend(saved,AA_ThemeFile,"UTF-8")
        before := FileRead(AA_ThemeFile,"UTF-8")
        AKAssert(AA_ThemeName()="Akatsuki" && FileRead(AA_ThemeFile,"UTF-8")=before,
            "legacy theme uses Akatsuki without rewriting saved data")
    }
    AA_StyleInit()
    palette := DoseThemePalette("Akatsuki")
    AKAssert(uiTheme[1]=palette.header && uiTheme[2]=palette.background && uiTheme[3]=palette.accent,
        "matching ivory, charcoal and crimson palette")
    AKAssert(uiTheme[5]="303030","original game transparency key retained")
    AKAssert(AA_AccentTextColor(uiTheme[3])="F1F5FF","crimson buttons use readable light text")
    root := A_ScriptDir "\..\Images\UI"
    DoseIconFont(root "\Fonts\DejaVuSans.ttf")
    AKAssert(DoseHeadingFont(root "\Fonts\NewRocker-Regular.ttf")="New Rocker","bundled display font loads privately")
    picker := AKGui.Add("DropDownList","x0 y0 w150 r1",AA_ThemeOrder)
    picker.Choose(1)
    AA_SaveTheme(picker)
    AKAssert(FileRead(AA_ThemeFile,"UTF-8")="Akatsuki" && AKLogs.Length=1,"existing theme-save behavior retained")
    title := AKGui.Add("Text","x0 y30 w500 h30","Dose AA Macro")
    activity := AKGui.Add("Text","x0 y70 w500 h30","Activity")
    DoseStyleHeadings(title,activity)
    AKAssert(InStr(title.Text,"v2.7") && activity.Text="Activity","header changes presentation only")
    signature := DoseBuildThemeSignature(AKGui)
    signature.GetPos(&x,&y,&w,&h)
    AKAssert(signature.Text="AKATSUKI" && x>=1392 && y>=804 && h>=35,"theme heading stays in the large artwork panel")
    AKAssert(!DoseBuildBackdrop(AKGui,AKTemp "\missing.jpg"),"missing artwork falls back without throwing")
    art := DoseThemeArtworkPath("Akatsuki",root)
    if FileExist(art) {
        picture := DoseBuildBackdrop(AKGui,art)
        picture.GetPos(&x,&y,&w,&h)
        AKAssert(x=1396 && y=48 && w=376 && h=212,"bundled group artwork stays outside Roblox viewport")
        DosePortrait.GetPos(&x,&y,&w,&h)
        AKAssert(x=1396 && y=272 && w=376 && h=638,"portrait crop stays in artwork panel")
        FileAppend("PASS: bundled Akatsuki artwork rendered at dashboard bounds.`n","*")
    } else
        FileAppend("PENDING: original Akatsuki artwork file is not bundled yet.`n","*")
    FileAppend("PASS: " AKChecks " Akatsuki theme-policy/font/control assertions (synthetic theme file).`n","*")
    AKGui.Destroy()
    DirDelete(AKTemp,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    AKGui.Destroy()
    try DirDelete(AKTemp,1)
    ExitApp(1)
}
AddToLog(message) => AKLogs.Push(message)
