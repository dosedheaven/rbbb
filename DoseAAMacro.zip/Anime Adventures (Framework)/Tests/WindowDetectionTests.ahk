#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\..\Lib\AppInfo.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; Real Win32 GUI, FindText and ImageSearch tests using synthetic windows only.
; Never includes Main/GUI/settings/webhooks and never clicks the real desktop.
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk

global offsetX := -5, offsetY := 1, targetWidth := 816, targetHeight := 638
global WTGame := Gui("-Caption +ToolWindow -DPIScale"), WTMacro := Gui("+AlwaysOnTop -Caption -DPIScale")
global rblxID := "ahk_id " WTGame.Hwnd, aaMainUIHwnd := WTMacro.Hwnd
global robloxHolder := WTMacro.Add("Text", "x3 y33 w797 h597 Background303030", "")
global WTOverlay := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale")
global WTCount := 0, WTClick := [], WTPixelMode := A_CoordModePixel, WTMouseMode := A_CoordModeMouse
WTGame.BackColor := "101010", WTMacro.BackColor := "181818", WTOverlay.BackColor := "FF0000"
global WTMarker := WTGame.Add("Picture", "x300 y359 w15 h14", A_ScriptDir "\Fixtures\AvailableMarker.bmp")
global WTRare := WTGame.Add("Picture", "x310 y394 w16 h12", A_ScriptDir "\..\Images\RareChestImage.png")
; Black/white fixtures decode the supplied patterns; these are synthetic tests,
; not screenshots or proof of matching the live red boss card.
global WTBossBorder := WTGame.Add("Picture", "x365 y408 Hidden", A_ScriptDir "\Fixtures\BossBorder.bmp")
global WTBossIcon := WTGame.Add("Picture", "x400 y365 Hidden", A_ScriptDir "\Fixtures\BossIcon.bmp")
global WTOpening := WTGame.Add("Picture", "x365 y370 Hidden", A_ScriptDir "\Fixtures\OpeningMarker.bmp")
global WTFuture1 := WTGame.Add("Picture", "x345 y270 Hidden", A_ScriptDir "\Fixtures\FutureRareChest1.bmp")
global WTFuture2 := WTGame.Add("Picture", "x435 y270 Hidden", A_ScriptDir "\Fixtures\FutureRareChest2.bmp")
global WTEntrance := WTGame.Add("Picture","x365 y355 Hidden",A_ScriptDir "\Fixtures\EnterDungeon.bmp")
WTAssert(condition, label) {
    global WTCount
    WTCount += 1
    if !condition
        throw Error(label " / window issue: " WF_LastIssue)
}
WTMain()
ExitApp(0)

WTMain() {
try {
    WTGame.Show("x100 y100 w816 h638")
    WTMacro.Show("x105 y99 w1364 h697")
    WinSetTransColor("303030", WTMacro)
    Sleep(150)
    WTAssert(IsObject(WF_RobloxRegion(263,332,312,445)), "macro transparent holder allowed")
    WTAssert(!WF_FindText(&X,&Y,275,340,300,437,0.20,0.20,DungeonRoomBorder), "old narrow marker column misses shifted reference")
    WTAssert(WF_FindText(&X,&Y,263,332,312,445,0.20,0.20,DungeonRoomBorder), "expanded marker column finds same reference")
    WTAssert(X >= 295 && X <= 310, "FindText returns calibrated X")
    WTMarker.Value := A_ScriptDir "\Fixtures\AvailableMarkerOnePixelWrong.bmp"
    Sleep(80)
    WTAssert(WF_FindText(&X,&Y,263,332,312,445,0,0,DungeonRoomBorder), "FindText zero-zero silently retries with five percent error")
    WTAssert(!WF_FindText(&X,&Y,263,332,312,445,0.000001,0.000001,DungeonRoomBorder), "explicit exact sampling rejects the changed pixel")
    WTMarker.Value := A_ScriptDir "\Fixtures\AvailableMarker.bmp"
    Sleep(80)
    WTAssert(WF_FindText(&X,&Y,263,332,312,445,0.000001,0.000001,DungeonRoomBorder), "explicit exact sampling accepts genuine unchanged pattern")


    CoordMode("Pixel", "Client")
    image := A_ScriptDir "\..\Images\RareChestImage.png"
    WTAssert(WF_ImageSearch(&X,&Y,280,343,370,435,image), "PNG found inside owning room")
    WTAssert(X=305 && Y=395, "PNG returns calibrated top-left")
    WTAssert(A_CoordModePixel="Client", "pixel mode restored after success")
    WTAssert(!WF_ImageSearch(&X,&Y,438,343,525,435,image), "neighbor room cannot inherit PNG")
    WTAssert(A_CoordModePixel="Client", "pixel mode restored after miss")
    try WF_ImageSearch(&X,&Y,280,343,370,435,"Z:\missing-dungeon-test.png")
    WTAssert(A_CoordModePixel="Client", "pixel mode retained after image error")

    WTOverlay.Show("x380 y440 w80 h90 NoActivate")
    WinSetTransparent(0, WTOverlay)
    Sleep(100)
    WTAssert(IsObject(WF_RobloxRegion(280,343,370,435)), "fully invisible overlay does not veto layout")
    WinSetTransparent("Off", WTOverlay)
    Sleep(100)
    WTAssert(!IsObject(WF_RobloxRegion(280,343,370,435)), "opaque covering window rejected")
    WTAssert(InStr(WF_LastIssue,"covered by"), "cover rejection explained")
    WTOverlay.Hide()

    WinMove(300,200,,,rblxID)
    WinMove(305,199,,,"ahk_id " aaMainUIHwnd)
    Sleep(100)
    WTAssert(WF_ImageSearch(&X,&Y,280,343,370,435,image), "PNG follows moved Roblox")
    WTAssert(X=305 && Y=395, "movement does not change calibrated PNG position")

    WinMove(-100,100,,,rblxID)
    WinMove(-95,99,,,"ahk_id " aaMainUIHwnd)
    Sleep(100)
    WTAssert(WF_ImageSearch(&X,&Y,280,343,370,435,image), "visible region works with negative outer origin")
    WTAssert(!IsObject(WF_RobloxRegion(0,0,10,10)), "off-desktop query refused")
    WinMove(100,100,,,rblxID)
    WinMove(105,99,,,"ahk_id " aaMainUIHwnd)
    WinMove(,,700,550,rblxID)
    WTAssert(!IsObject(WF_RobloxRegion(280,343,370,435)), "wrong size reported")
    WTAssert(InStr(WF_LastIssue,"size"), "size mismatch explained")
    WTAssert(WF_PrepareDungeon(), "supported size is restored before scan")
    WTAssert(IsObject(WF_RobloxRegion(280,343,370,435)), "restored region usable")

    CoordMode("Mouse", "Client")
    WTAssert(WF_RobloxClick(322,360), "targeted click wrapper reaches mock")
    WTAssert(WTClick.Length=2 && WTClick[1]=427 && WTClick[2]=459, "room click translated to real screen")
    WTAssert(A_CoordModeMouse="Client", "mouse mode restored after targeted click")

    WTMarker.Visible := false, WTRare.Visible := false
    WTBossBorder.Visible := true, WTBossIcon.Visible := true
    Sleep(100)
    center := DungeonRoomAreas()[3]
    WTAssert(DungeonBossCardMatch(center), "native FindText locates supplied boss border plus icon in center card")
    WTAssert(DungeonProbeRoom(center,&detail)="Boss", "production scanner recognizes boss-only center card")
    WTBossIcon.Visible := false
    Sleep(80)
    WTAssert(!DungeonBossCardMatch(center), "boss border alone cannot confirm a boss card")
    WTBossIcon.Visible := true, WTBossBorder.Visible := false
    Sleep(80)
    WTAssert(!DungeonBossCardMatch(center), "boss icon alone cannot confirm a boss border")
    WTBossBorder.Visible := true, WTOpening.Visible := true
    Sleep(80)
    WTAssert(DungeonProbeRoom(center,&detail)="Boss", "OPEN marker does not mask confirmed boss references")
    rooms := DungeonScanRooms(&detail)
    WTAssert(rooms.Length=1 && rooms[1].index=3 && rooms[1].type="Boss", "native scan returns single centered boss candidate")
    WTBossBorder.Visible := false, WTBossIcon.Visible := false
    WTOpening.Move(400,400)
    Sleep(100)
    marker := DungeonMarkerArea(center)
    WTAssert(!WF_FindText(&X,&Y,marker.x1,marker.y1,marker.x2,marker.y2,
        0.10,0.10,DungeonRoomBorderChestOpen), "old left strip misses a centered OPEN reference")
    WTAssert(DungeonOpeningCardMatch(center,true), "card interior finds centered OPEN without unrelated special icons")
    WTAssert(DungeonProbeRoom(center,&detail)="Opening", "production scanner recognizes centered OPEN checkpoint")
    rooms := DungeonScanRooms(&detail)
    WTAssert(rooms.Length=1 && rooms[1].index=3 && rooms[1].type="Opening", "centered OPEN is assigned to only its own card")
    WTBossIcon.Visible := true
    Sleep(80)
    WTAssert(!DungeonOpeningCardMatch(center,true), "Boss icon prevents unmarked OPEN-only promotion")
    WTAssert(DungeonProbeRoom(center,&detail)!="Opening", "OPEN plus Boss icon does not become a green checkpoint")
    WTBossIcon.Visible := false, WTOpening.Visible := false, WTFuture1.Visible := true
    Sleep(100)
    two := [{index:4,type:"Available",coords:DungeonRoomAreas()[4]}, {index:5,type:"Available",coords:DungeonRoomAreas()[5]}]
    WTAssert(WF_FindText(&X,&Y,329,248,489,349,0.000001,0.000001,FutureRareChest1), "old fixed center band captures a left parent's second preview")
    paths := DungeonFutureRarePaths(two)
    WTAssert(paths.Length=1 && paths[1]="Left", "two-room layout associates that preview with Left instead of nonexistent Center")
    WTFuture1.Visible := false, WTFuture2.Visible := true
    Sleep(80)
    paths := DungeonFutureRarePaths(two)
    WTAssert(paths.Length=1 && paths[1]="Right", "second future pattern belongs to Right in two-room layout")
    WTFuture1.Visible := true
    Sleep(80)
    paths := DungeonFutureRarePaths(two)
    WTAssert(paths.Length=2 && paths[1]="Left" && paths[2]="Right", "both two-room future groups retain independent ownership")
    two[1].type := "Unavailable"
    paths := DungeonFutureRarePaths(two)
    WTAssert(paths.Length=1 && paths[1]="Right", "unavailable future parent is excluded")
    one := [{index:3,type:"Available",coords:center}]
    paths := DungeonFutureRarePaths(one)
    WTAssert(paths.Length=1 && paths[1]="Center", "single centered parent owns its centered previews")
    WTFuture2.Visible := false
    WTFuture1.Move(280,270)
    Sleep(80)
    three := [{index:1,type:"Available",coords:DungeonRoomAreas()[1]}, {index:2,type:"Available",coords:DungeonRoomAreas()[2]}, {index:3,type:"Available",coords:center}]
    paths := DungeonFutureRarePaths(three)
    WTAssert(paths.Length=1 && paths[1]="Left", "three-room left future preview has one owner")
    WTFuture1.Move(535,270)
    Sleep(80)
    paths := DungeonFutureRarePaths(three)
    WTAssert(paths.Length=1 && paths[1]="Right", "three-room right future preview has one owner")
    WTFuture1.Move(400,220)
    Sleep(80)
    WTAssert(!DungeonFutureRarePaths(three).Length, "progress-bar reference cannot become a future-room preview")
    WTFuture1.Move(400,350)
    Sleep(80)
    WTAssert(!DungeonFutureRarePaths(three).Length, "current-room reference cannot become a future preview")
    ; Startup uses the existing Enter Dungeon pixels, not a new live reference.
    WTEntrance.Visible := true
    Sleep(100)
    WTAssert(!WF_FindText(&X,&Y,310,395,495,440,0.20,0.20,EnterDungeon),"old tight entrance box misses a shifted complete reference")
    WTAssert(DungeonEntranceScene(&X,&Y,&layout)="Enter","new entrance scene finds the complete shifted Enter reference")
    WTAssert(Abs(X-395)<=2 && Abs(Y-368)<=2,"entrance match center uses the shared calibration")
    entranceX := X, entranceY := Y
    CoordMode("Mouse","Client")
    WTAssert(WF_RobloxClick(X,Y) && WTClick[1]=entranceX+105 && WTClick[2]=entranceY+99,"entrance center translates to the correct native screen point")
    WTAssert(A_CoordModeMouse="Client","entrance click retains the caller mouse coordinate mode")
    WinMove(300,200,,,rblxID)
    WinMove(305,199,,,"ahk_id " aaMainUIHwnd)
    Sleep(100)
    WTAssert(DungeonEntranceScene(&X,&Y,&layout)="Enter" && X=entranceX && Y=entranceY,"entrance matching follows moved Roblox with unchanged calibrated coordinates")
    WTAssert(DungeonOpenEntranceMenu() && WTClick[1]=385 && WTClick[2]=600,"lobby input preserves original client coordinates through the real screen wrapper")
    WTOverlay.Show("x550 y530 w200 h170")
    WinSetTransparent("Off",WTOverlay)
    Sleep(100)
    WTAssert(DungeonEntranceScene(&X,&Y,&layout)="Blocked","obscured entrance returns a window failure rather than a missing-button result")
    WTOverlay.Hide()
    WTAssert(!IsCommonChestDone(),"blank/nonempty-reference scene cannot confirm Common empty")
    WTAssert(!IsRareChestDone(),"blank/nonempty-reference scene cannot confirm Rare empty")
    WTAssert(DungeonChestInput(565,260,"native Common Open") && WTClick[1]=865 && WTClick[2]=460,"Common Open preserves legacy client coordinates through real screen conversion")
    WTAssert(DungeonChestInput(565,320,"native Rare Open") && WTClick[1]=865 && WTClick[2]=520,"Rare Open preserves legacy client coordinates through real screen conversion")
    WTAssert(DungeonChestInput(560,560,"native reward claim") && WTClick[1]=860 && WTClick[2]=760,"reward claim preserves legacy client coordinates through real screen conversion")
    WTAssert(A_CoordModeMouse="Client","chest actions restore the caller mouse coordinate mode")
    WTOverlay.Show("x850 y450 w50 h50")
    WinSetTransparent("Off",WTOverlay)
    Sleep(100)
    WTAssert(!DungeonChestInput(565,260,"blocked Common Open"),"covered chest input is refused by the native window helper")
    WTOverlay.Hide()
    FileAppend("PASS: " WTCount " real window/image assertions.`n", "*")
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n", "*")
    ExitApp(1)
} finally {
    CoordMode("Pixel", WTPixelMode), CoordMode("Mouse", WTMouseMode)
    WTOverlay.Destroy(), WTMacro.Destroy(), WTGame.Destroy()
}
}
moveRobloxWindow(*) {
    throw Error("No main GUI positioning in isolated tests")
}
sizeDown(*) {
    WinMove(,,targetWidth,targetHeight,rblxID)
}
FixClick(x,y,*) {
    global WTClick
    if (A_CoordModeMouse != "Screen")
        throw Error("Click wrapper did not select Screen mode")
    WTClick := [x,y] ; no mouse movement or input
}
AddToLog(*) {
}
