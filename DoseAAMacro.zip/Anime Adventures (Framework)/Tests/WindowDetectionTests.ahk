#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; Real Win32 GUI, FindText and ImageSearch tests using synthetic windows only.
; Never includes Main/GUI/settings/webhooks and never clicks the real desktop.
#Include %A_ScriptDir%\..\Lib\Tools\WindowFollow.ahk
#Include %A_ScriptDir%\..\Lib\Tools\FindText.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk

global offsetX := -5, offsetY := 1, targetWidth := 816, targetHeight := 638
global WTGame := Gui("-Caption +ToolWindow -DPIScale"), WTMacro := Gui("+AlwaysOnTop -Caption -DPIScale")
global rblxID := "ahk_id " WTGame.Hwnd, aaMainUIHwnd := WTMacro.Hwnd
global robloxHolder := WTMacro.Add("Text", "x3 y33 w797 h597 Background303030", "")
global WTOverlay := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale")
global WTCount := 0, WTClick := [], WTPixelMode := A_CoordModePixel, WTMouseMode := A_CoordModeMouse
WTGame.BackColor := "101010", WTMacro.BackColor := "181818", WTOverlay.BackColor := "FF0000"
global WTMarker := WTGame.Add("Picture", "x300 y359 w15 h14", A_ScriptDir "\Fixtures\AvailableMarker.bmp")
global WTRare := WTGame.Add("Picture", "x310 y394 w16 h12", A_ScriptDir "\..\Images\RareChestImage.png")
; Black/white fixtures decode the supplied patterns; these are synthetic tests,
; not screenshots or proof of matching the live red boss card.
global WTBossBorder := WTGame.Add("Picture", "x365 y408 Hidden", A_ScriptDir "\Fixtures\BossBorder.bmp")
global WTBossIcon := WTGame.Add("Picture", "x400 y365 Hidden", A_ScriptDir "\Fixtures\BossIcon.bmp")
global WTOpening := WTGame.Add("Picture", "x365 y370 Hidden", A_ScriptDir "\Fixtures\OpeningMarker.bmp")
WTAssert(condition, label) {
    global WTCount
    WTCount += 1
    if !condition
        throw Error(label " / window issue: " WF_LastIssue)
}
WTMain()
ExitApp(0)

WTMain() {
try {
    WTGame.Show("x100 y100 w816 h638")
    WTMacro.Show("x105 y99 w1364 h697")
    WinSetTransColor("303030", WTMacro)
    Sleep(150)
    WTAssert(IsObject(WF_RobloxRegion(263,332,312,445)), "macro transparent holder allowed")
    WTAssert(!WF_FindText(&X,&Y,275,340,300,437,0.20,0.20,DungeonRoomBorder), "old narrow marker column misses shifted reference")
    WTAssert(WF_FindText(&X,&Y,263,332,312,445,0.20,0.20,DungeonRoomBorder), "expanded marker column finds same reference")
    WTAssert(X >= 295 && X <= 310, "FindText returns calibrated X")
    WTMarker.Value := A_ScriptDir "\Fixtures\AvailableMarkerOnePixelWrong.bmp"
    Sleep(80)
    WTAssert(WF_FindText(&X,&Y,263,332,312,445,0,0,DungeonRoomBorder), "FindText zero-zero silently retries with five percent error")
    WTAssert(!WF_FindText(&X,&Y,263,332,312,445,0.000001,0.000001,DungeonRoomBorder), "explicit exact sampling rejects the changed pixel")
    WTMarker.Value := A_ScriptDir "\Fixtures\AvailableMarker.bmp"
    Sleep(80)
    WTAssert(WF_FindText(&X,&Y,263,332,312,445,0.000001,0.000001,DungeonRoomBorder), "explicit exact sampling accepts genuine unchanged pattern")


    CoordMode("Pixel", "Client")
    image := A_ScriptDir "\..\Images\RareChestImage.png"
    WTAssert(WF_ImageSearch(&X,&Y,280,343,370,435,image), "PNG found inside owning room")
    WTAssert(X=305 && Y=395, "PNG returns calibrated top-left")
    WTAssert(A_CoordModePixel="Client", "pixel mode restored after success")
    WTAssert(!WF_ImageSearch(&X,&Y,438,343,525,435,image), "neighbor room cannot inherit PNG")
    WTAssert(A_CoordModePixel="Client", "pixel mode restored after miss")
    try WF_ImageSearch(&X,&Y,280,343,370,435,"Z:\missing-dungeon-test.png")
    WTAssert(A_CoordModePixel="Client", "pixel mode retained after image error")

    WTOverlay.Show("x380 y440 w80 h90 NoActivate")
    WinSetTransparent(0, WTOverlay)
    Sleep(100)
    WTAssert(IsObject(WF_RobloxRegion(280,343,370,435)), "fully invisible overlay does not veto layout")
    WinSetTransparent("Off", WTOverlay)
    Sleep(100)
    WTAssert(!IsObject(WF_RobloxRegion(280,343,370,435)), "opaque covering window rejected")
    WTAssert(InStr(WF_LastIssue,"covered by"), "cover rejection explained")
    WTOverlay.Hide()

    WinMove(300,200,,,rblxID)
    WinMove(305,199,,,"ahk_id " aaMainUIHwnd)
    Sleep(100)
    WTAssert(WF_ImageSearch(&X,&Y,280,343,370,435,image), "PNG follows moved Roblox")
    WTAssert(X=305 && Y=395, "movement does not change calibrated PNG position")

    WinMove(-100,100,,,rblxID)
    WinMove(-95,99,,,"ahk_id " aaMainUIHwnd)
    Sleep(100)
    WTAssert(WF_ImageSearch(&X,&Y,280,343,370,435,image), "visible region works with negative outer origin")
    WTAssert(!IsObject(WF_RobloxRegion(0,0,10,10)), "off-desktop query refused")
    WinMove(100,100,,,rblxID)
    WinMove(105,99,,,"ahk_id " aaMainUIHwnd)
    WinMove(,,700,550,rblxID)
    WTAssert(!IsObject(WF_RobloxRegion(280,343,370,435)), "wrong size reported")
    WTAssert(InStr(WF_LastIssue,"size"), "size mismatch explained")
    WTAssert(WF_PrepareDungeon(), "supported size is restored before scan")
    WTAssert(IsObject(WF_RobloxRegion(280,343,370,435)), "restored region usable")

    CoordMode("Mouse", "Client")
    WTAssert(WF_RobloxClick(322,360), "targeted click wrapper reaches mock")
    WTAssert(WTClick.Length=2 && WTClick[1]=427 && WTClick[2]=459, "room click translated to real screen")
    WTAssert(A_CoordModeMouse="Client", "mouse mode restored after targeted click")

    WTMarker.Visible := false, WTRare.Visible := false
    WTBossBorder.Visible := true, WTBossIcon.Visible := true
    Sleep(100)
    center := DungeonRoomAreas()[3]
    WTAssert(DungeonBossCardMatch(center), "native FindText locates supplied boss border plus icon in center card")
    WTAssert(DungeonProbeRoom(center,&detail)="Boss", "production scanner recognizes boss-only center card")
    WTBossIcon.Visible := false
    Sleep(80)
    WTAssert(!DungeonBossCardMatch(center), "boss border alone cannot confirm a boss card")
    WTBossIcon.Visible := true, WTBossBorder.Visible := false
    Sleep(80)
    WTAssert(!DungeonBossCardMatch(center), "boss icon alone cannot confirm a boss border")
    WTBossBorder.Visible := true, WTOpening.Visible := true
    Sleep(80)
    WTAssert(DungeonProbeRoom(center,&detail)="Boss", "OPEN marker does not mask confirmed boss references")
    rooms := DungeonScanRooms(&detail)
    WTAssert(rooms.Length=1 && rooms[1].index=3 && rooms[1].type="Boss", "native scan returns single centered boss candidate")
    FileAppend("PASS: " WTCount " real window/image assertions.`n", "*")
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n", "*")
    ExitApp(1)
} finally {
    CoordMode("Pixel", WTPixelMode), CoordMode("Mouse", WTMouseMode)
    WTOverlay.Destroy(), WTMacro.Destroy(), WTGame.Destroy()
}
}
moveRobloxWindow(*) {
    throw Error("No main GUI positioning in isolated tests")
}
sizeDown(*) {
    WinMove(,,targetWidth,targetHeight,rblxID)
}
FixClick(x,y,*) {
    global WTClick
    if (A_CoordModeMouse != "Screen")
        throw Error("Click wrapper did not select Screen mode")
    WTClick := [x,y] ; no mouse movement or input
}
