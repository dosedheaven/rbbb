#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\AppInfo.ahk
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonEntrance.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\DungeonChestOpening.ahk
#Include %A_ScriptDir%\EntranceFunctionsForTests.ahk
; Production startup control flow, synthetic screen/matching/input. The lobby
; coordinate conversion uses a real native window. No Main/settings/services.
global SGame := Gui("-Caption +ToolWindow -DPIScale"), rblxID := "ahk_id " SGame.Hwnd
global WF_LastIssue := "", SChecks := 0, SFrames := [], SCurrent := Map(), SRead := 0
global SClicks := [], SLogs := [], SPrepare := true, SClickOK := true, SHandOff := 0, SNonStartupWork := 0
global SaveChestsBox := {Value:1}
SGame.Show("x100 y100 w816 h638")
SFrame(kind := "Waiting", x := 405, y := 420) {
    rooms := kind="Route" ? [{index:3,type:"Available"}] : []
    return Map("kind",kind,"x",x,"y",y,"rooms",rooms,"issue","")
}
SReset(frames) {
    global SFrames, SCurrent, SRead, SClicks, SLogs, SPrepare, SClickOK, SHandOff, SNonStartupWork, WF_LastIssue
    SFrames := frames, SCurrent := frames[1], SRead := 0
    SClicks := [], SLogs := [], SPrepare := true, SClickOK := true, SHandOff := 0, SNonStartupWork := 0, WF_LastIssue := ""
}
SAssert(ok,label) {
    global SChecks
    SChecks += 1
    if !ok
        throw Error(label)
}
SHasLog(needle) {
    for message in SLogs
        if InStr(message,needle)
            return true
    return false
}
try {
    SReset([SFrame(),SFrame(),SFrame("Enter",400,415),SFrame("Enter",411,424),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1),"late Enter button is retried until a route is confirmed")
    SAssert(SClicks.Length=1 && SClicks[1][1]=411 && SClicks[1][2]=424,"click uses the fresh detected center, not the old fixed point or stale coordinates")
    SAssert(SHasLog("stable route screen ready"),"successful transition is explicitly logged")

    SReset([SFrame("Enter"),SFrame("Enter"),SFrame("Enter"),SFrame("Enter"),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1),"a missed first click is retried while the same button remains")
    SAssert(SClicks.Length=2,"second confirmed Enter receives a second attempt")

    SReset([SFrame("Enter"),SFrame("Route"),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1),"a button disappearing before click can transition directly to route")
    SAssert(!SClicks.Length,"no stale click is sent when the immediate recheck loses the button")

    SReset([SFrame("Enter")]), SClickOK := false
    SAssert(!DungeonWaitForEntrance(1000,1,1),"refused input prevents successful startup")
    SAssert(SHasLog("click refused"),"refused startup input is explained")

    bad := SFrame(), bad["issue"] := "covered by another window"
    SReset([bad])
    SAssert(!DungeonWaitForEntrance(1000,1,1) && !SClicks.Length,"unreadable entrance sends no input")
    SAssert(SHasLog("covered by another window"),"window failure is retained in the log")

    SReset([SFrame()])
    SAssert(!DungeonWaitForEntrance(70,1,1),"missing button and route time out rather than continue as if entered")
    SAssert(!SClicks.Length && SHasLog("timed out"),"missing reference gets no blind fallback click and a timeout diagnostic")

    SReset([SFrame("Enter")])
    SAssert(!DungeonWaitForEntrance(130,1,1,2),"an unresponsive Enter button has a bounded deadline")
    SAssert(SClicks.Length=2 && SHasLog("click limit reached"),"input remains capped while awaiting a late route")

    SReset([SFrame("Route"),SFrame(),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1) && SRead=4,"a disappearing route snapshot resets the stability requirement")
    SReset([SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1) && SRead=2 && !SClicks.Length,"an existing stable route needs no entrance click")

    invalid := SFrame("Route"), invalid["rooms"] := [{index:3,type:"Available"},{index:4,type:"Available"}]
    SReset([invalid])
    SAssert(!DungeonWaitForEntrance(70,1,1),"mixed room families cannot confirm entrance completion")

    SReset([SFrame("Death"),SFrame("Enter"),SFrame("Enter"),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1),"death Continue can precede startup Enter")
    SAssert(SClicks.Length=2 && SHasLog("death Continue") && SHasLog("Enter Dungeon"),"each startup dialog is identified before its own click")
    SReset([SFrame("DeathPending"),SFrame("Death"),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonWaitForEntrance(1000,1,1),"a delayed death Continue is awaited without blind input")

    SReset([SFrame("Enter"),SFrame("Enter"),SFrame("Enter"),SFrame("Route"),SFrame("Route")])
    SAssert(DungeonStartEntrance() && SClicks.Length=1,"starting on Enter resumes it without toggling the lobby button")
    SReset([SFrame("Route")])
    SAssert(DungeonStartEntrance() && !SClicks.Length,"starting on an existing route leaves the lobby button alone")
    SReset([SFrame(),SFrame("Enter"),SFrame("Enter"),SFrame("Route"),SFrame("Route")])
    CoordMode("Mouse","Client")
    SAssert(DungeonStartEntrance() && SClicks.Length=2,"lobby start opens the menu once, then handles Enter")
    SAssert(SClicks[1][1]=80 && SClicks[1][2]=401,"original client lobby point is converted to calibrated window coordinates")
    SAssert(A_CoordModeMouse="Client","lobby conversion does not change the caller mouse mode")

    SReset([SFrame("Route")]), SPrepare := false
    SAssert(!DungeonMode() && !SHandOff && !SClicks.Length,"actual DungeonMode refuses handoff when window preparation fails")
    SReset([bad])
    SAssert(!DungeonMode() && !SHandOff && !SClicks.Length,"actual DungeonMode refuses handoff for an obscured screen")
    SReset([SFrame("Enter")]), SClickOK := false
    SAssert(!DungeonMode() && !SHandOff,"actual DungeonMode never scans/selects rooms after a refused Enter")
    SReset([SFrame("Route")])
    SAssert(DungeonMode() && SHandOff=1,"actual DungeonMode hands off to room selection once after confirmed entrance")
    SReset([SFrame("Enter")]), SClickOK := false
    SAssert(!DungeonLookForRoomsUnderTest() && !SNonStartupWork,"actual room-flow recovery stops before special menus when startup click is refused")
    SReset([SFrame("Enter"),SFrame("Enter"),SFrame("Enter"),SFrame("Route"),SFrame("Route")])
    SAssert(!DungeonLookForRoomsUnderTest() && SNonStartupWork=1,"actual room flow handles a reappearing startup Enter before checking special menus")
    SAssert(SHasLog("resuming Enter Dungeon") && SHasLog("stable route screen ready"),"recovery has a confirmed entrance transition before room handoff")
    FileAppend("PASS: " SChecks " dungeon entrance assertions (screen/input mocked; native client-coordinate conversion).`n","*")
    SGame.Destroy()
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    SGame.Destroy()
    ExitApp(1)
}
WF_FindText(&X,&Y,x1,y1,x2,y2,e1,e0,text) {
    global SCurrent,SRead,WF_LastIssue
    if (text=EnterDungeon) {
        SRead += 1
        SCurrent := SFrames[Min(SRead,SFrames.Length)]
    }
    WF_LastIssue := SCurrent["issue"], X := SCurrent["x"], Y := SCurrent["y"]
    if (WF_LastIssue!="")
        return false
    if (text=EnterDungeon)
        return SCurrent["kind"]="Enter"
    if (text=DungeonDeath)
        return SCurrent["kind"]="Death" || SCurrent["kind"]="DeathPending"
    if (text=DungeonDeathContinue)
        return SCurrent["kind"]="Death"
    throw Error("Unexpected startup reference")
}
DungeonScanRooms(&diagnostic) {
    diagnostic := "synthetic scene"
    return SCurrent["rooms"]
}
WF_PrepareDungeon() {
    global WF_LastIssue
    WF_LastIssue := SPrepare ? "" : "window not found"
    return SPrepare
}
WF_RobloxClick(x,y) {
    SClicks.Push([x,y])
    return SClickOK
}
FT_GetOffset(&dx,&dy) {
    WinGetPos(&x,&y,,,rblxID)
    dx := x+5, dy := y-1
}
LookForDungeonRooms() {
    global SHandOff
    SHandOff += 1
    return true
}
AddToLog(message) {
    SLogs.Push(message)
}

CheckDungeonSpecials() {
    global SNonStartupWork
    SNonStartupWork += 1
    return false ; end this integration probe before any room selection
}
SelectBestRoom(*) {
    throw Error("Room selection escaped the startup integration probe")
}

DungeonHasCurseExclusions() => false
