#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
#Include %A_ScriptDir%\..\Lib\GuiSkin.ahk
#Include %A_ScriptDir%\..\Lib\GuiStyle.ahk
; Actual theme file IO is redirected to a unique temp folder. Never Main or
; private app settings. Native controls/font loading; no game or network.
global ATTemp := A_Temp "\DoseThemeTests-" A_TickCount
DirCreate(ATTemp)
AA_ThemeFile := ATTemp "\Theme.txt"
global ATChecks := 0, ATLogs := [], uiTheme := ["F1F5FF","0D1220","8B7CF8","171D30","303030","10192B","77E5F4"]
global ATGui := Gui("+ToolWindow -DPIScale")
class MacroLoopState {
    static Active := true ; SaveTheme must save without prompting/reloading a run.
}
ATAssert(ok,label) {
    global ATChecks
    ATChecks += 1
    if !ok
        throw Error(label)
}
ATWrite(name) {
    if FileExist(AA_ThemeFile)
        FileDelete(AA_ThemeFile)
    FileAppend(name,AA_ThemeFile,"UTF-8")
}
try {
    ATAssert(AA_ThemeOrder.Length=2 && AA_ThemeOrder[1]="Astral" && AA_ThemeOrder[2]="Tokyo Ghoul","exactly the two requested themes are offered")
    ATAssert(AA_Themes.Count=2,"removed color themes have no entries")
    ATAssert(AA_ThemeName()="Astral","new or missing settings use retained Astral")
    ATWrite("Arcane")
    ATAssert(AA_ThemeName()="Astral" && FileRead(AA_ThemeFile,"UTF-8")="Arcane","old Arcane selection aliases Astral without overwriting its file")
    for name in ["Orange","Blue","Purple","Green","Pink","Red"] {
        ATWrite(name)
        ATAssert(AA_ThemeName()="Astral","removed saved " name " safely falls back to Astral")
    }
    ATWrite("unknown")
    ATAssert(AA_ThemeName()="Astral","unknown selection has a valid fallback")
    ATWrite("")
    ATAssert(AA_ThemeName()="Astral","empty selection has a valid fallback")
    picker := ATGui.Add("DropDownList","x0 y0 w150 r2",AA_ThemeOrder)
    picker.Choose("Tokyo Ghoul")
    AA_SaveTheme(picker)
    ATAssert(FileRead(AA_ThemeFile,"UTF-8")="Tokyo Ghoul" && AA_ThemeName()="Tokyo Ghoul","actual native picker saves and reloads Tokyo Ghoul")
    AA_StyleInit()
    ATAssert(uiTheme[2]="0B0C11" && uiTheme[3]="C91E46" && uiTheme[7]="FF6B83","Tokyo startup applies charcoal/crimson/highlight palette")
    ATAssert(AA_CardColor="16141B" && AA_InputBg="100D14" && AA_BtnBg="2B1621","cards, inputs and buttons use the matching palette")
    ATAssert(uiTheme[5]="303030","Roblox color key stays unchanged")
    ATAssert(AA_AccentTextColor(uiTheme[3])="F1F5FF","active crimson buttons retain readable light labels")
    for theme in AA_ThemeOrder {
        palette := DoseThemePalette(theme)
        valid := true
        for name,value in palette.OwnProps()
            if (value="303030")
                valid := false
        ATAssert(valid,theme " decoration never uses the game transparency key")
    }
    root := A_ScriptDir "\..\Images\UI"
    tokyo := DoseThemeArtworkPath("Tokyo Ghoul",root)
    astral := DoseThemeArtworkPath("Astral",root)
    ATAssert(FileExist(tokyo) && InStr(tokyo,"DoseKaneki.jpg"),"Tokyo selects its own packaged artwork")
    ATAssert(FileExist(astral) && InStr(astral,"DoseJuuzou.png"),"Astral keeps the packaged Juuzou artwork")
    backdrop := DoseBuildBackdrop(ATGui,tokyo)
    backdrop.GetPos(&x,&y,&w,&h)
    ATAssert(x=804 && y=31 && w=558 && h=666,"artwork remains entirely outside the game rectangle")
    ATAssert(!DoseBuildBackdrop(ATGui,ATTemp "\missing.png"),"missing art has a nonthrowing plain-color fallback")
    DoseIconFont(root "\Fonts\DejaVuSans.ttf")
    ATAssert(DoseHeadingFont(root "\Fonts\NewRocker-Regular.ttf")="New Rocker","bundled display font loads privately without installation")
    title := ATGui.Add("Text","x0 y20 w300 h27","◈ Dose AA Macro v2.5")
    activity := ATGui.Add("Text","x0 y50 w400 h25","◈  ACTIVITY")
    DoseStyleHeadings(title,activity)
    ATAssert(title.Text="Dose AA Macro v2.5" && activity.Text="ACTIVITY","Tokyo heading styling changes decoration only")
    signature := DoseBuildThemeSignature(ATGui,tokyo)
    signature.GetPos(&x,&y,&w,&h)
    ATAssert(signature.Text="TOKYO GHOUL" && x>=804 && y=677,"theme signature uses the selected identity outside the viewport")
    picker.Choose("Astral")
    AA_SaveTheme(picker)
    ATAssert(AA_ThemeName()="Astral" && uiTheme[3]="C91E46","saving a future theme does not change an active run's current styling")
    AA_StyleInit()
    ATAssert(uiTheme[1]="EFF9F6" && uiTheme[2]="0B1519" && uiTheme[3]="66CDBB" && uiTheme[4]="13242A" && uiTheme[6]="0C191E" && uiTheme[7]="B5ECE0","Astral reload loads the matching Juuzou palette")
    ATAssert(uiTheme[5]="303030","theme changes never modify the game color key")
    title.Text := "◈ Dose AA Macro v2.5",activity.Text := "◈  ACTIVITY"
    DoseStyleHeadings(title,activity)
    ATAssert(title.Text="◈ Dose AA Macro v2.5" && activity.Text="◈  ACTIVITY","Astral keeps its original headings")
    ATAssert(ATLogs.Length>=2,"actual theme saving retains the existing running-macro log behavior")
    FileAppend("PASS: " ATChecks " anime-theme assertions (native controls/assets/fonts; synthetic theme file only).`n","*")
    ATGui.Destroy()
    DirDelete(ATTemp,1)
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n","*")
    ATGui.Destroy()
    try DirDelete(ATTemp,1)
    ExitApp(1)
}
AddToLog(message) => ATLogs.Push(message)
