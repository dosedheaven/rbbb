#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; OFFLINE Windows regression harness. Includes production dungeon functions and
; patterns, never Main/GUI/settings/webhooks. All screen/input/game hooks mocked.
; Executed with AutoHotkey v2 via Wine. Expected duration about 30-60 seconds.
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk

; Inert globals normally supplied by GUI/startup; never read user settings.
global SaveChestsBox := {Value:1}, DenyShrines := {Value:0}, ChallengeBox := {Value:0}, StopAfterDefeat := {Value:0}
global StageGuard := {}, FW_EndScreenTimeoutMs := 0, dungeonDeathBroken := false, enabledShrines := [], mode := "Dungeon"
global debugMessages := false
global PrioritiseFutureRareChests := {Value: false}
global routePriorityOrder := ["Rare_Chest", "Chest", "Hoard", "Shop", "Shrine", "Boss"]
global enabledCurses := [], TCurseReads := 0
global TScene := Map(), TFuture := [], TPattern := 1, TLast := 0, TEntered := 0
global TImageFail := false, TImageCalls := Map(), TChecks := 0, TClicks := []
global WF_LastIssue := ""
global TLogs := []

TAssert(condition, label) {
    global TChecks
    TChecks += 1
    if !condition
        throw Error("FAILED: " label)
}
TReset(ids) {
    global TScene, TFuture, TPattern, TLast, TEntered, TImageFail, TImageCalls, TClicks, enabledCurses, TCurseReads
    global PrioritiseFutureRareChests, routePriorityOrder, BossRoomCompleted
    global TLogs
    TLogs := []
    enabledCurses := [], TCurseReads := 0
    TScene := Map(), TFuture := [], TPattern := 1, TLast := 0, TEntered := 0
    TImageFail := false, TImageCalls := Map(), TClicks := [], BossRoomCompleted := false
    PrioritiseFutureRareChests.Value := false
    routePriorityOrder := ["Rare_Chest", "Chest", "Hoard", "Shop", "Shrine", "Boss"]
    areas := DungeonRoomAreas(), rooms := []
    for id in ids {
        TScene[id] := {kind: "Chest", state: "Available", curse: "allow", recheck: true, clickOK: true,
            rareSamples: [], specialSamples: [], specialReads: 0, imageErrorAfter: 0, textIssue: false,
            bossBorder: false, bossSamples: [], bossReads: 0, extraIcons: [],
            openingMarker: false, openingSamples: [], openingReads: 0, markerMissing: false, curseIcon: false}
        rooms.Push({index: id, type: "Available", coords: areas[id]})
    }
    return rooms
}
TState(rooms, id, state) {
    TScene[id].state := state
    for room in rooms
        if (room.index = id)
            room.type := state
}
TSelect(rooms, expected, label) {
    global TEntered
    SelectBestRoom(rooms.Length, rooms)
    TAssert(TEntered = expected, label)
}

; Screen mocks use EXACT rectangles passed by production, not a global flag.
WF_FindText(&X, &Y, x1, y1, x2, y2, e1, e0, text) {
    global TCurseReads, WF_LastIssue
    WF_LastIssue := ""
    X := x1, Y := y1
    if (x1 = 121 && y1 = 168) {
        if (!TLast || !TScene.Has(TLast))
            return false
        TCurseReads += 1
        if (TScene[TLast].curse = "unknown")
            return false
        if (TScene[TLast].curse = "shop")
            return text = CurseOfShop
        return TScene[TLast].curse = "skip" ? text = CurseOfWind : text = CurseOfMoney
    }
    for a in DungeonFutureAreas() {
        if (x1 = a.x1 && y1 = a.y1 && x2 = a.x2 && y2 = a.y2)
            return HasValue(TFuture, a.path) && text = (TPattern = 1 ? FutureRareChest1 : FutureRareChest2)
    }
    for id, scene in TScene {
        a := DungeonRoomAreas()[id]
        marker := DungeonMarkerArea(a)
        if (x1 = marker.x1 && y1 = marker.y1 && x2 = marker.x2 && y2 = marker.y2)
            return scene.recheck && !scene.markerMissing && (text = DungeonBorderText(scene.state)
                || (scene.bossBorder && text = DungeonBorderText("Boss")))
        if (x1 = a.searchX1 && y1 = a.searchY1 && x2 = a.searchX2 && y2 = a.searchY2) {
            if scene.textIssue {
                WF_LastIssue := "Simulated obscured text region"
                return false
            }
            if (text = DungeonRoomBorderChestOpen) {
                if scene.openingSamples.Length {
                    scene.openingReads += 1
                    return scene.openingSamples[Min(scene.openingReads, scene.openingSamples.Length)]
                }
                return scene.state = "Opening" || scene.openingMarker
            }
            if (text = Curse)
                return scene.curseIcon
            if (text = roomTexts["Hoard"] && scene.specialSamples.Length) {
                scene.specialReads += 1
                return scene.specialSamples[Min(scene.specialReads, scene.specialSamples.Length)]
            }
            if (text = BossRoom2 && scene.bossSamples.Length) {
                scene.bossReads += 1
                return scene.bossSamples[Min(scene.bossReads, scene.bossSamples.Length)]
            }
            for extra in scene.extraIcons {
                if (roomTexts.Has(extra) && text = roomTexts[extra])
                    return true
            }
            if (text = roomTexts["Chest"])
                return scene.kind = "Chest" || scene.kind = "Rare_Chest"
            return roomTexts.Has(scene.kind) && text = roomTexts[scene.kind] && text != ""
        }
    }
    return false
}
WF_ImageSearch(&X, &Y, x1, y1, x2, y2, imagePath, variation := 20) {
    global TImageCalls
    if TImageFail
        throw Error("Simulated unreadable reference image")
    X := x1, Y := y1
    for id, scene in TScene {
        a := DungeonRoomAreas()[id]
        if (x1 != a.searchX1 || y1 != a.searchY1 || x2 != a.searchX2 || y2 != a.searchY2)
            continue
        TImageCalls[id] := TImageCalls.Has(id) ? TImageCalls[id] + 1 : 1
        if (scene.imageErrorAfter && TImageCalls[id] > scene.imageErrorAfter)
            throw Error("Simulated image-region failure before selection")
        if scene.rareSamples.Length
            return scene.rareSamples[Min(TImageCalls[id], scene.rareSamples.Length)]
        return scene.kind = "Rare_Chest"
    }
    throw Error("Rare-image search did not use an exact room rectangle")
}
WF_RobloxClick(x, y) {
    global TLast, TClicks
    for id, scene in TScene {
        a := DungeonRoomAreas()[id]
        if (x = a.clickX && y = a.clickY) {
            if !scene.clickOK
                return false
            TLast := id, TClicks.Push(id)
            return true
        }
    }
    throw Error("Unexpected click")
}
FT(&X, &Y, x1, y1, x2, y2, e1, e0, text, args*) {
    X := x1, Y := y1
    return text = Enter ; only the simulated room Enter button exists
}
AddToLog(message) {
    TLogs.Push(message)
}
WaitFor(*) => true
WF_PrepareDungeon(*) => true
ClickUntilGone(*) => true
ShouldSkipCurse(curse) => HasValue(enabledCurses, curse)
NextStep(step) {
    global TEntered
    TEntered := TLast
    return true
}
HasValue(array, value) {
    for item in array
        if (item = value)
            return true
    return false
}
; Required references in production functions not exercised by these tests.
RestartStage(*) {
}
CheckLobby(*) {
}
StartSelectedMode(*) {
}
RejoinPrivateServer(*) {
    throw Error("Rejoining is forbidden in offline tests")
}
CheckForLobby(*) {
}
CheckForReturnToLobby(*) => false
ClickReplay(*) {
}
ClickReturnToLobby(*) {
}
FixClick(*) {
    throw Error("A legacy click escaped the offline mock")
}
Reconnect(*) {
}
ScheduleTick(*) => false
SendFinalWebhookBeforeExit(*) {
    throw Error("Network action is forbidden in this harness")
}

TMain()

TMain() {
    global TImageCalls, TImageFail, TPattern, TFuture, routePriorityOrder, enabledCurses

try {
    for ids in [[3], [4,5], [1,2,3]] {
        rooms := TReset(ids)
        TAssert(DungeonValidLayout(rooms), "valid layout")
        for target in ids {
            rooms := TReset(ids)
            TScene[target].kind := "Rare_Chest"
            detections := DungeonDetectRooms(rooms, Map())
            for id in ids {
                TAssert(detections[id].Has("Rare_Chest") = (id = target), "rare associated only with room " target)
                TAssert(detections[id].Has("Chest") = (id != target), "mutually exclusive chest classification")
            }
        }
    }
    rooms := TReset([4])
    TAssert(DungeonValidLayout(rooms), "confirmed card remains usable with a missed neighbor")
    TSelect(rooms,4,"partial two-card layout selects only confirmed physical room")
    rooms := TReset([3,4])
    TAssert(!DungeonValidLayout(rooms), "mixed calibration rejected")
    rooms := TReset([3])
    TScene[3].rareSamples := [false,true,true]
    TAssert(DungeonDetectRooms(rooms, Map())[3].Has("Rare_Chest"), "bounded retry finds delayed rare")
    TImageCalls := Map(), TScene[3].rareSamples := [false,true,false]
    d := DungeonDetectRooms(rooms, Map())[3]
    TAssert(!d.Has("Rare_Chest") && !d.Has("Chest"), "one-frame rare is inconclusive")
    TImageFail := true
    d := DungeonDetectRooms(rooms, Map())[3]
    TAssert(!d.Has("Chest") && !d.Has("Rare_Chest") && !d.Has("Normal"), "asset error does not become a chest or regular room")

    for pattern in [1,2] {
        for path in ["Left","Center","Right"] {
            rooms := TReset([1,2,3]), TPattern := pattern, TFuture := [path]
            TAssert(CheckFutureRareChest() = path, "future pattern " pattern " independently detects " path)
        }
    }
    rooms := TReset([4,5]), TFuture := ["Center"]
    TAssert(!DungeonFutureRarePaths(rooms).Length, "two-room layout does not invent center")
    rooms := TReset([4,5]), TFuture := ["Left","Right"]
    TState(rooms,4,"Unavailable")
    paths := DungeonFutureRarePaths(rooms)
    TAssert(paths.Length = 1 && paths[1] = "Right", "unavailable future path excluded")

    rooms := TReset([4,5]), TScene[5].kind := "Rare_Chest"
    TSelect(rooms,5,"rare selected in correct room")
    rooms := TReset([4,5]), TScene[4].kind := "Rare_Chest"
    routePriorityOrder := ["Chest","Rare_Chest"]
    TSelect(rooms,5,"configured normal-chest priority preserved")
    rooms := TReset([4,5]), TScene[4].kind := "Rare_Chest", TScene[5].kind := "Hoard"
    TState(rooms,4,"Unavailable")
    TSelect(rooms,5,"unavailable rare excluded")
    rooms := TReset([4,5]), TScene[4].kind := "Rare_Chest", TScene[4].curse := "skip", TScene[5].kind := "Hoard"
    TState(rooms,4,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,5,"avoided curse excluded from lower priorities")
    rooms := TReset([4,5]), TFuture := ["Left"], TScene[4].curse := "skip", TScene[5].kind := "Hoard"
    PrioritiseFutureRareChests.Value := true, TState(rooms,4,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,5,"future path obeys curse protection")
    rooms := TReset([4,5]), TFuture := ["Left","Right"]
    TState(rooms,4,"Cursed"), TState(rooms,5,"Cursed")
    TScene[4].curse := "unknown", TScene[5].curse := "unknown"
    PrioritiseFutureRareChests.Value := true
    TSelect(rooms,4,"reported two-cursed-room case works when no curses are excluded")
    TAssert(TCurseReads=0,"empty avoidance list does not wait for curse identification")
    rooms := TReset([3]), TScene[3].curse := "unknown"
    TState(rooms,3,"Cursed"), enabledCurses := ["None", "", " None "]
    TSelect(rooms,3,"None-only avoidance slots mean all curses are allowed")
    TAssert(TCurseReads=0,"None-only slots do not trigger curse scan")
    rooms := TReset([3]), TScene[3].curse := "unknown"
    TState(rooms,3,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,0,"unknown curse remains blocked when an exclusion is configured")
    TAssert(TCurseReads>0,"active exclusions trigger curse recognition")
    rooms := TReset([3]), TState(rooms,3,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,3,"recognized non-excluded curse remains allowed")
    rooms := TReset([3]), TScene[3].curse := "shop"
    TState(rooms,3,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,3,"known Shop curse is recognized and allowed when Wind alone is excluded")
    rooms := TReset([3]), TScene[3].kind := "Boss"
    TSelect(rooms,3,"boss selected")
    TAssert(BossRoomCompleted,"boss completion flag preserved")
    rooms := TReset([3]), TScene[3].kind := "Unknown"
    TSelect(rooms,3,"reported single available room with no icon is entered")
    TAssert(TClicks.Length=1 && TClicks[1]=3,"regular room uses its confirmed card click point")
    TAssert(!BossRoomCompleted,"regular room does not become a boss")
    rooms := TReset([4]), TScene[4].kind := "Unknown"
    TSelect(rooms,4,"regular room in a partial two-card layout uses the actual card")
    rooms := TReset([1,2,3])
    for id in [1,2,3]
        TScene[id].kind := "Unknown"
    TSelect(rooms,1,"three regular rooms preserve scan tie order")
    rooms := TReset([4,5]), TScene[4].kind := "Unknown", TScene[5].kind := "Rare_Chest"
    TSelect(rooms,5,"configured special priority wins over a regular room")
    rooms := TReset([4,5]), TScene[5].kind := "Unknown", routePriorityOrder := ["Hoard"]
    TSelect(rooms,4,"omitted chest preference remains eligible before ordinary-room fallback")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Unavailable")
    TSelect(rooms,0,"unavailable iconless room is not a regular candidate")
    TAssert(!TClicks.Length,"unavailable iconless room receives no click")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Opening")
    TSelect(rooms,3,"green OPEN checkpoint with no special room icon uses the Enter flow")
    TAssert(!BossRoomCompleted,"green OPEN checkpoint is not marked as a boss")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Cursed")
    TScene[3].curse := "unknown"
    TSelect(rooms,3,"regular cursed room enters when no curses are excluded")
    TAssert(TCurseReads=0,"regular room respects no-exclusions policy")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Cursed")
    TScene[3].curse := "unknown", enabledCurses := ["Wind"]
    TSelect(rooms,0,"regular room still rejects unknown curse with active exclusions")
    rooms := TReset([4,5]), TScene[4].kind := "Unknown", TScene[5].kind := "Unknown"
    TState(rooms,4,"Cursed"), TScene[4].curse := "skip", enabledCurses := ["Wind"]
    TSelect(rooms,5,"rejected regular cursed room yields to a second regular candidate")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].rareSamples := [false,true,false]
    TSelect(rooms,0,"inconclusive rare observation is not treated as a regular room")
    TAssert(!TClicks.Length,"inconclusive icon does not cause a fallback click")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].specialSamples := [false,true,false]
    TSelect(rooms,0,"one transient special icon prevents regular-room classification")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].rareSamples := [false,false,false,true]
    TSelect(rooms,0,"rare icon appearing before the regular-room click cancels selection")
    TAssert(!TClicks.Length,"changed rare evidence receives no click")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].specialSamples := [false,false,false,true]
    TSelect(rooms,0,"special icon appearing at regular-room recheck cancels selection")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TImageFail := true
    TSelect(rooms,0,"failed image search cannot qualify an iconless room")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].imageErrorAfter := 3
    TSelect(rooms,0,"failed image recheck cannot enter a regular room")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].textIssue := true
    TSelect(rooms,0,"failed text search cannot qualify an iconless room")
    rooms := TReset([3]), TScene[3].recheck := false
    TSelect(rooms,0,"changed border causes no click")
    TAssert(!TClicks.Length,"border recheck blocks click")

    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Boss")
    scanned := DungeonScanRooms(&scanDetail)
    TAssert(scanned.Length=1 && scanned[1].index=3 && scanned[1].type="Boss",
        "boss-only border and icon are scanned as the single center candidate")
    TScene[3].extraIcons := ["Chest"], routePriorityOrder := ["Chest"]
    PrioritiseFutureRareChests.Value := true, TFuture := ["Center"]
    TSelect(scanned,3,"final boss with chest and future markers enters without Boss in preferences")
    TAssert(BossRoomCompleted,"final boss is marked as a boss despite chest-first preferences")
    TAssert(TClicks.Length=1 && TClicks[1]=3,"final stage clicks only its center card")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Opening")
    TScene[3].bossBorder := true
    TAssert(DungeonProbeRoom(rooms[1].coords,&scanDetail)="Boss",
        "OPEN/chest marker does not hide a corroborated boss card")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Boss")
    TAssert(!DungeonScanRooms(&scanDetail).Length,"boss border alone is insufficient")
    TSelect(rooms,0,"unconfirmed final boss icon never triggers a center click")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Unknown")
    TAssert(!DungeonScanRooms(&scanDetail).Length,"boss icon alone does not invent a room border")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Unavailable")
    TScene[3].bossBorder := true
    TAssert(DungeonProbeRoom(rooms[1].coords,&scanDetail)="Unavailable",
        "boss evidence cannot upgrade an unavailable card")
    TSelect(rooms,0,"unavailable boss remains unselectable")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Cursed")
    TScene[3].bossBorder := true, TScene[3].curse := "skip", enabledCurses := ["Wind"]
    TAssert(DungeonProbeRoom(rooms[1].coords,&scanDetail)="Cursed",
        "boss evidence cannot erase a cursed card state")
    TSelect(rooms,0,"boss icon does not bypass curse exclusions")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Boss")
    TScene[3].bossSamples := [false,true,false]
    TSelect(rooms,0,"single-frame boss icon is not a confirmed final stage")
    TAssert(!TClicks.Length,"inconclusive boss evidence causes no click")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Boss")
    TScene[3].bossSamples := [true,true,true,false]
    TSelect(rooms,0,"boss icon disappearing at border recheck cancels entry")
    TAssert(!BossRoomCompleted && !TClicks.Length,"failed boss recheck neither clicks nor marks completion")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Boss")
    TScene[3].bossSamples := [true,true,true,true,false]
    TSelect(rooms,0,"boss icon is checked once more before the targeted click")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Boss")
    TScene[3].clickOK := false
    TSelect(rooms,0,"failed final boss click cannot enter")
    TAssert(!BossRoomCompleted,"failed final boss click does not set boss completion state")
    rooms := TReset([4,5]), TScene[4].kind := "Boss", TState(rooms,4,"Boss")
    routePriorityOrder := ["Chest"]
    TSelect(rooms,5,"side boss does not outrank an explicitly preferred chest")
    rooms := TReset([1,2,3]), TScene[3].kind := "Boss", TState(rooms,3,"Boss")
    TScene[1].kind := "Hoard", routePriorityOrder := ["Hoard"]
    TSelect(rooms,1,"multiple-room layout keeps configured priorities")

    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Opening")
    TScene[3].markerMissing := true
    scanned := DungeonScanRooms(&scanDetail)
    TAssert(scanned.Length=1 && scanned[1].index=3 && scanned[1].type="Opening",
        "centered OPEN is found inside the card when the narrow marker strip misses")
    routePriorityOrder := [], PrioritiseFutureRareChests.Value := true, TFuture := ["Center"]
    TSelect(scanned,3,"single centered OPEN checkpoint needs no route priority")
    TAssert(TClicks.Length=1 && TClicks[1]=3,"OPEN checkpoint uses only its confirmed card click")
    rooms := TReset([4,5]), TScene[4].kind := "Unknown", TState(rooms,4,"Opening")
    TScene[5].kind := "Rare_Chest"
    TSelect(rooms,5,"configured rare priority wins over an optional OPEN checkpoint")
    rooms := TReset([4,5]), TScene[4].kind := "Unknown", TScene[5].kind := "Unknown"
    TState(rooms,5,"Opening")
    TSelect(rooms,5,"OPEN checkpoint precedes ordinary-room fallback")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Opening")
    TScene[3].openingSamples := [false,true,false], PrioritiseFutureRareChests.Value := true, TFuture := ["Center"]
    TSelect(rooms,0,"one-frame OPEN marker cannot enter even through future preference")
    TAssert(!TClicks.Length,"inconclusive OPEN evidence causes no click")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Opening")
    TScene[3].openingSamples := [true,true,true,false]
    TSelect(rooms,0,"OPEN disappearing at final recheck cancels the card click")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Opening")
    TScene[3].clickOK := false
    TSelect(rooms,0,"refused OPEN card click does not enter")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Opening")
    TImageFail := true
    TSelect(rooms,3,"positive OPEN marker does not depend on the unrelated rare-chest PNG")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Unavailable")
    TScene[3].openingMarker := true
    TAssert(DungeonProbeRoom(rooms[1].coords,&scanDetail)="Unavailable",
        "centered OPEN never upgrades an unavailable card")
    TSelect(rooms,0,"unavailable OPEN is not selected")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TState(rooms,3,"Cursed")
    TScene[3].openingMarker := true
    TAssert(DungeonProbeRoom(rooms[1].coords,&scanDetail)="Cursed",
        "OPEN never erases a detected curse state")
    rooms := TReset([3]), TScene[3].kind := "Boss", TState(rooms,3,"Unknown")
    TScene[3].openingMarker := true, TScene[3].markerMissing := true
    TAssert(!DungeonScanRooms(&scanDetail).Length,"OPEN plus Boss icon cannot invent a green checkpoint")
    rooms := TReset([3]), TScene[3].kind := "Chest", TScene[3].openingMarker := true, TScene[3].markerMissing := true
    TAssert(!DungeonScanRooms(&scanDetail).Length,"OPEN plus Chest label cannot invent a green checkpoint")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].openingMarker := true
    TScene[3].markerMissing := true, TScene[3].curseIcon := true
    TAssert(!DungeonScanRooms(&scanDetail).Length,"OPEN plus curse icon cannot invent a green checkpoint")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TScene[3].openingMarker := true
    TScene[3].markerMissing := true, TScene[3].textIssue := true
    TAssert(!DungeonScanRooms(&scanDetail).Length,"failed text capture cannot invent an OPEN checkpoint")

    rooms := TReset([3]), TScene[3].kind := "Chest", TScene[3].extraIcons := ["Hoard","Shrine"]
    TState(rooms,3,"Cursed"), routePriorityOrder := ["Rare_Chest","Rare_Chest","Rare_Chest","Rare_Chest","Rare_Chest","Rare_Chest"]
    d := DungeonDetectRooms(rooms,Map())[3]
    TAssert(d.Has("Chest") && d.Has("Hoard") && d.Has("Shrine"),"reported single cursed card has all three confirmed reward types")
    TSelect(rooms,3,"reported six-duplicate-priority dead end enters the confirmed single cursed room")
    TAssert(TCurseReads=0 && TClicks.Length=1,"reported no-exclusions case enters once without unnecessary curse matching")
    selectedForChest := false
    for message in TLogs {
        if InStr(message,"because priority Chest")
            selectedForChest := true
    }
    TAssert(selectedForChest,"reported case uses a confirmed Chest priority, not a blind center fallback")
    TAssert(routePriorityOrder.Length=6 && routePriorityOrder[2]="Rare_Chest","priority recovery never rewrites saved/runtime source preferences")
    order := DungeonEffectiveRoutePriorities(&detail)
    TAssert(DungeonPriorityList(order)="Rare_Chest > Chest > Hoard > Shop > Shrine > Boss","duplicate preference list recovers complete canonical order")
    TAssert(InStr(detail,"omitted") && InStr(detail,"duplicate/invalid"),"recovery explains missing and duplicated entries")
    rooms := TReset([4,5]), TScene[4].kind := "Chest", TScene[5].kind := "Shrine"
    routePriorityOrder := ["Shrine","Chest","Shrine","Rare Chest"]
    order := DungeonEffectiveRoutePriorities(&detail)
    TAssert(DungeonPriorityList(order)="Shrine > Chest > Rare_Chest > Hoard > Shop > Boss","valid custom order precedes omitted defaults and aliases normalize")
    TSelect(rooms,5,"custom shrine preference is preserved ahead of a chest")
    rooms := TReset([3]), routePriorityOrder := []
    TSelect(rooms,3,"empty route preferences recover defaults without a stall")
    rooms := TReset([3]), routePriorityOrder := ["", "None", "unrecognized", 0]
    TSelect(rooms,3,"invalid route entries recover defaults without selecting unknown icons")
    rooms := TReset([3]), TScene[3].kind := "Unknown", routePriorityOrder := ["Rare_Chest"]
    TSelect(rooms,3,"regular-room entry survives priority recovery")
    rooms := TReset([3]), TScene[3].kind := "Chest", TScene[3].extraIcons := ["Hoard","Shrine"]
    TState(rooms,3,"Cursed"), routePriorityOrder := ["Rare_Chest"], enabledCurses := ["Wind"], TScene[3].curse := "skip"
    TSelect(rooms,0,"expanded preference list still rejects avoided cursed rooms")
    TAssert(TClicks.Length=2,"rejected multi-icon cursed room is clicked and dismissed only once")
    rooms := TReset([3]), TScene[3].kind := "Chest", TScene[3].extraIcons := ["Hoard","Shrine"]
    TState(rooms,3,"Unavailable"), routePriorityOrder := ["Rare_Chest"]
    TSelect(rooms,0,"expanded preference list cannot unlock an unavailable multi-icon room")
    TAssert(!TClicks.Length,"unavailable multi-icon room receives no click")
    rooms := TReset([3]), TScene[3].kind := "Unknown", TImageFail := true, routePriorityOrder := []
    TSelect(rooms,0,"preference recovery does not invent evidence after image failure")
    FileAppend("PASS: " TChecks " assertions against production dungeon functions (screen/input mocked).`n", "*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n", "*")
    ExitApp(1)
}

}
