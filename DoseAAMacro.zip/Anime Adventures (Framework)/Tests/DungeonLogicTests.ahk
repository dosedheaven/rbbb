#Requires AutoHotkey v2.0
#SingleInstance Off
#Warn All, StdOut
#Warn LocalSameAsGlobal, Off
; OFFLINE Windows regression harness. Includes production dungeon functions and
; patterns, never Main/GUI/settings/webhooks. All screen/input/game hooks mocked.
; Executed with AutoHotkey v2 via Wine. Expected duration about 30-60 seconds.
#Include %A_ScriptDir%\..\Lib\Tools\Image.ahk
#Include %A_ScriptDir%\..\Lib\Modes\Dungeon\Dungeon_FutureRareChest.ahk

; Inert globals normally supplied by GUI/startup; never read user settings.
global SaveChestsBox := {Value:1}, DenyShrines := {Value:0}, ChallengeBox := {Value:0}, StopAfterDefeat := {Value:0}
global StageGuard := {}, FW_EndScreenTimeoutMs := 0, dungeonDeathBroken := false, enabledShrines := [], mode := "Dungeon"
global debugMessages := false
global PrioritiseFutureRareChests := {Value: false}
global routePriorityOrder := ["Rare_Chest", "Chest", "Hoard", "Shop", "Shrine", "Boss"]
global enabledCurses := [], TCurseReads := 0
global TScene := Map(), TFuture := [], TPattern := 1, TLast := 0, TEntered := 0
global TImageFail := false, TImageCalls := Map(), TChecks := 0, TClicks := []

TAssert(condition, label) {
    global TChecks
    TChecks += 1
    if !condition
        throw Error("FAILED: " label)
}
TReset(ids) {
    global TScene, TFuture, TPattern, TLast, TEntered, TImageFail, TImageCalls, TClicks, enabledCurses, TCurseReads
    global PrioritiseFutureRareChests, routePriorityOrder, BossRoomCompleted
    enabledCurses := [], TCurseReads := 0
    TScene := Map(), TFuture := [], TPattern := 1, TLast := 0, TEntered := 0
    TImageFail := false, TImageCalls := Map(), TClicks := [], BossRoomCompleted := false
    PrioritiseFutureRareChests.Value := false
    routePriorityOrder := ["Rare_Chest", "Chest", "Hoard", "Shop", "Shrine", "Boss"]
    areas := DungeonRoomAreas(), rooms := []
    for id in ids {
        TScene[id] := {kind: "Chest", state: "Available", curse: "allow", recheck: true, clickOK: true, rareSamples: []}
        rooms.Push({index: id, type: "Available", coords: areas[id]})
    }
    return rooms
}
TState(rooms, id, state) {
    TScene[id].state := state
    for room in rooms
        if (room.index = id)
            room.type := state
}
TSelect(rooms, expected, label) {
    global TEntered
    SelectBestRoom(rooms.Length, rooms)
    TAssert(TEntered = expected, label)
}

; Screen mocks use EXACT rectangles passed by production, not a global flag.
WF_FindText(&X, &Y, x1, y1, x2, y2, e1, e0, text) {
    global TCurseReads
    X := x1, Y := y1
    if (x1 = 121 && y1 = 168) {
        if (!TLast || !TScene.Has(TLast))
            return false
        TCurseReads += 1
        if (TScene[TLast].curse = "unknown")
            return false
        if (TScene[TLast].curse = "shop")
            return text = CurseOfShop
        return TScene[TLast].curse = "skip" ? text = CurseOfWind : text = CurseOfMoney
    }
    for a in DungeonFutureAreas() {
        if (x1 = a.x1 && y1 = a.y1 && x2 = a.x2 && y2 = a.y2)
            return HasValue(TFuture, a.path) && text = (TPattern = 1 ? FutureRareChest1 : FutureRareChest2)
    }
    for id, scene in TScene {
        a := DungeonRoomAreas()[id]
        marker := DungeonMarkerArea(a)
        if (x1 = marker.x1 && y1 = marker.y1 && x2 = marker.x2 && y2 = marker.y2)
            return scene.recheck && text = DungeonBorderText(scene.state)
        if (x1 = a.searchX1 && y1 = a.searchY1 && x2 = a.searchX2 && y2 = a.searchY2) {
            if (text = roomTexts["Chest"])
                return scene.kind = "Chest" || scene.kind = "Rare_Chest"
            return roomTexts.Has(scene.kind) && text = roomTexts[scene.kind] && text != ""
        }
    }
    return false
}
WF_ImageSearch(&X, &Y, x1, y1, x2, y2, imagePath, variation := 20) {
    global TImageCalls
    if TImageFail
        throw Error("Simulated unreadable reference image")
    X := x1, Y := y1
    for id, scene in TScene {
        a := DungeonRoomAreas()[id]
        if (x1 != a.searchX1 || y1 != a.searchY1 || x2 != a.searchX2 || y2 != a.searchY2)
            continue
        TImageCalls[id] := TImageCalls.Has(id) ? TImageCalls[id] + 1 : 1
        if scene.rareSamples.Length
            return scene.rareSamples[Min(TImageCalls[id], scene.rareSamples.Length)]
        return scene.kind = "Rare_Chest"
    }
    throw Error("Rare-image search did not use an exact room rectangle")
}
WF_RobloxClick(x, y) {
    global TLast, TClicks
    for id, scene in TScene {
        a := DungeonRoomAreas()[id]
        if (x = a.clickX && y = a.clickY) {
            if !scene.clickOK
                return false
            TLast := id, TClicks.Push(id)
            return true
        }
    }
    throw Error("Unexpected click")
}
FT(&X, &Y, x1, y1, x2, y2, e1, e0, text, args*) {
    X := x1, Y := y1
    return text = Enter ; only the simulated room Enter button exists
}
AddToLog(*) {
}
WaitFor(*) => true
WF_PrepareDungeon(*) => true
ClickUntilGone(*) => true
ShouldSkipCurse(curse) => HasValue(enabledCurses, curse)
NextStep(step) {
    global TEntered
    TEntered := TLast
    return true
}
HasValue(array, value) {
    for item in array
        if (item = value)
            return true
    return false
}
; Required references in production functions not exercised by these tests.
RestartStage(*) {
}
CheckLobby(*) {
}
StartSelectedMode(*) {
}
RejoinPrivateServer(*) {
    throw Error("Rejoining is forbidden in offline tests")
}
CheckForLobby(*) {
}
CheckForReturnToLobby(*) => false
ClickReplay(*) {
}
ClickReturnToLobby(*) {
}
FixClick(*) {
    throw Error("A legacy click escaped the offline mock")
}
Reconnect(*) {
}
ScheduleTick(*) => false
SendFinalWebhookBeforeExit(*) {
    throw Error("Network action is forbidden in this harness")
}

TMain()

TMain() {
    global TImageCalls, TImageFail, TPattern, TFuture, routePriorityOrder, enabledCurses

try {
    for ids in [[3], [4,5], [1,2,3]] {
        rooms := TReset(ids)
        TAssert(DungeonValidLayout(rooms), "valid layout")
        for target in ids {
            rooms := TReset(ids)
            TScene[target].kind := "Rare_Chest"
            detections := DungeonDetectRooms(rooms, Map())
            for id in ids {
                TAssert(detections[id].Has("Rare_Chest") = (id = target), "rare associated only with room " target)
                TAssert(detections[id].Has("Chest") = (id != target), "mutually exclusive chest classification")
            }
        }
    }
    rooms := TReset([4])
    TAssert(DungeonValidLayout(rooms), "confirmed card remains usable with a missed neighbor")
    TSelect(rooms,4,"partial two-card layout selects only confirmed physical room")
    rooms := TReset([3,4])
    TAssert(!DungeonValidLayout(rooms), "mixed calibration rejected")
    rooms := TReset([3])
    TScene[3].rareSamples := [false,true,true]
    TAssert(DungeonDetectRooms(rooms, Map())[3].Has("Rare_Chest"), "bounded retry finds delayed rare")
    TImageCalls := Map(), TScene[3].rareSamples := [false,true,false]
    d := DungeonDetectRooms(rooms, Map())[3]
    TAssert(!d.Has("Rare_Chest") && !d.Has("Chest"), "one-frame rare is inconclusive")
    TImageFail := true
    d := DungeonDetectRooms(rooms, Map())[3]
    TAssert(!d.Has("Chest") && !d.Has("Rare_Chest"), "asset error does not become normal chest")

    for pattern in [1,2] {
        for path in ["Left","Center","Right"] {
            rooms := TReset([1,2,3]), TPattern := pattern, TFuture := [path]
            TAssert(CheckFutureRareChest() = path, "future pattern " pattern " independently detects " path)
        }
    }
    rooms := TReset([4,5]), TFuture := ["Center"]
    TAssert(!DungeonFutureRarePaths(rooms).Length, "two-room layout does not invent center")
    rooms := TReset([4,5]), TFuture := ["Left","Right"]
    TState(rooms,4,"Unavailable")
    paths := DungeonFutureRarePaths(rooms)
    TAssert(paths.Length = 1 && paths[1] = "Right", "unavailable future path excluded")

    rooms := TReset([4,5]), TScene[5].kind := "Rare_Chest"
    TSelect(rooms,5,"rare selected in correct room")
    rooms := TReset([4,5]), TScene[4].kind := "Rare_Chest"
    routePriorityOrder := ["Chest","Rare_Chest"]
    TSelect(rooms,5,"configured normal-chest priority preserved")
    rooms := TReset([4,5]), TScene[4].kind := "Rare_Chest", TScene[5].kind := "Hoard"
    TState(rooms,4,"Unavailable")
    TSelect(rooms,5,"unavailable rare excluded")
    rooms := TReset([4,5]), TScene[4].kind := "Rare_Chest", TScene[4].curse := "skip", TScene[5].kind := "Hoard"
    TState(rooms,4,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,5,"avoided curse excluded from lower priorities")
    rooms := TReset([4,5]), TFuture := ["Left"], TScene[4].curse := "skip", TScene[5].kind := "Hoard"
    PrioritiseFutureRareChests.Value := true, TState(rooms,4,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,5,"future path obeys curse protection")
    rooms := TReset([4,5]), TFuture := ["Left","Right"]
    TState(rooms,4,"Cursed"), TState(rooms,5,"Cursed")
    TScene[4].curse := "unknown", TScene[5].curse := "unknown"
    PrioritiseFutureRareChests.Value := true
    TSelect(rooms,4,"reported two-cursed-room case works when no curses are excluded")
    TAssert(TCurseReads=0,"empty avoidance list does not wait for curse identification")
    rooms := TReset([3]), TScene[3].curse := "unknown"
    TState(rooms,3,"Cursed"), enabledCurses := ["None", "", " None "]
    TSelect(rooms,3,"None-only avoidance slots mean all curses are allowed")
    TAssert(TCurseReads=0,"None-only slots do not trigger curse scan")
    rooms := TReset([3]), TScene[3].curse := "unknown"
    TState(rooms,3,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,0,"unknown curse remains blocked when an exclusion is configured")
    TAssert(TCurseReads>0,"active exclusions trigger curse recognition")
    rooms := TReset([3]), TState(rooms,3,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,3,"recognized non-excluded curse remains allowed")
    rooms := TReset([3]), TScene[3].curse := "shop"
    TState(rooms,3,"Cursed"), enabledCurses := ["Wind"]
    TSelect(rooms,3,"known Shop curse is recognized and allowed when Wind alone is excluded")
    rooms := TReset([3]), TScene[3].kind := "Boss"
    TSelect(rooms,3,"boss selected")
    TAssert(BossRoomCompleted,"boss completion flag preserved")
    rooms := TReset([3]), TScene[3].kind := "Unknown"
    TSelect(rooms,0,"no blind fallback on unknown icon")
    TAssert(!TClicks.Length,"unknown icon causes no click")
    rooms := TReset([3]), TScene[3].recheck := false
    TSelect(rooms,0,"changed border causes no click")
    TAssert(!TClicks.Length,"border recheck blocks click")
    FileAppend("PASS: " TChecks " assertions against production dungeon functions (screen/input mocked).`n", "*")
    ExitApp(0)
} catch as err {
    FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n", "*")
    ExitApp(1)
}

}
