#Requires AutoHotkey v2.0
#Include %A_ScriptDir%\Lib\Tools\Image.ahk
; [Modularized] This file keeps the game lifecycle: hotkeys, StartMacro/TogglePause, mode starters,
;   RestartStage, monitors, end screens, lobby/load/vote checks, reconnect/rejoin, stage setup.
;   Placement/upgrades/stage events/navigation/map detection/map movement -> Lib\Game\*.ahk,
;   contracts -> Lib\Modes\Contract.ahk, shared helpers -> Lib\Tools\ and Lib\Functions\.
global macroStartTime := A_TickCount
global stageStartTime := A_TickCount
global contractPageCounter := 0
global contractSwitchPattern := 0

global adaptations := 0
global setMahoragoStyle := false

LoadKeybindSettings()  ; Load saved keybinds
Hotkey(F1Key, (*) => moveRobloxWindow())
Hotkey(F2Key, (*) => StartMacro())
Hotkey(F3Key, (*) => Reload())
Hotkey(F4Key, (*) => TogglePause())

F5:: {

}

F6:: {

}

F7:: {
    Run (A_ScriptDir "\Lib\Tools\FindText.ahk")
}


StartMacro(*) {
    try CP_OverlayHide()   ; [Custom placement] no circles on screen while the macro runs
    if (MacroLoopState.Active) {   ; [Framework] F2 while already running would start a second, interleaved loop
        AddToLog("Macro is already running - press " F3Key " to reload")
        return
    }
    if (!ScheduleStart() && !ValidateMode()){   ; schedule on → it picks the mode, no need to select one
        return
    }
    RunMacroLoop(StartSelectedMode)
} 


TogglePause(*) {
    static pausedAt := 0   ; [Framework] paused time must not count towards failsafe timeouts
    Pause -1
    if (A_IsPaused) {
        pausedAt := A_TickCount
        AddToLog("Macro Paused")
        Sleep(1000)
    } else {
        if (pausedAt) {
            TimerManager.ShiftAll(A_TickCount - pausedAt)
            pausedAt := 0
        }
        AddToLog("Macro Resumed")
        Sleep(1000)
    }
}

GetNameForMode() {
    if (PlacementSelection.Text = "Winter Event") {
        return "event"
    }
    if (PlacementSelection.Text = "Fool's Hunt") {
        return "event"
    }
    if (PlacementSelection.Text = "Default") {
        return ""
    }
    return PlacementSelection.Text
}

ChallengeMode() {    
    AddToLog("Moving to Challenge mode")
    ChallengeMovement()

    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Challenge entrance not reached")   ; [Framework]
        ChallengeMovement()
    }
    NextStep(RestartStage)
}

StoryMode() {
    global StoryDropdown, StoryActDropdown
    
    ; Get current map and act
    currentStoryMap := StoryDropdown.Text
    currentStoryAct := StoryActDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for " currentStoryMap)
    if (Random(1, 2) = 1) {
        StoryMovement()
    } else {
        OppositeStoryMovement()
    }
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Story entrance not reached")   ; [Framework]
        if (Random(1, 2) = 1) {
            StoryMovement()
        } else {
            OppositeStoryMovement()
        }
    }
    AddToLog("Starting " currentStoryMap " - " currentStoryAct)
    
    if (StoryUINav.Value) {
        StartStory(currentStoryMap, currentStoryAct)
    } else {
        StartStoryNoUINavigation(currentStoryMap, currentStoryAct)
    }

    ; Handle play mode selection
    if (StoryActDropdown.Text != "Infinity") {
        PlayHere()  ; Always PlayHere for normal story acts
    } else {
        if (MatchMaking.Value) {
            FindMatch()
        } else {
            PlayHere()
        }
    }

    NextStep(RestartStage)
}


LegendMode() {
    global LegendDropdown, LegendActDropdown
    
    ; Get current map and act
    currentLegendMap := LegendDropdown.Text
    currentLegendAct := LegendActDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for " currentLegendMap)
    StoryMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Legend entrance not reached")   ; [Framework]
        StoryMovement()
    }
    AddToLog("Starting " currentLegendMap " - " currentLegendAct)
    if (StoryUINav.Value) {
        StartLegend(currentLegendMap, currentLegendAct)
    } else {
        StartLegendNoUINavigation(currentLegendMap, currentLegendAct)
    }

    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    NextStep(RestartStage)
}

RaidMode() {
    global RaidDropdown, RaidActDropdown
    
    ; Get current map and act
    currentRaidMap := RaidDropdown.Text
    currentRaidAct := RaidActDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for " currentRaidMap)
    RaidMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Raid entrance not reached")   ; [Framework]
        RaidMovement()
    }
    AddToLog("Starting " currentRaidMap " - " currentRaidAct)
    if (StoryUINav.Value) {
        StartRaid(currentRaidMap, currentRaidAct)
    } else {
        StartRaidNoUINavigation(currentRaidMap, currentRaidAct)
    }
    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    NextStep(RestartStage)
}

InfinityCastleMode() {
    global InfinityCastleDropdown
    
    ; Get current difficulty
    currentDifficulty := InfinityCastleDropdown.Text
    
    ; Execute the movement pattern
    AddToLog("Moving to position for Infinity Castle")
    InfCastleMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Infinity Castle entrance not reached")   ; [Framework]
        InfCastleMovement()
    }
    AddToLog("Starting Infinity Castle - " currentDifficulty)

    ; Select difficulty with direct clicks
    if (currentDifficulty = "Normal") {
        FixClick(418, 375)  ; Click Easy Mode
    } else {
        FixClick(485, 375)  ; Click Hard Mode
    }
    
    ;Start Inf Castle
    if (ok := FT(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        ClickUntilGone(0, 0, 325, 520, 489, 587, ModeCancel, -10, -120)
    }

    NextStep(RestartStage)
}

FoolsEvent() {
    ; Execute the movement pattern
    AddToLog("Moving to position for Fool's Hunt")
    EventMovement()
    
    ; Start stage
    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok:=FT(&X, &Y, 468-150000, 386-150000, 468+150000, 386+150000, 0, 0, JoinMatchmaking)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Fool's Hunt entrance not reached")   ; [Framework]
        EventMovement()
    }

    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    AddToLog("Starting Fool's Hunt")
    NextStep(RestartStage)
}

CursedWombMode() {
    AddToLog("Moving to Cursed womb")
    CursedWombMovement()

    StageGuard.Arm("Entrance", FW_EntranceTimeoutMs)   ; [Framework]
    while !(ok := FT(&X, &Y, 445, 440, 650, 487, 0, 0, Capacity)) {
        Reconnect() ; Added Disconnect Check
        StageGuard.Check("Entrance", "Cursed Womb entrance not reached")   ; [Framework]
        if (ok := FT(&X, &Y, 434-150000, 383-150000, 434+150000, 383+150000, 0, 0, RobuxPurchaseKey)) {
            AddToLog("Found Key Purchase Attempt")
            Sleep 50000
        }
        CursedWombMovement()
    }

    FixClick(500, 190)
    for char in StrSplit("Key (Cursed Womb)") {
    Send char
    Sleep (100)
    } 
    sleep (1000)
    FixClick(215, 285)
    sleep (500)
    FixClick(345, 370)
    sleep (500)
    
    NextStep(RestartStage)
}

ContractMode() {
   Sleep(2500)
   FixClick(33, 400)
   Sleep(2500)
   HandleContractJoin()
   Sleep(2500)
   NextStep(RestartStage)
}

PortalMode() {
    HandlePortalJoin()
    Sleep(2500)
    NextStep(RestartStage)
}

DungeonMode() {
    DungeonResetChestGate()
    AddToLog("Entering Dungeon Mode")
    FixClick(85, 400)  ; Click Dungeon mode button
    Sleep(1000)
    if (ok := FT(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath)) {  ;FIUXXXX
        ClickDungeonDeathContinue()
    }
    Sleep(2000)
    if (ok := FT(&X, &Y, 310, 395, 495, 440, 0.20, 0.20, EnterDungeon)) {
        FixClick(395,380)
    }
    Sleep(1000)
    ; Select dungeon route and enter
    LookForDungeonRooms()
}

CheckForReturnToLobby() {
    if (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
        return true
    }
    return false
}

CheckForNextText() {
    if (ok := FT(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
        return true
    }
    return false
}

MonitorEndScreen() {
    global mode, StoryDropdown, StoryActDropdown, ReturnLobbyBox, MatchMaking, challengeStartTime, inChallengeMode

    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(3000)  
        StageGuard.Check("EndScreen", "end screen not handled")   ; [Framework]
        
        FixClick(560, 560)
        FixClick(560, 560)

        if (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
            Sleep(1500)
        }

        CloseChat()

        if (ok := FT(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
            Sleep(1500)
        }   

        ; Now handle each mode
        if (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            AddToLog("Found Lobby Text - Current Mode: " (inChallengeMode ? "Challenge" : mode))
            Sleep(2000)
            if (!inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                 AddToLog("Challenge completed - returning to " mode " mode")
                inChallengeMode := false
                challengeStartTime := A_TickCount
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Check if it's time for challenge mode
            if (!inChallengeMode && ChallengeBox.Value) {
                timeElapsed := A_TickCount - challengeStartTime
                if (timeElapsed >= 1800000) {
                    AddToLog("30 minutes passed - switching to Challenge mode")
                    inChallengeMode := true
                    challengeStartTime := A_TickCount
                    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                    return NextStep(CheckLobby)
                }
            }

            if (mode = "Story") {
                AddToLog("Handling Story mode end")
                if (StoryActDropdown.Text != "Infinity") {
                    if (NextLevelBox.Value && lastResult = "win") {
                        AddToLog("Next level")
                        ClickNextLevel()
                    } else {
                        AddToLog("Replay level")
                        ClickReplay()
                    }
                } else {
                    if (PortalSwap.Value && GetMapForFarming(StoryDropdown.Text) != "no map found") {
                        SwitchActiveFarm()
                        Sleep(1500)
                        ClickReturnToLobby()
                        return NextStep(CheckLobby)
                    } else if (ReturnLobbyBox.Value) {
                        AddToLog("Return to lobby")
                        ClickReturnToLobby()
                    } else {
                        AddToLog("Story Infinity replay")
                        ClickReplay()
                    }
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Raid") {
                AddToLog("Handling Raid end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replay raid")
                    ClickReplay()
                    return NextStep(RestartStage)
                }
            }
            else if (mode = "Dungeon") {
                AddToLog("Handling Dungeon end")
                return NextStep(MonitorDungeonEnd)
            }
            else if (mode = "Infinity Castle") {
                AddToLog("Handling Infinity Castle end")
                if (lastResult = "win") {
                    AddToLog("Next floor")
                    ClickReplay() ; Uses the replay coords for next level
                } else {
                    AddToLog("Restart floor")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Cursed Womb") {
                AddToLog("Handling Cursed Womb End")
                AddToLog("Returning to lobby")
                ClickReturnToLobby()
                return NextStep(CheckLobby)
            }
            else if (mode = "Fool's Hunt") {
                AddToLog("Handling Fool's Hunt end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else if (mode = "Winter Event") {
                AddToLog("Handling Winter Event end")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                }
                return NextStep(RestartStage)
            }
            else {
                AddToLog("Handling end case")
                if (ReturnLobbyBox.Value) {
                    AddToLog("Return to lobby enabled")
                    ClickReturnToLobby()
                    return NextStep(CheckLobby)
                } else {
                    AddToLog("Replaying")
                    ClickReplay()
                    return NextStep(RestartStage)
                }
            }
        }
        Reconnect()
    }
}


MonitorStage() {
global mode, StoryActDropdown

    lastClickTime := A_TickCount
    
    Loop {
        Sleep(1000)
        StageGuard.Check("Stage", "stage took too long")   ; [Framework]
        
        if (mode = "Story" && StoryActDropdown.Text = "Infinity") || (mode = "Winter Event") {
            timeElapsed := A_TickCount - lastClickTime
            if (timeElapsed >= 30000) {
                AddToLog("Performing anti-AFK click")
                FixClick(560, 560)
                lastClickTime := A_TickCount
            }
        }

        if (mode = "Winter Event") {
            CheckForCardSelection()
        }

        if (mode = "Fool's Hunt") { ; [Fixed] was "Fools Event", which never matched
            CheckForCardSelection()
        }


        CheckForMahoraga()
        CheckForMahoragaAdaptation()

        if (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }

        CloseChat() ; Close chat if open

        if CheckForXp(true) {
            NextStep(HandleStageEnd)
        }

        CheckEndAndRoute()
        Reconnect()
    }
}

PerformAntiAFK(lastClickTime) {
    if (A_TickCount - lastClickTime >= 60000) {
        AddToLog("Performing anti-AFK click")
        Loop 3 {
            FixClick(560, 560)
        }
        return A_TickCount ; Return the updated lastClickTime
    }
}

HandleStageEnd() {
    global Wins, loss, stageStartTime

    isWin := false

    stageEndTime := A_TickCount
    stageLength := FormatStageTime(stageEndTime - stageStartTime)

    if (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
        ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
    }

    if (ok := FT(&X, &Y, 150, 180, 350, 260, 0, 0, DefeatText) or (ok:=FT(&X, &Y, 319, 176, 492, 279, 0, 0, DefeatText2))) { ;defeat 2 is the edited version
        isWin := false
    }

    if (ok := FT(&X, &Y, 150, 180, 350, 260, 0, 0, VictoryText) or (ok:=FT(&X, &Y, 319, 176, 492, 279, 0, 0, VictoryText2)) or (ok:=FT(&X, &Y, 363, 193, 475, 274, 0, 0, VictoryTextApril))) { ;victory 2 is the edited version
        isWin := true  
    }

    if (mode = "Dungeon")
        DungeonRecordStageResult(isWin)

    if isWin {
        AddToLog("Victory detected - Stage Length: " stageLength)
        Wins += 1
    } else {
        AddToLog("Defeat detected - Stage Length: " stageLength)
        loss += 1
    }

    SendInput("{Tab}") ; Open Player leaderboard
    try {   ; [Framework] a webhook failure must not end the run (Anime Guardians pattern)
        SendWebhookWithTime(isWin, stageLength)
    } catch Error as err {
        if (err is MacroNextStep || err is MacroStop)
            throw err
        AddToLog("Webhook error: " err.Message " - continuing")
    }
    SendInput("{Tab}") ; Open Player leaderboard
    Sleep (500)

    if (mode = "Portal") {
        return NextStep(HandlePortalReJoin)           
    } else if (mode = "Contract") {
        return NextStep(HandleContractEnd) 
    } else if (mode = "Dungeon") {
        return NextStep(MonitorDungeonEnd)
    } else {
        return NextStep(MonitorEndScreen) 
    }
}

Zoom() {
    MouseMove(400, 300)
    Sleep 100

    ; Zoom in smoothly
    Loop 10 {
        Send "{WheelUp}"
        Sleep 50
    }

    ; Look down
    Click
    MouseMove(400, 400)  ; Move mouse down to angle camera down
    
    ; Zoom back out smoothly
    Loop 20 {
        Send "{WheelDown}"
        Sleep 50
    }
    
    ; Move mouse back to center
    MouseMove(400, 300)
}

TpSpawn() {
    FixClick(26, 570) ;click settings
    Sleep 300
    FixClick(400, 215)
    Sleep 300
    loop 6 {
        Sleep 150
        SendInput("{WheelDown 1}") ;scroll
    }
    Sleep 300
    if (ok := FT(&X, &Y, 215, 160, 596, 480, 0.20, 0.20, Spawn)) {
        AddToLog("Found Teleport to Spawn button")
        FixClick(X + 100, Y - 30)
    } else {
        AddToLog("Could not find Teleport button")
    }
    Sleep 300
    FixClick(583, 147)
    Sleep 300

    ;
}

TpLobby() {
    FixClick(26, 570) ;click settings
    Sleep 300
    FixClick(400, 215)
    Sleep 300
    loop 4 {
        Sleep 250
        SendInput("{WheelDown 1}") ;scroll
    }
    Sleep 300
    if (ok := FT(&X, &Y, 233, 424, 567, 471, 0.20, 0.20, ReturnToLobbySettings)) {
        AddToLog("Found Teleport to Lobby button")
        FixClick(X + 150, Y - 30)
    } else {
        AddToLog("Could not find Teleport button")
    }
    Sleep 300
    FixClick(525, 415)
    Sleep 300
    return NextStep(CheckLobby)
}

CloseChat() {
    if (ok := FT(&X, &Y, 123, 50, 156, 79, 0, 0, OpenChat)) {
        AddToLog "Closing Chat"
        FixClick(138, 30) ;close chat
    }
}

BasicSetup() {
    SendInput("{Tab}") ; Closes Player leaderboard
    Sleep 1000
    FixClick(569, 72) ; Closes Player leaderboard
    Sleep 1000
    FixClick(569, 72) ; Closes Player leaderboard
    Sleep 300
    CloseChat()
    Sleep 300
    Zoom()
    Sleep 300
    TpSpawn()
}
    
RestartStage() {
    global adaptations, setMahoragoStyle, inChallengeMode

    adaptations := 0
    setMahoragoStyle := false

    currentMap := (ModeDropdown.Text = "Fool's Hunt") ? DetectHuntMap() : DetectMapImageSearch() ;(ModeDropdown.Text = "Dungeon") ? DetectMapImageSearch() : DetectMap() backup
    CP_SetStageMap(currentMap)   ; [Custom placement] which map's spots to use
    
    if (ModeDropdown.Text = "Fool's Hunt") {
        if (BringUnits.Value) {
            CoordMode("Mouse", "Window")
            ClickAndHoldExit()
            CoordMode("Mouse", "Client")
            Sleep(1000)
        }
    }

    ; Wait for loading
    CheckLoaded()

    if (!inChallengeMode) {
        if (!IsCorrectMap(currentMap)) {
            AddToLog("Incorrect map detected, teleporting to lobby")
            return TpLobby()
        }
    }

    if (ModeDropdown.Text = "Fool's Hunt") {
        if (MatchMaking.Value) {
            if (ShouldSkipMap(currentMap)) {
                AddToLog("Map is set to be skipped: " currentMap ", returning to lobby")
                return TpLobby()
            }
        }
    }

    ; Do initial setup and map-specific movement during vote timer
    BasicSetup()
    
    if (currentMap != "no map found") {
        if (NoMovement.Visible && NoMovement.Value) {
            AddToLog("Skipping movement...")
        } else if (!CM_HandleStageMovement(currentMap)) {   ; [Custom movement] records / replays your own walk when set up
            HandleMapMovement(currentMap)
        }
    }

    ; Wait for game to actually start
    StartedGame()
    StageGuard.Arm("Stage", FW_StageGuardApplies() ? FW_StageTimeoutMs : 0)   ; [Framework] not armed for Story Infinity / Winter Event

    CP_HandleRecording(currentMap)   ; [Custom placement] record mode: you click the spots, then the macro stops

    ; Begin unit placement and management
    if (NewPlacementMethod.Visible && NewPlacementMethod.Value) { ; For April Fools Event
        PlaceFoolUnits()
    } else {
        PlacingUnits()
    }
    
    ; Monitor stage progress
    NextStep(MonitorStage)
}

Reconnect() {
    ;Credit: @Haie fixed by Randomdev
    ;color_home := PixelGetColor(10, 10)
    ; Optimised Retries with a loop instead of calling Reconnect() inside itself (that piled up calls while disconnected)
    loop {
    color_reconnect := PixelGetColor(430,384)
    color_reconnectVerify := PixelGetColor(489,341)
    if !(color_reconnectVerify == 0x393B3D and color_reconnect == 0xFFFFFF) ; not on the disconnect screen
        return
    ;color_home == 0x121215
        AddToLog("Disconnected! Attempting to reconnect...")
        sendDCWebhook()
        StageGuard.Arm("Reconnect", FW_ReconnectTimeoutMs)   ; [Framework]

        try {
            if (WinExist(rblxID)) { 
                WinActivate(rblxID)
            }
        } catch {
            if (debugMessages) {
                AddToLog("Error: Unable to activate Roblox window.")
            }
        }

        psLink := FileExist("Settings\PrivateServer.txt") ? FileRead("Settings\PrivateServer.txt", "UTF-8") : ""

        ; Reconnect to Ps
        if FileExist("Settings\PrivateServer.txt") && (psLink := FileRead("Settings\PrivateServer.txt", "UTF-8")) {
            AddToLog("Connecting to private server...")
            Run(psLink)
        } else {
            Run("roblox://placeID=" 8304191830)
        }

        Sleep 2000
        if WinExist(rblxID) {
            WinActivate(rblxID)
            forceRobloxSize()
            moveRobloxWindow()
            Sleep (1000)
        }
        loop {
            FixClick(490, 400)
            AddToLog("Reconnecting to Roblox...")
            Sleep 15000
            StageGuard.Check("Reconnect", "reconnect not finished", false)   ; [Framework]
            if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
                AddToLog("Reconnected Successfully!")
                return NextStep(StartSelectedMode)
            } else if (PixelGetColor(489,341) == 0x393B3D and PixelGetColor(430,384) == 0xFFFFFF) {
                break ; still disconnected -> start the reconnect again (was: Reconnect())
            }
        }
    }
}

RejoinPrivateServer() {   
    AddToLog("Attempting To Reconnect To Private Server...")

    psLink := FileExist("Settings\PrivateServer.txt") ? FileRead("Settings\PrivateServer.txt", "UTF-8") : ""

    if psLink {
        AddToLog("Connecting to private server...")
        Run(psLink)
    } else {
        Run("roblox://placeID=8304191830")  ; Public server if no PS file or empty
    }

    Sleep(5000)

    ; Loop until successfully reconnected
    StageGuard.Arm("Rejoin", FW_ReconnectTimeoutMs)   ; [Framework]
    loop {
        AddToLog("Reconnecting to Roblox...")
        StageGuard.Check("Rejoin", "rejoin not finished - relaunching", false)   ; [Framework]
        Sleep(5000)

        if WinExist(rblxID) {
            forceRobloxSize()
            Sleep(1000)
        }

        if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
            AddToLog("Reconnected Successfully!")
            return NextStep(StartSelectedMode)
        }

        Reconnect()
    }
}

CheckForXp(closeLeaderboard := false) {
    if (closeLeaderboard) {
        FixClick(564, 72)
        Sleep(1200)
    }
    ; Check for lobby text
    if (ok := FT(&X, &Y, 575, 145, 641, 210, 0, 0, XpText)) {
        FixClick(325, 185)
        FixClick(560, 560)
        return true
    }
    return false
}

CheckLobby() {
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("Lobby", FW_LobbyTimeoutMs)   ; [Framework]
    loop {
        Sleep 1000
        StageGuard.Check("Lobby", "lobby not reached")   ; [Framework]
        if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
            break
        }
        if (CheckForEndGameScreens()) {
            return NextStep(MonitorStage)
        }
        Reconnect()
    }
    Sleep(SleepTime())
    AddToLog("Returned to lobby, restarting selected mode")
    return NextStep(StartSelectedMode)
}

CheckForEndGameScreens() {
    if (CheckForXp(true) || CheckForReturnToLobby() || CheckForNextText()) {
        AddToLog("Detected end game screen when should have already returned to lobby")
        CloseChat()
        return true
    }
}

CheckForLobbyText() {
    if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
        return true
    }
    return false
}

CheckForLobby() {
    loop {
        Sleep 1000
        if (ok := FT(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
            break
        }
        Reconnect()
    }
    AddToLog("Returned to lobby.")
    return true
}

CheckLoaded() {
    StageGuard.Arm("Load", FW_LoadTimeoutMs)   ; [Framework]
    loop {
        Sleep(1000)
        StageGuard.Check("Load", "stage did not load")   ; [Framework]
        
        ; Check for vote screen 742, 287, 832, 377
        if (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStart) or (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStartLaptop) or (ok := FT(&X, &Y, 0, 0, 742, 287, 832, 377, 0.10, 0.10, Units) or (ok := FT(&X, &Y, 0, 0, 1080, 1080, 0, 0, UnitManager) or PixelGetColor(320, 60) = 0x00EE00)))) {
            AddToLog("Successfully Loaded In")
            Sleep(1000)
            break
        } 
;13, 263, 89, 334
        Reconnect()
    }
}

StartedGame() {
    StageGuard.Arm("Vote", FW_VoteTimeoutMs)   ; [Framework]
    loop {
        Sleep(1000)
        StageGuard.Check("Vote", "vote screen did not close")   ; [Framework]
        if (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStart) or (ok := FT(&X, &Y, 301, 64, 503, 154, 0, 0, VoteStartLaptop))) {
            FixClick(350, 103) ; click yes
            FixClick(350, 100)
            FixClick(350, 97)
            continue  ; Keep waiting if vote screen is still there
        }
        
        ; If we don't see vote screen anymore the game has started
        AddToLog("Game started")
        global stageStartTime := A_TickCount
        break
    }
}

StartSelectedMode() {
    global inChallengeMode, firstStartup, challengeStartTime
    FixClick(400,340)
    FixClick(400,390)
    CloseChat()

    if (ChallengeBox.Value && firstStartup) {
        AddToLog("Auto Challenge enabled - starting with challenge")
        inChallengeMode := true
        firstStartup := false
        challengeStartTime := A_TickCount  ; Set initial challenge time
        ChallengeMode()
        return
    }

    if (!inChallengeMode)
        Sched_RunPendingTeamSwap()   ; [Scheduler team swap] equip the scheduled step's team while still in the lobby

    ; If we're in challenge mode, do challenge
    if (inChallengeMode) {
        AddToLog("Starting Challenge Mode")
        ChallengeMode()
        return
    }    
    else if (ModeDropdown.Text = "Story") {
        StoryMode()
    }
    else if (ModeDropdown.Text = "Legend") {
        LegendMode()
    }
    else if (ModeDropdown.Text = "Raid") {
        RaidMode()
    }
    else if (ModeDropdown.Text = "Infinity Castle") {
        InfinityCastleMode()
    }
    else if (ModeDropdown.Text = "Contract") {
        if (contractsEnabled) {
            ContractMode()
        } else {
            AddToLog("Contracts are is not currently in Anime Adventures!")
        }
    }
    else if (ModeDropdown.Text = "Fool's Hunt") {
        FoolsEvent()
    }
    else if (ModeDropdown.Text = "Winter Event") {
        if (isWinter) {
            WinterEvent()
        } else {
            AddToLog("The Winter Event is not currently in Anime Adventures!")
        }
    }
    else if (ModeDropdown.Text = "Cursed Womb") {
        CursedWombMode()
    }
    else if (ModeDropdown.Text = "Portal") {
        PortalMode()
    }
    else if (ModeDropdown.Text = "Dungeon") {
        DungeonMode()
    }
}

ValidateMode() {
    if (ModeDropdown.Text = "") {
        AddToLog("Please select a gamemode before starting the macro!")
        return false
    }
    if (!confirmClicked) {
        AddToLog("Please click the confirm button before starting the macro!")
        return false
    }
    return true
}

GetNavKeys() {
    return StrSplit(FileExist("Settings\UINavigation.txt") ? FileRead("Settings\UINavigation.txt", "UTF-8") : "\,#,}", ",")
}

CheckEndAndRoute() {
    if (ok := FT(&X, &Y, 140, 130, 662, 172, 0, 0, LobbyText)) {
        AddToLog("Found end screen")
        if (mode = "Contract") {
            return NextStep(HandleContractEnd)
        } else if (mode = "Dungeon") {
            return NextStep(MonitorDungeonEnd)
        } else if (mode = "Portal") {
            return NextStep(HandlePortalReJoin)
        } else {
            return NextStep(MonitorEndScreen)
        }
    }
    return false
}

SleepTime() {
    time := [0, 5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000]  ; Array of sleep values
    timeIndex := LobbySleepTimer.Value  ; Get the selected speed value

    if timeIndex is number  ; Ensure it's a number
        return time[timeIndex]  ; Use the value directly from the array
}

ClickReplay() {
    FixClick(480,121)
    sleep 1000
    FixClick(480,121)
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, Replay, 0, -35, RetryBackup)
}

ClickNextLevel() {
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, Nextlevelforstory, 0, -35)
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, NextLevel, 0, -35, NextRoomInf)
    FixClick(480,121)
    sleep 1000
    FixClick(480,121)
}

ClickReturnToLobby() {
    FixClick(200,121)
    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
}

ClickStartStory() {
    ClickUntilGone(0, 0, 0, 0, 1000, 1000, StartStoryButton, 0, -35)
}

CheckForRobloxApp() {
    return FT(&X, &Y, 14, 55, 57, 115, 0, 0, RobloxApp) ? true : false
}

CheckForNotification() {
    return FT(&X, &Y, 748, 94, 778, 551, 0, 0, ExitNotification) ? true : false
}