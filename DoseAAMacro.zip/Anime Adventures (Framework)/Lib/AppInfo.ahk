#Requires AutoHotkey v2.0

; One release version for the window, log header, and packaged VERSION.txt.
; Increase by 0.1 for each delivered update: 2.0, 2.1, 2.2, ...
DoseReleaseVersion() {
    return "3.1"
}

DoseDungeonDefaults() {
    return {
        route: ["Rare_Chest", "Chest", "Shop", "Shrine", "Hoard", "Boss"],
        curses: ["None", "None", "None", "None", "None", "None", "None", "None"],
        shrines: ["Burst", "Chaos", "Vamparism", "None", "None", "None"]
    }
}
