#Requires AutoHotkey v2.0

; ============================================================================
;  WindowFollow.ahk  -  FindText that follows Roblox
; ----------------------------------------------------------------------------
;  All FindText search areas in this macro were captured with the GUI in the
;  top-left corner of the screen and Roblox at (offsetX, offsetY) = (-5, 1).
;  FindText always works in screen coordinates, so it only worked there.
;
;  FT() is used instead of FindText(&X, &Y, ...). It shifts the search area by
;  how far the Roblox window has moved from that original spot, then shifts the
;  found X/Y back. So every existing coordinate in the macro stays the same and
;  works wherever the window is.
;
;  Legacy input/pixel calls still depend on their caller's coordinate mode.
;  Dungeon detection uses the explicit WF_* helpers below, independent of focus.
;  The Roblox window must stay the same size (sizeDown() still enforces that).
; ============================================================================

; How far the Roblox window is from where the search areas were captured.
FT_GetOffset(&dx, &dy) {
    global rblxID, offsetX, offsetY
    dx := 0, dy := 0
    try {
        if WinExist(rblxID) {
            WinGetPos(&wx, &wy,,, rblxID)
            dx := wx - offsetX   ; original spot: GUI at (0, 0) + offsetX
            dy := wy - offsetY   ; original spot: GUI at (0, 0) + offsetY
        }
    }
}

; Drop-in replacement for FindText(&X, &Y, x1, y1, x2, y2, ...)
FT(&X := "", &Y := "", x1 := 0, y1 := 0, x2 := 0, y2 := 0, args*) {
    FT_GetOffset(&dx, &dy)
    if (x1 = 0 && y1 = 0 && x2 = 0 && y2 = 0)   ; 0,0,0,0 means "whole screen" - leave it
        dx := 0, dy := 0
    ok := FindText(&X, &Y, x1 + dx, y1 + dy, x2 + dx, y2 + dy, args*)
    if (ok && IsNumber(X) && IsNumber(Y))
        X -= dx, Y -= dy
    return ok
}

; Replacement for FindText().Click(X, Y, ...) when X/Y came from FT()
FTClick(x, y, args*) {
    FT_GetOffset(&dx, &dy)
    return FindText().Click(x + dx, y + dy, args*)
}

; Put the GUI in the middle of the main screen, then Roblox follows it
CenterMacroWindow() {
    global aaMainUIHwnd
    MonitorGetWorkArea(MonitorGetPrimary(), &left, &top, &right, &bottom)
    WinGetPos(,, &w, &h, "ahk_id " aaMainUIHwnd)
    x := Max(left, left + (right - left - w) // 2)
    y := Max(top, top + (bottom - top - h) // 2)
    WinMove(x, y,,, "ahk_id " aaMainUIHwnd)
}

; Drag the GUI by clicking anywhere on its background
SetupDraggableGui() {
    OnMessage(0x0201, MacroGui_OnLButtonDown)   ; WM_LBUTTONDOWN
    OnMessage(0x0232, MacroGui_OnMoveEnd)       ; WM_EXITSIZEMOVE (finished dragging)
}

MacroGui_OnLButtonDown(wParam, lParam, msg, hwnd) {
    global aaMainUIHwnd
    if (hwnd = aaMainUIHwnd)
        PostMessage(0xA1, 2,,, "ahk_id " aaMainUIHwnd)   ; start a normal window drag
}

MacroGui_OnMoveEnd(wParam, lParam, msg, hwnd) {
    global aaMainUIHwnd
    if (hwnd = aaMainUIHwnd)
        moveRobloxWindow()   ; Roblox snaps back next to the GUI
}


; Dungeon-only helpers. Coordinates use the SAME original-screen reference as FT,
; NOT the active window's client origin. Check against Roblox's actual client and
; the virtual desktop (including negative monitor coordinates). Do not change FT.
WF_RobloxRegion(x1, y1, x2, y2) {
    global rblxID, offsetX, offsetY, targetWidth, targetHeight
    try {
        hwnd := WinExist(rblxID)
        if (!hwnd || WinGetMinMax("ahk_id " hwnd) = -1)
            return false
        WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
        if ((IsSet(targetWidth) && ww != targetWidth)
            || (IsSet(targetHeight) && wh != targetHeight))
            return false
        WinGetClientPos(&cx, &cy, &cw, &ch, "ahk_id " hwnd)
        dx := wx - offsetX, dy := wy - offsetY
        left := x1 + dx, top := y1 + dy, right := x2 + dx, bottom := y2 + dy
        vx := SysGet(76), vy := SysGet(77), vw := SysGet(78), vh := SysGet(79)
        if (left > right || top > bottom || left < cx || top < cy
            || right >= cx + cw || bottom >= cy + ch
            || left < vx || top < vy || right >= vx + vw || bottom >= vy + vh)
            return false

        ; Screen matching cannot see through another application. Reject any visible
        ; top-level window above Roblox overlapping this region, even when inactive.
        ; This also prevents detecting a chest screenshot in another application.
        for other in WinGetList() {
            if (other = hwnd)
                break
            ; The macro is AlwaysOnTop with a color-keyed Roblox holder. Its
            ; bounding rectangle is not an occluder inside that transparent hole.
            if WF_IsMacroHole(other, left, top, right, bottom)
                continue
            if (!DllCall("IsWindowVisible", "Ptr", other) || WinGetMinMax("ahk_id " other) = -1)
                continue
            WinGetPos(&ox, &oy, &ow, &oh, "ahk_id " other)
            if (ow > 0 && oh > 0 && ox <= right && oy <= bottom
                && ox + ow > left && oy + oh > top)
                return false
        }
        return {hwnd: hwnd, wx: wx, wy: wy, cx: cx, cy: cy, cw: cw, ch: ch, dx: dx, dy: dy,
            left: left, top: top, right: right, bottom: bottom}
    } catch {
        return false
    }
}

WF_IsMacroHole(hwnd, left, top, right, bottom) {
    global aaMainUIHwnd, robloxHolder
    if (!IsSet(aaMainUIHwnd) || hwnd != aaMainUIHwnd || !IsSet(robloxHolder))
        return false
    if (WinGetTransColor("ahk_id " hwnd) = "")
        return false
    WinGetPos(&hx, &hy, &hw, &hh, "ahk_id " robloxHolder.Hwnd)
    return left >= hx && top >= hy && right < hx + hw && bottom < hy + hh
}

WF_RegionUnchanged(region, x1, y1, x2, y2) {
    now := WF_RobloxRegion(x1, y1, x2, y2)
    return IsObject(now) && now.hwnd = region.hwnd
        && now.wx = region.wx && now.wy = region.wy
        && now.cx = region.cx && now.cy = region.cy
        && now.cw = region.cw && now.ch = region.ch
}

WF_FindText(&X, &Y, x1, y1, x2, y2, err1, err0, text) {
    X := "", Y := ""
    region := WF_RobloxRegion(x1, y1, x2, y2)
    if !IsObject(region)
        return false
    ok := FindText(&X, &Y, region.left, region.top, region.right, region.bottom,
        err1, err0, text)
    if (!WF_RegionUnchanged(region, x1, y1, x2, y2)) {
        X := "", Y := ""
        return false
    }
    if (ok && IsNumber(X) && IsNumber(Y))
        X -= region.dx, Y -= region.dy
    return ok
}

WF_ImageSearch(&X, &Y, x1, y1, x2, y2, imagePath, variation := 20) {
    X := "", Y := ""
    ; Honor existing absolute override paths; anchor relative overrides to Main.
    if !RegExMatch(imagePath, "i)^(?:[A-Z]:[\\/]|[\\/]{2})")
        imagePath := A_ScriptDir "\" imagePath
    if !FileExist(imagePath)
        throw Error("Dungeon reference image is missing")
    region := WF_RobloxRegion(x1, y1, x2, y2)
    if !IsObject(region)
        throw Error("Roblox image region is not available for screen matching")
    previousMode := A_CoordModePixel
    try {
        CoordMode("Pixel", "Screen")
        ok := ImageSearch(&X, &Y, region.left, region.top, region.right,
            region.bottom, "*" variation " " imagePath)
    } finally {
        CoordMode("Pixel", previousMode)
    }
    if (!WF_RegionUnchanged(region, x1, y1, x2, y2)) {
        X := "", Y := ""
        throw Error("Roblox image region moved or became obscured during matching")
    }
    if ok
        X -= region.dx, Y -= region.dy
    return ok
}

; Only dungeon room-card clicks use this helper. Legacy FixClick is untouched.
WF_RobloxClick(x, y) {
    global rblxID
    hwnd := WinExist(rblxID)
    if !hwnd
        return false
    WinActivate("ahk_id " hwnd)
    if !WinWaitActive("ahk_id " hwnd,, 0.5)
        return false
    region := WF_RobloxRegion(x, y, x, y)
    if (!IsObject(region) || region.hwnd != hwnd)
        return false
    previousMode := A_CoordModeMouse
    try {
        CoordMode("Mouse", "Screen")
        FixClick(region.left, region.top)
    } finally {
        CoordMode("Mouse", previousMode)
    }
    return true
}
