#Requires AutoHotkey v2.0

; Startup only. Keep room-dialog Enter, chest saving, shop and shrine policies
; separate. Search coordinates share the existing WindowFollow calibration.
DungeonEntranceScene(&X, &Y, &layout) {
    global WF_LastIssue
    X := "", Y := "", layout := ""
    if WF_FindText(&X, &Y, 250, 340, 550, 495, 0.20, 0.20, EnterDungeon)
        return "Enter"
    if (WF_LastIssue != "")
        return "Blocked"
    if WF_FindText(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath) {
        if WF_FindText(&X, &Y, 308, 391, 494, 437, 0.10, 0.10, DungeonDeathContinue)
            return "Death"
        return WF_LastIssue = "" ? "DeathPending" : "Blocked"
    }
    if (WF_LastIssue != "")
        return "Blocked"
    rooms := DungeonScanRooms(&diagnostic)
    if (WF_LastIssue != "")
        return "Blocked"
    if !DungeonValidLayout(rooms)
        return "Waiting"
    for room in rooms
        layout .= room.index ":" room.type ";"
    return "Route"
}

DungeonOpenEntranceMenu() {
    global rblxID
    ; Preserve the original lobby click at CLIENT (85,400), while sending it
    ; through the validated screen-coordinate input helper. No guessed offsets.
    try {
        hwnd := WinExist(rblxID)
        point := Buffer(8, 0)
        NumPut("Int",85,"Int",400,point)
        if (!hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int")) {
            AddToLog("Dungeon entrance: lobby button coordinates unavailable")
            return false
        }
        FT_GetOffset(&dx, &dy)
        return WF_RobloxClick(NumGet(point,0,"Int")-dx, NumGet(point,4,"Int")-dy)
    } catch {
        AddToLog("Dungeon entrance: lobby button coordinates unavailable")
        return false
    }
}

DungeonStartEntrance() {
    global WF_LastIssue
    if !WF_PrepareDungeon() {
        AddToLog("Dungeon entrance window not ready: " WF_LastIssue)
        return false
    }
    scene := DungeonEntranceScene(&X,&Y,&layout)
    if (scene = "Blocked") {
        AddToLog("Dungeon entrance screen unreadable: " WF_LastIssue)
        return false
    }
    ; Resume an already-open entrance/route instead of toggling the lobby menu.
    if (scene = "Waiting") {
        if !DungeonOpenEntranceMenu() {
            AddToLog("Dungeon entrance lobby click refused; no room selection attempted")
            return false
        }
        AddToLog("Dungeon entrance opened; waiting for Enter Dungeon")
    }
    return DungeonWaitForEntrance()
}

DungeonWaitForEntrance(timeoutMs := 45000, pollMs := 500, retryMs := 1500, maxClicks := 6) {
    global WF_LastIssue
    started := A_TickCount, lastClick := 0, clicks := 0, previousLayout := ""
    lastScene := "Waiting", retriesExhausted := false
    Loop {
        if (A_TickCount-started >= timeoutMs)
            break
        scene := DungeonEntranceScene(&X,&Y,&layout)
        lastScene := scene
        if (scene = "Blocked") {
            AddToLog("Dungeon entrance screen unreadable: " WF_LastIssue "; no further clicks")
            return false
        }
        if (scene = "Route") {
            if (layout = previousLayout) {
                AddToLog("Dungeon entrance confirmed: stable route screen ready")
                return true
            }
            previousLayout := layout
        } else {
            previousLayout := ""
            if (scene = "Enter" || scene = "Death") {
                if (clicks < maxClicks && (!lastClick || A_TickCount-lastClick >= retryMs)) {
                    ; Fresh match immediately before input, using the detected
                    ; text center rather than the previous fixed client click.
                    text := scene = "Enter" ? EnterDungeon : DungeonDeathContinue
                    x1 := scene = "Enter" ? 250 : 308
                    y1 := scene = "Enter" ? 340 : 391
                    x2 := scene = "Enter" ? 550 : 494
                    y2 := scene = "Enter" ? 495 : 437
                    tolerance := scene = "Enter" ? 0.20 : 0.10
                    if WF_FindText(&X,&Y,x1,y1,x2,y2,tolerance,tolerance,text) {
                        if !WF_RobloxClick(X,Y) {
                            AddToLog("Dungeon entrance click refused; no room selection attempted")
                            return false
                        }
                        clicks += 1, lastClick := A_TickCount
                        AddToLog("Dungeon entrance: " (scene = "Enter" ? "Enter Dungeon" : "death Continue")
                            " click " clicks "/" maxClicks "; waiting for route confirmation")
                    } else if (WF_LastIssue != "") {
                        AddToLog("Dungeon entrance recheck failed: " WF_LastIssue)
                        return false
                    }
                } else if (clicks >= maxClicks && !retriesExhausted) {
                    retriesExhausted := true
                    AddToLog("Dungeon entrance click limit reached; waiting for route without further clicks")
                }
            }
        }
        Sleep(Max(1,Min(pollMs,timeoutMs-(A_TickCount-started))))
    }
    AddToLog("Dungeon entrance timed out after " timeoutMs//1000 "s; last screen=" lastScene
        "; clicks=" clicks ". No room selection attempted. Check the visible entrance and Debug patterns.")
    return false
}
