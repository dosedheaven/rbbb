#Requires AutoHotkey v2.0

global BossRoomCompleted := false
global SaveChestsForBoss := true


DungeonRoomAreas() {
    ; Keep the original calibrated borders, interiors, and click points.
    return [
        {x1: 200, y1: 340, x2: 222, y2: 437, searchX1: 204, searchY1: 343, searchX2: 290, searchY2: 435, clickX: 250, clickY: 360, path: "Left"},
        {x1: 507, y1: 340, x2: 530, y2: 437, searchX1: 514, searchY1: 343, searchX2: 600, searchY2: 435, clickX: 555, clickY: 360, path: "Right"},
        {x1: 352, y1: 343, x2: 379, y2: 437, searchX1: 358, searchY1: 343, searchX2: 447, searchY2: 435, clickX: 400, clickY: 360, path: "Center"},
        {x1: 275, y1: 340, x2: 300, y2: 437, searchX1: 280, searchY1: 343, searchX2: 370, searchY2: 435, clickX: 322, clickY: 360, path: "Left"},
        {x1: 430, y1: 340, x2: 450, y2: 437, searchX1: 438, searchY1: 343, searchX2: 525, searchY2: 435, clickX: 477, clickY: 360, path: "Right"}
    ]
}

DungeonBorderText(roomType) {
    switch roomType {
        case "Available": return DungeonRoomBorder
        case "Unavailable": return DungeonRoomBorderDark
        case "Cursed": return DungeonRoomBorderCursed
        case "Opening": return DungeonRoomBorderChestOpen
        case "Boss": return DungeonRoomBorderBoss
    }
    return ""
}

DungeonValidLayout(rooms) {
    ids := Map()
    for room in rooms {
        if (ids.Has(room.index) || room.index < 1 || room.index > 5)
            return false
        ids[room.index] := true
    }
    if !ids.Count
        return false
    ; A missed/locked neighbor must not invalidate a confirmed card. The room's
    ; own border/icon still must be verified; never mix 2-card and 3-card positions.
    if (ids.Has(4) || ids.Has(5))
        return !ids.Has(1) && !ids.Has(2) && !ids.Has(3)
    return true
}

DungeonMarkerArea(area) {
    ; Original columns were only 13-27 px wide. Allow a small marker-position
    ; margin without changing room interiors, PNG bounds, or click coordinates.
    return {x1: area.x1 - 12, y1: area.y1 - 8,
        x2: area.x2 + 12, y2: area.y2 + 8}
}

DungeonProbeRoom(area, &diagnostic) {
    global WF_LastIssue
    marker := DungeonMarkerArea(area), windowIssue := "", detectedType := ""
    for roomType in ["Available", "Unavailable", "Cursed", "Opening"] {
        tolerance := roomType = "Available" ? 0.20 : 0.10
        if WF_FindText(&X, &Y, marker.x1, marker.y1, marker.x2, marker.y2,
            tolerance, tolerance, DungeonBorderText(roomType)) {
            detectedType := roomType
            break
        }
        if (IsSet(WF_LastIssue) && WF_LastIssue != "")
            windowIssue := WF_LastIssue
    }
    ; The final red card can also match the shared OPEN/chest marker. Keep
    ; unavailable/cursed states authoritative; require BOTH boss references
    ; before promoting any other card (or recognizing a boss-only border).
    if (detectedType != "Unavailable" && detectedType != "Cursed"
        && DungeonBossCardMatch(area))
        detectedType := "Boss"
    ; A green checkpoint has its OPEN label centered instead of on the left.
    ; Search only this card's interior when no existing state marker matched.
    if (detectedType = "" && DungeonOpeningCardMatch(area, true))
        detectedType := "Opening"
    if (detectedType != "") {
        diagnostic := detectedType
        return detectedType
    }
    if (IsSet(WF_LastIssue) && WF_LastIssue != "")
        windowIssue := WF_LastIssue
    diagnostic := windowIssue = "" ? "marker pattern not found" : windowIssue
    return ""
}

DungeonBossCardMatch(area) {
    marker := DungeonMarkerArea(area)
    return WF_FindText(&X, &Y, marker.x1, marker.y1, marker.x2, marker.y2,
        0.10, 0.10, DungeonBorderText("Boss"))
        && WF_FindText(&X, &Y, area.searchX1, area.searchY1,
            area.searchX2, area.searchY2, 0.20, 0.20, BossRoom2)
}

DungeonOpeningCardMatch(area, requireNoSpecialIcon := false) {
    global WF_LastIssue
    if !WF_FindText(&X, &Y, area.searchX1, area.searchY1,
        area.searchX2, area.searchY2, 0.10, 0.10, DungeonRoomBorderChestOpen)
        return false
    if !requireNoSpecialIcon
        return true
    ; A shared OPEN label must not invent a checkpoint when a missed card's
    ; contents identify a cursed/boss/special room instead.
    for priority, text in roomTexts {
        if (text = "")
            continue
        if WF_FindText(&X, &Y, area.searchX1, area.searchY1,
            area.searchX2, area.searchY2, 0.20, 0.20, text)
            return false
        if (IsSet(WF_LastIssue) && WF_LastIssue != "")
            return false
    }
    if WF_FindText(&X, &Y, area.searchX1, area.searchY1,
        area.searchX2, area.searchY2, 0.20, 0.20, Curse)
        return false
    return !IsSet(WF_LastIssue) || WF_LastIssue = ""
}

DungeonScanRooms(&diagnostics) {
    rooms := [], diagnostics := ""
    for index, area in DungeonRoomAreas() {
        roomType := DungeonProbeRoom(area, &issue)
        diagnostics .= (diagnostics = "" ? "" : "; ") index ":" issue
        if (roomType != "")
            rooms.Push({index: index, type: roomType, coords: area})
    }
    return rooms
}

DungeonRoomEligible(room, unsafeRooms) {
    return !unsafeRooms.Has(room.index) && (room.type = "Available"
        || room.type = "Cursed" || room.type = "Opening" || room.type = "Boss")
}

DungeonHasCurseExclusions() {
    global enabledCurses
    ; Missing configuration is not evidence that every curse is allowed.
    if (!IsSet(enabledCurses) || !IsObject(enabledCurses))
        return true
    for curse in enabledCurses {
        value := Trim(curse)
        if (value != "" && value != "None")
            return true
    }
    return false
}

DungeonDefaultRoutePriorities() {
    return DoseDungeonDefaults().route
}

DungeonCanonicalPriority(value) {
    if IsObject(value)
        return ""
    name := StrReplace(Trim(value), " ", "_")
    if (name = "RareChest")
        name := "Rare_Chest"
    for priority in DungeonDefaultRoutePriorities() {
        if (name = priority)
            return priority
    }
    return ""
}

DungeonPriorityList(priorities) {
    text := ""
    for priority in priorities
        text .= (text = "" ? "" : " > ") priority
    return text
}

DungeonEffectiveRoutePriorities(&diagnostic) {
    global routePriorityOrder
    order := [], seen := Map(), omitted := [], ignored := 0
    if (IsSet(routePriorityOrder) && IsObject(routePriorityOrder)) {
        for value in routePriorityOrder {
            priority := DungeonCanonicalPriority(value)
            if (priority = "" || seen.Has(priority)) {
                ignored += 1
                continue
            }
            seen[priority] := true
            order.Push(priority)
        }
    }
    ; These dropdowns express preferences, not forbidden room types. Keep the
    ; user's order first, then permit omitted types so duplicate/partial lists
    ; cannot strand a route with positively recognized, eligible rooms.
    for priority in DungeonDefaultRoutePriorities() {
        if !seen.Has(priority) {
            order.Push(priority)
            omitted.Push(priority)
        }
    }
    diagnostic := omitted.Length ? "added omitted types: " DungeonPriorityList(omitted) : ""
    if ignored
        diagnostic .= (diagnostic = "" ? "" : "; ") ignored " duplicate/invalid entries ignored"
    return order
}

LookForDungeonRooms() {
    global SaveChestsForBoss
    SaveChestsForBoss := SaveChestsBox.Value = 1
    AddToLog("Dungeon detector: Dose v" DoseReleaseVersion())
    AddToLog("Curse exclusions: " (DungeonHasCurseExclusions() ? "active" : "none; all curses allowed"))
    if !WF_PrepareDungeon() {
        AddToLog("Dungeon window check failed: " WF_LastIssue)
        return false
    }
    ; Replay/recovery can return to the large startup Enter Dungeon screen.
    ; Resolve it before shop/shrine/room scans, using the same confirmed flow.
    if WF_FindText(&X,&Y,250,340,550,495,0.20,0.20,EnterDungeon) {
        AddToLog("Dungeon entrance still visible; resuming Enter Dungeon")
        if !DungeonWaitForEntrance()
            return false
    }
    ; Special screens can change the visible route. Handle them BEFORE scanning.
    if !CheckDungeonSpecials()
        return false
    previousLayout := ""
    Loop 3 {
        foundRooms := DungeonScanRooms(&diagnostics), layout := ""
        for room in foundRooms
            layout .= room.index ":" room.type ";"
        ; Require two consecutive equal border snapshots, not a partial animation.
        if (DungeonValidLayout(foundRooms) && layout = previousLayout) {
            DungeonClearBossExitRecovery()
            AddToLog("Dungeon layout: " layout)
            return SelectBestRoom(foundRooms.Length, foundRooms)
        }
        previousLayout := layout
        if (A_Index < 3)
            Sleep(120)
    }
    AddToLog("Dungeon scan detail: " diagnostics)
    AddToLog("Dungeon detection stopped: no stable compatible room candidates; no room clicked. See scan detail above for window rejection versus missing marker patterns.")
    return false
}

DungeonRareMatch(room) {
    area := room.coords
    matched := WF_ImageSearch(&X, &Y, area.searchX1, area.searchY1,
        area.searchX2, area.searchY2, RareChestImage, 20)
    if (matched && debugMessages)
        AddToLog("Rare Chest PNG: room " room.index " at calibrated " X "," Y)
    return matched
}

DungeonTextMatch(room, text) {
    area := room.coords
    return text != "" && WF_FindText(&X, &Y, area.searchX1, area.searchY1,
        area.searchX2, area.searchY2, 0.20, 0.20, text)
}

DungeonNormalRoomMatch(room) {
    global WF_LastIssue
    ; Ordinary rooms have no special icon. Absence only counts in a readable
    ; room interior; failed searches and opening/boss cards are not normal rooms.
    if (room.type != "Available" && room.type != "Cursed")
        return false
    if DungeonRareMatch(room)
        return false
    for priority, text in roomTexts {
        if (priority = "Rare_Chest")
            continue
        if (text = "" || DungeonTextMatch(room, text))
            return false
        if (IsSet(WF_LastIssue) && WF_LastIssue != "")
            return false
    }
    return true
}

DungeonDetectRooms(foundRooms, unsafeRooms) {
    global WF_LastIssue
    detections := Map(), votes := Map(), normalVotes := Map(), imageOK := true
    for room in foundRooms {
        detections[room.index] := Map()
        votes[room.index] := Map("Rare_Chest", 0, "Opening", 0)
        normalVotes[room.index] := 0
    }
    ; One bounded sampling pass for ALL priorities, never a retry per priority.
    ; Two of three hits are required, keeping the existing PNG tolerance at 20.
    Loop 3 {
        for room in foundRooms {
            if !DungeonRoomEligible(room, unsafeRooms)
                continue
            tally := votes[room.index], clearInterior := false
            if (room.type = "Opening" && DungeonOpeningCardMatch(room.coords))
                tally["Opening"] += 1
            if imageOK {
                try {
                    rareHit := DungeonRareMatch(room)
                    clearInterior := !rareHit
                    if rareHit
                        tally["Rare_Chest"] += 1
                } catch {
                    imageOK := false
                    AddToLog("Rare Chest image search could not complete (asset/window/visibility). Chest and regular-room classification disabled for this scan; show Roblox unobscured at its normal size and check RareChestImage in Detection Tester.")
                }
            }
            for priority, text in roomTexts {
                if (priority = "Rare_Chest")
                    continue
                if (text = "") {
                    clearInterior := false
                    continue
                }
                if !tally.Has(priority)
                    tally[priority] := 0
                if DungeonTextMatch(room, text) {
                    tally[priority] += 1
                    clearInterior := false
                }
                if (IsSet(WF_LastIssue) && WF_LastIssue != "")
                    clearInterior := false
            }
            if clearInterior
                normalVotes[room.index] += 1
        }
        if (A_Index < 3)
            Sleep(120)
    }
    for room in foundRooms {
        if !DungeonRoomEligible(room, unsafeRooms) {
            AddToLog("Room " room.index " (" room.coords.path ") excluded: " room.type)
            continue
        }
        tally := votes[room.index], types := detections[room.index], description := ""
        for priority, count in tally {
            if (priority = "Rare_Chest") {
                if (imageOK && count >= 2)
                    types[priority] := true
            } else if (priority = "Chest") {
                ; The binary Chest pattern is shared by both rarities. Only label
                ; it normal when ALL rare-image samples missed, never on one miss.
                if (imageOK && tally["Rare_Chest"] = 0 && count >= 2)
                    types[priority] := true
            } else if (count >= 2)
                types[priority] := true
            if types.Has(priority)
                description .= (description = "" ? "" : ", ") priority
        }
        if (tally["Rare_Chest"] = 1)
            AddToLog("Room " room.index " Rare Chest inconclusive (1/3); not classified as normal Chest")
        if (imageOK && normalVotes[room.index] = 3
            && (room.type = "Available" || room.type = "Cursed")) {
            types["Normal"] := true
            description := "Normal (no special icon in 3/3 clear scans)"
        }
        AddToLog("Room " room.index " (" room.coords.path ", " room.type "): "
            (description = "" ? "no confirmed icon" : description)
            "; Rare Chest hits=" tally["Rare_Chest"] "/3")
    }
    return detections
}

SelectBestRoom(totalrooms, foundRooms) {
    if (totalrooms != foundRooms.Length || !DungeonValidLayout(foundRooms)) {
        AddToLog("Dungeon selection refused: inconsistent room layout")
        return false
    }
    unsafeRooms := Map()
    priorities := DungeonEffectiveRoutePriorities(&priorityDetail)
    AddToLog("Route priorities: " DungeonPriorityList(priorities))
    if (priorityDetail != "")
        AddToLog("Route priority recovery: " priorityDetail "; saved settings unchanged")
    ; Classify once before considering previews. A current Rare Chest must not
    ; be bypassed by a future marker; all layouts use the same preference loop.
    detections := DungeonDetectRooms(foundRooms, unsafeRooms)
    ; The red single center boss stage is mandatory progression, even if Boss
    ; is absent from route preferences. Confirm its icon before future routes
    ; or chest icons on the same card can choose it for the wrong reason.
    if (totalrooms = 1 && foundRooms[1].index = 3 && foundRooms[1].type = "Boss") {
        if detections[3].Has("Boss")
            return DungeonTryEnterRoom(foundRooms[1], unsafeRooms, "final centered boss stage", "Boss")
        AddToLog("Final boss candidate has no confirmed Boss icon; no room clicked")
        return false
    }
    if (totalrooms = 1 && foundRooms[1].index = 3 && foundRooms[1].type = "Opening") {
        if (detections[3].Has("Opening") && !detections[3].Has("Boss"))
            return DungeonTryEnterRoom(foundRooms[1], unsafeRooms, "green OPEN checkpoint", "Opening")
        if (!detections[3].Has("Opening") && !detections[3].Has("Boss")) {
            AddToLog("OPEN checkpoint marker was not confirmed; no room clicked")
            return false
        }
    }
    for priority in priorities {
        candidates := foundRooms, paths := []
        if (priority = "Rare_Chest") {
            ; Scan previews before selecting a tied current rare. Reuse this
            ; snapshot for future-only routing if every current rare is rejected.
            if PrioritiseFutureRareChests.Value
                paths := DungeonFutureRarePaths(foundRooms)
            candidates := DungeonRankRareRooms(foundRooms,detections,priorities,unsafeRooms,paths)
        }
        for room in candidates {
            if (!DungeonRoomEligible(room, unsafeRooms)
                || !detections[room.index].Has(priority))
                continue
            if DungeonTryEnterRoom(room, unsafeRooms, "priority " priority, priority)
                return true
        }
        ; Future Rare Chest belongs at Rare_Chest's configured rank. All current
        ; rare candidates get first refusal, including their curse checks.
        if (priority = "Rare_Chest" && PrioritiseFutureRareChests.Value) {
            for path in DungeonRankFuturePaths(paths, foundRooms, detections, priorities, unsafeRooms) {
                if ClickFutureRareChestPath(path, foundRooms, unsafeRooms)
                    return true
            }
        }
        if debugMessages
            AddToLog("No safe confirmed room for priority: " priority)
    }
    ; OPEN checkpoints follow configured special priorities when other current
    ; rooms are available. Ordinary rooms remain the final choice.
    for room in foundRooms {
        if (DungeonRoomEligible(room, unsafeRooms) && room.type = "Opening"
            && detections[room.index].Has("Opening") && !detections[room.index].Has("Boss")) {
            if DungeonTryEnterRoom(room, unsafeRooms, "OPEN checkpoint after configured priorities", "Opening")
                return true
        }
    }
    for room in foundRooms {
        if (DungeonRoomEligible(room, unsafeRooms)
            && detections[room.index].Has("Normal")) {
            if DungeonTryEnterRoom(room, unsafeRooms, "regular room with no special icon", "Normal")
                return true
        }
    }
    AddToLog("Dungeon selection failed: no eligible priority, OPEN checkpoint, or regular room; no room clicked. Check room/icon detection in the Debug panel.")
    return false
}

; Only current Rare Chest ties change order. Other configured priorities,
; mandatory single cards, entry checks and exclusions retain their behavior.
DungeonRankRareRooms(rooms,detections,priorities,unsafeRooms,paths) {
    candidates := [], rewards := Map(), votes := Map(), ranked := []
    for room in rooms {
        if (!DungeonRoomEligible(room,unsafeRooms) || !detections[room.index].Has("Rare_Chest"))
            continue
        candidates.Push(room), rewards[room.index] := detections[room.index].Clone()
        votes[room.index] := 0
    }
    if (candidates.Length<2)
        return candidates
    ; CHEST text is shared by both rarities. Count an extra chest only when
    ; its label is spatially separate from the confirmed rare icon, in 2/3 scans.
    Loop 3 {
        for room in candidates
            if DungeonRareExtraChest(room)
                votes[room.index] += 1
        if (A_Index<3)
            Sleep(120)
    }
    for room in candidates {
        if (votes[room.index]>=2)
            rewards[room.index]["Chest"] := true
        detail := ""
        for priority in priorities
            if (priority!="Rare_Chest" && rewards[room.index].Has(priority))
                detail .= (detail="" ? "" : ", ") priority
        AddToLog("Rare Chest candidate " room.index " (" room.coords.path "): future rare="
            (DungeonRarePathPresent(paths,room.coords.path) ? "confirmed" : "not confirmed")
            "; extra rewards=" (detail="" ? "none confirmed" : detail))
        inserted := false
        for i,existing in ranked {
            if DungeonRareRoomBetter(room,existing,rewards,priorities,paths) {
                ranked.InsertAt(i,room), inserted := true
                break
            }
        }
        if !inserted
            ranked.Push(room)
    }
    order := ""
    for room in ranked
        order .= (order="" ? "" : " > ") room.coords.path
    AddToLog("Current Rare Chest comparison: " order "; future rare first, then configured extra rewards")
    return ranked
}

DungeonRarePathPresent(paths,path) {
    for candidate in paths
        if (candidate=path)
            return true
    return false
}

DungeonRareRoomBetter(a,b,rewards,priorities,paths) {
    af := DungeonRarePathPresent(paths,a.coords.path), bf := DungeonRarePathPresent(paths,b.coords.path)
    if (af!=bf)
        return af
    ; Lexicographic comparison preserves the user's order: one higher-priority
    ; extra reward beats any number of lower-priority extras. Exact ties stay stable.
    for priority in priorities {
        if (priority="Rare_Chest")
            continue
        av := rewards[a.index].Has(priority), bv := rewards[b.index].Has(priority)
        if (av!=bv)
            return av
    }
    return false
}

DungeonRareExtraChest(room) {
    global WF_LastIssue
    area := room.coords
    try {
        if !WF_ImageSearch(&rareX,&rareY,area.searchX1,area.searchY1,
            area.searchX2,area.searchY2,RareChestImage,20)
            return false
        matches := WF_FindText(&firstX,&firstY,area.searchX1,area.searchY1,
            area.searchX2,area.searchY2,0.20,0.20,roomTexts["Chest"])
        if (!IsObject(matches) || matches.Length<2 || (IsSet(WF_LastIssue) && WF_LastIssue!=""))
            return false
        ; WF_FindText normalizes its output point, while result-array points
        ; remain in screen coordinates. Derive that translation from the first hit.
        dx := matches[1].x-firstX, dy := matches[1].y-firstY
        ownLabel := false, extraLabel := false
        for hit in matches {
            x := hit.x-dx, y := hit.y-dy
            ; The 16x12 rare reference sits above its own CHEST label. Ignore
            ; that label and nearby duplicate matches; accept a different column
            ; or row only. All points must still belong to this current card.
            if (x<area.searchX1 || x>area.searchX2 || y<area.searchY1 || y>area.searchY2)
                continue
            if (Abs(x-(rareX+8))>=24 || y<rareY-4 || y>rareY+30)
                extraLabel := true
            else
                ownLabel := true
        }
        return ownLabel && extraLabel
    }
    return false
}

DungeonTryEnterRoom(room, unsafeRooms, reason, priority := "") {
    if !DungeonRoomEligible(room, unsafeRooms)
        return false
    area := room.coords
    ; Revalidate the border and selected icon immediately before the click.
    currentType := DungeonProbeRoom(area, &issue)
    if (currentType = "" || currentType != room.type) {
        unsafeRooms[room.index] := true
        AddToLog("Room " room.index " recheck failed: " issue)
        return false
    }
    if (priority != "") {
        confirmed := false
        try {
            if (priority = "Normal")
                confirmed := DungeonNormalRoomMatch(room)
            else if (priority = "Opening")
                confirmed := room.type = "Opening" && DungeonOpeningCardMatch(area)
            else if (priority = "Rare_Chest")
                confirmed := DungeonRareMatch(room)
            else if (priority = "Chest")
                confirmed := DungeonTextMatch(room, roomTexts["Chest"]) && !DungeonRareMatch(room)
            else if roomTexts.Has(priority)
                confirmed := DungeonTextMatch(room, roomTexts[priority])
        } catch {
            confirmed := false
        }
        if !confirmed {
            unsafeRooms[room.index] := true
            AddToLog("Room " room.index " icon recheck failed; skipping")
            return false
        }
    }
    if !WF_RobloxClick(area.clickX, area.clickY) {
        unsafeRooms[room.index] := true
        AddToLog("Room " room.index " click refused: Roblox not ready")
        return false
    }
    Sleep(500)
    if (room.type = "Cursed" && DungeonHasCurseExclusions()) {
        curseResult := DetectCurse()
        if (curseResult.skip || curseResult.curse = "no curse found") {
            unsafeRooms[room.index] := true
            AddToLog("Room " room.index " rejected: " curseResult.curse)
            ; Preserve the existing card-toggle behavior to dismiss curse details.
            if !WF_RobloxClick(area.clickX, area.clickY) {
                ; No further selection is safe with an unresolved modal.
                for id in [1, 2, 3, 4, 5]
                    unsafeRooms[id] := true
            }
            Sleep(1000)
            return false
        }
    }
    if (room.type = "Cursed" && !DungeonHasCurseExclusions())
        AddToLog("Room " room.index " curse identification not required: no curses are excluded")
    if (room.type = "Boss" || priority = "Boss") {
        global BossRoomCompleted := true
        AddToLog("Boss room detected, setting BossRoomCompleted to true")
    }
    AddToLog("Selecting room " room.index " (" area.path ", " room.type ") because " reason)
    ; This normally hands off via MacroNextStep; do not swallow that exception.
    CheckForEnterButton()
    return true
}

CheckForEnterButton() {
    global BossRoomCompleted
    WaitFor("Dungeon Room Enter")
    if (CheckIfFinalRoom()) {
        BossRoomCompleted := true
        AddToLog("Final room detected, setting BossRoomCompleted to true")
    }
    if (ok := FT(&X, &Y, 31, 241, 801, 543, 0.20, 0.20, Enter)) {
        AddToLog("Found Enter button, joining dungeon")
        ClickUntilGone(0, 0, 31, 241, 801, 543, Enter, 0, -30)
        Sleep(2000)
        ; Start dungeon run
        AddToLog("Starting dungeon run")
        NextStep(RestartStage)
    } else {
        AddToLog("Enter button not found, retrying...")
        ClickUntilGone(0, 0, 588, 107, 780, 249, DungeonRedX)
        Sleep(2500)
        ClickReturnToLobby()
        Sleep(2000)
        return NextStep(CheckLobby)
    }
}

; Function to check for special dungeon elements after replay
CheckDungeonSpecials(chestOptions := 0) {
    AddToLog("Checking for dungeon shop, shrine, open chest")
    
    ; Give time for special elements to appear
    Sleep(2000)
    
    foundShop := false
    foundShrine := false
    foundChest := false

    ; Check the area for shop, shrine, or chest
    Loop 5 {
        ; Check for shop
        if (!foundShop && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shop)) {
            AddToLog("Found Shop")
            Sleep(1000)
            if !HandleShop()
                return false
            Sleep(1000)
            foundShop := true
        }
        Sleep(1000)
        ; Check for shrine
        if (!foundShrine && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shrine)) {
            if (DenyShrines.Value) {
                AddToLog("Found Shrine, Denying")
                ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
            } else {
                ShrinePriority()
            }
            Sleep(1000)
            foundShrine := true
        }
        Sleep(1000)
        ; Check for Chest Opening
        if (!foundChest && IsChestScreenVisible()) {
            AddToLog("Found Chest Opening")
            if !HandleChestScreen(chestOptions)
                return false
            foundChest := true
        }
        
        ; If all elements are found, exit early
        if (foundShop && foundShrine && foundChest)
            break

        Sleep(1000)  ; Wait and check again
    }
    
    if (!foundShop && !foundShrine && !foundChest)
        AddToLog("No shop, shrine, or chest opening found")
    return true
}

HandleShop(overrides := 0) {
    global WF_LastIssue
    options := DungeonShopOptions(overrides)
    if !WF_PrepareDungeon() {
        AddToLog("Shop window not ready; no purchases attempted")
        return false
    }
    AddToLog("Handling shop: Golden Fishhook, then Fishhook; never buy Axe; remaining buttons bottom to top")
    Sleep(options.loadMs)
    if !DungeonShopVisible() {
        AddToLog("Shop header not confirmed; no purchases attempted")
        return false
    }
    state := {actions:0, deadline:A_TickCount+options.totalMs}
    buttons := DungeonShopReadStable(options)
    if !IsObject(buttons)
        return DungeonShopFailure("initial purchase-button scan")
    AddToLog("Shop: " buttons.Length " visible gold purchase buttons")
    blocked := Map()
    for hookName in ["Golden Fishhook", "Fishhook"] {
        hookFound := false
        Loop 3 {
            if DungeonShopHook(&hookX,&hookY,hookName) {
                hookFound := true
                break
            }
            if (WF_LastIssue != "")
                return DungeonShopFailure(hookName " search")
            Sleep(options.pollMs)
        }
        if hookFound {
            row := DungeonShopHookRow(buttons,hookX,hookY,hookName)
            if row {
                result := DungeonShopBuy(buttons,row,options,state,hookName)
                if !result.ok
                    return false
                buttons := result.buttons
                if (!result.progress && !result.changed)
                    blocked[result.row] := true
            } else {
                if (hookName="Golden Fishhook") {
                    AddToLog("Golden Fishhook found without an active purchase button; checking other items")
                    continue
                }
                ; Keep the known-working Fishhook click even when its button is
                ; disabled or the gold shape is not detected. Never claim success.
                AddToLog(hookName " found without a recognized active gold button; trying its existing purchase point first")
                if !DungeonShopVisible()
                    return DungeonShopFailure(hookName " fallback header recheck")
                if !DungeonShopHook(&hookX,&hookY,hookName) {
                    if (WF_LastIssue!="")
                        return DungeonShopFailure(hookName " fallback recheck")
                } else {
                    excluded := DungeonShopExcluded({y:hookY})
                    if (WF_LastIssue!="")
                        return DungeonShopFailure("hook fallback exclusion check")
                    if excluded {
                        AddToLog("Shop skip: " excluded " is never-buy")
                        continue
                    }
                    if !DungeonShopClick(hookX+150,hookY,hookName " first")
                        return false
                    state.actions += 1
                }
                if !DungeonShopMoveOffButtons()
                    return DungeonShopFailure("moving off purchase button")
                Sleep(options.settleMs)
                buttons := DungeonShopReadStable(options)
                if !IsObject(buttons)
                    return DungeonShopFailure("post-" hookName " scan")
                AddToLog(hookName " purchase not independently confirmed; checking other available items")
            }
        } else
            AddToLog(hookName " not detected after 3 checks; using visible purchase buttons")
    }

    while (buttons.Length && state.actions < options.maxActions && A_TickCount < state.deadline) {
        row := 0
        Loop buttons.Length {
            candidate := buttons.Length-A_Index+1
            if !blocked.Has(candidate) {
                row := candidate
                break
            }
        }
        if !row
            break
        result := DungeonShopBuy(buttons,row,options,state)
        if !result.ok
            return false
        buttons := result.buttons
        if (result.progress || result.changed)
            blocked := Map()
        else
            blocked[row] := true
    }
    if buttons.Length
        AddToLog("Shop: " buttons.Length " purchase buttons remain (excluded or possibly unaffordable); continuing as configured")
    else
        AddToLog("Shop: no active gold purchase buttons detected; checking Continue")
    return DungeonShopClose(options)
}

DungeonShopOptions(overrides := 0) {
    options := {loadMs:1500,pollMs:200,settleMs:500,observeMs:2500,
        scanTries:8,attempts:3,maxActions:12,totalMs:60000,closeMs:8000}
    if IsObject(overrides) {
        for name,value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    }
    return options
}

DungeonShopFailure(context) {
    global WF_LastIssue
    AddToLog("Shop " context " failed: " WF_LastIssue "; no later purchase or Continue sent")
    return false
}

DungeonShopVisible() {
    return WF_FindText(&X,&Y,110,120,420,280,0,0,Shop)
}

DungeonShopFishhook(&X,&Y) {
    return WF_FindText(&X,&Y,184,118,623,523,0,0,Fishhook)
}

; Keep the original regular Fishhook detector and offset unchanged.
DungeonShopHook(&X,&Y,kind) {
    if (kind="Golden Fishhook")
        return WF_FindText(&X,&Y,184,118,623,523,0,0,GoldenFishhook)
    return DungeonShopFishhook(&X,&Y)
}

; Re-read the icon for this live purchase row, including immediately before input.
; Row-local matching prevents one Axe from excluding unrelated offers.
DungeonShopHookRow(buttons,x,y,kind) {
    if !buttons.Length
        return 0
    return DungeonShopButtonAt(buttons,kind="Golden Fishhook" ? buttons[1].x : x+150,y)
}

DungeonShopExcluded(button) {
    if WF_FindText(&X,&Y,375,Max(118,button.y-24),435,Min(523,button.y+24),0,0,Axe)
        return "Axe"
    return ""
}

DungeonShopCapture() {
    global WF_LastIssue
    ; Only the calibrated shop purchase column. Currency, item art and the
    ; green Continue button are outside this color/geometry detector.
    x1 := 500,y1 := 160,x2 := 625,y2 := 375
    region := WF_RobloxRegion(x1,y1,x2,y2)
    if !IsObject(region)
        return false
    try {
        left := region.left,top := region.top,w := x2-x1+1,h := y2-y1+1
        capturedX := left,capturedY := top,capturedW := w,capturedH := h
        criticalBefore := A_IsCritical
        try {
            Critical "On"
            bits := FindText().GetBitsFromScreen(&capturedX,&capturedY,&capturedW,&capturedH,1)
            if (!bits.Scan0 || bits.BindWindow || capturedX!=left || capturedY!=top || capturedW!=w || capturedH!=h) {
                WF_LastIssue := "Shop screen capture is incomplete or FindText is window-bound"
                return false
            }
            pixels := Buffer(w*h*4,0)
            Loop h {
                source := bits.Scan0+(top-bits.zy+A_Index-1)*bits.Stride+(left-bits.zx)*4
                DllCall("RtlMoveMemory","Ptr",pixels.Ptr+(A_Index-1)*w*4,"Ptr",source,"UPtr",w*4)
            }
        } finally {
            Critical criticalBefore
        }
        if !WF_RegionUnchanged(region,x1,y1,x2,y2) {
            WF_LastIssue := "Shop window moved or became covered during capture"
            return false
        }
        return {pixels:pixels,w:w,h:h,x:x1,y:y1}
    } catch as err {
        WF_LastIssue := "Shop capture failed at line " err.Line
        return false
    }
}

DungeonShopGold(color) {
    r := (color>>16)&255,g := (color>>8)&255,b := color&255
    return r>=185 && g>=125 && b<=130 && r+25>=g && g>=b+45 && r>=b+80
}

DungeonShopButtonsFromFrame(frame) {
    w := frame.w,h := frame.h,mask := Buffer(w*h,0),buttons := []
    Loop w*h
        if DungeonShopGold(NumGet(frame.pixels,(A_Index-1)*4,"UInt"))
            NumPut("UChar",1,mask,A_Index-1)
    Loop w*h {
        seed := A_Index-1
        if !NumGet(mask,seed,"UChar")
            continue
        queue := [seed],head := 1,count := 0,minX := w,minY := h,maxX := -1,maxY := -1
        NumPut("UChar",0,mask,seed)
        while (head<=queue.Length) {
            index := queue[head],head += 1
            px := Mod(index,w),py := index//w
            minX := Min(minX,px),maxX := Max(maxX,px),minY := Min(minY,py),maxY := Max(maxY,py)
            count += 1
            for dy in [-1,0,1] {
                ny := py+dy
                if (ny<0 || ny>=h)
                    continue
                for dx in [-1,0,1] {
                    nx := px+dx
                    if (nx<0 || nx>=w || (dx=0 && dy=0))
                        continue
                    next := ny*w+nx
                    if NumGet(mask,next,"UChar") {
                        NumPut("UChar",0,mask,next)
                        queue.Push(next)
                    }
                }
            }
        }
        bw := maxX-minX+1,bh := maxY-minY+1
        ; Connected gold plate, not the small coin glyph or yellow item text.
        if (minX=0 || minY=0 || maxX=w-1 || maxY=h-1 || bw<40 || bw>90 || bh<14 || bh>38
            || bw<bh*1.4 || bw>bh*5 || count<bw*bh*0.40)
            continue
        button := {x:frame.x+Round((minX+maxX)/2),y:frame.y+Round((minY+maxY)/2),w:bw,h:bh}
        pos := 1
        while (pos<=buttons.Length && buttons[pos].y<button.y)
            pos += 1
        buttons.InsertAt(pos,button)
    }
    return buttons
}

DungeonShopSameButtons(a,b) {
    if (a.Length!=b.Length)
        return false
    for i,button in a
        if (Abs(button.x-b[i].x)>3 || Abs(button.y-b[i].y)>3 || Abs(button.w-b[i].w)>3 || Abs(button.h-b[i].h)>3)
            return false
    return true
}

DungeonShopReadStable(options) {
    global WF_LastIssue
    previous := 0,streak := 0
    Loop options.scanTries {
        if !DungeonShopVisible() {
            if (WF_LastIssue="")
                WF_LastIssue := "Shop header is not visible"
            return false
        }
        frame := DungeonShopCapture()
        if !IsObject(frame)
            return false
        buttons := DungeonShopButtonsFromFrame(frame)
        if (buttons.Length>3) {
            WF_LastIssue := "More than three purchase-button candidates; refusing ambiguous clicks"
            return false
        }
        for i,button in buttons {
            if (i>1 && (Abs(button.x-buttons[1].x)>16 || button.y-buttons[i-1].y<30)) {
                WF_LastIssue := "Purchase-button column is ambiguous"
                return false
            }
        }
        streak := IsObject(previous) && DungeonShopSameButtons(previous,buttons) ? streak+1 : 1
        if (streak >= (buttons.Length ? 2 : 3))
            return buttons
        previous := buttons
        Sleep(options.pollMs)
    }
    WF_LastIssue := "Shop purchase layout did not settle"
    return false
}

DungeonShopButtonAt(buttons,x,y) {
    for i,button in buttons
        if (Abs(button.x-x)<=button.w//2 && Abs(button.y-y)<=button.h//2+3)
            return i
    return 0
}

DungeonShopMoveOffButtons() {
    region := WF_RobloxRegion(300,350,300,350)
    return IsObject(region) && DllCall("SetCursorPos","Int",region.left,"Int",region.top,"Int")
}

DungeonShopBuy(before,row,options,state,fishhook := false) {
    global WF_LastIssue
    description := fishhook ? fishhook " first" : "remaining item"
    Loop options.attempts {
        if (state.actions>=options.maxActions || A_TickCount>=state.deadline)
            break
        fresh := DungeonShopReadStable(options)
        if !IsObject(fresh) {
            DungeonShopFailure(description " recheck")
            return {ok:false}
        }
        if !DungeonShopSameButtons(before,fresh) {
            if fishhook {
                if DungeonShopHook(&hookX,&hookY,fishhook) {
                    newRow := DungeonShopHookRow(fresh,hookX,hookY,fishhook)
                    if newRow
                        before := fresh,row := newRow
                    else
                        return {ok:true,progress:false,changed:true,buttons:fresh,row:row}
                } else {
                    if (WF_LastIssue!="") {
                        DungeonShopFailure("moved Fishhook recheck")
                        return {ok:false}
                    }
                    return {ok:true,progress:false,changed:true,buttons:fresh,row:row}
                }
            } else
                return {ok:true,progress:false,changed:true,buttons:fresh,row:row}
        }
        x := fresh[row].x,y := fresh[row].y
        if fishhook {
            if !DungeonShopHook(&hookX,&hookY,fishhook) {
                if (WF_LastIssue!="") {
                    DungeonShopFailure("Fishhook recheck")
                    return {ok:false}
                }
                return {ok:true,progress:false,changed:false,buttons:fresh,row:row}
            }
            x := fishhook="Golden Fishhook" ? fresh[row].x : hookX+150,y := hookY
            if (DungeonShopButtonAt(fresh,x,y)!=row) {
                WF_LastIssue := "Fishhook moved outside its confirmed purchase row"
                DungeonShopFailure("Fishhook row recheck")
                return {ok:false}
            }
        }
        excluded := DungeonShopExcluded({y:y})
        if (WF_LastIssue!="") {
            DungeonShopFailure("never-buy exclusion recheck")
            return {ok:false}
        }
        if excluded {
            AddToLog("Shop skip: " excluded " is never-buy; no purchase click sent")
            return {ok:true,progress:false,changed:false,buttons:fresh,row:row}
        }
        if !DungeonShopClick(x,y,description)
            return {ok:false}
        state.actions += 1
        if !DungeonShopMoveOffButtons() {
            DungeonShopFailure("purchase hover reset")
            return {ok:false}
        }
        Sleep(options.settleMs)
        observed := A_TickCount
        while (A_TickCount-observed<options.observeMs && A_TickCount<state.deadline) {
            after := DungeonShopReadStable(options)
            if !IsObject(after) {
                DungeonShopFailure("post-purchase scan")
                return {ok:false}
            }
            hookGone := true
            if fishhook {
                hookGone := !DungeonShopHook(&hookX,&hookY,fishhook)
                if (WF_LastIssue!="") {
                    DungeonShopFailure("Fishhook completion check")
                    return {ok:false}
                }
            }
            if (after.Length<before.Length && hookGone) {
                AddToLog("Shop " description ": visible purchase buttons " before.Length " -> " after.Length "; re-scanning next item")
                return {ok:true,progress:true,changed:true,buttons:after}
            }
            Sleep(options.pollMs)
        }
        AddToLog("Shop " description " purchase not confirmed; attempt " A_Index "/" options.attempts)
    }
    AddToLog("Shop " description " still unconfirmed (possibly unaffordable); trying other items before Continue")
    return {ok:true,progress:false,changed:false,buttons:before,row:row}
}

DungeonShopClose(options) {
    global WF_LastIssue
    started := A_TickCount,lastClick := 0,clicks := 0,absent := 0
    while (A_TickCount-started<options.closeMs) {
        visible := DungeonShopVisible()
        if (WF_LastIssue!="")
            return DungeonShopFailure("close confirmation")
        absent := visible ? 0 : absent+1
        if (absent>=2) {
            AddToLog("Shop closed; returning to dungeon flow")
            return true
        }
        if (visible && clicks<3 && (!lastClick || A_TickCount-lastClick>=options.observeMs)) {
            if WF_FindText(&X,&Y,350,345,630,500,0,0,DungeonContinue) {
                if !DungeonShopClick(X,Y,"close shop")
                    return false
                clicks += 1,lastClick := A_TickCount
            } else if (WF_LastIssue!="")
                return DungeonShopFailure("Continue search")
        }
        Sleep(options.pollMs)
    }
    AddToLog("Shop Continue did not close the menu; no room selection attempted")
    return false
}

DungeonShopClick(x, y, description) {
    if !WF_RobloxClick(x, y) {
        AddToLog("Shop input refused for " description "; no later purchases attempted")
        return false
    }
    AddToLog("Shop purchase/action click sent: " description "; purchase/buff not independently confirmed")
    return true
}

IsChestScreenVisible() {
    return FT(&X, &Y, 140, 200, 375, 250, 0, 0, ChestRoom) or FT(&X, &Y, 358, 238, 604, 261, 0, 0, ChestRoomLuck)
}

IsCommonChestDone() {
    ; An empty-slot reference must not tolerate a different remaining count.
    return WF_FindText(&X, &Y, 357, 265, 407, 315, 0.000001, 0.000001, EmptyCommonChest)
}

IsRareChestDone() {
    return WF_FindText(&X, &Y, 353, 324, 408, 379, 0.000001, 0.000001, EmptyRareChest)
}

HandleChestScreen(options := 0) {
    global BossRoomCompleted, SaveChestsForBoss
    
    ; Determine if we should open chests now
    shouldOpenChests := BossRoomCompleted || !SaveChestsForBoss
    
    if (shouldOpenChests) {
        if BossRoomCompleted
            DungeonClearBossExitRecovery()
        AddToLog("Opening all available chests")
        
        if !WF_PrepareDungeon() {
            AddToLog("Chest opening window not ready; no Continue sent")
            return false
        }
        try {
            if !DungeonOpenAllChestsWithRecovery(options)
                return false
        } catch as err {
            AddToLog("Chest opening stopped after an unexpected error at line " err.Line "; no Continue sent")
            return false
        }

        if (BossRoomCompleted) {
            DungeonArmBossExitRecovery()
            BossRoomCompleted := false
            ClickDungeonContinue()
        } else {
            ClickDungeonContinue()
            if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    NextStep(StartSelectedMode)
                }
        }

        } else {
            AddToLog("Saving chests for boss room - clicking continue")
            ClickDungeonContinue()
            if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    NextStep(StartSelectedMode)
                }
        }
        Sleep(1000)
        Reconnect()
        return true
}

ClaimChestReward(options := 0) {
    return DungeonClaimChestReward(options)
}

; Custom monitor for dungeon ending
MonitorDungeonEnd() {
    global mode, Wins, loss, challengeStartTime, inChallengeMode

    failed := false
    
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(3000)  
        StageGuard.Check("EndScreen", "dungeon end screen not handled")   ; [Framework]
        FixClick(560, 560)  ; Move click

        ; Check for unit exit UI element
        if (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }
        
        if (ok := FT(&X, &Y, 150, 180, 350, 260, 0, 0, DefeatText) or (ok:=FT(&X, &Y, 319, 176, 492, 279, 0, 0, DefeatText2))) {
            failed := true
        }

        ; Check for next text UI element
        if (ok := FT(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
        }

        ; Check for returning to lobby
        if (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            if (!inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                AddToLog("Challenge completed - returning to " mode " mode")
               inChallengeMode := false
               challengeStartTime := A_TickCount
               ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
               return NextStep(CheckLobby)
           }

           ; Check if it's time for challenge mode
           if (!inChallengeMode && ChallengeBox.Value) {
               timeElapsed := A_TickCount - challengeStartTime
               if (timeElapsed >= 1800000) {
                   AddToLog("30 minutes passed - switching to Challenge mode")
                   inChallengeMode := true
                   challengeStartTime := A_TickCount
                   ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                   return NextStep(CheckLobby)
               }
           }

            if (StopAfterDefeat.Value && failed) {
                AddToLog("Dungeon run failed, stopping to save lives...")
                ClickReturnToLobby()
                SendFinalWebhookBeforeExit()
                CheckForLobby()
                Sleep(2000)
                return Reload()
            } else  {
                AddToLog("Dungeon run completed, clicking replay")
            
                ; Click replay button
                ClickReplay()
                ClickUntilGone(0, 0, 0, 0, 1000, 1000, OpenDungeon, 0, -35)
                
                ; After clicking replay, check for shop/shrine/chest
                if !CheckDungeonSpecials()
                    return false

                Sleep(2500)
    
                if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    return NextStep(StartSelectedMode)
                }
                
                ; Start a new dungeon run
                AddToLog("Starting next dungeon")
                return LookForDungeonRooms()
            }
            Reconnect()
        }
    }
}

ClickDungeonContinue() {
    ClickUntilGoneFinishDungeon(0, 0, 380, 385, 615, 490, DungeonContinue, -3, -35)
}

ClickDungeonDeathContinue() {
    ClickUntilGone(0, 0, 308, 391, 494, 437, DungeonDeathContinue, -0, -30)
}

CheckIfFinalRoom() {
    if (ok := FT(&X, &Y, 434, 215, 479, 230, 0, 0, FinalRoom)) {
        return true
    }
    return false
}

DetectCurse() {
    AddToLog("Checking room for curse...")  ; Log the curse check start
    curseCheckTime := A_TickCount
    
    Loop {
        if (A_TickCount - curseCheckTime > 3000) {
            AddToLog("Could not detect curse after 3 seconds; room selection will reject unknown curse")
            return {curse: "no curse found", skip: false}
        }

        curseTexts := Map(
            "Flying", CurseOfFlight,
            "Wind", CurseOfWind,
            "Money", CurseOfMoney,
            "Shop", CurseOfShop,
            "Health", CurseOfHealth,
            "Shielding", CurseOfShielding, ;done
            "Regen", CurseOfRegen,
            "Exploding", CurseofExplosion
        )

        for curseName, curse in curseTexts {
            if (ok := WF_FindText(&X, &Y, 121, 168, 681, 493, 0.05, 0.05, curse)) {
                skip := ShouldSkipCurse(curseName)
                if (skip) {
                    AddToLog("Skipping because of curse: " curseName)
                } else {
                    AddToLog("Detected Curse: " curseName)
                }
                return {curse: curseName, skip: skip}
            }
        }
        Sleep 1000
    }
}

CheckForFinishDungeon() {
    ; Check for the finish dungeon popup
    if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.20, 0.20, FinishDungeon) or (ok := FT(&X, &Y, 310, 395, 495, 440, 0.20, 0.20, EnterDungeon)) or (ok := FT(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath))) {
        
        ; Click the Finish button
        ClickUntilGone(0, 0, 240, 180, 565, 480, DungeonFinish, -3, -35)
        Sleep(1500)

        if (!dungeonDeathBroken) {
            ; Click Dungeon Death if needed
            ClickDungeonDeathContinue()
            Sleep(1500)
        }
        
        ; Click the X in the top right
        ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
        Sleep(1000)
        
        ; Return to lobby
        AddToLog("Returning to lobby after completing dungeon")
        ClickReturnToLobby()
        
        ; Check for lobby and restart
        return NextStep(CheckLobby)
    }
    
    return false
} 

CheckForFinishDungeonV2() {
    ; The old finish handler treated a post-boss Enter button as completion and
    ; restarted without checking whether that button ever worked. Use the same
    ; bounded entrance confirmation/recovery flow instead.
    if DungeonBossExitPending {
        entranceVisible := WF_FindText(&X,&Y,250,340,550,495,0.20,0.20,EnterDungeon)
        if (WF_LastIssue!="")
            return false
        if entranceVisible {
            AddToLog("Post-boss entrance detected; verifying entry before restarting")
            return DungeonWaitForEntrance()
        }
    }
    ; Check for the finish dungeon popup
    if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.10, 0.10, FinishDungeon) or (ok := FT(&X, &Y, 310, 395, 495, 440, 0.10, 0.10, EnterDungeon)) or (ok := FT(&X, &Y, 370, 225, 545, 300, 0.10, 0.10, DungeonDeath))) {
        AddToLog("Detected dungeon finish Continuing...")
        ; Click the Finish button
        if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.20, 0.20, FinishDungeon)){
            AddToLog("Detected Finish dungeon text clicking....")
            sleep 2000
            FixClick(344,251)
            sleep 1000
            FixClick(322,340)
            sleep 300
            FixClick(666, 145)
            Sleep(2000)
            if (ok := FT(&X, &Y, 126, 56, 675, 230, 0, 0, LobbyText2)) or (ok := FT(&X, &Y, 126, 56, 675, 230, 0, 0, LobbyText)){
                ClickReturnToLobby()
            }
        }

        if (ok := FT(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath)){
            ClickDungeonDeathContinue()
            ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
            Sleep(1000)
        }

        if (!dungeonDeathBroken) {
            ; Click Dungeon Death if needed
            ClickDungeonDeathContinue()
            Sleep(1500)
            ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
            Sleep(1000)
        }
        return true
    }
}

ClickUntilGoneFinishDungeon(x, y, searchX1, searchY1, searchX2, searchY2, textToFind, offsetX:=0, offsetY:=0, textToFind2:="") {
    waitTime := A_TickCount ; Start timer
    while (ok := FT(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0, 0, textToFind) || textToFind2 && FT(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0, 0, textToFind2)) {
        if ((A_TickCount - waitTime) > 300000) { ; 5-minute limit
            AddToLog("5 minute failsafe triggered, trying to open roblox...")
            return NextStep(RejoinPrivateServer)
        }
        if (offsetX != 0 || offsetY != 0) {
            FixClick(X + offsetX, Y + offsetY)  
        } else {
            FixClick(x, y) 
        }
        Sleep(1000)
        if (ok := FT(&X, &Y, 174, 102, 631, 545, 0, 0, FinishDungeonText)){
            AddToLog("Found Finish Dungeon Clicking....")
            sleep 100
            FixClick(X,Y)
        }
    }
}

ClickFinishDungeonText(){
    ;Check if finish dungeon text is there and close it
    sleep 1000
    if (ok := FT(&X, &Y, 174, 102, 631, 545, 0.10, 0.10, FinishDungeonText)){ 
            AddToLog("Found Finish Dungeon Clicking...." x " " y)
            sleep 100
            FixClick(326,260)
            return true
        }
    return false
}

ShrinePriority() {
    global enabledShrines

    ; Detect which shrine curse is currently on screen
    shrineType := ""

    if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfArmor) {
        shrineType := "Armor"
    }
    else if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfBurst) {
        shrineType := "Burst"
    }
    else if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfChaos) {
        shrineType := "Chaos"
    }
    ;else if FT(&X, &Y, 140, 200, 375, 250, 0, 0, Vampire) {  gotta get the image of vamparism
    ;    shrineType := "Vamparism"
    ;}
    else if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfFrenzy) {
        shrineType := "Frenzy"
    }

    ; No shrine detected
    if (shrineType = "") {
        AddToLog("Shrine found, but could not identify the curse. Denying...")
        ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
        return
    }

    ; Check whether this shrine is on the reject list
    if (HasValue(enabledShrines, shrineType)) {
        AddToLog("Found avoided shrine: " shrineType " - Denying")
        ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
    }
    else {
        AddToLog("Found shrine: " shrineType " - Accepting")
        ClickUntilGone(0, 0, 334, 395, 672, 483, ShrineAccept, 0, -30)
    }
}

DungeonFutureAreas(foundRooms := 0) {
    if IsObject(foundRooms) {
        for room in foundRooms {
            if (room.index = 4 || room.index = 5) {
                ; Two current parents at x322 and x477. Their preview groups
                ; split at x400; there is no center parent in this layout.
                return [
                    {path: "Left", x1: 150, y1: 248, x2: 399, y2: 333},
                    {path: "Right", x1: 400, y1: 248, x2: 657, y2: 333}
                ]
            }
        }
    }
    ; Three-parent positions x250/400/555 split at their midpoints. Retain
    ; potential missing neighbors for partial scans, including center-only.
    ; Preview-only Y bounds exclude the progress bar and current room row.
    return [
        {path: "Left", x1: 150, y1: 248, x2: 324, y2: 333},
        {path: "Center", x1: 325, y1: 248, x2: 477, y2: 333},
        {path: "Right", x1: 478, y1: 248, x2: 657, y2: 333}
    ]
}

DungeonFutureRarePaths(foundRooms := 0) {
    votes := Map("Left", 0, "Center", 0, "Right", 0), paths := []
    futureAreas := DungeonFutureAreas(foundRooms)
    Loop 3 {
        for area in futureAreas {
            ; A tiny nonzero tolerance becomes zero allowed pixel errors while
            ; preventing FindText's implicit zero/zero -> 5% fallback.
            ; Both patterns use THIS path's layout-specific rectangle;
            ; one unavailable path must not hide a second reachable future chest.
            if (WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                0.000001, 0.000001, FutureRareChest1)
                || WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                    0.000001, 0.000001, FutureRareChest2))
                votes[area.path] += 1
        }
        if (A_Index < 3)
            Sleep(120)
    }
    for area in futureAreas {
        if (votes[area.path] < 2)
            continue
        reachable := !IsObject(foundRooms)
        if IsObject(foundRooms) {
            for room in foundRooms {
                if (room.coords.path = area.path && DungeonRoomEligible(room, Map()))
                    reachable := true
            }
        }
        AddToLog("Future Rare Chest " area.path ": " votes[area.path] "/3 hits; "
            (reachable ? "current path present" : "no eligible current path"))
        if reachable
            paths.Push(area.path)
    }
    if !paths.Length
        AddToLog("No confirmed reachable Future Rare Chest path")
    return paths
}

DungeonRankFuturePaths(paths, foundRooms, detections, priorities, unsafeRooms) {
    ranked := [], seen := Map()
    ; Equal future-rare routes prefer the current room's configured rewards.
    for priority in priorities {
        for room in foundRooms {
            path := room.coords.path
            if (!DungeonRoomEligible(room, unsafeRooms) || seen.Has(path)
                || !detections[room.index].Has(priority))
                continue
            for candidate in paths {
                if (candidate = path) {
                    ranked.Push(path), seen[path] := true
                    break
                }
            }
        }
    }
    for path in paths {
        if seen.Has(path)
            continue
        for room in foundRooms {
            if (room.coords.path = path && DungeonRoomEligible(room, unsafeRooms)) {
                ranked.Push(path), seen[path] := true
                break
            }
        }
    }
    return ranked
}

CheckFutureRareChest() {
    paths := DungeonFutureRarePaths()
    return paths.Length ? paths[1] : ""
}

ClickFutureRareChestPath(path, foundRooms, unsafeRooms := 0) {
    if !IsObject(unsafeRooms)
        unsafeRooms := Map()
    stillVisible := false
    for area in DungeonFutureAreas(foundRooms) {
        if (area.path = path) {
            stillVisible := WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                0.000001, 0.000001, FutureRareChest1)
                || WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                    0.000001, 0.000001, FutureRareChest2)
            break
        }
    }
    if !stillVisible {
        AddToLog("Future Rare Chest " path " changed before selection; continuing priorities")
        return false
    }
    for room in foundRooms {
        ; Explicit path metadata covers 1/3-card center and 2/3-card left/right.
        ; Never invent a Center route in a two-card layout.
        if (room.coords.path != path || !DungeonRoomEligible(room, unsafeRooms))
            continue
        if DungeonTryEnterRoom(room, unsafeRooms, "Future Rare Chest " path)
            return true
    }
    AddToLog("Future Rare Chest " path " path unavailable or rejected; continuing priorities")
    return false
}
