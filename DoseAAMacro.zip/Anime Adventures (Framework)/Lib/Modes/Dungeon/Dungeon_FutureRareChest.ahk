#Requires AutoHotkey v2.0

global BossRoomCompleted := false
global SaveChestsForBoss := true


DungeonRoomAreas() {
    ; Keep the original calibrated borders, interiors, and click points.
    return [
        {x1: 200, y1: 340, x2: 222, y2: 437, searchX1: 204, searchY1: 343, searchX2: 290, searchY2: 435, clickX: 250, clickY: 360, path: "Left"},
        {x1: 507, y1: 340, x2: 530, y2: 437, searchX1: 514, searchY1: 343, searchX2: 600, searchY2: 435, clickX: 555, clickY: 360, path: "Right"},
        {x1: 352, y1: 343, x2: 379, y2: 437, searchX1: 358, searchY1: 343, searchX2: 447, searchY2: 435, clickX: 400, clickY: 360, path: "Center"},
        {x1: 275, y1: 340, x2: 300, y2: 437, searchX1: 280, searchY1: 343, searchX2: 370, searchY2: 435, clickX: 322, clickY: 360, path: "Left"},
        {x1: 430, y1: 340, x2: 450, y2: 437, searchX1: 438, searchY1: 343, searchX2: 525, searchY2: 435, clickX: 477, clickY: 360, path: "Right"}
    ]
}

DungeonBorderText(roomType) {
    switch roomType {
        case "Available": return DungeonRoomBorder
        case "Unavailable": return DungeonRoomBorderDark
        case "Cursed": return DungeonRoomBorderCursed
        case "Opening": return DungeonRoomBorderChestOpen
        ; The original Boss border check was disabled. BossRoom2 still identifies
        ; boss contents; do not enable an unverified border template here.
    }
    return ""
}

DungeonValidLayout(rooms) {
    ids := Map()
    for room in rooms {
        if (ids.Has(room.index) || room.index < 1 || room.index > 5)
            return false
        ids[room.index] := true
    }
    if !ids.Count
        return false
    ; A missed/locked neighbor must not invalidate a confirmed card. The room's
    ; own border/icon still must be verified; never mix 2-card and 3-card positions.
    if (ids.Has(4) || ids.Has(5))
        return !ids.Has(1) && !ids.Has(2) && !ids.Has(3)
    return true
}

DungeonMarkerArea(area) {
    ; Original columns were only 13-27 px wide. Allow a small marker-position
    ; margin without changing room interiors, PNG bounds, or click coordinates.
    return {x1: area.x1 - 12, y1: area.y1 - 8,
        x2: area.x2 + 12, y2: area.y2 + 8}
}

DungeonProbeRoom(area, &diagnostic) {
    global WF_LastIssue
    marker := DungeonMarkerArea(area), windowIssue := ""
    for roomType in ["Available", "Unavailable", "Cursed", "Opening"] {
        tolerance := roomType = "Available" ? 0.20 : 0.10
        if WF_FindText(&X, &Y, marker.x1, marker.y1, marker.x2, marker.y2,
            tolerance, tolerance, DungeonBorderText(roomType)) {
            diagnostic := roomType
            return roomType
        }
        if (IsSet(WF_LastIssue) && WF_LastIssue != "")
            windowIssue := WF_LastIssue
    }
    diagnostic := windowIssue = "" ? "marker pattern not found" : windowIssue
    return ""
}

DungeonScanRooms(&diagnostics) {
    rooms := [], diagnostics := ""
    for index, area in DungeonRoomAreas() {
        roomType := DungeonProbeRoom(area, &issue)
        diagnostics .= (diagnostics = "" ? "" : "; ") index ":" issue
        if (roomType != "")
            rooms.Push({index: index, type: roomType, coords: area})
    }
    return rooms
}

DungeonRoomEligible(room, unsafeRooms) {
    return !unsafeRooms.Has(room.index) && (room.type = "Available"
        || room.type = "Cursed" || room.type = "Opening" || room.type = "Boss")
}

DungeonHasCurseExclusions() {
    global enabledCurses
    ; Missing configuration is not evidence that every curse is allowed.
    if (!IsSet(enabledCurses) || !IsObject(enabledCurses))
        return true
    for curse in enabledCurses {
        value := Trim(curse)
        if (value != "" && value != "None")
            return true
    }
    return false
}

LookForDungeonRooms() {
    global SaveChestsForBoss
    SaveChestsForBoss := SaveChestsBox.Value = 1
    AddToLog("Dungeon detector: curse-policy-fix-3")
    AddToLog("Curse exclusions: " (DungeonHasCurseExclusions() ? "active" : "none; all curses allowed"))
    if !WF_PrepareDungeon() {
        AddToLog("Dungeon window check failed: " WF_LastIssue)
        return false
    }
    ; Special screens can change the visible route. Handle them BEFORE scanning.
    CheckDungeonSpecials()
    previousLayout := ""
    Loop 3 {
        foundRooms := DungeonScanRooms(&diagnostics), layout := ""
        for room in foundRooms
            layout .= room.index ":" room.type ";"
        ; Require two consecutive equal border snapshots, not a partial animation.
        if (DungeonValidLayout(foundRooms) && layout = previousLayout) {
            AddToLog("Dungeon layout: " layout)
            return SelectBestRoom(foundRooms.Length, foundRooms)
        }
        previousLayout := layout
        if (A_Index < 3)
            Sleep(120)
    }
    AddToLog("Dungeon scan detail: " diagnostics)
    AddToLog("Dungeon detection stopped: no stable compatible room candidates; no room clicked. See scan detail above for window rejection versus missing marker patterns.")
    return false
}

DungeonRareMatch(room) {
    area := room.coords
    matched := WF_ImageSearch(&X, &Y, area.searchX1, area.searchY1,
        area.searchX2, area.searchY2, RareChestImage, 20)
    if (matched && debugMessages)
        AddToLog("Rare Chest PNG: room " room.index " at calibrated " X "," Y)
    return matched
}

DungeonTextMatch(room, text) {
    area := room.coords
    return text != "" && WF_FindText(&X, &Y, area.searchX1, area.searchY1,
        area.searchX2, area.searchY2, 0.20, 0.20, text)
}

DungeonDetectRooms(foundRooms, unsafeRooms) {
    detections := Map(), votes := Map(), imageOK := true
    for room in foundRooms {
        detections[room.index] := Map()
        votes[room.index] := Map("Rare_Chest", 0)
    }
    ; One bounded sampling pass for ALL priorities, never a retry per priority.
    ; Two of three hits are required, keeping the existing PNG tolerance at 20.
    Loop 3 {
        for room in foundRooms {
            if !DungeonRoomEligible(room, unsafeRooms)
                continue
            tally := votes[room.index]
            if imageOK {
                try {
                    if DungeonRareMatch(room)
                        tally["Rare_Chest"] += 1
                } catch {
                    imageOK := false
                    AddToLog("Rare Chest image search could not complete (asset/window/visibility). Chest classification disabled for this scan; show Roblox unobscured at its normal size and check RareChestImage in Detection Tester.")
                }
            }
            for priority, text in roomTexts {
                if (priority = "Rare_Chest" || text = "")
                    continue
                if !tally.Has(priority)
                    tally[priority] := 0
                if DungeonTextMatch(room, text)
                    tally[priority] += 1
            }
        }
        if (A_Index < 3)
            Sleep(120)
    }
    for room in foundRooms {
        if !DungeonRoomEligible(room, unsafeRooms) {
            AddToLog("Room " room.index " (" room.coords.path ") excluded: " room.type)
            continue
        }
        tally := votes[room.index], types := detections[room.index], description := ""
        for priority, count in tally {
            if (priority = "Rare_Chest") {
                if (imageOK && count >= 2)
                    types[priority] := true
            } else if (priority = "Chest") {
                ; The binary Chest pattern is shared by both rarities. Only label
                ; it normal when ALL rare-image samples missed, never on one miss.
                if (imageOK && tally["Rare_Chest"] = 0 && count >= 2)
                    types[priority] := true
            } else if (count >= 2)
                types[priority] := true
            if types.Has(priority)
                description .= (description = "" ? "" : ", ") priority
        }
        if (tally["Rare_Chest"] = 1)
            AddToLog("Room " room.index " Rare Chest inconclusive (1/3); not classified as normal Chest")
        AddToLog("Room " room.index " (" room.coords.path ", " room.type "): "
            (description = "" ? "no confirmed icon" : description)
            "; Rare Chest hits=" tally["Rare_Chest"] "/3")
    }
    return detections
}

SelectBestRoom(totalrooms, foundRooms) {
    if (totalrooms != foundRooms.Length || !DungeonValidLayout(foundRooms)) {
        AddToLog("Dungeon selection refused: inconsistent room layout")
        return false
    }
    unsafeRooms := Map()
    if PrioritiseFutureRareChests.Value {
        for futurePath in DungeonFutureRarePaths(foundRooms) {
            if ClickFutureRareChestPath(futurePath, foundRooms, unsafeRooms)
                return true
        }
    }
    detections := DungeonDetectRooms(foundRooms, unsafeRooms)
    for priority in routePriorityOrder {
        for room in foundRooms {
            if (!DungeonRoomEligible(room, unsafeRooms)
                || !detections[room.index].Has(priority))
                continue
            if DungeonTryEnterRoom(room, unsafeRooms, "priority " priority, priority)
                return true
        }
        if debugMessages
            AddToLog("No safe confirmed room for priority: " priority)
    }
    ; Do not blindly click the first room or the screen center. That previously
    ; selected unavailable/rejected cursed rooms, and bypassed configured priorities.
    AddToLog("Dungeon selection failed: no safe room matched configured priorities; no fallback click. Check room/icon detection in the Debug panel.")
    return false
}

DungeonTryEnterRoom(room, unsafeRooms, reason, priority := "") {
    if !DungeonRoomEligible(room, unsafeRooms)
        return false
    area := room.coords
    ; Revalidate the border and selected icon immediately before the click.
    currentType := DungeonProbeRoom(area, &issue)
    if (currentType = "" || currentType != room.type) {
        unsafeRooms[room.index] := true
        AddToLog("Room " room.index " recheck failed: " issue)
        return false
    }
    if (priority != "") {
        confirmed := false
        try {
            if (priority = "Rare_Chest")
                confirmed := DungeonRareMatch(room)
            else if (priority = "Chest")
                confirmed := DungeonTextMatch(room, roomTexts["Chest"]) && !DungeonRareMatch(room)
            else if roomTexts.Has(priority)
                confirmed := DungeonTextMatch(room, roomTexts[priority])
        } catch {
            confirmed := false
        }
        if !confirmed {
            unsafeRooms[room.index] := true
            AddToLog("Room " room.index " icon recheck failed; skipping")
            return false
        }
    }
    if !WF_RobloxClick(area.clickX, area.clickY) {
        unsafeRooms[room.index] := true
        AddToLog("Room " room.index " click refused: Roblox not ready")
        return false
    }
    Sleep(500)
    if (room.type = "Cursed" && DungeonHasCurseExclusions()) {
        curseResult := DetectCurse()
        if (curseResult.skip || curseResult.curse = "no curse found") {
            unsafeRooms[room.index] := true
            AddToLog("Room " room.index " rejected: " curseResult.curse)
            ; Preserve the existing card-toggle behavior to dismiss curse details.
            if !WF_RobloxClick(area.clickX, area.clickY) {
                ; No further selection is safe with an unresolved modal.
                for id in [1, 2, 3, 4, 5]
                    unsafeRooms[id] := true
            }
            Sleep(1000)
            return false
        }
    }
    if (room.type = "Cursed" && !DungeonHasCurseExclusions())
        AddToLog("Room " room.index " curse identification not required: no curses are excluded")
    if (room.type = "Boss" || priority = "Boss") {
        global BossRoomCompleted := true
        AddToLog("Boss room detected, setting BossRoomCompleted to true")
    }
    AddToLog("Selecting room " room.index " (" area.path ", " room.type ") because " reason)
    ; This normally hands off via MacroNextStep; do not swallow that exception.
    CheckForEnterButton()
    return true
}

CheckForEnterButton() {
    global BossRoomCompleted
    WaitFor("Dungeon Room Enter")
    if (CheckIfFinalRoom()) {
        BossRoomCompleted := true
        AddToLog("Final room detected, setting BossRoomCompleted to true")
    }
    if (ok := FT(&X, &Y, 31, 241, 801, 543, 0.20, 0.20, Enter)) {
        AddToLog("Found Enter button, joining dungeon")
        ClickUntilGone(0, 0, 31, 241, 801, 543, Enter, 0, -30)
        Sleep(2000)
        ; Start dungeon run
        AddToLog("Starting dungeon run")
        NextStep(RestartStage)
    } else {
        AddToLog("Enter button not found, retrying...")
        ClickUntilGone(0, 0, 588, 107, 780, 249, DungeonRedX)
        Sleep(2500)
        ClickReturnToLobby()
        Sleep(2000)
        return NextStep(CheckLobby)
    }
}

; Function to check for special dungeon elements after replay
CheckDungeonSpecials() {
    AddToLog("Checking for dungeon shop, shrine, open chest")
    
    ; Give time for special elements to appear
    Sleep(2000)
    
    foundShop := false
    foundShrine := false
    foundChest := false

    ; Check the area for shop, shrine, or chest
    Loop 5 {
        ; Check for shop
        if (!foundShop && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shop)) {
            AddToLog("Found Shop")
            Sleep(1000)
            HandleShop()
            Sleep(1000)
            foundShop := true
        }
        Sleep(1000)
        ; Check for shrine
        if (!foundShrine && FT(&X, &Y, 140, 200, 375, 250, 0, 0, Shrine)) {
            if (DenyShrines.Value) {
                AddToLog("Found Shrine, Denying")
                ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
            } else {
                ShrinePriority()
            }
            Sleep(1000)
            foundShrine := true
        }
        Sleep(1000)
        ; Check for Chest Opening
        if (!foundChest && IsChestScreenVisible()) {
            AddToLog("Found Chest Opening")
            HandleChestScreen()
            foundChest := true
        }
        
        ; If all elements are found, exit early
        if (foundShop && foundShrine && foundChest)
            break

        Sleep(1000)  ; Wait and check again
    }
    
    if (!foundShop && !foundShrine && !foundChest)
        AddToLog("No shop, shrine, or chest opening found")
}

HandleShop() {
    AddToLog("Handling shop - buying available items")
    
    ; Give the shop time to fully load
    Sleep(1500)

    if FT(&X, &Y, 184, 118, 623, 523, 0, 0, Fishhook){
        AddToLog("Detected Fishhook buying")
        FixClick(X+150,Y)
    }
    
    Sleep(1500)

    ; Buy item in slot 3 (bottom)
    FixClick(560, 335)
    Sleep(1000)
    
    ; Buy item in slot 2 (middle)
    FixClick(560, 280)
    Sleep(1000)
    
    ; Buy item in slot 1 (top)
    FixClick(560, 225)
    Sleep(1000)
    
    ; Click continue to close the shop
    AddToLog("Closing shop")
    FixClick(485, 410)

    ClickDungeonContinue()
    Sleep(1000)
    return true
}

IsChestScreenVisible() {
    return FT(&X, &Y, 140, 200, 375, 250, 0, 0, ChestRoom) or FT(&X, &Y, 358, 238, 604, 261, 0, 0, ChestRoomLuck)
}

IsCommonChestDone() {
    return FT(&X, &Y, 357, 265, 407, 315, 0.10, 0.10, EmptyCommonChest)
}

IsRareChestDone() {
    return FT(&X, &Y, 353, 324, 408, 379, 0.10, 0.10, EmptyRareChest)
}

HandleChestScreen() {
    global BossRoomCompleted, SaveChestsForBoss
    
    ; Determine if we should open chests now
    shouldOpenChests := BossRoomCompleted || !SaveChestsForBoss
    
    if (shouldOpenChests) {
        AddToLog("Opening all available chests")
        
        ; Process first chest position - keep clicking until exhausted
        commonChestExhausted := false
        
        while (!commonChestExhausted ) {
            ; Click first chest OPEN button
            FixClick(565, 260)
            Sleep(2000)
            
            ; Check if we're still on the chest screen
            if (!IsChestScreenVisible()) {
                ClaimChestReward()
            } else {
                AddToLog("Common chest is now empty, moving on...")
                commonChestExhausted := true
            }
        }

        ; Process rare chest position - keep clicking until exhausted
        rareChestExhausted := false
        
        while (!rareChestExhausted ) {
            ; Click first chest OPEN button
            FixClick(565, 320)
            Sleep(2000)
            
            ; Check if we're still on the chest screen
            if (!IsChestScreenVisible()) {
                ClaimChestReward()
            } else {
                AddToLog("Rare chest is now empty, moving on...")
                rareChestExhausted := true
            }
        }

        AddToLog("All chests opened")

        if (BossRoomCompleted) {
            BossRoomCompleted := false
            ClickDungeonContinue()
        } else {
            ClickDungeonContinue()
            if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    NextStep(StartSelectedMode)
                }
        }

        } else {
            AddToLog("Saving chests for boss room - clicking continue")
            ClickDungeonContinue()
            if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    NextStep(StartSelectedMode)
                }
        }
        Sleep(1000)
        Reconnect()
        return true
}

ClaimChestReward() {
    maxClicks := 40  ; Safety limit
    clicks := 0
    
    while (clicks < maxClicks) {
        ; Click to claim reward
        FixClick(560, 560)
        Sleep(1500)
        
        ; Check if chest screen has returned
        if (IsChestScreenVisible()) {
            return true
        }

        ;Check for return to lobby test
        if (CheckForReturnToLobby()) {
            if (IsChestScreenVisible()) {
                return true
            }
            if (debugMessages) {
                AddToLog("Found return to lobby text, might have max cursed tokens...")
            }
            FixClick(490, 120) ; If you have maxed cursed tokens it will close the interface
            Sleep(1500)
            return true
        }
        
        clicks++
    }
    
    AddToLog("Max clicks reached while claiming rewards")
    return false
} 

; Custom monitor for dungeon ending
MonitorDungeonEnd() {
    global mode, Wins, loss, challengeStartTime, inChallengeMode

    failed := false
    
    StageGuard.Disarm("Stage")   ; [Framework] stage is over - its timeout no longer applies
    StageGuard.Arm("EndScreen", FW_EndScreenTimeoutMs)   ; [Framework]
    Loop {
        Sleep(3000)  
        StageGuard.Check("EndScreen", "dungeon end screen not handled")   ; [Framework]
        FixClick(560, 560)  ; Move click

        ; Check for unit exit UI element
        if (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }
        
        if (ok := FT(&X, &Y, 150, 180, 350, 260, 0, 0, DefeatText) or (ok:=FT(&X, &Y, 319, 176, 492, 279, 0, 0, DefeatText2))) {
            failed := true
        }

        ; Check for next text UI element
        if (ok := FT(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
        }

        ; Check for returning to lobby
        if (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FT(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            if (!inChallengeMode && ScheduleTick()) {
                AddToLog("Schedule: next step, returning to lobby")
                ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                return NextStep(CheckLobby)
            }

            ; Challenge mode logic first
            if (inChallengeMode) {
                AddToLog("Challenge completed - returning to " mode " mode")
               inChallengeMode := false
               challengeStartTime := A_TickCount
               ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
               return NextStep(CheckLobby)
           }

           ; Check if it's time for challenge mode
           if (!inChallengeMode && ChallengeBox.Value) {
               timeElapsed := A_TickCount - challengeStartTime
               if (timeElapsed >= 1800000) {
                   AddToLog("30 minutes passed - switching to Challenge mode")
                   inChallengeMode := true
                   challengeStartTime := A_TickCount
                   ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
                   return NextStep(CheckLobby)
               }
           }

            if (StopAfterDefeat.Value && failed) {
                AddToLog("Dungeon run failed, stopping to save lives...")
                ClickReturnToLobby()
                SendFinalWebhookBeforeExit()
                CheckForLobby()
                Sleep(2000)
                return Reload()
            } else  {
                AddToLog("Dungeon run completed, clicking replay")
            
                ; Click replay button
                ClickReplay()
                ClickUntilGone(0, 0, 0, 0, 1000, 1000, OpenDungeon, 0, -35)
                
                ; After clicking replay, check for shop/shrine/chest
                CheckDungeonSpecials()

                Sleep(2500)
    
                if (CheckForFinishDungeonV2()) {
                    AddToLog("Handled dungeon completion")
                    sleep 2000
                    return NextStep(StartSelectedMode)
                }
                
                ; Start a new dungeon run
                AddToLog("Starting next dungeon")
                return LookForDungeonRooms()
            }
            Reconnect()
        }
    }
}

ClickDungeonContinue() {
    ClickUntilGoneFinishDungeon(0, 0, 380, 385, 615, 490, DungeonContinue, -3, -35)
}

ClickDungeonDeathContinue() {
    ClickUntilGone(0, 0, 308, 391, 494, 437, DungeonDeathContinue, -0, -30)
}

CheckIfFinalRoom() {
    if (ok := FT(&X, &Y, 434, 215, 479, 230, 0, 0, FinalRoom)) {
        return true
    }
    return false
}

DetectCurse() {
    AddToLog("Checking room for curse...")  ; Log the curse check start
    curseCheckTime := A_TickCount
    
    Loop {
        if (A_TickCount - curseCheckTime > 3000) {
            AddToLog("Could not detect curse after 3 seconds; room selection will reject unknown curse")
            return {curse: "no curse found", skip: false}
        }

        curseTexts := Map(
            "Flying", CurseOfFlight,
            "Wind", CurseOfWind,
            "Money", CurseOfMoney,
            "Health", CurseOfHealth,
            "Shielding", CurseOfShielding, ;done
            "Regen", CurseOfRegen,
            "Exploding", CurseofExplosion
        )

        for curseName, curse in curseTexts {
            if (ok := WF_FindText(&X, &Y, 121, 168, 681, 493, 0.05, 0.05, curse)) {
                skip := ShouldSkipCurse(curseName)
                if (skip) {
                    AddToLog("Skipping because of curse: " curseName)
                } else {
                    AddToLog("Detected Curse: " curseName)
                }
                return {curse: curseName, skip: skip}
            }
        }
        Sleep 1000
    }
}

CheckForFinishDungeon() {
    ; Check for the finish dungeon popup
    if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.20, 0.20, FinishDungeon) or (ok := FT(&X, &Y, 310, 395, 495, 440, 0.20, 0.20, EnterDungeon)) or (ok := FT(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath))) {
        
        ; Click the Finish button
        ClickUntilGone(0, 0, 240, 180, 565, 480, DungeonFinish, -3, -35)
        Sleep(1500)

        if (!dungeonDeathBroken) {
            ; Click Dungeon Death if needed
            ClickDungeonDeathContinue()
            Sleep(1500)
        }
        
        ; Click the X in the top right
        ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
        Sleep(1000)
        
        ; Return to lobby
        AddToLog("Returning to lobby after completing dungeon")
        ClickReturnToLobby()
        
        ; Check for lobby and restart
        return NextStep(CheckLobby)
    }
    
    return false
} 

CheckForFinishDungeonV2() {
    ; Check for the finish dungeon popup
    if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.10, 0.10, FinishDungeon) or (ok := FT(&X, &Y, 310, 395, 495, 440, 0.10, 0.10, EnterDungeon)) or (ok := FT(&X, &Y, 370, 225, 545, 300, 0.10, 0.10, DungeonDeath))) {
        AddToLog("Detected dungeon finish Continuing...")
        ; Click the Finish button
        if (ok := FT(&X, &Y, 240, 180, 565, 480, 0.20, 0.20, FinishDungeon)){
            AddToLog("Detected Finish dungeon text clicking....")
            sleep 2000
            FixClick(344,251)
            sleep 1000
            FixClick(322,340)
            sleep 300
            FixClick(666, 145)
            Sleep(2000)
            if (ok := FT(&X, &Y, 126, 56, 675, 230, 0, 0, LobbyText2)) or (ok := FT(&X, &Y, 126, 56, 675, 230, 0, 0, LobbyText)){
                ClickReturnToLobby()
            }
        }

        if (ok := FT(&X, &Y, 370, 225, 545, 300, 0.20, 0.20, DungeonDeath)){
            ClickDungeonDeathContinue()
            ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
            Sleep(1000)
        }

        if (!dungeonDeathBroken) {
            ; Click Dungeon Death if needed
            ClickDungeonDeathContinue()
            Sleep(1500)
            ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
            Sleep(1000)
        }
        return true
    }
}

ClickUntilGoneFinishDungeon(x, y, searchX1, searchY1, searchX2, searchY2, textToFind, offsetX:=0, offsetY:=0, textToFind2:="") {
    waitTime := A_TickCount ; Start timer
    while (ok := FT(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0, 0, textToFind) || textToFind2 && FT(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0, 0, textToFind2)) {
        if ((A_TickCount - waitTime) > 300000) { ; 5-minute limit
            AddToLog("5 minute failsafe triggered, trying to open roblox...")
            return NextStep(RejoinPrivateServer)
        }
        if (offsetX != 0 || offsetY != 0) {
            FixClick(X + offsetX, Y + offsetY)  
        } else {
            FixClick(x, y) 
        }
        Sleep(1000)
        if (ok := FT(&X, &Y, 174, 102, 631, 545, 0, 0, FinishDungeonText)){
            AddToLog("Found Finish Dungeon Clicking....")
            sleep 100
            FixClick(X,Y)
        }
    }
}

ClickFinishDungeonText(){
    ;Check if finish dungeon text is there and close it
    sleep 1000
    if (ok := FT(&X, &Y, 174, 102, 631, 545, 0.10, 0.10, FinishDungeonText)){ 
            AddToLog("Found Finish Dungeon Clicking...." x " " y)
            sleep 100
            FixClick(326,260)
            return true
        }
    return false
}

ShrinePriority() {
    global enabledShrines

    ; Detect which shrine curse is currently on screen
    shrineType := ""

    if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfArmor) {
        shrineType := "Armor"
    }
    else if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfBurst) {
        shrineType := "Burst"
    }
    else if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfChaos) {
        shrineType := "Chaos"
    }
    ;else if FT(&X, &Y, 140, 200, 375, 250, 0, 0, Vampire) {  gotta get the image of vamparism
    ;    shrineType := "Vamparism"
    ;}
    else if FT(&X, &Y, 327, 320, 506, 484, 0.1, 0.1, CurseOfFrenzy) {
        shrineType := "Frenzy"
    }

    ; No shrine detected
    if (shrineType = "") {
        AddToLog("Shrine found, but could not identify the curse. Denying...")
        ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
        return
    }

    ; Check whether this shrine is on the reject list
    if (HasValue(enabledShrines, shrineType)) {
        AddToLog("Found avoided shrine: " shrineType " - Denying")
        ClickUntilGone(0, 0, 334, 395, 672, 483, DenyShrine, 0, -30)
    }
    else {
        AddToLog("Found shrine: " shrineType " - Accepting")
        ClickUntilGone(0, 0, 334, 395, 672, 483, ShrineAccept, 0, -30)
    }
}

DungeonFutureAreas() {
    return [
        {path: "Left", x1: 150, y1: 226, x2: 329, y2: 350},
        {path: "Center", x1: 329, y1: 248, x2: 489, y2: 349},
        {path: "Right", x1: 490, y1: 242, x2: 657, y2: 348}
    ]
}

DungeonFutureRarePaths(foundRooms := 0) {
    votes := Map("Left", 0, "Center", 0, "Right", 0), paths := []
    Loop 3 {
        for area in DungeonFutureAreas() {
            ; A tiny nonzero tolerance becomes zero allowed pixel errors while
            ; preventing FindText's implicit zero/zero -> 5% fallback.
            ; Both patterns use THIS path's rectangle. Search all three paths;
            ; one unavailable path must not hide a second reachable future chest.
            if (WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                0.000001, 0.000001, FutureRareChest1)
                || WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                    0.000001, 0.000001, FutureRareChest2))
                votes[area.path] += 1
        }
        if (A_Index < 3)
            Sleep(120)
    }
    for area in DungeonFutureAreas() {
        if (votes[area.path] < 2)
            continue
        reachable := !IsObject(foundRooms)
        if IsObject(foundRooms) {
            for room in foundRooms {
                if (room.coords.path = area.path && DungeonRoomEligible(room, Map()))
                    reachable := true
            }
        }
        AddToLog("Future Rare Chest " area.path ": " votes[area.path] "/3 hits; "
            (reachable ? "current path present" : "no eligible current path"))
        if reachable
            paths.Push(area.path)
    }
    if !paths.Length
        AddToLog("No confirmed reachable Future Rare Chest path")
    return paths
}

CheckFutureRareChest() {
    paths := DungeonFutureRarePaths()
    return paths.Length ? paths[1] : ""
}

ClickFutureRareChestPath(path, foundRooms, unsafeRooms := 0) {
    if !IsObject(unsafeRooms)
        unsafeRooms := Map()
    stillVisible := false
    for area in DungeonFutureAreas() {
        if (area.path = path) {
            stillVisible := WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                0.000001, 0.000001, FutureRareChest1)
                || WF_FindText(&X, &Y, area.x1, area.y1, area.x2, area.y2,
                    0.000001, 0.000001, FutureRareChest2)
            break
        }
    }
    if !stillVisible {
        AddToLog("Future Rare Chest " path " changed before selection; continuing priorities")
        return false
    }
    for room in foundRooms {
        ; Explicit path metadata covers 1/3-card center and 2/3-card left/right.
        ; Never invent a Center route in a two-card layout.
        if (room.coords.path != path || !DungeonRoomEligible(room, unsafeRooms))
            continue
        if DungeonTryEnterRoom(room, unsafeRooms, "Future Rare Chest " path)
            return true
    }
    AddToLog("Future Rare Chest " path " path unavailable or rejected; continuing priorities")
    return false
}
