#Requires AutoHotkey v2.0

DungeonChestOptions(overrides := 0) {
    options := {pollMs:250, afterOpenMs:2000, departMs:4000, claimMs:60000,
        claimClickMs:1500, emptySamples:3, stalledClicks:4, totalMs:900000, maxOpenClicks:200,
        recoveryIdleMs:120000, recoveryPollMs:1000, maxRecoveries:2, session:0}
    if IsObject(overrides) {
        for name, value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    }
    return options
}

DungeonChestMenuVisible() {
    global WF_LastIssue
    if WF_FindText(&X,&Y,140,200,375,250,0,0,ChestRoom)
        return true
    if (WF_LastIssue != "")
        return false
    return WF_FindText(&X,&Y,358,238,604,261,0,0,ChestRoomLuck)
}

DungeonChestInput(x,y,description) {
    global rblxID
    ; Retain the working legacy CLIENT click positions, but validate and deliver
    ; them via WindowFollow. In particular, do not guess a title-bar offset.
    try {
        hwnd := WinExist(rblxID), point := Buffer(8,0)
        NumPut("Int",x,"Int",y,point)
        if (!hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int"))
            return false
        FT_GetOffset(&dx,&dy)
        if !WF_RobloxClick(NumGet(point,0,"Int")-dx,NumGet(point,4,"Int")-dy)
            return false
        AddToLog("Chest action sent: " description)
        return true
    } catch {
        return false
    }
}

DungeonChestDrainKind(kind,options,deadline) {
    global WF_LastIssue
    emptyStreak := 0, stalled := 0, opens := 0, missingSince := 0
    Loop {
        if (A_TickCount >= deadline) {
            AddToLog(kind " chest opening limit reached; remaining chests are NOT confirmed empty")
            return false
        }
        if !DungeonChestMenuVisible() {
            if (WF_LastIssue != "") {
                AddToLog(kind " chest screen unreadable: " WF_LastIssue)
                return false
            }
            emptyStreak := 0
            if !missingSince
                missingSince := A_TickCount
            if (A_TickCount-missingSince >= options.departMs) {
                AddToLog(kind " chest menu did not return; no Continue sent")
                return false
            }
            Sleep(options.pollMs)
            continue
        }
        missingSince := 0
        empty := kind="Common" ? IsCommonChestDone() : IsRareChestDone()
        if (WF_LastIssue != "") {
            AddToLog(kind " empty-counter search unreadable: " WF_LastIssue)
            return false
        }
        if empty {
            emptyStreak += 1
            if (emptyStreak >= options.emptySamples) {
                AddToLog(kind " chests confirmed empty (" emptyStreak " consecutive checks)")
                return true
            }
            Sleep(options.pollMs)
            continue
        }
        emptyStreak := 0
        if (opens >= options.maxOpenClicks) {
            AddToLog(kind " chest Open click limit reached; empty count not confirmed")
            return false
        }
        if !DungeonChestInput(565,kind="Common" ? 260 : 320,"open " kind " chest") {
            AddToLog(kind " chest Open input refused; no Continue sent")
            return false
        }
        opens += 1
        DungeonChestProgress(options,"Opening",false)
        Sleep(options.afterOpenMs)
        departed := false, absentStreak := 0, observed := A_TickCount
        while (A_TickCount-observed < options.departMs && A_TickCount < deadline) {
            menuVisible := DungeonChestMenuVisible()
            if (WF_LastIssue != "") {
                AddToLog(kind " chest transition unreadable: " WF_LastIssue)
                return false
            }
            absentStreak := menuVisible ? 0 : absentStreak+1
            if (absentStreak >= 2) {
                departed := true
                break
            }
            Sleep(options.pollMs)
        }
        if departed {
            DungeonChestProgress(options,"Reward")
            claimOptions := DungeonChestOptions(options)
            claimOptions.claimMs := Min(claimOptions.claimMs,Max(1,deadline-A_TickCount))
            if !ClaimChestReward(claimOptions) {
                AddToLog(kind " chest reward was not confirmed handled; no Continue sent")
                return false
            }
            stalled := 0
            AddToLog(kind " chest reward menu returned; checking remaining chests")
        } else {
            DungeonChestProgress(options,"Menu",false)
            ; Staying on this menu proves neither purchase nor exhaustion.
            ; Recheck the empty reference before deciding whether to retry.
            empty := kind="Common" ? IsCommonChestDone() : IsRareChestDone()
            if (WF_LastIssue != "")
                return false
            if !empty {
                stalled += 1
                AddToLog(kind " chest Open had no confirmed transition; retry " stalled "/" options.stalledClicks)
                if (stalled >= options.stalledClicks) {
                    AddToLog(kind " chest opening stalled; chests may remain. No Continue sent")
                    return false
                }
            }
        }
    }
}

DungeonChestConfirmAllEmpty(options,deadline) {
    global WF_LastIssue
    streak := 0, started := A_TickCount
    while (A_TickCount-started < options.departMs && A_TickCount < deadline) {
        visible := DungeonChestMenuVisible()
        if (WF_LastIssue != "")
            return false
        commonEmpty := false, rareEmpty := false
        if visible {
            commonEmpty := IsCommonChestDone()
            if (WF_LastIssue != "")
                return false
            rareEmpty := IsRareChestDone()
            if (WF_LastIssue != "")
                return false
        }
        streak := visible && commonEmpty && rareEmpty ? streak+1 : 0
        if (streak >= options.emptySamples)
            return true
        Sleep(options.pollMs)
    }
    return false
}

DungeonOpenAllChests(overrides := 0) {
    global WF_LastIssue
    options := DungeonChestOptions(overrides), deadline := A_TickCount+options.totalMs
    Loop 3 {
        if !DungeonChestDrainKind("Common",options,deadline)
            return false
        if !DungeonChestDrainKind("Rare",options,deadline)
            return false
        if DungeonChestConfirmAllEmpty(options,deadline) {
            AddToLog("All chests confirmed empty: Common and Rare; Continue unlocked")
            return true
        }
        if (WF_LastIssue != "")
            break
        AddToLog("Final chest verification changed or remained incomplete; rechecking both chest types")
    }
    AddToLog("Final chest verification failed: both counters must be confirmed empty together; no Continue sent")
    return false
}

DungeonClaimChestReward(overrides := 0) {
    global WF_LastIssue
    options := DungeonChestOptions(overrides), started := A_TickCount
    lastClick := 0, clicks := 0, returned := 0, overlayCloses := 0
    while (A_TickCount-started < options.claimMs) {
        visible := DungeonChestMenuVisible()
        if (WF_LastIssue != "") {
            AddToLog("Chest reward screen unreadable: " WF_LastIssue)
            return false
        }
        returned := visible ? returned+1 : 0
        if (returned >= 2) {
            DungeonChestProgress(options,"Menu")
            return true
        }
        if visible {
            Sleep(options.pollMs)
            continue
        }
        if (!lastClick || A_TickCount-lastClick >= options.claimClickMs) {
            if (clicks >= 40) {
                AddToLog("Chest reward claim click limit reached; chest menu not confirmed")
                return false
            }
            if CheckForReturnToLobby() {
                if (overlayCloses >= 2) {
                    AddToLog("Chest reward overlay did not clear; chest menu not confirmed")
                    return false
                }
                if !DungeonChestInput(490,120,"dismiss possible token-limit overlay")
                    return false
                overlayCloses += 1
            } else if !DungeonChestInput(560,560,"claim chest reward")
                return false
            clicks += 1, lastClick := A_TickCount
        }
        Sleep(options.pollMs)
    }
    AddToLog("Chest reward claim timed out; chest menu not confirmed. No Continue sent")
    return false
}


DungeonChestProgress(options,phase,confirmed := true) {
    if !IsObject(options.session)
        return
    state := options.session
    if (confirmed && state.phase!=phase)
        state.lastProgress := A_TickCount
    state.phase := phase
}

; Keep the macro active after a transient claim/menu failure. The supervisor
; rechecks this chest session only; it never changes rooms or restarts the run.
DungeonOpenAllChestsWithRecovery(overrides := 0) {
    options := DungeonChestOptions(overrides)
    options.session := {phase:"Menu",lastProgress:A_TickCount,lastRecovery:0,recoveries:0}
    deadline := A_TickCount+options.totalMs
    while (A_TickCount<deadline) {
        pass := DungeonChestOptions(options)
        pass.totalMs := Max(1,deadline-A_TickCount)
        try {
            if DungeonOpenAllChests(pass)
                return true
        } catch as err {
            AddToLog("Chest opening check failed at line " err.Line "; keeping chest verification locked")
        }
        if (options.maxRecoveries<=0)
            return false
        AddToLog("Chest opening has not completed; waiting for screen recovery (no Continue or lobby return)")
        if !DungeonChestResumeAfterStall(options,deadline)
            return false
    }
    AddToLog("Chest recovery total deadline reached; both counters unverified. Macro stopped without Continue")
    return false
}

DungeonChestResumeAfterStall(options,deadline) {
    global WF_LastIssue
    state := options.session, returned := 0
    while (A_TickCount<deadline) {
        ; A reward/menu transition can finish late. Observe it without sending
        ; more input, and resume immediately once the menu returns twice.
        if (state.phase="Reward") {
            visible := DungeonChestMenuVisible()
            returned := (WF_LastIssue="" && visible) ? returned+1 : 0
            if (returned>=2) {
                DungeonChestProgress(options,"Menu")
                AddToLog("Chest menu returned after the stalled reward; resuming both chest checks")
                return true
            }
        }
        if (state.recoveries>=options.maxRecoveries) {
            AddToLog("Chest recovery attempts exhausted; chests remain unverified. Macro stopped without Continue")
            return false
        }
        quietSince := Max(state.lastProgress,state.lastRecovery)
        if (A_TickCount-quietSince>=options.recoveryIdleMs) {
            state.recoveries += 1,state.lastRecovery := A_TickCount
            AddToLog("Chest inactivity recovery " state.recoveries "/" options.maxRecoveries ": no confirmed progress for "
                (A_TickCount-quietSince)//1000 "s; rescanning current screen")
            if WF_PrepareDungeon() {
                menu := DungeonChestMenuVisible()
                if (WF_LastIssue="" && menu) {
                    Sleep(options.pollMs)
                    if (DungeonChestMenuVisible() && WF_LastIssue="") {
                        DungeonChestProgress(options,"Menu")
                        AddToLog("Chest recovery: menu confirmed; restarting Common/Rare checks")
                        return true
                    }
                }
                ; Resend the existing reward-claim routine only when this
                ; session had already observed an Open -> reward transition.
                ; A fresh entrance or lobby marker forbids reward input.
                if (WF_LastIssue="" && state.phase="Reward") {
                    entrance := WF_FindText(&X,&Y,250,340,550,495,0.20,0.20,EnterDungeon)
                    if (WF_LastIssue!="") {
                        AddToLog("Chest recovery: entrance recheck unreadable; no input")
                    } else if entrance {
                        AddToLog("Chest recovery: unexpected entrance before empty verification; stopped without entry/lobby clicks")
                        return false
                    } else {
                        lobby := WF_FindText(&X,&Y,746,514,789,530,0.000001,0.000001,AreaText)
                        if (WF_LastIssue="" && !lobby) {
                            claim := DungeonChestOptions(options)
                            claim.claimMs := Min(claim.claimMs,Max(1,deadline-A_TickCount))
                            AddToLog("Chest recovery: resuming pending reward claim; chest menu must return before opening continues")
                            if ClaimChestReward(claim)
                                return true
                        } else
                            AddToLog("Chest recovery: lobby/unreadable screen while reward was pending; no claim input")
                    }
                } else
                    AddToLog("Chest recovery: chest menu not confirmed; waiting without guessed input")
            } else
                AddToLog("Chest recovery: Roblox window unavailable; waiting without input")
        }
        Sleep(Max(1,Min(options.recoveryPollMs,deadline-A_TickCount)))
    }
    AddToLog("Chest recovery deadline reached; no Continue or lobby return sent")
    return false
}
