#Requires AutoHotkey v2.0

DungeonChestOptions(overrides := 0) {
    options := {pollMs:250, afterOpenMs:2000, departMs:4000, claimMs:60000,
        claimClickMs:1500, emptySamples:3, stalledClicks:4, totalMs:900000, maxOpenClicks:200}
    if IsObject(overrides) {
        for name, value in overrides.OwnProps()
            if options.HasOwnProp(name)
                options.%name% := value
    }
    return options
}

DungeonChestMenuVisible() {
    global WF_LastIssue
    if WF_FindText(&X,&Y,140,200,375,250,0,0,ChestRoom)
        return true
    if (WF_LastIssue != "")
        return false
    return WF_FindText(&X,&Y,358,238,604,261,0,0,ChestRoomLuck)
}

DungeonChestInput(x,y,description) {
    global rblxID
    ; Retain the working legacy CLIENT click positions, but validate and deliver
    ; them via WindowFollow. In particular, do not guess a title-bar offset.
    try {
        hwnd := WinExist(rblxID), point := Buffer(8,0)
        NumPut("Int",x,"Int",y,point)
        if (!hwnd || !DllCall("user32\ClientToScreen","Ptr",hwnd,"Ptr",point,"Int"))
            return false
        FT_GetOffset(&dx,&dy)
        if !WF_RobloxClick(NumGet(point,0,"Int")-dx,NumGet(point,4,"Int")-dy)
            return false
        AddToLog("Chest action sent: " description)
        return true
    } catch {
        return false
    }
}

DungeonChestDrainKind(kind,options,deadline) {
    global WF_LastIssue
    emptyStreak := 0, stalled := 0, opens := 0, missingSince := 0
    Loop {
        if (A_TickCount >= deadline) {
            AddToLog(kind " chest opening limit reached; remaining chests are NOT confirmed empty")
            return false
        }
        if !DungeonChestMenuVisible() {
            if (WF_LastIssue != "") {
                AddToLog(kind " chest screen unreadable: " WF_LastIssue)
                return false
            }
            emptyStreak := 0
            if !missingSince
                missingSince := A_TickCount
            if (A_TickCount-missingSince >= options.departMs) {
                AddToLog(kind " chest menu did not return; no Continue sent")
                return false
            }
            Sleep(options.pollMs)
            continue
        }
        missingSince := 0
        empty := kind="Common" ? IsCommonChestDone() : IsRareChestDone()
        if (WF_LastIssue != "") {
            AddToLog(kind " empty-counter search unreadable: " WF_LastIssue)
            return false
        }
        if empty {
            emptyStreak += 1
            if (emptyStreak >= options.emptySamples) {
                AddToLog(kind " chests confirmed empty (" emptyStreak " consecutive checks)")
                return true
            }
            Sleep(options.pollMs)
            continue
        }
        emptyStreak := 0
        if (opens >= options.maxOpenClicks) {
            AddToLog(kind " chest Open click limit reached; empty count not confirmed")
            return false
        }
        if !DungeonChestInput(565,kind="Common" ? 260 : 320,"open " kind " chest") {
            AddToLog(kind " chest Open input refused; no Continue sent")
            return false
        }
        opens += 1
        Sleep(options.afterOpenMs)
        departed := false, absentStreak := 0, observed := A_TickCount
        while (A_TickCount-observed < options.departMs && A_TickCount < deadline) {
            menuVisible := DungeonChestMenuVisible()
            if (WF_LastIssue != "") {
                AddToLog(kind " chest transition unreadable: " WF_LastIssue)
                return false
            }
            absentStreak := menuVisible ? 0 : absentStreak+1
            if (absentStreak >= 2) {
                departed := true
                break
            }
            Sleep(options.pollMs)
        }
        if departed {
            claimOptions := DungeonChestOptions(options)
            claimOptions.claimMs := Min(claimOptions.claimMs,Max(1,deadline-A_TickCount))
            if !ClaimChestReward(claimOptions) {
                AddToLog(kind " chest reward was not confirmed handled; no Continue sent")
                return false
            }
            stalled := 0
            AddToLog(kind " chest reward menu returned; checking remaining chests")
        } else {
            ; Staying on this menu proves neither purchase nor exhaustion.
            ; Recheck the empty reference before deciding whether to retry.
            empty := kind="Common" ? IsCommonChestDone() : IsRareChestDone()
            if (WF_LastIssue != "")
                return false
            if !empty {
                stalled += 1
                AddToLog(kind " chest Open had no confirmed transition; retry " stalled "/" options.stalledClicks)
                if (stalled >= options.stalledClicks) {
                    AddToLog(kind " chest opening stalled; chests may remain. No Continue sent")
                    return false
                }
            }
        }
    }
}

DungeonChestConfirmAllEmpty(options,deadline) {
    global WF_LastIssue
    streak := 0, started := A_TickCount
    while (A_TickCount-started < options.departMs && A_TickCount < deadline) {
        visible := DungeonChestMenuVisible()
        if (WF_LastIssue != "")
            return false
        commonEmpty := false, rareEmpty := false
        if visible {
            commonEmpty := IsCommonChestDone()
            if (WF_LastIssue != "")
                return false
            rareEmpty := IsRareChestDone()
            if (WF_LastIssue != "")
                return false
        }
        streak := visible && commonEmpty && rareEmpty ? streak+1 : 0
        if (streak >= options.emptySamples)
            return true
        Sleep(options.pollMs)
    }
    return false
}

DungeonOpenAllChests(overrides := 0) {
    global WF_LastIssue
    options := DungeonChestOptions(overrides), deadline := A_TickCount+options.totalMs
    Loop 3 {
        if !DungeonChestDrainKind("Common",options,deadline)
            return false
        if !DungeonChestDrainKind("Rare",options,deadline)
            return false
        if DungeonChestConfirmAllEmpty(options,deadline) {
            AddToLog("All chests confirmed empty: Common and Rare; Continue unlocked")
            return true
        }
        if (WF_LastIssue != "")
            break
        AddToLog("Final chest verification changed or remained incomplete; rechecking both chest types")
    }
    AddToLog("Final chest verification failed: both counters must be confirmed empty together; no Continue sent")
    return false
}

DungeonClaimChestReward(overrides := 0) {
    global WF_LastIssue
    options := DungeonChestOptions(overrides), started := A_TickCount
    lastClick := 0, clicks := 0, returned := 0, overlayCloses := 0
    while (A_TickCount-started < options.claimMs) {
        visible := DungeonChestMenuVisible()
        if (WF_LastIssue != "") {
            AddToLog("Chest reward screen unreadable: " WF_LastIssue)
            return false
        }
        returned := visible ? returned+1 : 0
        if (returned >= 2)
            return true
        if visible {
            Sleep(options.pollMs)
            continue
        }
        if (!lastClick || A_TickCount-lastClick >= options.claimClickMs) {
            if (clicks >= 40) {
                AddToLog("Chest reward claim click limit reached; chest menu not confirmed")
                return false
            }
            if CheckForReturnToLobby() {
                if (overlayCloses >= 2) {
                    AddToLog("Chest reward overlay did not clear; chest menu not confirmed")
                    return false
                }
                if !DungeonChestInput(490,120,"dismiss possible token-limit overlay")
                    return false
                overlayCloses += 1
            } else if !DungeonChestInput(560,560,"claim chest reward")
                return false
            clicks += 1, lastClick := A_TickCount
        }
        Sleep(options.pollMs)
    }
    AddToLog("Chest reward claim timed out; chest menu not confirmed. No Continue sent")
    return false
}
