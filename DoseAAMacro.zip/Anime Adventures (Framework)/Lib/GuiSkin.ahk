#Requires AutoHotkey v2.0

; Decorative controls are confined to the macro panel/footer. The Roblox
; transparency rectangle and all game coordinates remain unchanged.
DoseBuildBackdrop(g, imagePath := "") {
    if (imagePath = "")
        imagePath := DoseThemeArtworkPath()
    if !FileExist(imagePath)
        return false
    try {
        palette := DoseThemePalette(AA_ThemeName())
        return DoseBuildArtwork(g,imagePath,804,31,558,666,48,palette.background,palette.focusX)
    } catch {
        return false
    }
}

; Render original artwork with a proportional cover crop and focal point. Bundled image bytes stay
; unchanged. The GUI owns the returned Picture bitmap and frees it on destroy.
DoseBuildArtwork(g,path,x,y,w,h,opacity := 255,background := "0B0C11",focusX := 0.5) {
    bitmap := DoseArtworkBitmap(path,w,h,opacity,background,focusX)
    if !bitmap
        return false
    try {
        picture := g.Add("Picture",Format("x{} y{} w{} h{}",x,y,w,h),"HBITMAP:" bitmap)
        bitmap := 0 ; ownership transferred to the Picture control
        return picture
    } finally {
        if bitmap
            DllCall("gdi32\DeleteObject","Ptr",bitmap)
    }
}

DoseArtworkBitmap(path,w,h,opacity,background,focusX := 0.5) {
    source := 0, result := 0, cover := 0, brush := 0
    srcDC := 0, dstDC := 0, cropDC := 0, oldSrc := 0, oldDst := 0, oldCrop := 0
    try {
        source := LoadPicture(path,"GDI+")
        if !source
            return 0
        info := Buffer(A_PtrSize=8 ? 32 : 24,0)
        if !DllCall("gdi32\GetObjectW","Ptr",source,"Int",info.Size,"Ptr",info)
            return 0
        sw := NumGet(info,4,"Int"), sh := Abs(NumGet(info,8,"Int"))
        if (sw<=0 || sh<=0)
            return 0
        srcDC := DllCall("gdi32\CreateCompatibleDC","Ptr",0,"Ptr")
        dstDC := DllCall("gdi32\CreateCompatibleDC","Ptr",0,"Ptr")
        cropDC := DllCall("gdi32\CreateCompatibleDC","Ptr",0,"Ptr")
        dib := Buffer(40,0)
        NumPut("UInt",40,"Int",w,"Int",-h,"UShort",1,"UShort",32,dib)
        result := DllCall("gdi32\CreateDIBSection","Ptr",dstDC,"Ptr",dib,"UInt",0,"Ptr*",&pixels := 0,"Ptr",0,"UInt",0,"Ptr")
        cover := DllCall("gdi32\CreateDIBSection","Ptr",cropDC,"Ptr",dib,"UInt",0,"Ptr*",&cropPixels := 0,"Ptr",0,"UInt",0,"Ptr")
        if !(srcDC && dstDC && cropDC && result && cover)
            return 0
        oldSrc := DllCall("gdi32\SelectObject","Ptr",srcDC,"Ptr",source,"Ptr")
        oldDst := DllCall("gdi32\SelectObject","Ptr",dstDC,"Ptr",result,"Ptr")
        oldCrop := DllCall("gdi32\SelectObject","Ptr",cropDC,"Ptr",cover,"Ptr")
        ratio := Max(w/sw,h/sh), cw := Round(w/ratio), ch := Round(h/ratio)
        DllCall("gdi32\SetStretchBltMode","Ptr",cropDC,"Int",4)
        DllCall("gdi32\SetBrushOrgEx","Ptr",cropDC,"Int",0,"Int",0,"Ptr",0)
        if !DllCall("gdi32\StretchBlt","Ptr",cropDC,"Int",0,"Int",0,"Int",w,"Int",h,
            "Ptr",srcDC,"Int",Round((sw-cw)*Min(1,Max(0,focusX))),"Int",(sh-ch)//2,"Int",cw,"Int",ch,"UInt",0x00CC0020)
            return 0
        color := Integer("0x" background)
        rgb := ((color & 255)<<16) | (color & 0xFF00) | ((color>>16) & 255)
        brush := DllCall("gdi32\CreateSolidBrush","UInt",rgb,"Ptr")
        rect := Buffer(16,0)
        NumPut("Int",w,"Int",h,rect,8)
        DllCall("user32\FillRect","Ptr",dstDC,"Ptr",rect,"Ptr",brush)
        if !DllCall("msimg32\AlphaBlend","Ptr",dstDC,"Int",0,"Int",0,"Int",w,"Int",h,
            "Ptr",cropDC,"Int",0,"Int",0,"Int",w,"Int",h,"UInt",opacity<<16)
            return 0
        output := result
        result := 0
        return output
    } catch {
        return 0
    } finally {
        if oldSrc
            DllCall("gdi32\SelectObject","Ptr",srcDC,"Ptr",oldSrc)
        if oldDst
            DllCall("gdi32\SelectObject","Ptr",dstDC,"Ptr",oldDst)
        if oldCrop
            DllCall("gdi32\SelectObject","Ptr",cropDC,"Ptr",oldCrop)
        for dc in [srcDC,dstDC,cropDC]
            if dc
                DllCall("gdi32\DeleteDC","Ptr",dc)
        for objectHandle in [source,result,cover,brush]
            if objectHandle
                DllCall("gdi32\DeleteObject","Ptr",objectHandle)
    }
}

DoseBuildBrandBadge(g, releaseVersion) {
    global uiTheme
    g.Add("Text","x14 y644 w78 h2 Background" uiTheme[3],"")
    if (AA_ThemeName() = "Tokyo Ghoul")
        g.SetFont("s14 Norm c" uiTheme[7],DoseHeadingFont())
    else
        g.SetFont("s13 Bold c" uiTheme[7],"Segoe UI")
    g.Add("Text","x15 y650 w80 h24 BackgroundTrans","DOSE")
    g.SetFont("s8 c" uiTheme[1],"Segoe UI")
    g.Add("Text","x16 y675 w78 h15 BackgroundTrans","AA  /  v" releaseVersion)
    g.SetFont("s9 c" uiTheme[1],"Segoe UI")
}

; Load a bundled, redistributable icon-capable font for this process only.
; No system font installation or administrator access is needed.
DoseIconFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\DejaVuSans.ttf"
    family := "Segoe UI Symbol"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "DejaVu Sans"
    }
    return family
}

; Only decorative palette/assets/type change; game transparency and coordinates
; are intentionally outside this data.
DoseThemePalette(name) {
    if (name = "Tokyo Ghoul")
        return {header:"F5EFF1",background:"0B0C11",accent:"C91E46",card:"16141B",
            input:"100D14",highlight:"FF6B83",button:"2B1621",off:"3A3039",
            on:"C91E46",divider:"3C2330",art:"DoseKaneki.jpg",focusX:0.5}
    return {header:"EFF9F6",background:"0B1519",accent:"66CDBB",card:"13242A",
        input:"0C191E",highlight:"B5ECE0",button:"1E343B",off:"34474C",
        on:"66CDBB",divider:"2B464D",art:"DoseJuuzou.png",focusX:1}
}

DoseThemeArtworkPath(name := "", root := "") {
    if (name = "")
        name := AA_ThemeName()
    if (root = "")
        root := A_ScriptDir "\Images\UI"
    return root "\" DoseThemePalette(name).art
}

; A process-private, OFL licensed display face. Body/input fonts remain readable.
DoseHeadingFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\NewRocker-Regular.ttf"
    family := "Segoe UI"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "New Rocker"
    }
    return family
}

DoseStyleHeadings(title,activity) {
    if (AA_ThemeName() != "Tokyo Ghoul")
        return
    face := DoseHeadingFont()
    title.Text := StrReplace(title.Text,"◈ ","")
    title.SetFont("s14 Norm",face)
    activity.Text := "ACTIVITY"
    activity.SetFont("s14 Norm cFF6B83",face)
}

DoseBuildThemeSignature(g,imagePath := "") {
    global uiTheme, AA_CardColor
    name := AA_ThemeName()
    g.Add("Text","x1208 y538 w148 h156 Background" AA_CardColor)
    if (imagePath="")
        imagePath := DoseThemeArtworkPath(name)
    try DoseBuildArtwork(g,imagePath,1212,542,140,130,255,"0B0C11",DoseThemePalette(name).focusX)
    for rect in [[1208,538,24,2],[1208,538,2,14],[1332,692,24,2],[1354,680,2,14]]
        g.Add("Text",Format("x{} y{} w{} h{} Background{}",rect[1],rect[2],rect[3],rect[4],uiTheme[3]))
    label := g.Add("Text","x1230 y677 w118 h16 Right Background" AA_CardColor,StrUpper(name))
    if (name = "Tokyo Ghoul") {
        label.SetFont("s8 Norm cFF6B83",DoseHeadingFont())
        eye := g.Add("Text","x1214 y677 w14 h16 Center Background" AA_CardColor,"◉")
        eye.SetFont("s8 Norm cFF254A",DoseIconFont())
    } else
        label.SetFont("s8 Bold c" uiTheme[7],"Segoe UI")
    return label
}
