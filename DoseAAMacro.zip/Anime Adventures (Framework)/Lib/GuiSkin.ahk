#Requires AutoHotkey v2.0

; Decorative controls are confined to the macro panel/footer. The Roblox
; transparency rectangle and all game coordinates remain unchanged.
DoseBuildBackdrop(g, imagePath := "") {
    if (imagePath = "")
        imagePath := A_ScriptDir "\Images\UI\DoseArcane.png"
    if !FileExist(imagePath)
        return false
    try {
        return g.Add("Picture","x804 y31 w558 h666",imagePath)
    } catch {
        return false
    }
}

DoseBuildBrandBadge(g, releaseVersion) {
    global uiTheme
    g.Add("Text","x14 y644 w78 h2 Background" uiTheme[3],"")
    g.SetFont("s13 Bold c" uiTheme[7],"Segoe UI")
    g.Add("Text","x15 y650 w80 h22 BackgroundTrans","DOSE")
    g.SetFont("s8 c" uiTheme[1],"Segoe UI")
    g.Add("Text","x16 y675 w78 h15 BackgroundTrans","AA  /  v" releaseVersion)
    g.SetFont("s9 c" uiTheme[1],"Segoe UI")
}

; Load a bundled, redistributable icon-capable font for this process only.
; No system font installation or administrator access is needed.
DoseIconFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\DejaVuSans.ttf"
    family := "Segoe UI Symbol"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "DejaVu Sans"
    }
    return family
}
