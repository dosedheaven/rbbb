#Requires AutoHotkey v2.0

; Decorative controls are confined to the macro panel/footer. The Roblox
; transparency rectangle and all game coordinates remain unchanged.
DoseBuildBackdrop(g, imagePath := "") {
    if (imagePath = "")
        imagePath := DoseThemeArtworkPath()
    if !FileExist(imagePath)
        return false
    try {
        return g.Add("Picture","x804 y31 w558 h666",imagePath)
    } catch {
        return false
    }
}

DoseBuildBrandBadge(g, releaseVersion) {
    global uiTheme
    g.Add("Text","x14 y644 w78 h2 Background" uiTheme[3],"")
    if (AA_ThemeName() = "Tokyo Ghoul")
        g.SetFont("s14 Norm c" uiTheme[7],DoseHeadingFont())
    else
        g.SetFont("s13 Bold c" uiTheme[7],"Segoe UI")
    g.Add("Text","x15 y650 w80 h22 BackgroundTrans","DOSE")
    g.SetFont("s8 c" uiTheme[1],"Segoe UI")
    g.Add("Text","x16 y675 w78 h15 BackgroundTrans","AA  /  v" releaseVersion)
    g.SetFont("s9 c" uiTheme[1],"Segoe UI")
}

; Load a bundled, redistributable icon-capable font for this process only.
; No system font installation or administrator access is needed.
DoseIconFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\DejaVuSans.ttf"
    family := "Segoe UI Symbol"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "DejaVu Sans"
    }
    return family
}

; Only decorative palette/assets/type change; game transparency and coordinates
; are intentionally outside this data.
DoseThemePalette(name) {
    if (name = "Tokyo Ghoul")
        return {header:"F5EFF1",background:"0B0C11",accent:"C91E46",card:"16141B",
            input:"100D14",highlight:"FF6B83",button:"2B1621",off:"3A3039",
            on:"C91E46",divider:"3C2330",art:"DoseTokyoGhoul.png"}
    return {header:"F1F5FF",background:"0D1220",accent:"8B7CF8",card:"171D30",
        input:"10192B",highlight:"77E5F4",button:"232C46",off:"344058",
        on:"2DD4BF",divider:"2A3553",art:"DoseArcane.png"}
}

DoseThemeArtworkPath(name := "", root := "") {
    if (name = "")
        name := AA_ThemeName()
    if (root = "")
        root := A_ScriptDir "\Images\UI"
    return root "\" DoseThemePalette(name).art
}

; A process-private, OFL licensed display face. Body/input fonts remain readable.
DoseHeadingFont(fontPath := "") {
    static family := ""
    if (family != "")
        return family
    if (fontPath = "")
        fontPath := A_ScriptDir "\Images\UI\Fonts\NewRocker-Regular.ttf"
    family := "Segoe UI"
    try {
        if (FileExist(fontPath) && DllCall("gdi32\AddFontResourceExW","Str",fontPath,"UInt",0x10,"Ptr",0,"Int") > 0)
            family := "New Rocker"
    }
    return family
}

DoseStyleHeadings(title,activity) {
    if (AA_ThemeName() != "Tokyo Ghoul")
        return
    face := DoseHeadingFont()
    title.Text := StrReplace(title.Text,"◈ ","")
    title.SetFont("s14 Norm",face)
    activity.Text := "ACTIVITY"
    activity.SetFont("s14 Norm cFF6B83",face)
}

DoseBuildThemeSignature(g) {
    name := AA_ThemeName()
    label := g.Add("Text","x1140 y35 w158 h16 Right BackgroundTrans",StrUpper(name))
    if (name = "Tokyo Ghoul") {
        label.SetFont("s10 Norm cFF6B83",DoseHeadingFont())
        eye := g.Add("Text","x1117 y35 w18 h16 Center BackgroundTrans","◉")
        eye.SetFont("s10 Norm cFF254A",DoseIconFont())
    } else
        label.SetFont("s8 Bold c77E5F4","Segoe UI")
    return label
}
