#Requires AutoHotkey v2.0

; ============================================================================
;  StageEvents.ahk  -  In-stage prompts: auto ability, Mahoraga, card selection.
;  [Modularized] functions moved here unchanged from Lib\Functions.ahk, Lib\GameMango.ahk.
;  Loaded from Main.ahk. Contains function definitions only (no start-up code).
; ============================================================================

    
    


CheckAbility() {
    global AutoAbilityBox  ; Reference your checkbox
    ; Only check ability if checkbox is checked
    if (AutoAbilityBox.Value) {
        if (ok := FT(&X, &Y, 342, 253, 401, 281, 0, 0, AutoOff)) {
            FixClick(373, 237)  ; Turn ability on
            AddToLog("Auto Ability Enabled")
        }
    }
}


CheckForMahoraga() {
    global setMahoragoStyle
    if (!setMahoragoStyle) {
        if (ok := FT(&X, &Y, 279, 517, 308, 541, 0.10, 0.10, MaharagaDefend)) {
            AddToLog("Found Mahoraga")
            ChangeMahoragaMode()
            return true
        }
    }
}


CheckForMahoragaAdaptation() {
    global adaptations, FirstAdaptation, SecondAdaptation, FinalAdaptation

    if (ok := FT(&X, &Y, 198, 394, 391, 419, 0, 0, Adaptation)) {
        adaptations += 1
        AddToLog("Mahoraga Upgrade Available")
        switch (adaptations) {
            case 1:
                ChoseMahoragaAdaptation(FirstAdaptation.Value)
            case 2:
                ChoseMahoragaAdaptation(SecondAdaptation.Value)
            case 3:
                adaptations := 0
                ChoseMahoragaAdaptation(FinalAdaptation.Value)
        }
        return true
    }
}


ChoseMahoragaAdaptation(adaption := 1) {
    switch (adaption) {
        case 1:
            FixClick(230, 410)
            AddToLog("Adapting to become hybrid...")
            return true
        case 2:
            FixClick(290, 408)
            AddToLog("Adapting to enable knockback...")
            return true
        default:
            FixClick(350, 408)
            AddToLog("Adapting to gain 100% crit with slash...")
            return true
    }
}


ChangeMahoragaMode() {
    global setMahoragoStyle

    if (!setMahoragoStyle) {
        if (MahoragoMode.Value = 3) {
            FixClick(292, 496)
            setMahoragoStyle := true
        } else if (MahoragoMode.Value = 2) {
            FixClick(292, 496)
            Sleep(1000)
            FixClick(292, 496)
            setMahoragoStyle := true
        }

    }

}


CheckForCardSelection() {
    if CardPick_Active() {      
        if CardPick_ScreenVisible()
            CardPick_Pick()
            sleep 1000
        return
    }
}
