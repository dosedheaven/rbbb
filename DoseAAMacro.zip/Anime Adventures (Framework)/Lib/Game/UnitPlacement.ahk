#Requires AutoHotkey v2.0

; ============================================================================
;  UnitPlacement.ahk  -  Unit placement during a stage.
;  [Modularized] functions moved here unchanged from Lib\GameMango.ahk.
;  Loaded from Main.ahk. Contains function definitions only (no start-up code).
; ============================================================================


PlacingUnits() {
    CheckForCardSelection()
    global successfulCoordinates, maxedCoordinates, inChallengeMode
    successfulCoordinates := []
    maxedCoordinates := []
    placedCounts := Map()  

    anyEnabled := false
    for slotNum in [1, 2, 3, 4, 5, 6] {
        enabled := inChallengeMode && ChallengeBox.Value ? "challengeEnabled" slotNum : GetNameForMode() "enabled" slotNum
        enabled := %enabled%
        enabled := enabled.Value
        if (enabled) {
            anyEnabled := true
            break
        }
    }

    if (!anyEnabled) {
        AddToLog("No units enabled - skipping to monitoring")
        return NextStep(MonitorStage)
    }

    if CheckForXp() || CheckForReturnToLobby() || CheckForNextText() {
        AddToLog("Stage ended during placements, proceeding to results")
        return NextStep(MonitorStage)
    }

    if CheckForLobbyText() {
        return NextStep(CheckLobby)
    }

    Reconnect()

    ; [Profile log] say which unit setup is used (a Challenge run uses the Challenge profile, not the one shown in the cards)
    AddToLog("Using placement profile: " (inChallengeMode && ChallengeBox.Value ? "Challenge (Auto Challenge run)" : PlacementSelection.Text))

    placementPoints := CP_WithCustomSpots(PlacementPatternDropdown.Text = "3x3 Grid" ? GenerateMoreGridPoints(3) : PlacementPatternDropdown.Text = "Circle" ? GenerateCirclePoints() : PlacementPatternDropdown.Text = "Grid" ? GenerateGridPoints() : PlacementPatternDropdown.Text = "Spiral(WIP)" ? GenerateSpiralGridPoints() : PlacementPatternDropdown.Text = "Up and Down" ? GenerateUpandDownPoints() : GenerateRandomPoints())   ; [Custom placement] your spots first when ON
    
    ; Go through each slot
    for slotNum in [1, 2, 3, 4, 5, 6] {
        enabled := inChallengeMode && ChallengeBox.Value ? "challengeEnabled" slotNum : GetNameForMode() "enabled" slotNum
        enabled := %enabled%
        enabled := enabled.Value
        
        ; Get number of placements wanted for this slot
        placements := inChallengeMode && ChallengeBox.Value ? "challengeplacement" slotNum : GetNameForMode() "placement" slotNum
        placements := %placements%
        placements := Integer(placements.Text)
        
        ; Initialize count if not exists
        if !placedCounts.Has(slotNum)
            placedCounts[slotNum] := 0
        
        ; If enabled, place all units for this slot
        if (enabled && placements > 0) {
            AddToLog("Placing Unit " slotNum " (0/" placements ")")
            CheckForCardSelection()
            ; Place all units for this slot
            while (placedCounts[slotNum] < placements) {
                for point in placementPoints {
                    ; Skip if this coordinate was already used successfully
                    alreadyUsed := false
                    for coord in successfulCoordinates {
                        if (coord.x = point.x && coord.y = point.y) {
                            alreadyUsed := true
                            break
                        }
                    }
                    for coord in maxedCoordinates { ; NEW CHECK
                        if (coord.x = point.x && coord.y = point.y) {
                            alreadyUsed := true
                            break
                        }
                    }
                    if (alreadyUsed)
                        continue
                    if PlaceUnit(point.x, point.y, slotNum) {
                        CheckForCardSelection()
                        CheckForMahoraga()
                        CheckForMahoragaAdaptation()
                        successfulCoordinates.Push({x: point.x, y: point.y, slot: slotNum})
                        placedCounts[slotNum] += 1
                        AddToLog("Placed Unit " slotNum " (" placedCounts[slotNum] "/" placements ")")
                        CheckAbility()
                        FixClick(560, 560) ; Move Click
                        AttemptUpgrade()
                        break
                    }

                    if (ModeDropdown.Text = "Fool's Hunt") {
                        CheckForFoolBuffs()
                    }

                    AttemptUpgrade()

                    if CheckForXp() || CheckForReturnToLobby() || CheckForNextText() {
                        AddToLog("Stage ended during placements, proceeding to results")
                        return NextStep(MonitorStage)
                    }

                    if CheckForLobbyText() {
                        return NextStep(CheckLobby)
                    }

                    Reconnect()
                    CheckEndAndRoute()
                    StageGuard.Check("Stage", "stage took too long")   ; [Framework]
                }
                Sleep(500)
                StageGuard.Check("Stage", "stage took too long")   ; [Framework] also covers the case where every point is already used
            }
            CheckForCardSelection()
            CheckForMahoraga()
            CheckForMahoragaAdaptation()
        }
    }
    
    AddToLog("All units placed to requested amounts")
    UpgradeUnits()
}


PlaceFoolUnits() {
    placementPoints := CP_WithCustomSpots(PlacementPatternDropdown.Text = "3x3 Grid" ? GenerateMoreGridPoints(3) : PlacementPatternDropdown.Text = "Circle" ? GenerateCirclePoints() : PlacementPatternDropdown.Text = "Grid" ? GenerateGridPoints() : PlacementPatternDropdown.Text = "Spiral(WIP)" ? GenerateSpiralGridPoints() : PlacementPatternDropdown.Text = "Up and Down" ? GenerateUpandDownPoints() : GenerateRandomPoints())   ; [Custom placement] your spots first when ON
    
    ; Collect enabled slots
    enabledSlots := []
    for slotNum in [1, 2, 3, 4, 5, 6] {
        enabled := GetNameForMode() "Enabled" slotNum
        enabled := %enabled%
        enabled := enabled.Value
        if (enabled) {
            enabledSlots.Push(slotNum)
        }
    }

    if (enabledSlots.Length = 0) {
        if (debugMessages) {
            AddToLog("No units enabled - exiting")
        }
        return
    }

    ; Loop through placement points and assign them to enabled slots in order
    pointIndex := 1
    while true {
        for slotIndex, slotNum in enabledSlots {
            point := placementPoints[pointIndex]
            if PlaceUnit(point.x, point.y, slotNum) {
                successfulCoordinates.Push({x: point.x, y: point.y, slot: slotNum})
                CheckAbility()
                FixClick(560, 560) ; Move Click
            }

            if (ModeDropdown.Text = "Fool's Hunt") {
                CheckForFoolBuffs()
            }

            AttemptUpgrade()

            if CheckForXp() || CheckForReturnToLobby() || CheckForNextText() {
                AddToLog("Stage ended during placements, proceeding to results")
                return NextStep(MonitorStage)
            }

            if CheckForLobbyText() {
                return NextStep(CheckLobby)
            }

            Reconnect()
            CheckEndAndRoute()
            StageGuard.Check("Stage", "stage took too long")   ; [Framework]

            Sleep(500) ; Prevent spamming

            ; Move to the next placement point, loop back if at the end
            pointIndex++
            if (pointIndex > placementPoints.Length) {
                pointIndex := 1
            }
        }
    }
}


PlaceUnit(x, y, slot := 1) {
    if (ModeDropdown.Text = "Winter Event") {
        CheckForCardSelection()
    }
    if (ModeDropdown.Text = "Fool's Hunt") {
        CheckForCardSelection()
    }

    Sleep 50
    SendInput(slot)
    Sleep 50
    FixClick(x, y)
    Sleep 50
    SendInput("q")
    
    if UnitPlaced() {
        Sleep 15
        return true
    }
    return false
}


CheckForElyssiaSummon() {
    if FT(&X, &Y, 14, 226, 138, 246, 0, 0, ElyssiaSummons) {
        AddToLog("Clicked on Elyssia Eel, ignoring...")
        return true
    }
}


UnitPlaced() {
    if (WaitForUpgradeText(PlacementSpeed())) { ; Wait up to 4.5 seconds for the upgrade text to appear
        AddToLog("Unit Placed Successfully")
        CheckAbility()
        FixClick(325, 185) ; Close upgrade menu
        return true
    }
    return false
}


WaitForUpgradeText(timeout := 4500) {
    sleep 100
    startTime := A_TickCount
        while (A_TickCount - startTime < timeout) {
             if (ok := FT(&X, &Y, 26, 300, 200, 475, 0, 0, AtkPrio)) or (ok := FT(&X, &Y, 26, 387, 192, 475, 0, 0, AtkPrio)) or (ok := FT(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)){
                if (CheckForElyssiaSummon()) {
                    return false
                }
                timeSaved := (A_TickCount - startTime)  ; Time saved
                if (debugMessages) {
                    AddToLog("Placement Speed: " . PlacementSpeed() . " ms")
                    AddToLog("Upgrade text found! Time saved: " . timeSaved . " ms")
                }
                return true
            }
            Sleep 50  ; Check every 100ms
        }
        if (debugMessages) {
            AddToLog("Timed out! No upgrade text found. Timeout was: " . timeout . " ms")
        }
        return false  ; Timed out, upgrade text was not found
    }



PlacementSpeed() {
    speeds := [1000, 1500, 2000, 2500, 3000, 4000, 5000, 600]  ; Array of sleep values
    speedIndex := PlaceSpeed.Value  ; Get the selected speed value

    if speedIndex is number  ; Ensure it's a number
        return speeds[speedIndex]  ; Use the value directly from the array
}

