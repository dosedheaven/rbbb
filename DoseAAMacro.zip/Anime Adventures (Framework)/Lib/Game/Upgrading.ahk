#Requires AutoHotkey v2.0

; ============================================================================
;  Upgrading.ahk  -  Unit upgrades and upgrade-level checks.
;  [Modularized] functions moved here unchanged from Lib\Functions.ahk, Lib\GameMango.ahk.
;  Loaded from Main.ahk. Contains function definitions only (no start-up code).
; ============================================================================


AttemptUpgrade() {
    global successfulCoordinates, maxedCoordinates, PriorityUpgrade, debugMessages, inChallengeMode

    if (successfulCoordinates.Length = 0) {
        return ; No units placed yet
    }

    anyToUpgrade := false
    for coord in successfulCoordinates {
        upgradeEnabled := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeEnabled" coord.slot : GetNameForMode() "upgradeEnabled" coord.slot
        upgradeEnabled := %upgradeEnabled%
        if (upgradeEnabled.Value) {
            anyToUpgrade := true
            break
        }
    }
    if (!anyToUpgrade)
        return

    static lastUpgradeLog := 0
    if (A_TickCount - lastUpgradeLog > 30000) {   ; log at most once every 30 seconds
        AddToLog("Attempting to upgrade placed units...")
        lastUpgradeLog := A_TickCount
    }

    if (PriorityUpgrade.Value) {
        if (debugMessages) {
            AddToLog("Using priority-based upgrading")
        }

        ; Loop through priority levels (1-6) and upgrade all matching units
        for priorityNum in [1, 2, 3, 4, 5, 6] {
            upgradedThisRound := false

            for index, coord in successfulCoordinates { 
                ; Check if upgrading is enabled for this unit's slot
                upgradeEnabled := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeEnabled" coord.slot : GetNameForMode() "upgradeEnabled" coord.slot
                upgradeEnabled := %upgradeEnabled%

                if (!upgradeEnabled.Value) {
                    if (debugMessages) {
                        AddToLog("Skipping Unit " coord.slot " - Upgrading Disabled")
                    }
                    continue
                }

                ; Get the priority value for this unit's slot
                priority := inChallengeMode && ChallengeBox.Value ? "challengepriority" coord.slot : GetNameForMode() "priority" coord.slot
                priority := %priority%

                upgradeLimitEnabled := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeLimitEnabled" coord.slot : GetNameForMode() "upgradeLimitEnabled" coord.slot
                upgradeLimitEnabled := %upgradeLimitEnabled%

                upgradeLimit := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeLimit" coord.slot : GetNameForMode() "upgradeLimit" coord.slot
                upgradeLimit := %upgradeLimit%
                upgradeLimit := String(upgradeLimit.Text)

                
                if (priority.Text = priorityNum) {
                    if (debugMessages) {
                        AddToLog("Upgrading Unit " coord.slot " at (" coord.x ", " coord.y ")")
                    }

                    if (!upgradeLimitEnabled.Value) {
                        UpgradeUnit(coord.x, coord.y)
                    } else {
                        UpgradeUnitLimit(coord.x, coord.y, coord, index, upgradeLimit)
                    }

                    if CheckForXp() || CheckForReturnToLobby() || CheckForNextText() {
                        AddToLog("Stage ended during upgrades, proceeding to results")
                        successfulCoordinates := []
                        maxedCoordinates := []
                        return NextStep(MonitorStage)
                    }

                    if CheckForLobbyText() {
                        return NextStep(CheckLobby)
                    }

                    if MaxUpgrade() {
                        AddToLog("Max upgrade reached for Unit " coord.slot)
                        successfulCoordinates.RemoveAt(index)
                        maxedCoordinates.Push(coord)
                        FixClick(325, 185) ; Close upgrade menu
                        continue
                    }

                    Sleep(200)
                    CheckAbility()
                    FixClick(560, 560) ; Move Click
                    CheckForCardSelection()
                    Reconnect()
                    CheckEndAndRoute()

                    upgradedThisRound := true
                }
            }

            if upgradedThisRound {
                Sleep(300) ; Add a slight delay between batches
            }
        }
    } else {
        ; Normal (non-priority) upgrading - upgrade all available units
        for index, coord in successfulCoordinates {
            ; Check if upgrading is enabled for this unit's slot
            upgradeEnabled := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeEnabled" coord.slot : GetNameForMode() "upgradeEnabled" coord.slot
            upgradeEnabled := %upgradeEnabled%

            upgradeLimitEnabled := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeLimitEnabled" coord.slot : GetNameForMode() "upgradeLimitEnabled" coord.slot
            upgradeLimitEnabled := %upgradeLimitEnabled%

            upgradeLimit := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeLimit" coord.slot : GetNameForMode() "upgradeLimit" coord.slot
            upgradeLimit := %upgradeLimit%
            upgradeLimit := String(upgradeLimit.Text)

            if (!upgradeEnabled.Value) {
                if (debugMessages) {
                    AddToLog("Skipping Unit " coord.slot " - Upgrading Disabled")
                }
                continue
            }

            if (debugMessages) {
                AddToLog("Upgrading Unit " coord.slot " at (" coord.x ", " coord.y ")")
            }

            if (!upgradeLimitEnabled.Value) {
                UpgradeUnit(coord.x, coord.y)
            } else {
                UpgradeUnitLimit(coord.x, coord.y, coord, index, upgradeLimit)
            }

            if CheckForXp() || CheckForReturnToLobby() || CheckForNextText() {
                AddToLog("Stage ended during upgrades, proceeding to results")
                successfulCoordinates := []
                maxedCoordinates := []
                return NextStep(MonitorStage)
            }

            if CheckForLobbyText() {
                return NextStep(CheckLobby)
            }

            if MaxUpgrade() {
                AddToLog("Max upgrade reached for Unit " coord.slot)
                successfulCoordinates.RemoveAt(index)
                maxedCoordinates.Push(coord)
                FixClick(325, 185) ; Close upgrade menu
                continue
            }

            Sleep(200)
            CheckAbility()
            FixClick(560, 560) ; Move Click
            CheckForCardSelection()
            Reconnect()
            CheckEndAndRoute()
        }
    }
    if (debugMessages) {
        AddToLog("Upgrade attempt completed")
    }
}


SetUnitAsMaxed(coord, index) {
    global successfulCoordinates, maxedCoordinates
    AddToLog("Max upgrade reached for Unit " coord.slot)
    successfulCoordinates.RemoveAt(index)
    maxedCoordinates.Push(coord)
    FixClick(325, 185) ; Close upgrade menu
}



UpgradeUnits() {
    global successfulCoordinates, maxedCoordinates, PriorityUpgrade, inChallengeMode

    local totalUnits := Map()  ; Initialize as a local variable
    local upgradedCount := Map()  ; Initialize as a local variable

    ; Initialize counters
    for coord in successfulCoordinates {
        totalUnits[coord.slot] := (totalUnits.Has(coord.slot) ? totalUnits[coord.slot] + 1 : 1)
        upgradedCount[coord.slot] := upgradedCount.Has(coord.slot) ? upgradedCount[coord.slot] : 0
    }

    AddToLog("Initiating Unit Upgrades...")

    if (PriorityUpgrade.Value) {
        AddToLog("Using priority upgrade system")
        ; Go through each priority level (1-6)
        for priorityNum in [1, 2, 3, 4, 5, 6] {
            for slot in [1, 2, 3, 4, 5, 6] {
                priority := inChallengeMode && ChallengeBox.Value ? "challengepriority" slot : GetNameForMode() "priority" slot
                priority := %priority%

                if (priority.Text = priorityNum && HasUnitsInSlot(slot, successfulCoordinates)) {
                    AddToLog("Starting upgrades for priority " priorityNum " (slot " slot ")")
                    UpgradeSlot(slot, priorityNum, totalUnits, upgradedCount)
                }
            }
        }
        AddToLog("Priority upgrading completed")
    } else {
        ; Normal upgrade (no priority)
        while (successfulCoordinates.Length > 0) {
            UpgradeAllUnits(totalUnits, upgradedCount)
        }
        AddToLog("All units maxed, proceeding to monitor stage")
    }

    return NextStep(MonitorStage)
}


HasUnitsInSlot(slot, coordinates) {
    for coord in coordinates {
        if (coord.slot = slot) {
            return true
        }
    }
    return false
}


UpgradeSlot(slot, priorityNum, totalUnits, upgradedCount) {
    while (true) {
        slotDone := true

        for index, coord in successfulCoordinates {
            if (coord.slot = slot) {
                slotDone := false

                ; If upgradeOneAtATime is true, only upgrade one unit
                if (MaxUpgradeBeforeMoving.Value) {
                    UpgradeUnitWithLimit(coord, index)

                    CheckForTerminationConditions()

                    if (MaxUpgrade()) {
                        HandleMaxUpgrade(coord, index, totalUnits, upgradedCount)
                        break
                    }

                    Sleep(200)
                    PostUpgradeChecks()

                    ; After upgrading one unit, exit the loop to prevent further upgrades
                    break
                } else {
                    ; Perform the upgrade as usual for multiple units
                    UpgradeUnitWithLimit(coord, index)

                    CheckForTerminationConditions()

                    if (MaxUpgrade()) {
                        HandleMaxUpgrade(coord, index, totalUnits, upgradedCount)
                        break
                    }

                    Sleep(200)
                    PostUpgradeChecks()
                }
            }
        }

        if (slotDone || successfulCoordinates.Length = 0) {
            AddToLog("Finished upgrades for priority " priorityNum)
            break
        }
    }
}


UpgradeAllUnits(totalUnits, upgradedCount) {
    for index, coord in successfulCoordinates {
        UpgradeUnitWithLimit(coord, index)

        Reconnect()

        CheckForTerminationConditions()

        if (MaxUpgrade()) {
            HandleMaxUpgrade(coord, index, totalUnits, upgradedCount)
            continue
        }

        Sleep(200)
        PostUpgradeChecks()
    }
}


UpgradeUnitWithLimit(coord, index) {
    global inChallengeMode
    upgradeLimitEnabled := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeLimitEnabled" coord.slot : GetNameForMode() "upgradeLimitEnabled" coord.slot
    upgradeLimitEnabled := %upgradeLimitEnabled%

    upgradeLimit := inChallengeMode && ChallengeBox.Value ? "challengeUpgradeLimit" coord.slot : GetNameForMode() "upgradeLimit" coord.slot
    upgradeLimit := %upgradeLimit%
    upgradeLimit := String(upgradeLimit.Text)

    if (!upgradeLimitEnabled.Value) {
        UpgradeUnit(coord.x, coord.y)
    } else {
        UpgradeUnitLimit(coord.x, coord.y, coord, index, upgradeLimit)
    }
}


CheckForTerminationConditions() {
    if (CheckForXp() || CheckForReturnToLobby() || CheckForNextText()) {
        AddToLog("Stage ended during upgrades, proceeding to results")
        successfulCoordinates := []
        maxedCoordinates := []
        return NextStep(MonitorStage)
    }
    Reconnect()
    if (CheckForLobbyText()) {
        return NextStep(CheckLobby)
    }
}


HandleMaxUpgrade(coord, index, totalUnits, upgradedCount) {
    upgradedCount[coord.slot]++
    AddToLog("Max upgrade reached for Unit " coord.slot " (" upgradedCount[coord.slot] "/" totalUnits[coord.slot] ")")
    successfulCoordinates.RemoveAt(index)
    FixClick(325, 185) ; Close upgrade menu
}


PostUpgradeChecks() {
    CheckAbility()
    FixClick(560, 560) ; Move Click
    CheckForCardSelection()
    Reconnect()
    CheckEndAndRoute()
    StageGuard.Check("Stage", "stage took too long")   ; [Framework]
    if (ModeDropdown.Text = "Fool's Hunt") {
        CheckForFoolBuffs()
    }
}


MaxUpgrade() {
    Sleep 500
    ; Check for max text
    if (ok := FT(&X, &Y, 225, 388, 278, 412 , 0, 0, MaxText) or (ok:=FT(&X, &Y, 255, 234, 299, 250, 0, 0, MaxTextNew))) {
        if (CheckForElyssiaSummon()) {
            return false
        }
        CheckAbility()
        return true
    }
    return false
}


MaxUpgraded(limit) {
    levelTexts := Map(
        1, Upgrade1,
        2, Upgrade2,
        3, Upgrade3,
        4, Upgrade4,
        5, Upgrade5,
        6, Upgrade6
    )

    if levelTexts.Has(limit) {
        level := levelTexts[limit]
        if (!level) {
            AddToLog("Error: Level " limit " is undefined or empty")
            return false
        }
        if (ok := FT(&X, &Y, 150, 200, 350, 450, 0, 0, level)) {
            return true
        }
        return false
    }
}


UpgradeUnit(x, y) {
    FixClick(x, y - 3)
    Sleep (500)
    SendInput("R")
    SendInput("R")
    SendInput("R")
}


UpgradeUnitLimit(x, y, coord, index, upgradeLimit) {
    FixClick(x, y - 3)
    Sleep (1000)
    if CheckUpgradeLimit(upgradeLimit + 1) {
        SetUnitAsMaxed(coord, index)
    } else {
        SendInput("R")
    }
}


ClickUnit(x, y) {
    FixClick(x, y - 3)
    Sleep (1000)
}


CheckForUpgrade(upgradeLimit) {
    if (!MaxUpgrade()) {
        return UpgradeDetect(170, 231, 118, 22, 400, 335, upgradeLimit) ? true : false
    }
    return false
}


CheckUpgradeLimit(upgradeCap) {
    Sleep 500

    ; Map the upgrade cap to the corresponding MaxText variable
    upgradeTexts := [
        Upgrade0, Upgrade1, Upgrade2, Upgrade3, Upgrade4,
        Upgrade5, Upgrade6, Upgrade7, Upgrade8, Upgrade9
    ]

    if (upgradeCap < 1 || upgradeCap > upgradeTexts.Length) {
    AddToLog("Invalid upgradeCap: " upgradeCap " - skipping upgrade check")
    return
    }

    ; Select the correct upgrade text based on the cap
    targetText := upgradeTexts[upgradeCap]

    ; Check for max text in the designated area
    if (ok := FT(&X, &Y, 170, 228, 312, 252, 0, 0, targetText) or (ok := FT(&X, &Y, 170, 228, 312, 252, 0, 0, targetText))) {
        return true
    }
    
    return false
}


UpgradeDetect(x, y, w, h, inputX, inputY, upgradeLimit) {
    detectionCount := 0
    AddToLog("Checking for upgrade level...")

    try {
        FT_GetOffset(&ocrDX, &ocrDY) ; [Window follow] OCR area follows Roblox
        result := OCR.FromRect(x + ocrDX, y + ocrDY, w, h, "FirstFromAvailableLanguages", { grayscale: true, scale: 4.0 })

        if result {
            rawText := result.Text
            if (debugMessages) {
                AddToLog("Raw OCR Upgrade Text: " rawText)
            }

            ; Clean text to isolate "Upgrade" + number
            cleanedText := RegExReplace(rawText, ".*Upgrade\D*(\d+).*", "$1") ; Capture only the number after "Upgrade"
            cleanedText := StrReplace(cleanedText, "O", "0") ; Fix OCR mistaking 0 as O

            ; Explicitly replace "O" with "0" to ensure OCR doesn't misinterpret them
            if (cleanedText = "O") {
                cleanedText := "0"
                AddToLog(cleanedText)
            }

            if (debugMessages) {
                AddToLog("Cleaned Upgrade Number: " cleanedText)
            }

            ; Check if the cleaned text is a valid number
            if (cleanedText != "" && RegExMatch(cleanedText, "^\d+$")) {
                detectionCount++
                    
                if (detectionCount >= 1) {
                    if (cleanedText >= upgradeLimit) {
                        AddToLog("Found Upgrade Level: " cleanedText)
                        return true
                    } else {
                        return false
                    }
                }
            }
        }
    }
    AddToLog("Could not detect valid upgrade level")
    return false
}

