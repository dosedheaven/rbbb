#Requires AutoHotkey v2.0

; [Scheduler team swap] Equips team 1-4 in the lobby (called by Sched_RunPendingTeamSwap).
TS_SwapTeam(teamNum) {
    teams := [
        [567, 232],   ; Team 1 - Load
        [567, 319],   ; Team 2 - Load
        [567, 406],   ; Team 3 - Load
        [567, 493],   ; Team 4 - Load
    ]
    if (teamNum < 1 || teamNum > teams.Length) {
        AddToLog("Team swap: there is no Team " teamNum)
        return false
    }
    AddToLog("Team swap: equipping Team " teamNum)
    SendInput("K") ; Open Units
    Sleep 2000
    FixClick(398, 223) ; Click Teams
    Sleep 1000
    FixClick(teams[teamNum][1], teams[teamNum][2]) ; Load team
    Sleep 2000
    SendInput("K") ; Close Units
    Sleep 1000
    return true
}
