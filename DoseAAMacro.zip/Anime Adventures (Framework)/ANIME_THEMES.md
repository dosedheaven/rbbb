# Anime themes — v2.3

Open Settings, find Anime Theme and choose Astral or Tokyo Ghoul. If the macro is idle, accept the existing restart prompt to apply it. If a run is active, the choice saves for the next restart; it does not reload the running macro.

Astral is the retained violet/cyan anime theme. Its original wallpaper is unchanged. Older Arcane selections load as Astral. Removed color-only themes safely load Astral until you choose another theme.

Tokyo Ghoul has charcoal/crimson cards, Kaneki artwork, a red eye motif, themed icons, and the OFL-licensed New Rocker font on decorative headings. Body labels and inputs keep their readable fonts. Artwork stays in the right macro panel and never covers the Roblox viewport.

Fonts and images are bundled for offline use. The app loads fonts privately for its own process, without installing system fonts. Missing artwork or the display font falls back to plain styling/readable text.

Keep your existing Settings folder when updating. This release changes only UI/theme presentation and version metadata; the v2.2 chest-opening repair and all gameplay logic are retained.
