# Akatsuki dashboard — v2.7

Akatsuki is the only active theme. The dashboard uses charcoal surfaces, crimson accents, ivory body text, rounded controls and angled outer corners. Your supplied artwork fills the right column with a complete group banner and an Itachi/Pain close-up. The Akatsuki heading uses the bundled New Rocker display font; controls use a readable interface font.

The dashboard is 1800x930 and is designed for the macro's recommended 1920x1080 display at 100% Windows scaling. Roblox's existing window size and viewing rectangle are retained. Navigation, two-column unit cards, profile/adaptation settings, run options and activity text have separate spaces.

Existing saved theme names fall back to Akatsuki without rewriting general configuration. All six placement profiles, settings files and existing control callbacks are retained. Fonts load privately for this process; no system font installation or web runtime is introduced. Missing artwork falls back to the plain themed surfaces.

Keep your existing Settings folder when updating. See DASHBOARD_REDESIGN.md for behavior and verification, and ARTWORK_SOURCES.md for the original image details.
