# Anime themes — v2.5

Open Settings > Anime Theme and choose Astral or Tokyo Ghoul. The existing restart behavior applies: idle changes offer a restart; choices made during a run save for the next restart.

Astral uses existing Juuzou Suzuya artwork with mint, ivory and dark teal. Tokyo Ghoul uses existing Ken Kaneki artwork with crimson, ivory and charcoal. Both include a framed portrait, matching corner accents and bundled icons. New Rocker is used only for Tokyo decorative headings; body labels and inputs use readable text fonts.

Original wallpaper files are bundled unchanged. The interface crops them proportionally and dims the background when rendering. Opaque cards protect text and controls. See ARTWORK_SOURCES.md for the exact public source links and hashes. Missing artwork falls back to plain styling; fonts load privately without a system installation.

The theme label now sits under the portrait, clear of Mode Select. The Activity heading and dividers have separate space. Older log lines use an ellipsis when needed; hover a line for its complete current text, or use Open log. All seven log values and the full log file are retained.

Only these two themes are offered. Older Arcane selections load Astral; removed color selections safely fall back to Astral. Keep your existing Settings folder when updating.
